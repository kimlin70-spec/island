// 아이패드 흉내: 엄격한 보안 규칙(아티팩트와 비슷)으로 띄운 복사본을 터치로 조작
const { chromium, devices } = require('playwright');
const DEV = [['iPad Pro 11 landscape', true], ['iPad Mini', false], ['iPad (gen 7) landscape', true]];
let fails = 0; const ok = (n, c, d = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + '  ' + d); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch();
  for (const [name] of DEV) {
    const ctx = await browser.newContext({ ...devices[name] });
    const page = await ctx.newPage();
    const errs = [];
    page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
    page.on('pageerror', (e) => errs.push(String(e)));
    page.on('requestfailed', (r) => errs.push('failed ' + r.url()));
    await page.addInitScript(() => document.addEventListener('securitypolicyviolation', (e) => (window.__csp = window.__csp || []).push(e.blockedURI + ' ' + e.violatedDirective)));
    await page.goto('http://127.0.0.1:8100/');
    await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 30000 });
    await page.waitForTimeout(800);
    const G = (fn, a) => page.evaluate(fn, a);
    const vp = page.viewportSize();
    const fit = await G(() => { const r = window.__game.canvas.getBoundingClientRect(); return { l: r.left, t: r.top, w: r.width, h: r.height, iw: innerWidth, ih: innerHeight, sx: scrollX, sy: scrollY, dw: document.documentElement.scrollWidth }; });
    ok(name + ': canvas fits the screen, no page scroll', fit.l >= -0.5 && fit.t >= -0.5 && fit.l + fit.w <= fit.iw + 0.5 && fit.t + fit.h <= fit.ih + 0.5 && (Math.abs(fit.w - fit.iw) < 1 || Math.abs(fit.h - fit.ih) < 1) && fit.dw <= fit.iw, JSON.stringify(fit));
    const g2p = (x, y) => G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect(); return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
    const w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, cam = g.scene.getScene('game').cameras.main, r = g.canvas.getBoundingClientRect();
      const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2; return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height }; }, [wx, wy]);
    const tap = async (p) => { await page.touchscreen.tap(p.x, p.y); await page.waitForTimeout(300); };
    // 1) 땅을 눌러 걷기
    const before = await G(() => { const p = window.__game.scene.getScene('game').player; return { c: p.tile.col, r: p.tile.row }; });
    let target = null;
    for (const [dc, dr] of [[2, 0], [0, 2], [-2, 0], [0, -2], [2, 2], [-2, -2]]) {
      const c = before.c + dc, r = before.r + dr;
      if (await G(([c, r]) => window.__game.scene.getScene('game').map.isWalkable(c, r), [c, r])) { target = { c, r }; break; }
    }
    await tap(await w2p((target.c - target.r) * 40, (target.c + target.r) * 20));
    await page.waitForTimeout(2500);
    const after = await G(() => { const p = window.__game.scene.getScene('game').player; return { c: p.tile.col, r: p.tile.row }; });
    ok(name + ': tapping the ground walks there', after.c === target.c && after.r === target.r, JSON.stringify({ before, target, after }));
    // 2) 나무를 눌러 베기 시작
    const tree = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
      const t = s.map.objects.filter((o) => o.node && o.node.group === 'tree').sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0];
      const sp = t.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.4, hp: t.node.hp, col: t.col, row: t.row }; });
    await tap(await w2p(tree.wx, tree.wy));
    await page.waitForTimeout(6000);
    const tr = await G((t) => { const s = window.__game.scene.getScene('game'); const o = s.map.objects.find((o) => o.col === t.col && o.row === t.row);
      return { hp: o && o.node ? o.node.hp : null, wood: s.inventory.count('wood'), kind: o && o.kind }; }, tree);
    ok(name + ': tapping a tree cuts it', tr.hp === null || tr.hp < tree.hp || tr.wood > 0, JSON.stringify({ tree, tr }));
    // 3) 만들기 단추 -> 창이 열리고 닫힌다
    await tap(await g2p(1824, 1104));
    const open1 = await G(() => { const u = window.__game.scene.getScene('ui'); return !!(u.craftWin && u.craftWin.visible); });
    await tap(await g2p(1824, 1104));
    const open2 = await G(() => { const u = window.__game.scene.getScene('ui'); return !!(u.craftWin && u.craftWin.visible); });
    ok(name + ': the craft button opens and closes the window by touch', open1 && !open2, JSON.stringify({ open1, open2 }));
    // 4) 2단계로 넘기고 만들기 창(두 줄)
    await G(() => { const s = window.__game.scene.getScene('game'); s.startStage2(); s.debugGive(); });
    await page.waitForTimeout(300);
    await tap(await g2p(1824, 1104));
    const st2 = await G(() => { const u = window.__game.scene.getScene('ui'); return { open: !!(u.craftWin && u.craftWin.visible), stage: window.__game.scene.getScene('game').stage }; });
    ok(name + ': stage 2 two-row craft window opens by touch', st2.open && st2.stage === 2, JSON.stringify(st2));
    if (name === 'iPad Pro 11 landscape' || name === 'iPad Mini') await page.screenshot({ path: __dirname + '/' + name.replace(/\W+/g, '_') + '.png' });
    await tap(await g2p(1824, 1104));
    // 5) 두 손가락 확대·끌기로 화면이 움직이지 않는다
    const sc = await G(() => ({ x: scrollX, y: scrollY, z: visualViewport ? visualViewport.scale : 1 }));
    ok(name + ': page did not zoom or scroll', sc.x === 0 && sc.y === 0 && sc.z === 1, JSON.stringify(sc));
    const csp = await G(() => window.__csp || []);
    ok(name + ': no blocked loads', csp.length === 0, JSON.stringify(csp));
    ok(name + ': no console errors', errs.length === 0, JSON.stringify(errs));
    await ctx.close();
  }
  await browser.close();
  console.log(fails ? fails + ' FAILED' : 'ALL PASS');
})().catch((e) => { console.log('CRASH', e); process.exit(1); });
