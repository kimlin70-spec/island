const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 } });
  page.on('pageerror', (e) => console.log('pageerror', e.message, e.stack));
  await page.route('**/src/config.js', async (route) => {
    let body = fs.readFileSync('/home/user/island/src/config.js', 'utf8');
    body = body.replace('width: 2048, height: 1536, dayZoom: 1.6, nightZoom: 1.0', 'width: 1024, height: 768, dayZoom: 0.8, nightZoom: 0.5');
    route.fulfill({ body, contentType: 'application/javascript' });
  });
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').cards);
  await page.evaluate(() => { const g = window.__game.scene.getScene('game'); g.debugToggleSpeed(); window.__z = g.zombies.spawn(); g.player.teleport(30, 22); });
  for (let i = 0; i < 14; i++) {
    await page.waitForTimeout(1500);
    console.log(await page.evaluate(() => { const g = window.__game.scene.getScene('game'), z = window.__z; return JSON.stringify([z.alive, z.tile, z.next, z.hp, g.zombies.isGoal(z.tile.col, z.tile.row), g.house.hp, g.player.tile, !!g.player.action, g.clock.label]); }));
  }
  await browser.close();
})();
