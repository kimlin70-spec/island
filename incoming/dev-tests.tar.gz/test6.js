const { chromium } = require('playwright');
const fs = require('fs');
const out = __dirname + '/';
const LOW = process.argv[2] !== 'full';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  if (LOW) await page.route('**/src/config.js', async (route) => {
    let body = fs.readFileSync('/home/user/island/src/config.js', 'utf8');
    body = body.replace('width: 2048, height: 1536, dayZoom: 1.6, nightZoom: 1.0', 'width: 1024, height: 768, dayZoom: 0.8, nightZoom: 0.5');
    route.fulfill({ body, contentType: 'application/javascript' });
  });
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').cards);
  const G = (fn, arg) => page.evaluate(fn, arg);
  const inv = () => G(() => ({ ...window.__game.scene.getScene('game').inventory.items }));
  // UI 좌표(2048 기준) -> 화면
  const ui = (x, y) => ({ x: x / 2, y: y / 2 });
  const tileScreen = (col, row) => G(([c, r]) => {
    const g = window.__game.scene.getScene('game'); const cam = g.cameras.main;
    const ds = window.__game.scale.displayScale; const b = window.__game.canvas.getBoundingClientRect();
    return { x: b.left + ((c - r) * 64 - cam.worldView.x) * cam.zoom / ds.x, y: b.top + ((c + r) * 32 - cam.worldView.y) * cam.zoom / ds.y };
  }, [col, row]);
  const tapTile = async (c, r) => { const s = await tileScreen(c, r); await page.mouse.click(s.x, s.y); await page.waitForTimeout(150); };
  const structs = () => G(() => window.__game.scene.getScene('game').mapSystem.structures.map(s => [s.type, s.col, s.row]));
  await page.waitForTimeout(1000);

  // 망치 -> 메뉴 (재료 없음: 카드 흐림)
  const hammer = ui(2048 - 26 - 104, 1536 - 26 - 104);
  await page.mouse.click(hammer.x, hammer.y);
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + 'p6_menu_dim.png' });
  const cardY = (i) => (1536 - 26 - 104) - 104 - 20 - 3 * 190 + 14 + i * 190 + 88;
  const card = (i) => ui(2048 - 26 - 235, cardY(i));
  await page.mouse.click(card(0).x, card(0).y);
  console.log('mode with no wood (expect null):', await G(() => window.__game.scene.getScene('game').build.mode));
  await G(() => { const g = window.__game.scene.getScene('game'); g.inventory.add('wood', 20); g.inventory.add('stone', 8); });
  await page.mouse.click(card(0).x, card(0).y);
  console.log('mode (expect fence):', await G(() => window.__game.scene.getScene('game').build.mode), 'player moving', await G(() => window.__game.scene.getScene('game').player.moving));
  // 울타리 짓기
  await tapTile(27, 29); await tapTile(26, 29); await tapTile(25, 29);
  console.log('fences', await structs(), await inv());
  // 지을 수 없는 곳: 같은 칸, 집, 문 앞, 주인공 칸, 물/안개
  await tapTile(27, 29); await tapTile(25, 25); await tapTile(26, 27); await tapTile(26, 20); await tapTile(30, 31);
  // 사물 위
  const objTile = await G(() => { const o = window.__game.scene.getScene('game').mapSystem.objects.find(o => o.sprite.visible && o.type !== 'house'); return [o.col, o.row]; });
  await tapTile(objTile[0], objTile[1]);
  console.log('after invalid taps (expect same 3)', (await structs()).length, await inv());
  // 누르고 있는 동안 표시
  let s = await tileScreen(objTile[0], objTile[1]);
  await page.mouse.move(s.x, s.y); await page.mouse.down(); await page.waitForTimeout(200);
  console.log('mark on object:', await G(() => { const b = window.__game.scene.getScene('game').build; return [b.mark.visible, b.mark.texture.key]; }));
  s = await tileScreen(24, 28);
  await page.mouse.move(s.x, s.y, { steps: 3 }); await page.waitForTimeout(200);
  console.log('mark on free tile:', await G(() => { const b = window.__game.scene.getScene('game').build; return [b.mark.visible, b.mark.texture.key]; }));
  await page.screenshot({ path: out + 'p6_mark.png' });
  s = await tileScreen(objTile[0], objTile[1]);
  await page.mouse.move(s.x, s.y, { steps: 3 }); await page.mouse.up(); await page.waitForTimeout(200);
  console.log('released on object (expect 3)', (await structs()).length);
  // 탑
  await page.mouse.click(card(1).x, card(1).y);
  await tapTile(28, 28);
  console.log('tower', await structs(), await inv());
  await page.screenshot({ path: out + 'p6_built.png' });
  // 치우기
  await page.mouse.click(card(2).x, card(2).y);
  await tapTile(27, 29); await tapTile(28, 28);
  console.log('after remove (fence +1 wood, tower +1 wood +2 stone)', await structs(), await inv());
  // 망치 다시 -> 짓기 끝, 울타리 통과
  await page.mouse.click(hammer.x, hammer.y);
  await page.waitForTimeout(200);
  console.log('mode after close', await G(() => window.__game.scene.getScene('game').build.mode), await G(() => window.__game.scene.getScene('ui').buildMenu.visible));
  await G(() => {
    const g = window.__game.scene.getScene('game');
    // 문 앞을 울타리로 완전히 둘러싼다
    g.inventory.add('wood', 40);
    for (const [c, r] of [[25, 28], [26, 28], [27, 28], [27, 27], [27, 26], [24, 27], [24, 28]]) if (g.build.canBuildAt(c, r)) g.build.place('fence', c, r);
  });
  await tapTile(26, 30);
  await page.waitForFunction(() => !window.__game.scene.getScene('game').player.moving, null, { timeout: 30000 });
  console.log('walked through fence to', await G(() => window.__game.scene.getScene('game').player.tile));
  // 탑은 통과 못 함
  console.log('tower blocks:', await G(() => { const g = window.__game.scene.getScene('game'); g.inventory.add('stone', 10); g.build.place('stoneTower', 26, 31); return [g.mapSystem.isWalkable(26, 31), g.mapSystem.isWalkable(26, 29)]; }));
  await page.waitForTimeout(500);
  await page.screenshot({ path: out + 'p6_final.png' });
  console.log('errors', errors);
  await browser.close();
})();
