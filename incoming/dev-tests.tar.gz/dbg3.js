const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 } });
  page.on('pageerror', (e) => console.log('pageerror', e.message, e.stack));
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').cards);
  await page.waitForTimeout(1500);
  console.log(JSON.stringify(await page.evaluate(() => {
    const g = window.__game.scene.getScene('game'), zs = g.zombies, m = g.mapSystem;
    const out = {};
    for (const z of g.mapData.zones) out[z.key] = z.spawns.map(s => [s.col, s.row, zs.dist[s.row * m.cols + s.col], zs.passable(s.col, s.row), m.terrainName(s.col, s.row), !!m.objectAt(s.col, s.row)]);
    // 34,17 둘레
    const around = [];
    for (let r = 15; r <= 19; r++) { let line = ''; for (let c = 32; c <= 36; c++) line += !m.isLand(c, r) ? '~' : m.isSolid(c, r) ? '#' : (isFinite(zs.dist[r * m.cols + c]) ? '.' : '?'); around.push(line); }
    let unreachable = 0, land = 0;
    for (let r = 0; r < 40; r++) for (let c = 0; c < 40; c++) if (zs.passable(c, r)) { land++; if (!isFinite(zs.dist[r * 40 + c])) unreachable++; }
    return { out, around, unreachable, land, age: zs.fieldAge, dirty: zs.fieldDirty };
  })));
  await browser.close();
})();
