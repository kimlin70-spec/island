const { chromium } = require('playwright');
const fs = require('fs');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  await page.route('**/src/config.js', async (route) => {
    let body = fs.readFileSync('/home/user/island/src/config.js', 'utf8');
    body = body.replace('width: 2048, height: 1536, dayZoom: 1.6, nightZoom: 1.0', 'width: 1024, height: 768, dayZoom: 0.8, nightZoom: 0.5');
    route.fulfill({ body, contentType: 'application/javascript' });
  });
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').cards);
  const G = (fn, arg) => page.evaluate(fn, arg);
  const W = (fn, t = 120000) => page.waitForFunction(fn, null, { timeout: t });
  await page.waitForTimeout(800);
  await page.screenshot({ path: out + 'p7_day.png' });
  console.log('errors@start', errors);

  await G(() => { const g = window.__game.scene.getScene('game'); g.debugRevealAll(); g.debugToggleSpeed(); });
  // --- 3) 집이 부서지면 아침 ---
  await G(() => {
    const g = window.__game.scene.getScene('game');
    for (const s of [...g.mapSystem.structures]) g.build.destroy(s);
    g.inventory.items.wood = 10; g.inventory.items.stone = 9;
    g.player.teleport(30, 22);
    g.debugNight(); g.house.hp = 1;
  });
  for (let i = 0; i < 12; i++) { await page.waitForTimeout(3000); console.log(JSON.stringify(await G(() => { const g = window.__game.scene.getScene('game'); return [g.clock.label, g.clock.t.toFixed(1), g.house.hp, g.zombies.list.map(z => [z.tile.col, z.tile.row, z.next && [z.next.col, z.next.row], z.hitTimer.toFixed(1)]), g.zombies.toSpawn.length, window.__game.loop.actualFps.toFixed(0)]; })), errors); if (await G(() => !window.__game.scene.getScene('game').clock.isNight)) break; }
  console.log('house destroyed ->', await G(() => { const g = window.__game.scene.getScene('game'); return { label: g.clock.label, house: g.house.hp, inv: g.inventory.items.wood + '/' + g.inventory.items.stone, n: g.zombies.list.length }; }));
  await page.waitForTimeout(700);
  await page.screenshot({ path: out + 'p7_destroyed.png' });

  // --- 4) 좀비가 주인공을 때린다 ---
  await G(() => {
    const g = window.__game.scene.getScene('game');
    g.vitals.hearts = 5; g.vitals.changed();
    window.__z = g.zombies.spawn();
    g.player.teleport(30, 22);
  });
  await W(() => { const g = window.__game.scene.getScene('game'); return g.zombies.isGoal(window.__z.tile.col, window.__z.tile.row) && !window.__z.next; }, 120000);
  await G(() => {
    const g = window.__game.scene.getScene('game'); const z = window.__z;
    const n = g.player.neighborsOf([z.tile])[0];
    g.player.teleport(n.col, n.row);
    g.player.cooldown = 1e9;   // 자동 공격을 막아 두고 맞는지만 본다
  });
  await W(() => window.__game.scene.getScene('game').vitals.hearts < 5, 60000);
  console.log('player hurt, hearts', await G(() => window.__game.scene.getScene('game').vitals.hearts));
  await G(() => { window.__game.scene.getScene('game').player.cooldown = 0; });
  await W(() => !window.__z.alive, 60000);
  console.log('auto attack killed zombie');

  // --- 5) 시간이 저절로 흐른다 + 재료 되살아남 ---
  await G(() => {
    const g = window.__game.scene.getScene('game');
    const o = g.nodes.nodes.find(n => n.node.kind === 'bush'); g.nodes.deplete(o); window.__bush = o;
    g.clock.t = 149;
  });
  await W(() => window.__game.scene.getScene('game').clock.evening, 60000);
  await page.waitForTimeout(800);
  await page.screenshot({ path: out + 'p7_evening.png' });
  await G(() => { window.__game.scene.getScene('game').clock.t = 179; });
  await W(() => window.__game.scene.getScene('game').clock.isNight, 60000);
  await G(() => { window.__game.scene.getScene('game').clock.t = 119; });
  await W(() => !window.__game.scene.getScene('game').clock.isNight, 60000);
  console.log('auto cycle ok; bush regrown:', await G(() => !window.__bush.node.depleted), await G(() => window.__game.scene.getScene('game').clock.label));
  console.log('errors', errors);
  await browser.close();
})();
