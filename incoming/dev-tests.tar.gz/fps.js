const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 } });
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui'));
  await page.waitForTimeout(5000);
  console.log('fps with fog', await page.evaluate(() => [window.__game.loop.actualFps, window.__game.renderer.type]));
  await page.evaluate(() => window.__game.scene.getScene('game').debugRevealAll());
  await page.waitForTimeout(5000);
  console.log('fps no fog', await page.evaluate(() => window.__game.loop.actualFps));
  await browser.close();
})();
