// play-1 verification with a natural layout and natural (random) spawn points:
// tent (39,37)-(40,38), a fence ring two tiles out (cols 37..42, rows 35..40) with one opening at (39,35)
// (the player cannot pass fences, so a pen needs an opening). Player rests in the tent. Real clicks for everything.
// Then: two test zombies (real clicks on 좀비 1마리 부르기), 60 Hz steps. Where do they stand?
const { setup, J } = require('./vlib.js');
const mode = process.argv[2] || 'test';   // test | night
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await T.sleep(); await T.run(2);
  await T.testItem(0); await T.testItem(0);
  await T.tapTileW(38, 38, 0);
  await T.until('const p = s.player; return !p.moving && p.tile.col === 38 && p.tile.row === 38;', 600);
  await T.card(4); await T.run(2); await T.tapWorld((39.5 - 37.5) * 40, (39.5 + 37.5) * 20, 100); await T.run(2);
  await T.card(2); await T.run(2);
  const ring = [];
  for (let c = 37; c <= 42; c++) { ring.push([c, 35]); ring.push([c, 40]); }
  for (let r = 36; r <= 39; r++) { ring.push([37, r]); ring.push([42, r]); }
  const OPEN = [40, 35];
  for (const [c, r] of ring) if (!(c === OPEN[0] && r === OPEN[1])) { await T.tapTileW(c, r, 50); await T.run(1); }
  await T.closeCraft(); await T.run(2);
  const tent = await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return t && { wx: t.sprite.x, wy: t.sprite.y - 60, tiles: t.tiles }; });
  await T.tapWorld(tent.wx, tent.wy, 0);
  await T.until('return s.rest.resting;', 600);
  let st = await T.state();
  const ringState = await G((ring) => { const m = window.__game.scene.getScene('game').map; return ring.map(([c, r]) => c + ',' + r + ':' + (m.structureAt(c, r) ? 'F' : (m.isOpen(c, r) ? 'open' : 'blocked'))).filter((x) => !x.endsWith(':F')); }, ring);
  console.log('setup: t', st.t, 'tent', J(tent.tiles), 'fences', st.fences, 'ring tiles without a fence', J(ringState), 'player tile', J(st.ptile), 'resting', st.resting);
  await T.shot('p1_setup');
  // per-frame monitor: standing zombies sharing a tile
  await G(() => { const s = window.__game.scene.getScene('game'); const M = window.__M = { dup: [], spawns: [], hits: [] };
    const ids = new Map(); const id = (e) => { if (!ids.has(e)) ids.set(e, ids.size); return ids.get(e); };
    const os = s.enemies.spawn.bind(s.enemies); s.enemies.spawn = (k) => { const e = os(k); if (e) M.spawns.push([+s.elapsed.toFixed(2), id(e), e.col, e.row]); return e; };
    const oh = s.enemies.hitStructure.bind(s.enemies); s.enemies.hitStructure = (e, st) => { M.hits.push([+s.elapsed.toFixed(2), id(e), e.tile.col + ',' + e.tile.row, st.type, st.hp - 1]); return oh(e, st); };
    M.goals = [];   // [t, id, planned path end, tile] whenever a zombie's planned end changes
    const lastEnd = new Map();
    s.events.on('postupdate', () => { for (const e of s.enemies.list) { const end = e.path[e.path.length - 1]; const g = end ? end.col + ',' + end.row : 'stop';
        if (lastEnd.get(e) !== g) { lastEnd.set(e, g); M.goals.push([+s.elapsed.toFixed(2), id(e), g, e.tile.col + ',' + e.tile.row]); } } });
    s.events.on('postupdate', () => { const standing = s.enemies.list.filter((e) => !e.moving);
      const by = {}; for (const e of standing) { const k = e.tile.col + ',' + e.tile.row; (by[k] = by[k] || []).push(id(e)); }
      for (const k in by) if (by[k].length > 1) { const last = M.dup[M.dup.length - 1]; const tag = k + ':' + by[k].join('+');
        if (!last || last[1] !== tag) M.dup.push([+s.elapsed.toFixed(2), tag]); } }); });
  const fixed = process.argv[3] ? JSON.parse(process.argv[3]) : null;   // e.g. [[39,14],[29,10]]: natural map spawn points, in order
  if (fixed) await G((fixed) => { const s = window.__game.scene.getScene('game'); let i = 0; const orig = s.enemies.spawnPoint.bind(s.enemies);
    s.enemies.spawnPoint = () => { const f = fixed[i++]; if (!f) return orig(); const t = s.mapData.zombieSpawns.find((z) => z.col === f[0] && z.row === f[1]); return t || orig(); }; }, fixed);
  if (mode === 'test') {
    await T.testItem(3);   // zombie A (random natural spawn point)
    let r = await T.until('const e = s.enemies.list[0]; return e && e.smashing && e.smashing.type === "tent";', 60 * 90);
    st = await T.state();
    console.log('A smashing the tent:', J(r), 'A', J(st.z[0]));
    await T.testItem(3);   // zombie B
    r = await T.until('const e = s.enemies.list[1]; return e && !e.moving && e.smashing;', 60 * 90);
    await T.run(60);
    st = await T.state();
    console.log('B standing:', J(r), 'zombies', J(st.z.map((z) => [z.tile, z.mv, z.smash, z.end])));
    const z0 = st.z[0];
    await T.snapWorld('p1_stacked_zoom', (z0.tile[0] - z0.tile[1]) * 40, (z0.tile[0] + z0.tile[1]) * 20, 420, 320, 0, 2);
    await T.shot('p1_stacked_full');
    await T.run(60 * 6);
    const M = await G(() => window.__M);
    console.log('spawns [t, id, col, row]:', J(M.spawns));
    console.log('standing on the same tile [t, tile:ids]:', J(M.dup));
    console.log('planned path ends [t, id, end, tile]:', J(M.goals.filter((x) => x[1] === 1)));
    console.log('hits (t, zombie, zombie tile, structure, hp after):', J(M.hits));
  } else {
    await T.testItem(1);   // 밤으로 넘기기: 4 zombies over the first 90 s, random natural spawn points
    for (let k = 0; k < 10; k++) {
      await T.run(60 * 12);
      st = await T.state();
      console.log('t', st.t, 'resting', st.resting, 'hearts', st.hearts, 'zombies', J(st.z.map((z) => [z.tile, z.mv ? 'walk' : 'stand', z.smash])), J(st.structs));
      if (!st.resting) break;
    }
    const M = await G(() => window.__M);
    console.log('spawns [t, id, col, row]:', J(M.spawns));
    console.log('standing on the same tile [t, tile:ids]:', J(M.dup));
    console.log('planned path ends [t, id, end, tile] (last 4 per zombie):', J([0,1,2,3].map((i) => M.goals.filter((x) => x[1] === i).slice(-4))));
    console.log('tent hits:', J(M.hits.filter((h) => h[3] === 'tent')));
    await T.shot('p1_night');
  }
  console.log('bad', J(await T.bad()), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
