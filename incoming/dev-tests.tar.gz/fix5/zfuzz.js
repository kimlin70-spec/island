// Driver: node zfuzz.js <firstSeed> <count> <frames> <delta|random> [json opts]
const fs = require('fs');
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const src = fs.readFileSync(__dirname + '/zfuzz_page.js', 'utf8');
const first = +(process.argv[2] || 1), count = +(process.argv[3] || 1), frames = +(process.argv[4] || 20000);
const delta = process.argv[5] && process.argv[5] !== 'random' ? +process.argv[5] : undefined;
const opts = Object.assign({ delta }, process.argv[6] ? JSON.parse(process.argv[6]) : {});
const tag = process.argv[7] || '';

(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  const all = { stats: {}, fails: [], runs: [] };
  for (let seed = first; seed < first + count; seed++) {
    if (seed !== first) {
      await page.reload();
      await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
      await page.waitForTimeout(300);
    }
    await page.addScriptTag({ content: src });
    await G(([seed, o]) => window.__zf.init(seed, o), [seed, opts]);
    const t0 = Date.now();
    let r;
    for (let done = 0; done < frames; done += 1000) {
      r = await G((n) => window.__zf.run(n), Math.min(1000, frames - done));
    }
    const res = await G(() => ({ stats: window.__zf.stats, fails: window.__zf.fails, perKind: window.__zf.perKind }));
    for (const [k, v] of Object.entries(res.stats)) all.stats[k] = (all.stats[k] || 0) + v;
    all.fails.push(...res.fails);
    all.runs.push({ seed, r, perKind: res.perKind });
    console.log(`seed ${seed}: frames ${r.frame} day ${r.day} z ${r.z} kills ${r.kills} fails ${JSON.stringify(res.perKind)} (${((Date.now() - t0) / 1000).toFixed(1)}s)`);
  }
  const keys = Object.keys(all.stats).sort();
  const out = {}; for (const k of keys) out[k] = all.stats[k];
  console.log(JSON.stringify(out, null, 0));
  const name = __dirname + `/out/zf_${first}_${count}_${frames}_${delta || 'random'}${tag ? '_' + tag : ''}.json`;
  fs.mkdirSync(__dirname + '/out', { recursive: true });
  fs.writeFileSync(name, JSON.stringify(all, null, 1));
  console.log('wrote', name);
  console.log('page errors:', JSON.stringify(T.errors.slice(0, 10)));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
