// Replay one fuzz seed up to a frame and run an inspection snippet in the page.
// node replay.js <seed> <frame> <delta|random> '<json opts>' '<js expression using s, E, p, m, zf>'
const fs = require('fs');
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const src = fs.readFileSync(__dirname + '/zfuzz_page.js', 'utf8');
const seed = +process.argv[2], stop = +process.argv[3];
const delta = process.argv[4] && process.argv[4] !== 'random' ? +process.argv[4] : undefined;
const opts = Object.assign({ delta }, process.argv[5] ? JSON.parse(process.argv[5]) : {});
const expr = process.argv[6] || 'zf.snap()';
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await page.addScriptTag({ content: src });
  await G(([seed, o]) => window.__zf.init(seed, o), [seed, opts]);
  await G((stop) => { window.__zf.stopAtFrame = stop; }, stop);
  while (true) {
    const r = await G(() => window.__zf.run(1000));
    if (r.frame >= stop) break;
  }
  const out = await G((expr) => { const zf = window.__zf, g = window.__game, s = g.scene.getScene('game'), E = s.enemies, p = s.player, m = s.map;
    return eval(expr); }, expr);
  console.log(JSON.stringify(out, null, 1));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
