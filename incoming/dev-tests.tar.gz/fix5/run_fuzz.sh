#!/bin/bash
# 리뷰의 무작위 시험(좀비, 시설, 누르기, 텐트, 밤과 아침)을 고친 코드로 다시
cd "$(dirname "$0")"
f() { echo "== fuzz $*"; timeout 1800 node zfuzz.js "$@" 2>&1 | grep -E "^seed|page errors|CRASH|wrote" ; }
f 1 3 20000 random '{}' r
f 41 2 30000 16.7 '{}' f60
f 61 3 25000 150 '{"maxZ":14,"speed3":true,"pSpeed":0,"pTime":0.0008}' x3
f 71 2 30000 33.3 '{"maxZ":14}' f30
f 11 2 20000 100 '{"maxZ":20}' x1
echo DONE
