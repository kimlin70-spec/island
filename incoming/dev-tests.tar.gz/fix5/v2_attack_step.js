// Verify spec-2 deterministically: step the game scene by hand at exactly 60 fps (loop asleep, no rendering)
// and count, for every zombie hit, how many frames the zombie's sprite shows the 'attack' frame afterwards.
// Scenario: player fenced in by 8 fences, one zombie (debugZombie = the test button's function) comes and breaks one.
const { setup } = require('../p5/lib5.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  const res = await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player;
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row + dr }]);
    const fencesBefore = s.build.count('fence');
    g.loop.sleep();
    const DT = 1000 / 60;
    let t = 0;
    const log = [];
    const origHit = s.enemies.hitStructure.bind(s.enemies);
    s.enemies.hitStructure = (e, st) => { log.push({ ev: 'HIT', t: +s.elapsed.toFixed(4), type: st.type, hpAfter: st.hp - 1 }); return origHit(e, st); };
    const origHP = s.enemies.hitPlayer.bind(s.enemies);
    s.enemies.hitPlayer = (e) => { log.push({ ev: 'HITPLAYER', t: +s.elapsed.toFixed(4) }); return origHP(e); };
    s.debugZombie();
    const z = s.enemies.list[0];
    const names = window.__game.scene.getScene('game').map.assets[z.key].frames;
    const step = () => {
      t += DT; s.sys.step(t, DT);
      if (!z.alive) return;
      log.push({ ev: 'f', t: +s.elapsed.toFixed(4), frame: names[z.sprite.frame.name] || z.sprite.frame.name, anim: z.sprite.anims.isPlaying,
        moving: z.moving, smash: z.smashing ? z.smashing.type : null, attackLeft: +z.attackLeft.toFixed(3), at: [+z.col.toFixed(2), +z.row.toFixed(2)] });
    };
    let guard = 0;
    while (s.build.count('fence') === fencesBefore && guard++ < 60 * 180) step();
    for (let i = 0; i < 120; i++) step();
    g.loop.wake();
    return { fencesBefore, fencesAfter: s.build.count('fence'), spawnedAt: null, log };
  });
  const log = res.log;
  console.log('fences before/after:', res.fencesBefore, res.fencesAfter, ' frames logged:', log.filter((x) => x.ev === 'f').length);
  const rows = [];
  for (let i = 0; i < log.length; i++) {
    if (log[i].ev !== 'HIT' && log[i].ev !== 'HITPLAYER') continue;
    let n = 0, first = null, last = null;
    for (let j = i + 1; j < log.length; j++) {
      if (log[j].ev !== 'f') continue;
      if (log[j].frame === 'attack') { n++; if (first === null) first = log[j].t; last = log[j].t; } else break;
    }
    rows.push({ hit: log[i].ev === 'HIT' ? `${log[i].type} hp->${log[i].hpAfter}` : 'player', at: log[i].t, attackFrames60fps: n, attackShown_s: n ? +(last - log[i].t + 1 / 60).toFixed(3) : 0 });
  }
  console.table(rows);
  const bi = log.findIndex((x) => x.ev === 'HIT' && x.hpAfter === 0);
  console.log('frames around the breaking blow:');
  for (const x of log.slice(Math.max(0, bi - 2), bi + 8)) console.log(J(x));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
