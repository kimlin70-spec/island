// logic-2 check. Game loop asleep; GameScene stepped by hand with a fixed frame time (what a device at that fps gives).
// N zombies from debugZombie (what "좀비 1마리 부르기" calls), the speed button's debugToggleSpeed for x3,
// the player walks back and forth between two ground tiles 6 apart (walkTo = what a ground click calls).
// Per zombie: re-plans, longest time it wanted a re-plan and was due but got none, how far it moved.
// node v2_starve.js <N> <deltaMs> <speed 1|3> <seconds> [rotate]   (rotate: in-page patch that starts the update loop at a moving index)
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const N = +(process.argv[2] || 14), delta = +(process.argv[3] || 50), speed = +(process.argv[4] || 3), secs = +(process.argv[5] || 40), rotate = process.argv[6] === 'rotate';
(async () => {
  const T = await open({ w: 640, h: 400 });
  const { G } = T;
  const r = await G(([N, delta, speed, secs, rotate]) => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, E = s.enemies;
    let rs = 777; Math.random = () => { rs = (rs * 1103515245 + 12345) & 0x7fffffff; return rs / 0x80000000; };
    g.loop.sleep();
    if (speed === 3) s.debugToggleSpeed();
    s.hurtPlayer = () => {};                                   // keep the game running (hearts do not matter here)
    for (let i = 0; i < N; i++) { const e = E.spawn(); e.hp = e.maxHp = 999; }
    if (rotate) {   // fair share of the 3-per-frame budget: start the loop at a different zombie each frame
      let k = 0; E.update = function (dt) { this.repathBudget = 3; const L = [...this.list]; k = (k + 1) % Math.max(1, L.length);
        for (let i = 0; i < L.length; i++) { const e = L[(i + k) % L.length]; if (e.alive) e.update(dt); } };
    }
    const A = { col: p.tile.col, row: p.tile.row }, B = { col: p.tile.col - 6, row: p.tile.row };
    const st = E.list.map((e) => ({ e, start: [e.col, e.row], repaths: 0, wait: 0, maxWait: 0, moved: 0, lastPos: [e.col, e.row] }));
    const proto = Object.getPrototypeOf(E.list[0]), orig = proto.repath;
    proto.repath = function (t, k) { const x = st.find((q) => q.e === this); if (x) x.repaths++; return orig.call(this, t, k); };
    let time = 1000, gt = 0, goB = true, walks = 0;
    const dtFrame = Math.min(delta / 1000, 0.1) * s.debugSpeed;
    const frames = Math.round(secs / dtFrame);
    for (let f = 0; f < frames; f++) {
      if (!p.moving) { const t = goB ? B : A; s.walkTo(t.col, t.row); goB = !goB; walks++; }
      time += delta; s.sys.step(time, delta);
      gt += dtFrame;
      for (const x of st) {
        const e = x.e;
        if (e.wantPath && e.repathLeft <= 0) { x.wait += dtFrame; x.maxWait = Math.max(x.maxWait, x.wait); } else x.wait = 0;
        x.moved += Math.hypot(e.col - x.lastPos[0], e.row - x.lastPos[1]); x.lastPos = [e.col, e.row];
      }
    }
    return { frames, dtFrame: +dtFrame.toFixed(3), gameSeconds: +gt.toFixed(1), walks, playerTile: [p.tile.col, p.tile.row],
      z: st.map((x, i) => ({ i, repaths: x.repaths, maxWait: +x.maxWait.toFixed(1), moved: +x.moved.toFixed(1), dist: +Math.hypot(x.e.col - p.col, x.e.row - p.row).toFixed(1) })) };
  }, [N, delta, speed, secs, rotate]);
  const starved = r.z.filter((z) => z.repaths <= 1);
  console.log(`N=${N} frame ${delta}ms (${(1000 / delta).toFixed(0)} fps) speed x${speed}${rotate ? ' ROTATED ORDER' : ''}: ${r.frames} frames of ${r.dtFrame}s game time, ${r.gameSeconds}s, ${r.walks} walks`);
  console.log('  per zombie [index: re-plans / longest wait for a due re-plan (s) / tiles moved / distance to player now]:');
  console.log('  ' + r.z.map((z) => `#${z.i}:${z.repaths}/${z.maxWait}/${z.moved}/${z.dist}`).join('  '));
  console.log(`  zombies with <=1 re-plan in ${r.gameSeconds}s: ${starved.length ? starved.map((z) => '#' + z.i).join(' ') : 'none'}; longest wait overall ${Math.max(...r.z.map((z) => z.maxWait))}s`);
  console.log('  console:', JSON.stringify(T.errors.slice(0, 3)));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
