// logic-3 check. Real clicks: +20 materials, craft window, tent card, a click on the ground to build the tent,
// a click on the tent to go in, speed x3, "좀비 1마리 부르기" xN, speed x1, then the rest button to come out.
// Shortcuts (state only): the tent's hp is raised so it stays up while the zombies gather; hearts set to 1 just before
// coming out (as if hit 4 times; the tent heals while resting, so it is set at the last moment).
const { setup, UI } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
const NZ = +(process.argv[2] || 8), NEED = +(process.argv[3] || 3), HEARTS = +(process.argv[4] || 1);
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); window.__downs = []; window.__hits = []; window.__pauseCalls = 0;
    s.events.on('down', () => window.__downs.push(window.__game.loop.frame));
    const hp = s.hurtPlayer.bind(s); s.hurtPlayer = (n) => { window.__hits.push([window.__game.loop.frame, s.hearts.value]); return hp(n); };
    const sp = s.scene.pause.bind(s.scene); s.scene.pause = (...a) => { window.__pauseCalls++; return sp(...a); }; });
  await T.testItem(0);                                   // +20 wood, +20 stone
  await T.ui(...UI.craft); await T.ui(...UI.card(4));    // 만들기 -> 텐트 카드
  const c = 37, r = 40;   // tent south of the start tile, so the player goes in from (37,39), on the side the zombies come from
  await T.tapWorld((c - r) * 40, (c + r + 1) * 20, 300); // click on the ground: tent at (37..38, 40..41)
  await T.ui(...UI.craft);                               // close the craft window
  const tent = await G(() => { const s = window.__game.scene.getScene('game'); const t = s.map.structures.find((x) => x.type === 'tent');
    return t ? t.tiles.map((x) => x.col + ',' + x.row).join(' ') : null; });
  console.log('tent built by clicks at', tent);
  // click the tent picture (a point the game's pick rule gives to the tent)
  const pt = await G(() => { const s = window.__game.scene.getScene('game'), o = s.map.structures.find((x) => x.type === 'tent'), sp = o.sprite;
    const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY;
    for (let y = top + sp.displayHeight * 0.3; y < top + sp.displayHeight; y += 3) for (let x = left + sp.displayWidth * 0.3; x < left + sp.displayWidth * 0.7; x += 3)
      if (s.map.pickObject(x, y) === o && s.map.pickObject(x + 6, y + 6) === o && s.map.pickObject(x - 6, y - 6) === o) return { x, y };
    return null; });
  await T.tapWorld(pt.x, pt.y);
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
  console.log('resting in the tent; entry tile', JSON.stringify(await G(() => { const p = window.__game.scene.getScene('game').player; return [p.tile.col, p.tile.row]; })));
  await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); t.hp = t.maxHp = 9999; });
  for (let i = 0; i < NZ; i++) await T.testItem(3);      // 좀비 1마리 부르기 (speed x1: at x3 the 4x rest speed runs the day out)
  const dump = () => G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return { t: +s.elapsed.toFixed(1), label: s.clock.label, active: window.__game.scene.isActive('game'), z: s.enemies.list.map((e) => [+e.col.toFixed(1), +e.row.toFixed(1), e.moving, e.smashing ? e.smashing.type : null]) }; });
  const iv = setInterval(async () => { try { console.log('wait', JSON.stringify(await dump())); } catch (e) {} }, 20000);
  await W((need) => { const s = window.__game.scene.getScene('game'), p = s.player;
    return s.enemies.list.filter((e) => e.col === e.tile.col && e.row === e.tile.row && !e.moving &&
      Math.max(Math.abs(e.tile.col - p.tile.col), Math.abs(e.tile.row - p.tile.row)) <= 1).length >= need; }, NEED, 240000);
  clearInterval(iv);
  const before = await G((h) => { const s = window.__game.scene.getScene('game'), p = s.player;
    s.hearts.value = h; s.events.emit('hearts-changed');
    return { adjacentStanding: s.enemies.list.filter((e) => !e.moving && Math.max(Math.abs(e.tile.col - p.tile.col), Math.abs(e.tile.row - p.tile.row)) <= 1).map((e) => e.tile.col + ',' + e.tile.row),
      zombies: s.enemies.list.length, resting: s.rest.resting, hearts: s.hearts.value }; }, HEARTS);
  console.log('before coming out:', JSON.stringify(before));
  await T.ui(...UI.rest, 0);                             // "쉬는 중 · 누르면 나옵니다"
  await W(() => !window.__game.scene.isActive('game'), null, 30000);
  await page.waitForTimeout(1000);
  const res = await G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui');
    return { downEvents: window.__downs, hurtCalls: window.__hits, scenePauseCalls: window.__pauseCalls, hearts: s.hearts.value, defeated: s.enemies.defeated,
      modal: u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : null,
      modalsOnScreen: u.children.list.filter((o) => o.type === 'Container' && o.depth === 30).length }; });
  console.log('result', JSON.stringify(res));
  await page.screenshot({ path: __dirname + '/v3_down.png' });
  console.log('console:', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
