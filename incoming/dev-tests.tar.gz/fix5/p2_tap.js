// play-2 verification: the player stands on the start tile (37,39); a zombie (test tool, natural map spawn point) walks in;
// when it is d tiles away (straight line), a REAL mouse click on the zombie. 60 Hz steps (like a 60 fps device).
// Does the zombie end up standing on the player's own tile, and for how long?
// Usage: node p2_tap.js "<spawn list json or all>" "<distances json>"
const { setup, J } = require('./vlib.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await T.sleep(); await T.run(2);
  const spawns = process.argv[2] && process.argv[2] !== 'all' ? JSON.parse(process.argv[2]) : await G(() => window.__game.scene.getScene('game').mapData.zombieSpawns.map((t) => [t.col, t.row]));
  const dists = process.argv[3] ? JSON.parse(process.argv[3]) : [2.6, 2.2, 1.9];
  const shots = process.argv[4] === 'shots';
  await G(() => { const s = window.__game.scene.getScene('game');
    s.enemies.startNight = () => {};   // test scaffold: no nightly spawns during the sweep
    window.__next = null; const orig = s.enemies.spawnPoint.bind(s.enemies);
    s.enemies.spawnPoint = () => { const f = window.__next; window.__next = null; if (!f) return orig(); return s.mapData.zombieSpawns.find((z) => z.col === f[0] && z.row === f[1]); };
    window.__mon = null;
    s.events.on('postupdate', () => { const M = window.__mon; if (!M) return; const e = M.e, p = s.player; M.frames++;
      if (!e.alive) { if (M.died === null) M.died = +s.elapsed.toFixed(2); return; }
      const same = e.tile.col === p.tile.col && e.tile.row === p.tile.row;
      if (same && !e.moving) { M.onTile++; if (M.first === null) M.first = { t: +s.elapsed.toFixed(2), tile: [e.tile.col, e.tile.row], pmoving: p.moving }; }
      if (same && !e.moving && !p.moving) M.onTileBothStand++;
      const pk = p.tile.col + ',' + p.tile.row; if (M.ptiles[M.ptiles.length - 1] !== pk) M.ptiles.push(pk);
      const ek = (e.moving ? '>' : '') + e.tile.col + ',' + e.tile.row; if (M.ztiles[M.ztiles.length - 1] !== ek) M.ztiles.push(ek); });
    const oh = s.enemies.hitPlayer.bind(s.enemies); s.enemies.hitPlayer = (e) => { if (window.__mon) window.__mon.zhits++; return oh(e); }; });
  const results = [];
  for (const sp of spawns) for (const d of dists) {
    await G((sp) => { const s = window.__game.scene.getScene('game');
      for (const e of [...s.enemies.list]) s.enemies.remove(e);
      s.clock.t = 0; s.hearts.value = 5;
      const p = s.player; p.stopAction(); p.path.length = 0; p.col = 37; p.row = 39; p.tile = { col: 37, row: 39 }; p.cooldown = 0; p.chaseLeft = 0; p.syncSprite();
      window.__next = sp; window.__mon = null; }, sp);
    await T.run(2);
    await T.testItem(3);   // real clicks: 좀비 1마리 부르기
    const r = await T.until(`const e = s.enemies.list[0]; return e && Math.hypot(e.col - s.player.col, e.row - s.player.row) <= ${d};`, 60 * 60);
    if (!r.ok) { results.push([sp, d, 'never came within d']); continue; }
    const z = await T.zombiePoint(0);
    const before = await G(() => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[0]; return { z: [+e.col.toFixed(2), +e.row.toFixed(2)], next: e.path[0] ? [e.path[0].col, e.path[0].row] : null, end: e.path.length ? [e.path[e.path.length - 1].col, e.path[e.path.length - 1].row] : null }; });
    await G(() => { const s = window.__game.scene.getScene('game'); window.__mon = { e: s.enemies.list[0], frames: 0, onTile: 0, onTileBothStand: 0, first: null, died: null, zhits: 0, ptiles: [], ztiles: [], t0: +s.elapsed.toFixed(2) }; });
    const p = await T.w2p(z.wx, z.wy);
    await page.mouse.click(p.x, p.y);   // REAL click on the zombie
    const pressed = await G(() => { const s = window.__game.scene.getScene('game'); return !!(s.player.action && s.player.action.chase); });
    let shot = null;
    if (shots) {
      const r2 = await T.until('const M = window.__mon; return M && M.onTileBothStand > 30;', 60 * 4);
      if (r2.ok) { const zz = await G(() => { const e = window.__mon.e; return { wx: e.sprite.x, wy: e.sprite.y }; });
        shot = await T.snapWorld(`p2_same_tile_${sp.join('_')}_${d}`, zz.wx, zz.wy, 300, 240, -50, 2); }
    }
    await T.until('const M = window.__mon; return M && M.died !== null;', 60 * 8);
    const M = await G(() => { const M = window.__mon; return { t0: M.t0, onTile: M.onTile, onTileBothStand: M.onTileBothStand, first: M.first, died: M.died, zhits: M.zhits, ptiles: M.ptiles, ztiles: M.ztiles }; });
    results.push({ spawn: sp, d, pressed, zombieAtClick: before.z, zNext: before.next, zGoal: before.end, overlapFrames60Hz: M.onTileBothStand, first: M.first, clickT: M.t0, died: M.died, zhits: M.zhits, ptiles: M.ptiles.join(' '), ztiles: M.ztiles.join(' '), shot });
  }
  let n = 0, k = 0;
  for (const r of results) { console.log(J(r)); if (r.overlapFrames60Hz !== undefined) { n++; if (r.overlapFrames60Hz > 0) k++; } }
  console.log(`trials ${n}, zombie standing on the player's own tile (both standing) in ${k}`);
  console.log('bad', J(await T.bad()), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
