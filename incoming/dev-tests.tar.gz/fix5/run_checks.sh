#!/bin/bash
# 리뷰에서 찾은 문제를 다시 재현해 본다(하나씩 차례로)
cd "$(dirname "$0")"
run() { n=$1; shift; echo "== $n"; timeout 900 node "$@" > out/$n.out 2>&1; echo "exit $?"; }
run spec1_mouse v1_overlap.js 1920 1200 0 craft-first
run spec1_touch v1_overlap.js 1024 768 1 test-first
run spec2 v2_attack_step.js
run logic1 v1_pocket.js
run logic2_a v2_starve.js 14 100 3 40
run logic2_b v2_starve.js 20 100 1 40
run logic2_c v2_starve.js 14 50 3 40
run logic3 v3_down.js
run play1 p1_pen.js test '[[39,14],[29,10]]'
run play2 p2_tap.js all '[2.6,2.2,1.9]'
echo DONE
