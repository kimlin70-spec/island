// Verify spec-1: does the test window cover the craft window when both are open (real clicks/taps)?
// usage: node v1_overlap.js <w> <h> <touch 0|1> <order craft-first|test-first>
const path = require('path');
const { setup, UI } = require('../p5/lib5.js');
const J = JSON.stringify;
const OUT = __dirname;
(async () => {
  const w = +(process.argv[2] || 1920), h = +(process.argv[3] || 1200), touch = process.argv[4] === '1';
  const order = process.argv[5] || 'craft-first';
  const T = await setup({ w, h, touch });
  const { page, G } = T;
  await page.waitForTimeout(8000); // let the 3 intro notices pass
  if (order === 'craft-first') { await T.ui(...UI.craft, 500); await T.ui(...UI.test, 500); }
  else { await T.ui(...UI.test, 500); await T.ui(...UI.craft, 500); }
  const info = await G(() => {
    const u = window.__game.scene.getScene('ui');
    const b = (o) => { const r = o.getBounds(); return [Math.round(r.x), Math.round(r.y), Math.round(r.right), Math.round(r.bottom)]; };
    const list = u.children.list;
    const note = u.craftWin.list.find((o) => o.type === 'Text' && /흐리게/.test(o.text));
    const title = u.craftWin.list.find((o) => o.type === 'Text' && o.text === '만들기');
    const cardsTop = Math.min(...u.cards.map((c) => c.box.getBounds().y));
    return {
      craftVisible: u.craftWin.visible, testVisible: u.debugWin.visible,
      // panel rectangle = container position + the panel graphics' hit area (Graphics have no getBounds size)
      craftWin: (() => { const a = u.craftWin.list[0].input.hitArea; return [u.craftWin.x + a.x, u.craftWin.y + a.y, u.craftWin.x + a.right, u.craftWin.y + a.bottom]; })(),
      debugWin: (() => { const a = u.debugWin.list[0].input.hitArea; return [u.debugWin.x + a.x, u.debugWin.y + a.y, u.debugWin.x + a.right, u.debugWin.y + a.bottom]; })(),
      craftDepth: u.craftWin.depth, debugDepth: u.debugWin.depth,
      craftIndex: list.indexOf(u.craftWin), debugIndex: list.indexOf(u.debugWin),
      note: note ? b(note) : null, title: title ? b(title) : null, cardsTop: Math.round(cardsTop),
      debugButtons: u.debugWin.list.filter((o) => o.type === 'Text').map((t) => [t.text, Math.round(u.debugWin.y + t.y)]),
      canvas: (() => { const r = window.__game.canvas.getBoundingClientRect(); return [r.left, r.top, r.width, r.height]; })(),
    };
  });
  console.log(J(info));
  const [cx0, cy0, cx1, cy1] = info.craftWin, [dx0, dy0, dx1, dy1] = info.debugWin;
  const ox0 = Math.max(cx0, dx0), oy0 = Math.max(cy0, dy0), ox1 = Math.min(cx1, dx1), oy1 = Math.min(cy1, dy1);
  console.log('overlap (game px):', ox1 > ox0 && oy1 > oy0 ? [ox0, oy0, ox1, oy1, 'w', ox1 - ox0, 'h', oy1 - oy0] : 'none');
  if (info.note) {
    const [nx0, ny0, nx1, ny1] = info.note;
    const ix0 = Math.max(nx0, dx0), iy0 = Math.max(ny0, dy0), ix1 = Math.min(nx1, dx1), iy1 = Math.min(ny1, dy1);
    const covered = ix1 > ix0 && iy1 > iy0 ? ((ix1 - ix0) * (iy1 - iy0)) / ((nx1 - nx0) * (ny1 - ny0)) : 0;
    console.log('note box covered by test window: ' + (covered * 100).toFixed(0) + '%  (test window drawn ' + (info.debugIndex > info.craftIndex ? 'ON TOP' : 'below') + ')');
  }
  // screenshot the area around the overlap (browser coords)
  const p0 = await T.g2p(1500, 640), p1 = await T.g2p(1920, 860);
  const file = path.join(OUT, `v1_${w}x${h}_${touch ? 'touch' : 'mouse'}_${order}.png`);
  await page.screenshot({ path: file, clip: { x: p0.x, y: p0.y, width: p1.x - p0.x, height: p1.y - p0.y } });
  await page.screenshot({ path: file.replace('.png', '_full.png') });
  console.log('shot', file);
  // still can press the 닫기 button of the test window (on top), and the craft cards still work?
  const before = await G(() => window.__game.scene.getScene('ui').debugWin.visible);
  await T.ui(1746, 398 + 5 * 56, 400); // 닫기
  const after = await G(() => window.__game.scene.getScene('ui').debugWin.visible);
  console.log('test window visible before/after pressing 닫기 over the craft panel:', before, after);
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
