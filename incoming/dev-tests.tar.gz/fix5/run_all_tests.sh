#!/bin/bash
# Phase 5 시험과 예전 시험을 하나씩 차례로
S=/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad
$S/fix3/run_regress.sh p5/t1.js p5/t2.js p5/t3.js p5/t4.js p5/t5.js p5/t6.js p2/t1.js p2/t2.js p2/t3.js p3/t1.js p3/t2.js p3/t3.js p4/t1.js p4/t2.js p4/t3.js p4/t4.js p4/t5.js p4/t6.js p4/t7.js p4/t8.js
