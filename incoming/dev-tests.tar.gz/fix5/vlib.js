// Verifier helpers on top of p5/lib5.js. Real clicks/taps for actions; page reads for state.
// A 60 Hz stepper (loop asleep, fixed delta) so timing is like a 60 fps device, independent of this slow machine.
const path = require('path');
const lib5 = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
const OUT = __dirname;
exports.UI = lib5.UI;
exports.J = JSON.stringify;
exports.setup = async (opts = {}) => {
  const T = await lib5.setup(opts);
  const { page, G } = T;
  T.shot = async (name, clip) => { const p = path.join(OUT, name + '.png'); await page.screenshot(clip ? { path: p, clip } : { path: p }); return p; };
  T.tileW = (c, r) => ({ wx: (c - r) * 40, wy: (c + r) * 20 });
  T.tapTileW = async (c, r, wait = 0) => { const w = T.tileW(c, r); return T.tapWorld(w.wx, w.wy, wait); };
  T.craftIsOpen = () => G(() => window.__game.scene.getScene('ui').craftOpen);
  T.openCraft = async () => { if (!(await T.craftIsOpen())) await T.ui(...lib5.UI.craft, 50); };
  T.closeCraft = async () => { if (await T.craftIsOpen()) await T.ui(...lib5.UI.craft, 50); };
  T.card = async (i) => { await T.openCraft(); await T.step1(); await T.ui(...lib5.UI.card(i), 50); await T.step1(); };
  // one rendered frame (only when the loop is asleep, so clicks on just-opened windows register)
  T.step1 = async () => { if (await G(() => !!(window.__S && window.__S.asleep))) await T.run(1); };
  // the test window with a game step between clicks (works with the loop asleep too)
  T.testItem = async (i) => { await T.ui(...lib5.UI.test, 50); await T.step1(); await T.ui(...lib5.UI.testItem(i), 50); await T.step1();
    if (await G(() => window.__game.scene.getScene('ui').debugWin.visible)) { await T.ui(...lib5.UI.testItem((await G(() => window.__game.scene.getScene('ui').debugLabels.length - 1))), 50); await T.step1(); } };
  // ---- stepper ----
  T.sleep = () => G(() => { const g = window.__game; if (!window.__S) window.__S = { t: performance.now() }; window.__S.asleep = true; g.loop.sleep(); });
  T.wake = () => G(() => { window.__S.asleep = false; window.__game.loop.wake(); });
  // run n frames of D ms; render the last frame (and every `renderEvery` frames if given)
  T.run = (n, D = 1000 / 60, renderEvery = 0) => G(([n, D, re]) => {
    const g = window.__game, S = window.__S;
    for (let i = 0; i < n; i++) {
      S.t += D;
      const render = i === n - 1 || (re && i % re === 0);
      if (render) g.step(S.t, D); else g.headlessStep(S.t, D);
    }
    return window.__game.scene.getScene('game').elapsed;
  }, [n, D, renderEvery]);
  // run until cond (source of a function body with s=game scene, g=game) is true; render the last frame
  T.until = (src, max = 36000, D = 1000 / 60) => G(([src, max, D]) => {
    const g = window.__game, S = window.__S, s = g.scene.getScene('game');
    const cond = new Function('s', 'g', src);
    for (let i = 0; i < max; i++) {
      S.t += D; g.headlessStep(S.t, D);
      if (cond(s, g)) { S.t += D; g.step(S.t, D); return { ok: true, frames: i + 2, t: +s.elapsed.toFixed(3) }; }
    }
    S.t += D; g.step(S.t, D);
    return { ok: false, frames: max + 1, t: +s.elapsed.toFixed(3) };
  }, [src, max, D]);
  T.state = () => G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return { t: +s.elapsed.toFixed(2), p: [+p.col.toFixed(2), +p.row.toFixed(2)], ptile: [p.tile.col, p.tile.row], pmoving: p.moving, hearts: s.hearts.value,
      resting: s.rest.resting, action: p.action ? (p.action.target.kind || p.action.target.type) : null,
      z: s.enemies.list.map((e) => ({ at: [+e.col.toFixed(2), +e.row.toFixed(2)], tile: [e.tile.col, e.tile.row], hp: e.hp, mv: e.moving,
        end: e.path.length ? [e.path[e.path.length - 1].col, e.path[e.path.length - 1].row] : null,
        smash: e.smashing ? e.smashing.type + '@' + e.smashing.col + ',' + e.smashing.row : null, flip: e.sprite.flipX, x: +e.sprite.x.toFixed(1) })),
      structs: s.map.structures.filter((x) => x.type !== 'fence' || x.hp < x.maxHp).map((x) => x.type + '@' + x.col + ',' + x.row + ':' + x.hp),
      fences: s.map.structures.filter((x) => x.type === 'fence').length }; });
  // screen clip (browser px) around a world point
  T.clipAt = async (wx, wy, w = 260, h = 200, dy = -60) => { const p = await T.w2p(wx, wy + dy); return { x: Math.max(0, p.x - w / 2), y: Math.max(0, p.y - h / 2), width: w, height: h }; };
  // full-resolution canvas snapshot (1920x1200 game px) of a w x h area centred on world point (wx, wy+dy).
  // The loop must be asleep: requests the snapshot, then renders one frame (advances the game by 1/60 s, or 0 if dtMs=0.0001).
  T.snapWorld = async (name, wx, wy, w = 360, h = 300, dy = -50, scale = 2, dtMs = 0.0001) => {
    const b64 = await G(([wx, wy, w, h, dy, scale, dtMs]) => new Promise((res) => {
      const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main;
      const sx = Math.round((wx - cam.midPoint.x) * cam.zoom + cam.width / 2 - w / 2), sy = Math.round((wy + dy - cam.midPoint.y) * cam.zoom + cam.height / 2 - h / 2);
      g.renderer.snapshotArea(Math.max(0, sx), Math.max(0, sy), w, h, (img) => {
        const c = document.createElement('canvas'); c.width = w * scale; c.height = h * scale;
        const ctx = c.getContext('2d'); ctx.imageSmoothingEnabled = false; ctx.drawImage(img, 0, 0, w * scale, h * scale);
        res(c.toDataURL('image/png').split(',')[1]);
      });
      window.__S.t += dtMs; g.step(window.__S.t, dtMs);
    }), [wx, wy, w, h, dy, scale, dtMs]);
    const p = path.join(OUT, name + '.png');
    require('fs').writeFileSync(p, Buffer.from(b64, 'base64'));
    return p;
  };
  return T;
};
