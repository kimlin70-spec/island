// play-4 verification: is the white hit flash (and the zombie shake) ever DRAWN, at a given frame time and test speed?
// Every step is a full Phaser step (logic + render); a postrender hook records what was drawn.
// Usage: node p4_flash.js <frame ms> <speed 1|3>
const { setup, J } = require('./vlib.js');
const D = +(process.argv[2] || 1000 / 60), speed = +(process.argv[3] || 1);
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await T.sleep(); await T.run(2);
  if (speed === 3) await T.testItem(4);   // real clicks: 속도 ×3
  await G(() => { const g = window.__game, s = g.scene.getScene('game');
    s.enemies.spawnPoint = () => s.mapData.zombieSpawns.find((z) => z.col === 23 && z.row === 31);   // a natural map spawn point
    const R = window.__R = { renders: 0, flashCalls: { zombie: 0, player: 0 }, drawnWhite: { zombie: 0, player: 0 }, drawnShake: 0, drawnHitFx: 0, strikes: 0 };
    const of = s.effects.flash.bind(s.effects);
    s.effects.flash = (sp) => { R.flashCalls[sp === s.player.sprite ? 'player' : 'zombie']++; return of(sp); };
    g.events.on('postrender', (r) => { if (!r) return; R.renders++;
      for (const e of s.enemies.list) { if (e.sprite.tintFill) R.drawnWhite.zombie++;
        const w = (e.col - e.row) * 40; if (Math.abs(e.sprite.x - w) > 0.5) R.drawnShake++; }
      if (s.player.sprite.tintFill) R.drawnWhite.player++;
      if (s.children.list.some((o) => o.texture && o.texture.key === 'fx_hit')) R.drawnHitFx++; }); });
  await T.testItem(3);   // real clicks: 좀비 1마리 부르기; the standing player auto-attacks it when it arrives
  const speedNow = await G(() => window.__game.scene.getScene('game').debugSpeed);
  // full (rendered) steps until the zombie is gone; also let it hit the player once by not attacking at first? (auto attack starts at once)
  const r = await G(([D]) => { const g = window.__game, S = window.__S, s = g.scene.getScene('game');
    for (let i = 0; i < 20000; i++) { S.t += D; g.step(S.t, D); if (!s.enemies.list.length) return { ok: true, frames: i + 1, t: +s.elapsed.toFixed(2) }; }
    return { ok: false }; }, [D]);
  const R = await G(() => window.__R);
  console.log(`frame ${D.toFixed(1)} ms (${(1000 / D).toFixed(0)} fps), test speed x${speedNow}, dt per frame ${(Math.min(D / 1000, 0.1) * speedNow).toFixed(4)} s:`, J(r));
  console.log('  flash() calls', J(R.flashCalls), '| frames DRAWN with: white zombie', R.drawnWhite.zombie, ', white player', R.drawnWhite.player, ', shaken zombie', R.drawnShake, ', fx_hit', R.drawnHitFx, '| renders', R.renders);
  console.log('  hearts', await G(() => window.__game.scene.getScene('game').hearts.value), 'defeated', await G(() => window.__game.scene.getScene('game').enemies.defeated), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
