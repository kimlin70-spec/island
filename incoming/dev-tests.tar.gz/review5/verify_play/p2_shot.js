// play-2: snapshot of the fight between strikes (no flash), natural spawn (23,31), real click at 2.2 tiles.
const { setup, J } = require('./vlib.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.spawnPoint = () => s.mapData.zombieSpawns.find((z) => z.col === 23 && z.row === 31); });
  await T.testItem(3);
  // reference: the same zombie standing NEXT to the player, before the tap, is not possible here; take a shot while it walks in
  await T.until('const e = s.enemies.list[0]; return e && Math.hypot(e.col - s.player.col, e.row - s.player.row) <= 2.2;', 3600);
  await T.snapWorld('p2_before_tap', -80, 1520, 300, 240, -50, 1, 0.0001);
  const z = await T.zombiePoint(0); const p = await T.w2p(z.wx, z.wy);
  await page.mouse.click(p.x, p.y);
  const r = await T.until('const e = s.enemies.list[0]; return e && !e.moving && e.tile.col === s.player.tile.col && e.tile.row === s.player.tile.row && !s.player.moving;', 300);
  await T.run(15);
  const st = await T.state();
  console.log('stopped on the player tile:', J(r), 'player', J(st.ptile), 'zombie', J(st.z.map((z) => [z.tile, z.mv, z.hp])));
  const pw = await G(() => { const s = window.__game.scene.getScene('game'); return { wx: s.player.sprite.x, wy: s.player.sprite.y, white: !!s.enemies.list[0].sprite.tintFill }; });
  console.log('zombie white now?', pw.white);
  await T.snapWorld('p2_same_tile_1x', pw.wx, pw.wy, 300, 240, -50, 1, 0.0001);
  await T.snapWorld('p2_same_tile_2x', pw.wx, pw.wy, 200, 170, -50, 2, 0.0001);
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
