const { setup, J } = require('./vlib.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  const inv = () => G(() => { const s = window.__game.scene.getScene('game'); return [s.inventory.count('wood'), window.__game.scene.getScene('ui').craftOpen, s.build.mode]; });
  await T.sleep(); await T.run(2);
  console.log('before', J(await inv()));
  await T.testItem(0);
  console.log('after testItem asleep', J(await inv()));
  await T.run(2);
  console.log('after run', J(await inv()));
  await T.card(4);
  console.log('after card asleep', J(await inv()));
  await T.run(2);
  console.log('after run', J(await inv()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
