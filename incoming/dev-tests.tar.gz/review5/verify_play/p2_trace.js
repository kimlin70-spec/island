// play-2: one trial with a per-frame trace of the zombie's route around the tap (natural spawn (23,31), real click at 2.2 tiles).
const { setup, J } = require('./vlib.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game');
    s.enemies.spawnPoint = () => s.mapData.zombieSpawns.find((z) => z.col === 23 && z.row === 31);
    window.__tr = []; window.__on = false;
    const E = s.enemies;
    s.events.on('postupdate', () => { if (!window.__on) return; const e = E.list[0], p = s.player; if (!e) return;
      window.__tr.push([+s.elapsed.toFixed(3), 'P' + p.col.toFixed(2) + ',' + p.row.toFixed(2) + ' tile ' + p.tile.col + ',' + p.tile.row + ' here ' + p.here().col + ',' + p.here().row,
        'Z' + e.col.toFixed(2) + ',' + e.row.toFixed(2) + ' tile ' + e.tile.col + ',' + e.tile.row, 'path [' + e.path.map((t) => t.col + ',' + t.row).join(' ') + ']', 'hp' + e.hp]); }); });
  // wrap repath of the zombie once it exists
  await T.testItem(3);
  await G(() => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[0]; const o = e.repath.bind(e);
    e.repath = (target, key) => { const before = e.path.map((t) => t.col + ',' + t.row).join(' '); o(target, key);
      window.__tr.push([+s.elapsed.toFixed(3), 'REPATH target ' + key, 'before [' + before + ']', 'after [' + e.path.map((t) => t.col + ',' + t.row).join(' ') + ']']); }; });
  await T.until('const e = s.enemies.list[0]; return e && Math.hypot(e.col - s.player.col, e.row - s.player.row) <= 2.2;', 3600);
  const z = await T.zombiePoint(0); const p = await T.w2p(z.wx, z.wy);
  await G(() => { window.__on = true; });
  await page.mouse.click(p.x, p.y);
  await T.run(60 * 1.6);
  const tr = await G(() => window.__tr);
  let last = '';
  for (const r of tr) { const k = r.slice(1).join(' | '); if (r[1].startsWith('REPATH') || k.replace(/P[\d.,]+|Z[\d.,]+/g, '') !== last.replace(/P[\d.,]+|Z[\d.,]+/g, '')) console.log(J(r)); last = k; }
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
