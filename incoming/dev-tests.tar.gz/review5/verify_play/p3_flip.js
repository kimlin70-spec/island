// play-3 verification: a zombie from a natural northern spawn point walks to (36,38), straight above the standing player (37,39)
// on screen; the player auto-attacks (no taps). 60 Hz steps. Record the zombie's facing every frame, and snapshot frames around a hit.
const { setup, J } = require('./vlib.js');
const spawn = process.argv[2] ? JSON.parse(process.argv[2]) : [32, 22];
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await T.sleep(); await T.run(2);
  await G((sp) => { const s = window.__game.scene.getScene('game');
    s.enemies.spawnPoint = () => s.mapData.zombieSpawns.find((z) => z.col === sp[0] && z.row === sp[1]);
    window.__fl = []; window.__hits = []; let last = null;
    const oh = s.enemies.hitPlayer.bind(s.enemies); s.enemies.hitPlayer = (e) => { window.__hits.push(['zombie hits player', +s.elapsed.toFixed(3)]); return oh(e); };
    s.events.on('postupdate', () => { const e = s.enemies.list[0]; if (!e) return; const f = e.sprite.flipX;
      const row = [+s.elapsed.toFixed(3), f ? 'L' : 'R', e.tile.col + ',' + e.tile.row, e.moving ? 'walk' : 'stand', 'hp' + e.hp, 'zx' + e.sprite.x.toFixed(0), 'px' + s.player.sprite.x.toFixed(0), e.sprite.tintFill ? 'WHITE' : '', 'shake' + e.shakeLeft.toFixed(3)];
      if (f !== last) { window.__fl.push(row); last = f; } window.__all = window.__all || []; window.__all.push(row); }); }, spawn);
  await T.testItem(3);   // real clicks: 좀비 1마리 부르기 (spawn point: a natural map point in the north)
  // wait until the zombie stands next to the player
  let r = await T.until('const e = s.enemies.list[0]; return e && !e.moving && Math.max(Math.abs(e.tile.col - s.player.tile.col), Math.abs(e.tile.row - s.player.tile.row)) <= 1;', 60 * 40);
  const st = await T.state();
  console.log('zombie standing next to the player:', J(r), 'player tile', J(st.ptile), 'zombie', J(st.z.map((z) => [z.tile, z.flip ? 'L' : 'R', 'x' + z.x])), 'player x', await G(() => window.__game.scene.getScene('game').player.sprite.x));
  // snapshots: every frame from 1 frame before the first strike until 8 frames after it
  await T.until('const p = s.player; return p.swing && !p.swing.struck && p.swing.t + 1/60 >= 0.2 - 1e-9;', 60 * 5);
  const zw = await G(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return { wx: e.sprite.x, wy: e.sprite.y }; });
  for (let i = 0; i < 10; i++) {
    await T.snapWorld(`p3_f${i}`, -80, zw.wy, 200, 200, -60, 2, 1000 / 60);   // one real 60 Hz frame (logic + render), captured
    const info = await G(() => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[0]; return e ? [+s.elapsed.toFixed(3), e.sprite.flipX ? 'L' : 'R', e.sprite.tintFill ? 'WHITE' : 'normal', 'zx' + e.sprite.x.toFixed(0), 'shake' + e.shakeLeft.toFixed(3), s.player.swing ? 'swing' + s.player.swing.t.toFixed(3) : ''] : null; });
    console.log('frame', i, J(info));
  }
  await T.until('return s.enemies.list.length === 0;', 60 * 10);
  console.log('zombie facing changes [t, facing, tile, walk/stand, hp, zombie x, player x, white, shakeLeft]:');
  for (const x of await G(() => window.__fl)) console.log('  ', J(x));
  console.log('zombie hits on the player:', J(await G(() => window.__hits)));
  console.log('bad', J(await T.bad()), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
