// Real game loop, real taps: test window "속도 ×3", "좀비 1마리 부르기" ×N, then the player walks back and forth
// between two ground tiles (a tap each time it arrives). Reports how far each zombie got from where it appeared.
const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
const N = +(process.argv[2] || 14), W = +(process.argv[3] || 1920), H = +(process.argv[4] || 1200), secs = +(process.argv[5] || 25);
(async () => {
  const T = await setup({ w: W, h: H });
  const { page, G } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); window.__all = []; s.hurtPlayer = () => {};   // no damage: keep the game running
    const o = s.enemies.spawn.bind(s.enemies); s.enemies.spawn = (k) => { const e = o(k); if (e) { e.hp = e.maxHp = 999; window.__all.push(e); } return e; }; });
  await T.testItem(4);                       // 속도 ×3
  for (let i = 0; i < N; i++) await T.testItem(3);   // 좀비 1마리 부르기
  await G(() => { const s = window.__game.scene.getScene('game'); window.__fps = []; window.__repaths = new Map();
    const proto = Object.getPrototypeOf(window.__all[0]), orig = proto.repath;
    proto.repath = function (t, k) { window.__repaths.set(this, (window.__repaths.get(this) || 0) + 1); return orig.call(this, t, k); };
    window.__all.forEach((e) => { e.__start = [e.col, e.row]; });
    s.events.on('postupdate', (t, d) => window.__fps.push(d)); });
  const A = await G(() => { const p = window.__game.scene.getScene('game').player; return [p.tile.col, p.tile.row]; });
  const B = [A[0] - 6, A[1]];
  const t0 = Date.now(); let goB = true, taps = 0;
  while (Date.now() - t0 < secs * 1000) {
    const st = await G(() => { const s = window.__game.scene.getScene('game'); return { moving: s.player.moving, hearts: s.hearts.value }; });
    if (st.hearts < 3) await G(() => { const s = window.__game.scene.getScene('game'); s.hearts.value = 5; s.events.emit('hearts-changed'); });
    if (!st.moving) {
      const t = goB ? B : A; goB = !goB;
      await T.tapWorld((t[0] - t[1]) * 40, (t[0] + t[1]) * 20);
      taps++;
    }
    await page.waitForTimeout(50);
  }
  const r = await G(() => { const s = window.__game.scene.getScene('game'), d = window.__fps;
    return { fps: +(1000 / (d.reduce((a, b) => a + b, 0) / d.length)).toFixed(1), speed: s.debugSpeed,
      n: window.__all.length, z: window.__all.map((e, i) => `#${i}: moved ${Math.hypot(e.col - e.__start[0], e.row - e.__start[1]).toFixed(1)} tiles, re-plans ${window.__repaths.get(e) || 0}, goal ${e.goalKind}`) }; });
  console.log(`spawned ${r.n}; N=${N} viewport ${W}x${H}: real fps ${r.fps}, test speed x${r.speed}, ground taps ${taps}, ${secs}s real time`);
  for (const l of r.z) console.log('  ' + l);
  console.log('errors', JSON.stringify(T.errors.slice(0, 3)));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
