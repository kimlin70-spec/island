// Find tiles next to which the player can stand where some neighbour is open land a zombie cannot reach.
const m = require('/home/user/island/data/map.json');
const C = m.cols, R = m.rows;
const blocked = new Set(m.objects.map((o) => o.col + ',' + o.row));
const land = (c, r) => c >= 0 && r >= 0 && c < C && r < R && m.terrain[r][c] !== 0;
const kind = {}; for (const o of m.objects) kind[o.col + ',' + o.row] = o.kind;
function comps(isOpen) {
  const id = new Map(); let n = 0;
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
    if (!isOpen(c, r) || id.has(c + ',' + r)) continue;
    n++; const q = [[c, r]]; id.set(c + ',' + r, n);
    while (q.length) { const [a, b] = q.pop();
      for (const [dc, dr] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]) {
        const x = a + dc, y = b + dr; if (!isOpen(x, y) || id.has(x + ',' + y)) continue;
        if (dc && dr && (!isOpen(a + dc, b) || !isOpen(a, b + dr))) continue;
        id.set(x + ',' + y, n); q.push([x, y]); } }
  }
  return id;
}
const start = m.playerStart;
// 1) as the map starts
const open0 = (c, r) => land(c, r) && !blocked.has(c + ',' + r);
let id = comps(open0); const main = id.get(start.col + ',' + start.row);
const out0 = [];
for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
  if (id.get(c + ',' + r) !== main) continue;
  const bad = [], good = [];
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { if (!dc && !dr) continue; const k = (c + dc) + ',' + (r + dr);
    if (!open0(c + dc, r + dr)) continue; (id.get(k) === main ? good : bad).push(k); }
  if (bad.length) out0.push({ at: c + ',' + r, unreachableNeighbours: bad, reachableNeighbours: good.length, dist: Math.hypot(c - start.col, r - start.row).toFixed(1) });
}
out0.sort((a, b) => a.dist - b.dist);
console.log('at the start: player tiles with an unreachable open neighbour:', out0.length);
console.log(JSON.stringify(out0.slice(0, 8)));
// 2) chopping one tree (diagonally) leaves a stump pocket
const out1 = [];
for (const o of m.objects) {
  if (!['tree', 'pine', 'palm'].includes(o.kind)) continue;
  const k0 = o.col + ',' + o.row;
  const open1 = (c, r) => land(c, r) && (!blocked.has(c + ',' + r) || (c + ',' + r) === k0);
  const id1 = comps(open1); const main1 = id1.get(start.col + ',' + start.row);
  if (id1.get(k0) === main1) continue;            // the stump is reachable: no pocket
  // where can the player stand to chop it (any neighbour in the main area)?
  const stands = [];
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { if (!dc && !dr) continue; const x = o.col + dc, y = o.row + dr;
    if (id1.get(x + ',' + y) === main1) { let reach = 0; for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) { if (!a && !b) continue; if (id1.get((x + b) + ',' + (y + a)) === main1) reach++; } stands.push({ at: x + ',' + y, reachableNeighbours: reach }); } }
  if (stands.length) out1.push({ tree: o.kind + '@' + k0, stands, dist: +Math.hypot(o.col - start.col, o.row - start.row).toFixed(1) });
}
out1.sort((a, b) => a.dist - b.dist);
console.log('trees that leave an unreachable stump when chopped from a diagonal tile:', out1.length);
console.log(JSON.stringify(out1.slice(0, 8)));
