// Zombies wait around the tent; the player comes out (rest button) next to three of them with 1 heart left.
// Their first-hit timers all start in the frame the player comes out, so they hit in the same frame 1.5 s later.
// How many "down" windows, what the console says, whether the hero is still white under the window.
const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
const NZ = +(process.argv[2] || 10), NEED = +(process.argv[3] || 3);
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  const setupInfo = await G(() => {
    const s = window.__game.scene.getScene('game'), p = s.player;
    const c = p.tile.col - 1, r = p.tile.row - 3;
    const tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }];
    const ok = tiles.every((t) => s.build.canBuildAt(t.col, t.row));
    if (ok) { const t = s.build.place('tent', tiles); s.pressTent(t); }
    window.__downs = 0; window.__tinted = []; window.__hits = [];
    s.events.on('down', () => { window.__downs++; window.__tinted.push(s.player.sprite.isTinted); });
    const hp = s.enemies.hitPlayer.bind(s.enemies);
    s.enemies.hitPlayer = (e) => { window.__hits.push([s.game.loop.frame, s.hearts.value]); return hp(e); };
    return { ok, tiles };
  });
  console.log('tent', JSON.stringify(setupInfo));
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await G(() => { const t = window.__game.scene.getScene('game').rest.tent; t.hp = t.maxHp = 9999; });   // keep the tent up while they gather
  await T.testItem(4);                                   // 속도 ×3 so they gather sooner
  for (let i = 0; i < NZ; i++) await T.testItem(3);      // 좀비 1마리 부르기
  await W((need) => { const s = window.__game.scene.getScene('game'), p = s.player;
    return s.enemies.list.filter((e) => e.col === e.tile.col && e.row === e.tile.row && !e.moving &&
      Math.max(Math.abs(e.tile.col - p.tile.col), Math.abs(e.tile.row - p.tile.row)) <= 1).length >= need; }, NEED, 40000).catch(() => null);
  console.log("state", JSON.stringify(await G(() => { const s = window.__game.scene.getScene("game"), p = s.player; return { entry: [p.tile.col, p.tile.row], resting: s.rest.resting, tent: s.rest.tent && s.rest.tent.tiles, z: s.enemies.list.map((e) => [+e.col.toFixed(2), +e.row.toFixed(2), e.moving, e.smashing ? e.smashing.type : null, e.goalKind]) }; })));
  await T.testItem(4);                                   // back to 속도 ×1
  const before = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    s.hearts.value = 1; s.events.emit('hearts-changed');
    const adj = s.enemies.list.filter((e) => Math.max(Math.abs(e.tile.col - p.tile.col), Math.abs(e.tile.row - p.tile.row)) <= 1).length;
    return { adj, resting: s.rest.resting, speed: s.debugSpeed, entry: [p.tile.col, p.tile.row] }; });
  console.log('before coming out:', JSON.stringify(before));
  await T.ui(960, 1132, 0);                              // "쉬는 중 · 누르면 나옵니다"
  await W(() => !window.__game.scene.isActive('game'), null, 30000);
  await page.waitForTimeout(800);
  const r = await G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui');
    return { downs: window.__downs, hits: window.__hits, tintedAtEachDown: window.__tinted, tintedNow: s.player.sprite.isTinted, hearts: s.hearts.value,
      modal: u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : null }; });
  console.log('result', JSON.stringify(r));
  await page.screenshot({ path: __dirname + '/out/down_twice.png' });
  console.log('console:', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
