const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const r = await T.G(() => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, E = s.enemies;
    g.loop.sleep();
    const zs = []; for (let i = 0; i < 6; i++) zs.push(E.spawn());
    const time = (label) => {
      const out = [];
      for (const e of zs) {
        const goals = e.goalsAround(E.target().tiles);
        const t0 = performance.now(); let n = 0, path;
        while (performance.now() - t0 < 50) { path = e.findRoute(goals); n++; }
        out.push(+((performance.now() - t0) / n).toFixed(3));
      }
      return label + ': ms per route ' + JSON.stringify(out);
    };
    const a = time('open ground');
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row + dr }]);
    const b = time('player in a ring of 8 fences');
    for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) if (Math.max(Math.abs(dc), Math.abs(dr)) === 2 && s.build.canBuildAt(p.tile.col + dc, p.tile.row + dr)) s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row + dr }]);
    const c = time('two rings');
    return [a, b, c];
  });
  console.log(r.join('\n'));
  await T.browser.close();
})();
