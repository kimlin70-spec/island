// A stump closed in by trees and rocks that touches the player's tile only corner to corner is a goal no zombie
// can reach. When the reachable tiles next to the player are taken (by zombies standing there or walking there),
// goalsAround returns only that stump, the route search fails and the zombie stands still.
// Real game loop; real taps for the test tool; the tree is pressed through GameScene.pressNode (what a tap on it calls).
const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  // 1. chop the tree at (39,22) (axe given to save time; with the dagger it is the same, only slower)
  await G(() => { const s = window.__game.scene.getScene('game'); s.tools.push('axe');
    const o = s.map.objects.find((x) => x.col === 39 && x.row === 22); s.pressNode(o); });
  await W(() => { const s = window.__game.scene.getScene('game'); const o = s.map.objects.find((x) => x.col === 39 && x.row === 22); return o.kind === 'stump' && !s.player.action; }, null, 120000);
  const st = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; return { player: [p.tile.col, p.tile.row] }; });
  console.log('tree (39,22) is now a stump; the player stands at', JSON.stringify(st.player));
  // 2. three zombies from the test window, one right after the other
  for (let i = 0; i < 5; i++) await T.testItem(3);
  // 3. watch them for 25 s
  const t0 = Date.now(), rows = [];
  while (Date.now() - t0 < 40000) {
    rows.push(await G(() => { const s = window.__game.scene.getScene('game'), E = s.enemies;
      return { t: +s.elapsed.toFixed(1), p: [s.player.tile.col, s.player.tile.row], hearts: s.hearts.value,
        z: E.list.map((e) => { const goals = e.goalsAround(E.target().tiles);
          return { at: [+e.col.toFixed(2), +e.row.toFixed(2)], end: e.path.length ? [e.path[e.path.length - 1].col, e.path[e.path.length - 1].row] : null,
            want: e.wantPath, goal: e.goalKind, goals: goals.map((g) => g.col + ',' + g.row).join(' '), route: !!e.findRoute(goals) }; }) }; }));
    await page.waitForTimeout(4000);
  }
  for (const r of rows) console.log(`t=${r.t}s player ${r.p} hearts ${r.hearts}\n` + r.z.map((z, i) => `   z${i}: at ${z.at} pathEnd ${z.end} wantPath ${z.want} goals [${z.goals}] routeFound ${z.route}`).join('\n'));
  console.log('console:', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
