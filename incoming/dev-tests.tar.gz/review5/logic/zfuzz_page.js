// Page-side fuzz for Phase 5: zombies, structures, player taps, tent, nights/mornings.
// Installed as window.__zf. The game loop is asleep; we step GameScene by hand (same update code),
// apply queued scene ops (pause/resume) the way Game.step does, and check invariants after every frame.
(() => {
  const g = window.__game, s = g.scene.getScene('game'), ui = g.scene.getScene('ui');
  const m = s.map, p = s.player, b = s.build, E = s.enemies;
  const K = (t) => t.col + ',' + t.row;
  const W = (c, r) => m.isWalkable(c, r);
  const cheb = (a, z) => Math.max(Math.abs(a.col - z.col), Math.abs(a.row - z.row));
  const RUNNING = 5;   // Phaser.Scenes.RUNNING

  const zf = { seed: 0, frame: 0, time: 0, gt: 0, now: 0, log: [], fails: [], stats: {}, perKind: {}, zid: 0, kills: 0,
               pendingHits: [], pendingSmash: [], lastHearts: s.hearts.value, maxDtSinceMorning: 0, debugCall: false, natural: true };
  window.__zf = zf;
  const stat = (k, n = 1) => { zf.stats[k] = (zf.stats[k] || 0) + n; };

  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const ri = (n) => Math.floor(zf.rnd() * n);
  const pick = (arr) => arr[ri(arr.length)];

  const zs = (e) => `z${e.__id}@${+e.col.toFixed(3)},${+e.row.toFixed(3)} t${K(e.tile)} p[${e.path.slice(0, 5).map(K).join(' ')}${e.path.length > 5 ? ' …' + e.path.length : ''}]` +
    `${e.smashing ? ' smash:' + e.smashing.type + '@' + K(e.smashing) : ''}${e.hitLeft !== null ? ' hit:' + e.hitLeft.toFixed(2) : ''} want:${e.wantPath ? 1 : 0} rl:${e.repathLeft.toFixed(2)} hp:${e.hp} gk:${e.goalKind}`;
  const ps = () => `${+p.col.toFixed(3)},${+p.row.toFixed(3)} t${K(p.tile)} here${K(p.here())} path[${p.path.map(K).join(' ')}] act:${p.action ? (p.action.chase ? 'zombie z' + p.action.target.__id : (p.action.target.kind || p.action.target.type || '?')) : '-'} swing:${p.swing ? p.swing.t.toFixed(2) : '-'} cd:${p.cooldown.toFixed(2)} chaseLeft:${p.chaseLeft.toFixed(2)} rest:${s.rest.resting}`;
  const snap = () => ({
    gt: +zf.gt.toFixed(3), day: s.clock.day, night: s.clock.isNight, t: +s.clock.t.toFixed(2), hearts: s.hearts.value, speed: s.speed,
    p: ps(), z: E.list.map(zs), st: m.structures.map((x) => x.type[0] + K(x) + ':' + x.hp).join(' '),
  });
  const L = (what) => { zf.log.push({ f: zf.frame, what }); if (zf.log.length > 600) zf.log.shift(); };
  const fail = (kind, info) => {
    zf.perKind[kind] = (zf.perKind[kind] || 0) + 1;
    stat('FAIL:' + kind);
    if (zf.perKind[kind] <= 3) zf.fails.push({ kind, info, frame: zf.frame, seed: zf.seed, st: snap(), recent: zf.log.slice(-60) });
  };

  // ── zombie ids and bookkeeping ──
  const meta = new Map();
  const tag = (e) => {
    if (e.__id === undefined) {
      e.__id = ++zf.zid;
      meta.set(e, { still: 0, lastPos: [e.col, e.row], reported: false, run: null, hitsInRun: 0, smashObj: null, smashAcc: 0, smashHits: 0 });
    }
    return e;
  };
  const origSpawn = E.spawn.bind(E);
  E.spawn = function (kind) {
    const night = s.clock.isNight, dbg = zf.debugCall;
    const e = origSpawn(kind);
    if (e) {
      tag(e); L(`spawn z${e.__id}@${K(e.tile)}${dbg ? ' (test tool)' : ''}`); stat(dbg ? 'spawned:test' : 'spawned:night');
      if (!dbg && !night) fail('night-spawn-in-daytime', {});
      if (!dbg) zf.nightSpawns = (zf.nightSpawns || 0) + 1;
      if (!W(e.tile.col, e.tile.row)) fail('spawn-on-blocked', { z: zs(e) });
    } else stat('spawn-null');
    return e;
  };

  // ── hooks ──
  const origHitPlayer = E.hitPlayer.bind(E);
  E.hitPlayer = function (e) {
    zf.pendingHits.push(e);
    if (s.rest.resting) fail('zombie-hit-player-in-tent', { z: zs(e) });
    stat('zombie-hit-player');
    L(`z${e.__id} hits player (hearts ${s.hearts.value})`);
    return origHitPlayer(e);
  };
  const origHitStructure = E.hitStructure.bind(E);
  E.hitStructure = function (e, x) {
    const atC = e.col === e.tile.col && e.row === e.tile.row;
    if (!atC) fail('smash-while-not-standing', { z: zs(e) });
    if (!m.structures.includes(x)) fail('smash-gone-structure', { z: zs(e), x: x.type + K(x) });
    if (!x.tiles.some((t) => cheb(t, e.tile) <= 1)) fail('smash-from-afar', { z: zs(e), x: x.type + K(x) });
    zf.pendingSmash.push([e, x]);
    stat('smash:' + x.type);
    L(`z${e.__id} hits ${x.type}@${K(x)} hp ${x.hp}->${x.hp - e.cfg.structureDamage}`);
    return origHitStructure(e, x);
  };
  zf.patchEnemyProto = (proto) => {
    if (proto.__patched) return;
    proto.__patched = true;
    const origHurt = proto.hurt;
    proto.hurt = function (n) {
      if (!this.alive) fail('hurt-dead-zombie', { z: zs(this) });
      if (!p.isNextTo(this.tiles)) fail('hurt-not-next-to', { z: zs(this) });
      if (s.rest.resting) fail('hurt-while-resting', { z: zs(this) });
      stat('player-hit-zombie');
      L(`player hits z${this.__id} hp ${this.hp}->${this.hp - n}`);
      return origHurt.call(this, n);
    };
  };
  // the player chasing and zombies re-planning must finish the step in progress (never turn back)
  const origChase = p.chase.bind(p);
  p.chase = function (a, dt) {
    const N = segOther(p), before = p.path.map(K).join(' '), p0 = p.path[0] ? K(p.path[0]) : null;
    const r = origChase(a, dt);
    if (N && p.path.length && K(p.path[0]) !== p0) fail('chase-turned-back', { N: K(N), before, after: p.path.map(K).join(' ') });
    if (N && !p.path.length) fail('chase-dropped-path-mid-step', { N: K(N), before });
    return r;
  };
  zf.patchRepath = (proto) => {
    if (proto.__patchedRepath) return;
    proto.__patchedRepath = true;
    const orig = proto.repath;
    proto.repath = function (target, key) {
      const N = segOther(this), before = this.path.map(K).join(' '), p0 = this.path[0] ? K(this.path[0]) : null;
      stat('repath');
      const r = orig.call(this, target, key);
      if (N && this.path.length && K(this.path[0]) !== p0) fail('zombie-turned-back', { z: zs(this), N: K(N), before });
      if (N && !this.path.length) fail('zombie-dropped-path-mid-step', { z: zs(this), before });
      return r;
    };
  };
  const origKill = E.kill.bind(E);
  E.kill = function (e) { const r = origKill(e); zf.kills++; if (E.list.includes(e)) fail('killed-still-listed', { z: zs(e) }); stat('killed'); L(`kill z${e.__id}`); return r; };
  const origDZ = s.debugZombie.bind(s);
  s.debugZombie = function () { zf.debugCall = true; try { return origDZ(); } finally { zf.debugCall = false; } };
  const origDM = s.debugMorning.bind(s);
  s.debugMorning = function () { zf.natural = false; try { return origDM(); } finally { zf.natural = true; } };

  s.events.on('night', () => { L('night ' + s.clock.day); stat('night'); zf.nightSpawns = 0; zf.nightDay = s.clock.day; });
  s.events.on('morning', (day) => {
    zf.morningAt = zf.now; zf.morningDay = day; zf.maxDtSinceMorning = 0; zf.heartsAtMorning = zf.lastHearts;
    L('morning ' + day + (zf.natural ? '' : ' (test tool)')); stat('morning');
    if (E.list.length) fail('morning-zombies-left', { n: E.list.length });
    if (E.schedule.length) fail('morning-schedule-left', { n: E.schedule.length });
    if (zf.natural && zf.nightDay !== undefined) {
      const want = Math.min(14, 4 + 2 * (zf.nightDay - 1));
      if (zf.nightSpawns !== want && !zf.stats['spawn-null']) fail('night-spawn-count', { got: zf.nightSpawns, want });
    }
  });
  s.events.on('down', () => { zf.down = true; stat('down'); if (s.hearts.value > 0) fail('down-with-hearts', { h: s.hearts.value }); L('DOWN'); });
  s.events.on('result', (r) => {
    zf.result = r; stat('result'); L('RESULT ' + JSON.stringify(r));
    if (zf.morningDay !== 2) fail('result-not-day2', { day: zf.morningDay });
    const since = zf.now - zf.morningAt;
    if (since < 3 - 1e-6) fail('result-too-early', { since });
    if (since > 3 + zf.maxDtSinceMorning + 1e-6) fail('result-too-late', { since, maxDt: zf.maxDtSinceMorning });
    if (r.defeated !== zf.kills) fail('result-defeated-mismatch', { r, kills: zf.kills });
    if (r.hearts !== zf.heartsAtMorning) fail('result-hearts-mismatch', { r, h: zf.heartsAtMorning });
    if (r.fences !== b.count('fence')) fail('result-fences-mismatch', { r });
  });
  s.events.on('rest-changed', () => { if (zf.inStep) zf.restChanged = true; stat(s.rest.resting ? 'rest:enter' : 'rest:exit'); L(s.rest.resting ? 'rest enter' : 'rest exit'); });

  const segOther = (w) => {
    let dc = w.col - w.tile.col, dr = w.row - w.tile.row;
    if (Math.abs(dc) < 1e-9) dc = 0;
    if (Math.abs(dr) < 1e-9) dr = 0;
    if (dc === 0 && dr === 0) return null;
    return { col: w.tile.col + Math.sign(dc), row: w.tile.row + Math.sign(dr) };
  };
  const bodyTiles = (w) => {
    const out = [], e9 = 1e-9;
    for (let c = Math.floor(w.col + e9); c <= Math.ceil(w.col - e9); c++) for (let r = Math.floor(w.row + e9); r <= Math.ceil(w.row - e9); r++) out.push({ col: c, row: r });
    return out;
  };

  function checkWalker(who, w, isZ) {
    const t = w.tile, Z = () => (isZ ? zs(w) : ps());
    if (!Number.isInteger(t.col) || !Number.isInteger(t.row)) fail(who + ':tile-not-integer', {});
    for (const x of bodyTiles(w)) if (!W(x.col, x.row)) fail(who + ':body-on-blocked', { blocked: K(x), struct: !!m.structureAt(x.col, x.row), w: Z() });
    if (!W(t.col, t.row)) fail(who + ':tile-blocked', { w: Z() });
    const dc = w.col - t.col, dr = w.row - t.row;
    if (Math.abs(dc) >= 1 || Math.abs(dr) >= 1) stat(who + ':pos-off-tile-box(known rounding)');
    if (dc !== 0 && dr !== 0 && Math.abs(Math.abs(dc) - Math.abs(dr)) > 1e-9) fail(who + ':pos-off-diagonal', { dc, dr, w: Z() });
    if (!w.path.length && (w.col !== t.col || w.row !== t.row)) fail(who + ':stranded-fractional', { w: Z() });
    const N = segOther(w);
    if (N) {
      if (cheb(N, t) !== 1) fail(who + ':segment-not-adjacent', { w: Z() });
      else if (!w.canStep(t, N)) fail(who + ':current-step-illegal', { from: K(t), to: K(N), w: Z() });
      if (m.structureAt(N.col, N.row)) fail(who + ':stepping-into-structure', { to: K(N), w: Z() });
      if (N.col !== t.col && N.row !== t.row && (!W(N.col, t.row) || !W(t.col, N.row))) fail(who + ':diagonal-between-blocked', { w: Z() });
      if (!w.path.length) fail(who + ':mid-step-no-path', { w: Z() });
      else if (K(w.path[0]) !== K(N) && K(w.path[0]) !== K(t)) fail(who + ':path0-not-on-segment', { N: K(N), w: Z() });
    }
    let from = t;
    for (let k = 0; k < w.path.length; k++) {
      const q = w.path[k], d = cheb(from, q);
      if (k === 0 && d === 0) { from = q; continue; }
      if (d !== 1) { fail(who + ':path-non-adjacent', { k, from: K(from), to: K(q), w: Z() }); break; }
      if (!w.canStep(from, q)) { fail(who + ':path-step-illegal', { k, from: K(from), to: K(q), w: Z() }); break; }
      from = q;
    }
    const occ = new Set(w.occupiedTiles().map(K));
    for (const x of bodyTiles(w)) if (!occ.has(K(x))) fail(who + ':under-reserved-body', { tile: K(x), w: Z() });
    if (N) for (const x of [t, N, { col: N.col, row: t.row }, { col: t.col, row: N.row }]) if (!occ.has(K(x))) fail(who + ':under-reserved-step', { tile: K(x), w: Z() });
  }

  let pChaseStuck = 0, pNearNoSwing = 0;
  function gridCheck() {
    let n = 0;
    for (let i = 0; i < m.structGrid.length; i++) {
      const x = m.structGrid[i];
      if (!x) continue;
      n++;
      if (!m.structures.includes(x)) { fail('grid-has-unlisted-structure', { x: x.type + K(x) }); return; }
    }
    const want = m.structures.reduce((a, x) => a + x.tiles.length, 0);
    if (n !== want) fail('grid-count-mismatch', { n, want });
  }
  function check(dt) {
    zf.maxDtSinceMorning = Math.max(zf.maxDtSinceMorning, dt);
    if (zf.frame % 5 === 0) gridCheck();
    checkWalker('player', p, false);
    if (s.rest.resting) {
      if (!m.structures.includes(s.rest.tent)) fail('resting-in-gone-tent', {});
      if (p.sprite.visible) fail('resting-player-visible', {});
      if (p.moving || p.action || p.swing) fail('resting-player-busy', { p: ps() });
    } else if (!p.sprite.visible) fail('outside-player-invisible', {});
    if (!s.rest.resting && !p.moving && !p.action && !p.swing && E.nextTo(p.tile)) fail('no-auto-attack', { z: zs(E.nextTo(p.tile)), p: ps() });
    const a = p.action;
    if (a && a.chase && !p.moving && !p.isNextTo(a.target.tiles)) { pChaseStuck += dt; if (pChaseStuck > 1.2) { fail('player-chase-stuck', { z: a.target.alive ? zs(a.target) : 'dead', p: ps() }); pChaseStuck = -1e9; } }
    else pChaseStuck = 0;
    if (a && a.chase && !a.isValid() && !p.moving) { if (zf.deadTarget === a.target) { fail('player-acting-on-dead-2frames', { p: ps() }); } zf.deadTarget = a.target; } else zf.deadTarget = null;
    if (a && a.chase && a.isValid()) {
      if (zf.chaseAct !== a) { zf.chaseAct = a; zf.chaseT = 0; zf.chaseNear = false; zf.chaseReported = false; }
      zf.chaseT += dt;
      if (p.isNextTo(a.target.tiles)) zf.chaseNear = true;
      if (!zf.chaseNear && zf.chaseT > 12 && !zf.chaseReported) { zf.chaseReported = true; fail('chase-never-arrives', { z: zs(a.target), p: ps(), t: zf.chaseT }); }
    }
    if (a && a.chase && a.isValid() && !p.moving && p.isNextTo(a.target.tiles) && !p.swing) { pNearNoSwing += dt; if (pNearNoSwing > 0.75) { fail('player-near-no-swing', { z: zs(a.target), p: ps() }); pNearNoSwing = -1e9; } }
    else pNearNoSwing = 0;

    const target = E.target();
    const midFrameSwitch = zf.restChanged; zf.restChanged = false;
    // update the runs first, then judge the hits of this frame, then look for missing hits
    for (const e of E.list) {
      tag(e);
      const mt = meta.get(e);
      const atC = e.col === e.tile.col && e.row === e.tile.row;
      const adj = atC && e.nextTo(target) && !target.structure && !midFrameSwitch;
      if (adj) { if (mt.run === null) { mt.run = 0; mt.hitsInRun = 0; } mt.run += dt; } else mt.run = null;
      if (e.smashing) { if (mt.smashObj !== e.smashing) { mt.smashObj = e.smashing; mt.smashAcc = 0; mt.smashHits = 0; } mt.smashAcc += dt; }
      else mt.smashObj = null;
    }
    for (const [e, x] of zf.pendingSmash) {
      const mt = meta.get(e);
      if (!mt || mt.smashObj !== x) { fail('smash-hit-untracked', { z: zs(e) }); continue; }
      const need = 1.5 * (mt.smashHits + 1);
      if (mt.smashAcc < need - 1e-6) fail('smash-too-early', { z: zs(e), acc: mt.smashAcc, need });
      mt.smashHits++;
    }
    zf.pendingSmash.length = 0;
    for (const e of zf.pendingHits) {
      const mt = meta.get(e);
      if (midFrameSwitch) continue;
      if (!mt || mt.run === null) { fail('hit-not-standing-next-to', { z: zs(e), p: ps() }); continue; }
      const need = 1.5 + 2 * mt.hitsInRun;
      if (mt.run < need - 1e-6) fail(mt.hitsInRun ? 'hit-interval-too-short' : 'first-hit-too-early', { z: zs(e), run: mt.run, need });
      mt.hitsInRun++;
    }
    zf.pendingHits.length = 0;
    for (const e of E.list) {
      if (!e.alive) fail('dead-zombie-listed', { z: zs(e) });
      checkWalker('zombie', e, true);
      const mt = meta.get(e);
      const atC = e.col === e.tile.col && e.row === e.tile.row;
      const near = e.nextTo(target);
      // smash run
      if (e.smashing) {
        if (!atC) fail('smashing-not-at-centre', { z: zs(e) });
        const x = e.smashing;
        const onPath = e.path[0] && x.tiles.some((t) => K(t) === K(e.path[0]));
        const isTarget = target.structure === x && near;
        if (!onPath && !isTarget && m.structures.includes(x)) fail('smashing-not-blocker-nor-target', { z: zs(e) });
        if (!x.tiles.some((t) => cheb(t, e.tile) <= 1)) fail('smashing-far-structure', { z: zs(e) });
        if (m.structures.includes(x) && mt.smashAcc > 1.5 * (mt.smashHits + 1) + 1e-6) { fail('smash-missing', { z: zs(e), acc: mt.smashAcc, hits: mt.smashHits }); mt.smashObj = null; }
      }
      if (mt.run !== null && mt.run > 1.5 + 2 * mt.hitsInRun + 1e-6) { fail('hit-missing', { z: zs(e), run: mt.run, hits: mt.hitsInRun }); mt.run = null; }
      // standing still away from the target, not smashing
      const movedNow = e.col !== mt.lastPos[0] || e.row !== mt.lastPos[1];
      mt.lastPos = [e.col, e.row];
      if (!movedNow && !near && !e.smashing) {
        mt.still += dt;
        if (mt.still > 2.0 && !mt.reported) {
          mt.reported = true;
          const route = e.findRoute(e.goalsAround(target.tiles));
          fail(route ? 'zombie-still-away-with-route' : 'zombie-still-away-no-route',
            { z: zs(e), still: +mt.still.toFixed(2), routeLen: route ? route.length : 0, idx: E.list.indexOf(e), n: E.list.length, speed: s.speed, dt });
        }
      } else { mt.still = 0; mt.reported = false; }
      stat(e.smashing ? 'z:smashing' : !atC ? 'z:walking' : e.moving ? 'z:centre-with-path' : near ? 'z:adjacent' : 'z:idle');
      const kind = target.structure ? 'tent' : 'player';
      if (e.goalKind !== null && e.goalKind !== kind) { mt.stale = (mt.stale || 0) + dt; if (mt.stale > 2.0 && !mt.staleReported) { mt.staleReported = true; fail('stale-goal-kind', { z: zs(e), kind, stale: mt.stale, idx: E.list.indexOf(e), n: E.list.length }); } }
      else { mt.stale = 0; mt.staleReported = false; }
    }
    if (p.action && p.action.chase) stat(p.moving ? 'p:chasing' : 'p:fighting');
    zf.lastHearts = s.hearts.value;
  }

  // ── random actions (between frames, like taps) ──
  const nearTile = (c0, r0, rad) => ({ col: c0 + ri(2 * rad + 1) - rad, row: r0 + ri(2 * rad + 1) - rad });
  function hotTiles() {
    const out = [];
    const add = (w) => {
      const t = w.tile, N = segOther(w);
      if (N) out.push(N, { col: N.col, row: t.row }, { col: t.col, row: N.row });
      let from = t;
      for (let k = 0; k < Math.min(4, w.path.length); k++) { const q = w.path[k]; out.push(q, { col: q.col, row: from.row }, { col: from.col, row: q.row }); from = q; }
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) out.push({ col: t.col + dc, row: t.row + dr });
    };
    add(p);
    for (const e of E.list) if (cheb(e.tile, p.tile) <= 8) add(e);
    return out;
  }
  function tryBuild(type) {
    const H = hotTiles();
    if (type === 'tent') {
      if (b.atMax('tent')) return false;
      for (let k = 0; k < 8; k++) {
        const base = zf.rnd() < 0.6 ? pick(H) : nearTile(p.tile.col, p.tile.row, 4);
        const c = base.col - ri(2), r = base.row - ri(2);
        const tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }];
        if (tiles.every((x) => b.canBuildAt(x.col, x.row))) { L(`place tent ${tiles.map(K).join('+')}`); b.place('tent', tiles); stat('build:tent'); return true; }
      }
      return false;
    }
    for (let k = 0; k < 8; k++) {
      const x = zf.rnd() < 0.8 ? pick(H) : nearTile(p.tile.col, p.tile.row, 5);
      if (b.canBuildAt(x.col, x.row)) { L(`place ${type} ${K(x)}`); b.place(type, [x]); stat('build:' + type); return true; }
    }
    return false;
  }
  function ring() {
    const done = [];
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      if (!dc && !dr) continue;
      const x = { col: p.tile.col + dc, row: p.tile.row + dr };
      if (b.canBuildAt(x.col, x.row)) { b.place('fence', [x]); done.push(K(x)); }
    }
    L(`ring around ${K(p.tile)}: fences ${done.join(' ')}`); stat('ring');
  }
  function randomWalkable(c0, r0, rad) {
    for (let k = 0; k < 30; k++) { const x = nearTile(c0, r0, rad); if (W(x.col, x.row)) return x; }
    return null;
  }
  let failedWalks = 0;
  function act() {
    zf.now = zf.gt;
    const r = zf.rnd();
    const C = s.clock;
    if (r < zf.pTime) {
      if (!C.isNight) {
        const pend = s.resultPending; L('debugNight' + (pend ? ' (result pending)' : '')); s.debugNight();
        if (pend && s.clock.isNight) fail('night-while-result-pending', {});
      } else { L('debugMorning'); s.debugMorning(); }
      return;
    }
    if (r < zf.pTime + zf.pSpawn) { if (E.list.length < zf.maxZ) { L('debugZombie'); s.debugZombie(); } return; }
    if (r < zf.pTime + zf.pSpawn + zf.pSpeed) { L('toggle speed'); s.debugToggleSpeed(); return; }
    if (s.rest.resting) {
      const q = zf.rnd();
      if (q < 0.03) { L('rest.exit (tap)'); s.rest.exit(); }
      else if (q < 0.10) tryBuild(zf.rnd() < 0.9 ? 'fence' : 'campfire');
      else if (q < 0.11) { L('destroy tent while resting'); b.destroy(s.rest.tent); }
      else if (q < 0.14) { const list = m.structures.filter((x) => x.type !== 'tent' && cheb(x.tiles[0], p.tile) <= 6); if (list.length) { const x = pick(list); L(`destroy ${x.type}@${K(x)}`); b.destroy(x); } }
      return;
    }
    const moving = p.moving;
    const q = zf.rnd();
    let acc = 0;
    if (q < (acc += moving ? 0.02 : zf.pWalk)) {
      const base = zf.rnd() < 0.4 && E.list.length ? pick(E.list).tile : p.tile;
      const x = randomWalkable(base.col, base.row, 6); if (!x) return;
      const ok = p.goTo(x.col, x.row); L(`goTo ${K(x)} ${ok}`); stat('goTo:' + ok);
      if (!ok) failedWalks++; else failedWalks = 0;
    } else if (q < (acc += zf.pPressEnemy)) {
      if (E.list.length) { const e = pick(E.list); L(`pressEnemy z${e.__id}`); s.pressEnemy(e); stat('pressEnemy'); }
    } else if (q < (acc += moving ? 0.10 : 0.04)) {
      const t = zf.rnd();
      tryBuild(t < 0.85 ? 'fence' : t < 0.96 ? 'campfire' : 'tent');
    } else if (q < (acc += zf.pRing)) {
      ring();
    } else if (q < (acc += 0.025)) {
      const list = m.structures.filter((x) => cheb(x.tiles[0], p.tile) <= 7 || E.list.some((e) => e.smashing === x));
      if (list.length) {
        const sm = E.list.find((e) => e.smashing && m.structures.includes(e.smashing));
        const x = zf.rnd() < 0.4 && sm ? sm.smashing : pick(list);
        if (m.structures.includes(x)) { L(`destroy ${x.type}@${K(x)}`); b.destroy(x); }
      }
    } else if (q < (acc += 0.01)) {
      const list = m.objects.filter((o) => o.node && cheb(o, p.tile) <= 6);
      if (list.length) { const o = pick(list); L(`pressNode ${o.kind}@${o.col},${o.row}`); s.pressNode(o); }
    } else if (q < (acc += 0.015)) {
      const t = m.structures.find((x) => x.type === 'tent');
      if (t) { L('pressTent'); s.pressTent(t); }
    }
    if (m.structures.length > zf.maxS || failedWalks >= 3) {
      const list = failedWalks >= 3 ? m.structures.filter((x) => cheb(x.tiles[0], p.tile) <= 3) : [m.structures[0]];
      for (const x of list) { if (!m.structures.includes(x)) continue; L(`destroy-old ${x.type}@${K(x)}`); b.destroy(x); }
      failedWalks = 0;
    }
  }

  // one frame, the way Game.step does it: queued scene ops first, then the scene's update
  function frame(delta) {
    g.scene.processQueue();
    if (s.sys.settings.status !== RUNNING) {
      L('window up: ' + (zf.down ? 'down' : 'result'));
      if (zf.down) { s.hearts.value = s.hearts.max; s.events.emit('hearts-changed'); zf.down = false; zf.lastHearts = s.hearts.value; }
      ui.closeModal();
      s.resumeGame();
      g.scene.processQueue();
      if (s.sys.settings.status !== RUNNING) fail('could-not-resume', { st: s.sys.settings.status });
      return;
    }
    const sleeping = s.rest.resting && !s.enemyNear(s.rest.tent, 6);
    const dt = Math.min(delta / 1000, 0.1) * s.debugSpeed * (sleeping ? 4 : 1);
    zf.time += delta;
    zf.now = zf.gt + dt;
    try {
      zf.inStep = true;
      s.sys.step(zf.time, delta);
      zf.inStep = false;
    } catch (err) {
      zf.inStep = false;
      fail('exception', { msg: String(err && err.message), stack: String(err && err.stack).slice(0, 1200) });
    }
    if (Math.abs(Math.min(delta / 1000, 0.1) * s.speed - dt) > 1e-12) stat('dt-mismatch');
    zf.gt = zf.now;
    zf.frame++;
    check(dt);
  }

  zf.init = (seed, opts = {}) => {
    zf.seed = seed; zf.rnd = mulberry32(seed);
    Math.random = mulberry32(seed ^ 0x9e3779b9);   // spawn points become reproducible
    zf.deltaMode = opts.delta === undefined ? 'random' : opts.delta;
    zf.maxZ = opts.maxZ || 10; zf.maxS = opts.maxS || 18;
    zf.pTime = opts.pTime === undefined ? 0.0015 : opts.pTime;
    zf.pSpawn = opts.pSpawn === undefined ? 0.006 : opts.pSpawn;
    zf.pSpeed = opts.pSpeed === undefined ? 0.0005 : opts.pSpeed;
    zf.pWalk = opts.pWalk === undefined ? 0.12 : opts.pWalk;
    zf.pPressEnemy = opts.pPressEnemy === undefined ? 0.03 : opts.pPressEnemy;
    zf.pRing = opts.pRing === undefined ? 0.004 : opts.pRing;
    s.tools = ['dagger', 'axe', 'pickaxe'];
    if (!g.loop.sleeping) g.loop.sleep();
    s.clock.t = opts.clockT || 0; s.elapsed = 0; s.clock.dawn = 0;
    if (opts.speed3 && s.debugSpeed === 1) s.debugToggleSpeed();
    zf.time = 1000;
    for (const e of E.list) tag(e);
  };
  zf.run = (n) => {
    for (let i = 0; i < n; i++) {
      const k = 1 + (zf.rnd() < 0.25 ? ri(3) : 0);
      for (let j = 0; j < k; j++) act();
      if (E.list[0]) { zf.patchEnemyProto(Object.getPrototypeOf(E.list[0])); zf.patchRepath(Object.getPrototypeOf(E.list[0])); }
      const delta = zf.deltaMode === 'random' ? (zf.rnd() < 0.1 ? 150 : 5 + zf.rnd() * 110) : zf.deltaMode;
      frame(delta);
      if (zf.stopAtFrame && zf.frame >= zf.stopAtFrame) break;
    }
    return { frame: zf.frame, fails: zf.fails.length, z: E.list.length, structures: m.structures.length, day: s.clock.day, kills: zf.kills };
  };
  zf.snap = snap; zf.zs = zs; zf.ps = ps; zf.frameOnce = frame; zf.check = check;
})();
