const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
(async () => {
  const T = await setup({ w: +process.argv[2] || 960, h: +process.argv[3] || 600 });
  await T.page.waitForTimeout(3000);
  const r = await T.G(() => ({ fps: window.__game.loop.actualFps, delta: window.__game.loop.delta }));
  // white flash under the window: 1 heart, hurt once, then look at the hero while the window is up
  await T.G(() => { const s = window.__game.scene.getScene('game'); s.hearts.value = 1; s.hurtPlayer(1); });
  await T.page.waitForTimeout(1500);
  const t = await T.G(() => { const s = window.__game.scene.getScene('game'); return { active: window.__game.scene.isActive('game'), tinted: s.player.sprite.isTinted, tintFill: s.player.sprite.tintFill }; });
  await T.page.screenshot({ path: __dirname + '/out/down_white.png' });
  console.log(JSON.stringify(r), JSON.stringify(t), JSON.stringify(T.errors));
  await T.browser.close();
})();
