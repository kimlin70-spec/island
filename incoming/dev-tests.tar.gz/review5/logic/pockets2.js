// After chopping N random trees within ${process.argv[2] || 15} tiles of the start: how many tiles the player can stand on have an open
// neighbour that zombies cannot reach (a closed-in stump)?
const m = require('/home/user/island/data/map.json');
const C = m.cols, R = m.rows, start = m.playerStart;
const land = (c, r) => c >= 0 && r >= 0 && c < C && r < R && m.terrain[r][c] !== 0;
function comps(isOpen) {
  const id = new Map(); let n = 0;
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
    if (!isOpen(c, r) || id.has(c + ',' + r)) continue;
    n++; const q = [[c, r]]; id.set(c + ',' + r, n);
    while (q.length) { const [a, b] = q.pop();
      for (const [dc, dr] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]) {
        const x = a + dc, y = b + dr; if (!isOpen(x, y) || id.has(x + ',' + y)) continue;
        if (dc && dr && (!isOpen(a + dc, b) || !isOpen(a, b + dr))) continue;
        id.set(x + ',' + y, n); q.push([x, y]); } } }
  return id;
}
let seed = 7; const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x80000000; };
const trees = m.objects.filter((o) => ['tree', 'pine', 'palm'].includes(o.kind) && Math.hypot(o.col - start.col, o.row - start.row) <= +(process.argv[2] || 15));
for (const N of [5, 10, 20, 30]) {
  let tot = 0, withPocket = 0;
  for (let trial = 0; trial < 200; trial++) {
    const chopped = new Set(); const pool = trees.slice();
    for (let i = 0; i < N && pool.length; i++) { const k = Math.floor(rnd() * pool.length); const o = pool.splice(k, 1)[0]; chopped.add(o.col + ',' + o.row); }
    const blocked = new Set(m.objects.filter((o) => !chopped.has(o.col + ',' + o.row)).map((o) => o.col + ',' + o.row));
    const open = (c, r) => land(c, r) && !blocked.has(c + ',' + r);
    const id = comps(open), main = id.get(start.col + ',' + start.row);
    let spots = 0;
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
      if (id.get(c + ',' + r) !== main) continue;
      let bad = false;
      for (let dr = -1; dr <= 1 && !bad; dr++) for (let dc = -1; dc <= 1; dc++) { if (!dc && !dr) continue; if (open(c + dc, r + dr) && id.get((c + dc) + ',' + (r + dr)) !== main) { bad = true; break; } }
      if (bad) spots++;
    }
    tot += spots; if (spots) withPocket++;
  }
  console.log(`chop ${N} of the ${trees.length} trees within ${process.argv[2] || 15} tiles: games with a closed-in stump ${(withPocket / 2).toFixed(0)}%, player tiles next to one: ${(tot / 200).toFixed(1)} on average`);
}
