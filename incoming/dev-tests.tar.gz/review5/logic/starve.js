// Re-plan budget starvation: N zombies from the test tool, the player walks back and forth between two tiles
// (taps when it arrives). The game loop is asleep; GameScene is stepped with a fixed frame time.
// node starve.js <nZombies> <deltaMs> <speed 1|3> [seconds]
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const N = +(process.argv[2] || 14), delta = +(process.argv[3] || 100), speed = +(process.argv[4] || 3), secs = +(process.argv[5] || 60);
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { G } = T;
  const r = await G(([N, delta, speed, secs]) => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, E = s.enemies;
    let rs = 12345; Math.random = () => { rs = (rs * 1103515245 + 12345) & 0x7fffffff; return rs / 0x80000000; };
    g.loop.sleep();
    if (speed === 3 && s.debugSpeed === 1) s.debugToggleSpeed();
    for (let i = 0; i < N; i++) s.debugZombie();
    // two tiles 6 apart on open ground near the start
    const A = { col: p.tile.col, row: p.tile.row }, B = { col: p.tile.col - 6, row: p.tile.row };
    const ok = s.map.isWalkable(B.col, B.row);
    let time = 1000, gt = 0, goB = true;
    const st = E.list.map(() => ({ wantSince: null, maxWant: 0, still: 0, maxStill: 0, last: null, repaths: 0 }));
    const proto = Object.getPrototypeOf(E.list[0]); const orig = proto.repath;
    proto.repath = function (t, k) { st[E.list.indexOf(this)].repaths++; return orig.call(this, t, k); };
    const frames = Math.round(secs / (Math.min(delta / 1000, 0.1) * speed));
    for (let f = 0; f < frames; f++) {
      if (!p.moving) { const t = goB ? B : A; s.walkTo(t.col, t.row); goB = !goB; }
      time += delta; s.sys.step(time, delta);
      const dt = Math.min(delta / 1000, 0.1) * s.speed; gt += dt;
      E.list.forEach((e, i) => {
        const x = st[i];
        if (e.wantPath && e.repathLeft <= 0) { x.wantSince = x.wantSince === null ? gt : x.wantSince; x.maxWant = Math.max(x.maxWant, gt - x.wantSince); } else x.wantSince = null;
        const pos = e.col + ',' + e.row;
        const near = e.nextTo(E.target());
        if (pos === x.last && !near && !e.smashing) { x.still += dt; x.maxStill = Math.max(x.maxStill, x.still); } else x.still = 0;
        x.last = pos;
      });
      if (s.hearts.value < 3) { s.hearts.value = 5; }
    }
    return { ok, frames, gameSeconds: +gt.toFixed(1), perZombie: st.map((x, i) => `#${i}: repaths ${x.repaths}, longest wait for a re-plan ${x.maxWant.toFixed(1)}s, longest stand-still away ${x.maxStill.toFixed(1)}s`) };
  }, [N, delta, speed, secs]);
  console.log(`N=${N} delta=${delta}ms speed x${speed}:`, JSON.stringify({ ok: r.ok, frames: r.frames, gameSeconds: r.gameSeconds }));
  for (const l of r.perZombie) console.log('  ' + l);
  console.log('errors', JSON.stringify(T.errors.slice(0, 3)));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
