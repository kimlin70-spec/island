// Static map check: which open tiles (now, or after a tree/rock is used up) cannot be reached from the start,
// although they touch a reachable tile (8 directions). Uses the zombie rule: diagonal step needs both side tiles open.
const m = require('/home/user/island/data/map.json');
const C = m.cols, R = m.rows;
const block = new Set(m.objects.map((o) => o.col + ',' + o.row));
const kindAt = {}; for (const o of m.objects) kindAt[o.col + ',' + o.row] = o.kind;
const land = (c, r) => c >= 0 && r >= 0 && c < C && r < R && m.terrain[r][c] !== 0;
const openWith = (extra) => (c, r) => land(c, r) && (!block.has(c + ',' + r) || extra.has(c + ',' + r));
function reach(open, start) {
  const seen = new Set([start.col + ',' + start.row]), q = [start];
  while (q.length) {
    const { col: c, row: r } = q.shift();
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      if (!dr && !dc) continue;
      const nc = c + dc, nr = r + dr, k = nc + ',' + nr;
      if (seen.has(k) || !open(nc, nr)) continue;
      if (dc && dr && (!open(c + dc, r) || !open(c, r + dr))) continue;
      seen.add(k); q.push({ col: nc, row: nr });
    }
  }
  return seen;
}
const start = m.playerStart;
const base = reach(openWith(new Set()), start);
// natural pockets: open land not reachable that touches a reachable tile
const natural = [];
for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
  const k = c + ',' + r;
  if (!openWith(new Set())(c, r) || base.has(k)) continue;
  let touches = false;
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if ((dr || dc) && base.has((c + dc) + ',' + (r + dr))) touches = true;
  if (touches) natural.push(k);
}
console.log('reachable open tiles from start:', base.size);
console.log('natural unreachable open tiles touching a reachable tile:', natural.length, natural.join(' '));
// each tree/rock used up alone: is its tile reachable?
const choppable = m.objects.filter((o) => ['tree', 'pine', 'palm', 'rock'].includes(o.kind));
const walled = [];
for (const o of choppable) {
  const k = o.col + ',' + o.row;
  // must touch a reachable tile (the player stands there to chop it)
  let touches = false;
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if ((dr || dc) && base.has((o.col + dc) + ',' + (o.row + dr))) touches = true;
  if (!touches) continue;
  const open = openWith(new Set([k]));
  const rr = reach(open, start);
  if (!rr.has(k)) walled.push(k + '(' + o.kind + ', ' + Math.hypot(o.col - start.col, o.row - start.row).toFixed(0) + ' from start)');
}
console.log('trees/rocks that leave a walled-in stump/rubble when used up alone:', walled.length + ' of ' + choppable.length);
console.log(walled.join('\n'));
