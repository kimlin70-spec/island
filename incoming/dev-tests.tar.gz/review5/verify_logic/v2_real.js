// logic-2 in the real game loop with real clicks: "속도 x3", "좀비 1마리 부르기" xN, then ground clicks back and forth.
// State-only shortcuts: zombies get 999 hp and hurtPlayer does nothing (so nobody dies and the run keeps going).
const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
const N = +(process.argv[2] || 8), SECS = +(process.argv[3] || 25);
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); window.__all = []; s.hurtPlayer = () => {};
    const o = s.enemies.spawn.bind(s.enemies); s.enemies.spawn = (k) => { const e = o(k); if (e) { e.hp = e.maxHp = 999; window.__all.push(e); } return e; }; });
  await T.testItem(4);
  for (let i = 0; i < N; i++) await T.testItem(3);
  await G(() => { const s = window.__game.scene.getScene('game'); window.__d = []; window.__rp = new Map();
    const proto = Object.getPrototypeOf(window.__all[0]), orig = proto.repath;
    proto.repath = function (t, k) { window.__rp.set(this, (window.__rp.get(this) || 0) + 1); return orig.call(this, t, k); };
    window.__all.forEach((e) => { e.__start = [e.col, e.row]; });
    s.events.on('postupdate', (t, d) => window.__d.push(d)); });
  const A = await G(() => { const p = window.__game.scene.getScene('game').player; return [p.tile.col, p.tile.row]; });
  const B = [A[0] - 6, A[1]];
  const t0 = Date.now(); let goB = true, clicks = 0;
  while (Date.now() - t0 < SECS * 1000) {
    if (!(await G(() => window.__game.scene.getScene('game').player.moving))) {
      const t = goB ? B : A; goB = !goB; await T.tapWorld((t[0] - t[1]) * 40, (t[0] + t[1]) * 20); clicks++;
    }
    await page.waitForTimeout(50);
  }
  const r = await G(() => { const s = window.__game.scene.getScene('game'), d = window.__d, p = s.player;
    return { fps: +(1000 / (d.reduce((a, b) => a + b, 0) / d.length)).toFixed(1), speed: s.debugSpeed, gameTime: +s.elapsed.toFixed(1),
      z: window.__all.map((e, i) => `#${i}: re-plans ${window.__rp.get(e) || 0}, moved ${Math.hypot(e.col - e.__start[0], e.row - e.__start[1]).toFixed(1)} tiles from where it appeared, ${Math.hypot(e.col - p.col, e.row - p.row).toFixed(1)} tiles from the player`) }; });
  console.log(`real loop: ${r.fps} fps, test speed x${r.speed}, ${N} zombies from the test button, ${clicks} ground clicks, game time now ${r.gameTime}s`);
  for (const l of r.z) console.log('  ' + l);
  console.log('console:', JSON.stringify(T.errors.slice(0, 3)));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
