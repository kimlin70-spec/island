const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); window.__press = [];
    const op = s.onPress.bind(s); s.input.off('pointerdown'); s.input.on('pointerdown', (p) => { window.__press.push([p.worldX, p.worldY]); op(p); }); });
  const p1 = await T.tapWorld((35 - 28) * 40, (35 + 28) * 20);
  console.log('ground click page pos', JSON.stringify(p1));
  await page.waitForTimeout(500);
  console.log(JSON.stringify(await G(() => { const s = window.__game.scene.getScene('game'); return { press: window.__press, tile: [s.player.tile.col, s.player.tile.row], moving: s.player.moving, path: s.player.path.length }; })));
  await W(() => !window.__game.scene.getScene('game').player.moving, null, 60000);
  await page.waitForTimeout(1500);
  console.log(JSON.stringify(await G(() => { const s = window.__game.scene.getScene('game'); const c = s.cameras.main; return { tile: [s.player.tile.col, s.player.tile.row], cam: [c.midPoint.x, c.midPoint.y], fps: window.__game.loop.actualFps }; })));
  const pt = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), o = s.map.objects.find((x) => x.col === c && x.row === r);
    const sp = o.sprite, left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY;
    const cx = left + sp.displayWidth / 2, cy = top + sp.displayHeight * 0.7; let best = null;
    for (let y = top; y < top + sp.displayHeight; y += 3) for (let x = left; x < left + sp.displayWidth; x += 3)
      if (s.map.pickObject(x, y) === o && !s.enemies.pickAt(x, y)) { const d = Math.hypot(x - cx, y - cy); if (!best || d < best.d) best = { x, y, d }; }
    return { kind: o.kind, best, sprite: [sp.x, sp.y, sp.displayWidth, sp.displayHeight, sp.originX, sp.originY] }; }, [39, 22]);
  console.log('pick point', JSON.stringify(pt));
  const p2 = await T.tapWorld(pt.best.x, pt.best.y);
  console.log('tree click page pos', JSON.stringify(p2));
  await page.waitForTimeout(500);
  console.log(JSON.stringify(await G(() => { const s = window.__game.scene.getScene('game'), pr = window.__press[window.__press.length - 1]; const o = s.map.pickObject(pr[0], pr[1]);
    return { press: window.__press, picked: o ? [o.kind, o.col, o.row] : null, tool: o ? s.nodes.toolFor(o) : null, action: s.player.action ? s.player.action.target.kind : null, moving: s.player.moving }; })));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
