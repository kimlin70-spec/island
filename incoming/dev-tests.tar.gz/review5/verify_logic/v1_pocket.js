// logic-1 check, real game loop and real clicks only:
// click the tree at (39,22) (dagger only, no shortcuts), wait until it is a stump, then press
// "좀비 1마리 부르기" in the test window 5 times, and watch every zombie.
const { setup } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
const COL = +(process.argv[2] || 39), ROW = +(process.argv[3] || 22), NZ = +(process.argv[4] || 5), SECS = +(process.argv[5] || 36);
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); window.__fail = new Map(); window.__ok = new Map();
    const proto = Object.getPrototypeOf(s.enemies); const sp = s.enemies.spawn.bind(s.enemies);
    s.enemies.spawn = (k) => { const e = sp(k); if (e && !e.__hooked) { e.__hooked = true; const rp = e.repath.bind(e);
      e.repath = (t, key) => { rp(t, key); const m = e.wantPath ? window.__fail : window.__ok; m.set(e, (m.get(e) || 0) + 1); }; } return e; }; });
  // first walk closer (a click on the ground) so the tree is in the middle of the screen, not under the to-do panel
  await T.tapWorld((35 - 28) * 40, (35 + 28) * 20);
  await page.waitForTimeout(300);
  await W(() => !window.__game.scene.getScene('game').player.moving, null, 60000);
  await page.waitForTimeout(1500);   // camera catches up
  // a point on the tree picture that a click picks (the game's own pick rule), with every point 6 px around it picking it too
  await W(() => { const s = window.__game.scene.getScene('game'), c = s.cameras.main, sp = s.player.sprite;
    return Math.hypot(c.midPoint.x - sp.x, c.midPoint.y - sp.y) < 1; }, null, 60000);   // camera has caught up
  const pt = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), o = s.map.objects.find((x) => x.col === c && x.row === r);
    const sp = o.sprite, left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY;
    const good = (x, y) => s.map.pickObject(x, y) === o && !s.enemies.pickAt(x, y);
    let best = null;
    for (let y = top; y < top + sp.displayHeight; y += 2) for (let x = left; x < left + sp.displayWidth; x += 2) {
      if (!good(x, y)) continue;
      let all = true; for (let dy = -6; dy <= 6 && all; dy += 3) for (let dx = -6; dx <= 6 && all; dx += 3) if (!good(x + dx, y + dy)) all = false;
      if (all) { best = { x, y }; break; }
    }
    return { kind: o.kind, best }; }, [COL, ROW]);
  console.log('target', COL, ROW, pt.kind, 'click at world', pt.best && [pt.best.x, pt.best.y]);
  await T.tapWorld(pt.best.x, pt.best.y);
  await page.waitForTimeout(300);
  console.log('after click: player action =', await G(() => { const p = window.__game.scene.getScene('game').player; return p.action ? (p.action.target.kind) : null; }));
  await W(([c, r]) => { const s = window.__game.scene.getScene('game'), o = s.map.objects.find((x) => x.col === c && x.row === r);
    return o && o.kind === 'stump' && !s.player.action && !s.player.moving; }, [COL, ROW], 180000);
  const at = await G(() => { const s = window.__game.scene.getScene('game'); return { tile: [s.player.tile.col, s.player.tile.row], t: +s.elapsed.toFixed(1), wood: s.inventory.count ? s.inventory.count('wood') : undefined }; });
  console.log('tree is a stump; player stands at', JSON.stringify(at));
  for (let i = 0; i < NZ; i++) await T.testItem(3);           // 좀비 1마리 부르기 (real clicks)
  const t0 = Date.now(), rows = [];
  while (Date.now() - t0 < SECS * 1000) {
    rows.push(await G(() => { const s = window.__game.scene.getScene('game'), E = s.enemies, tg = E.target();
      const all = [];   // every goal tile around the target (no "taken" filter)
      for (const t of tg.tiles) for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { const c = t.col + dc, r = t.row + dr;
        if ((dc || dr) && E.list[0] && E.list[0].costAt(c, r)) all.push({ col: c, row: r }); }
      return { t: +s.elapsed.toFixed(1), active: window.__game.scene.isActive('game'), p: [s.player.tile.col, s.player.tile.row], hearts: s.hearts.value, defeated: E.defeated,
        z: E.list.map((e) => { const goals = e.goalsAround(tg.tiles); const end = e.path[e.path.length - 1];
          return { id: e.__id || (e.__id = 'z' + (window.__zid = (window.__zid || 0) + 1)), at: [+e.col.toFixed(2), +e.row.toFixed(2)], end: end ? [end.col, end.row] : null,
            want: e.wantPath, next: e.nextTo(tg), goals: goals.map((g) => g.col + ',' + g.row + (e.findRoute([g]) ? '' : '(no way)')).join(' '),
            route: !!e.findRoute(goals), routeAll: !!e.findRoute(all), fails: window.__fail.get(e) || 0, oks: window.__ok.get(e) || 0 }; }) }; }));
    await page.waitForTimeout(3000);
  }
  for (const r of rows) console.log(`t=${r.t}s active=${r.active} player ${r.p} hearts ${r.hearts} defeated ${r.defeated}\n` +
    r.z.map((z) => `   ${z.id}: at ${z.at} pathEnd ${z.end} want ${z.want} nextToPlayer ${z.next} goals [${z.goals}] route ${z.route} routeWithTakenTiles ${z.routeAll} repaths ok/failed ${z.oks}/${z.fails}`).join('\n'));
  // A* cost of one failed search
  const ms = await G(() => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[0]; if (!e) return null;
    const t0 = performance.now(); for (let i = 0; i < 50; i++) e.findRoute([{ col: 39, row: 22 }]); return +((performance.now() - t0) / 50).toFixed(2); });
  console.log('one failed route search (walled-in stump as the only goal):', ms, 'ms');
  console.log('console:', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
