// Spec review 2: 3.5 "좀비와 해적이 때릴 때는 attack 프레임을 0.3초 보여 준다."
// Record, per frame (game time), the zombie's shown frame around each structure hit, especially the blow that breaks the fence.
const { setup } = require('../../p5/lib5.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  await G(() => {
    const s = window.__game.scene.getScene('game'), p = s.player;
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row + dr }]);
    window.__log = [];
    const origHit = s.enemies.hitStructure.bind(s.enemies);
    s.enemies.hitStructure = (e, st) => { window.__log.push(['HIT', +s.elapsed.toFixed(3), st.type, st.hp - 1]); return origHit(e, st); };
    const origHP = s.enemies.hitPlayer.bind(s.enemies);
    s.enemies.hitPlayer = (e) => { window.__log.push(['HITPLAYER', +s.elapsed.toFixed(3)]); return origHP(e); };
    s.events.on('postupdate', () => {
      const e = s.enemies.list[0]; if (!e) return;
      window.__log.push(['f', +s.elapsed.toFixed(3), e.sprite.frame.name, e.sprite.anims.isPlaying ? 'anim' : 'still', e.moving ? 'mv' : 'st']);
    });
    s.debugZombie();
    s.debugSpeed = 3; s.events.emit('speed-changed');
  });
  // wait until the zombie is close (smashing starts), then go to x1
  await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.smashing), null, 120000);
  await G(() => { const s = window.__game.scene.getScene('game'); s.debugSpeed = 1; s.events.emit('speed-changed'); window.__log = []; });
  await W(() => window.__game.scene.getScene('game').build.count('fence') === 7, null, 60000);
  await page.waitForTimeout(1500);
  const log = await G(() => window.__log);
  // summarize: for each HIT, how long the attack frame (frame index 2) was shown afterwards (game time)
  const out = [];
  for (let i = 0; i < log.length; i++) {
    if (log[i][0] !== 'HIT' && log[i][0] !== 'HITPLAYER') continue;
    const t0 = log[i][1];
    let last = null, frames = 0;
    for (let j = i + 1; j < log.length; j++) {
      if (log[j][0] !== 'f') continue;
      if (log[j][2] === 2) { last = log[j][1]; frames++; } else break;
    }
    out.push({ hit: log[i], attackShownFor: last === null ? 0 : +(last - t0).toFixed(3), framesWithAttack: frames });
  }
  console.log(J(out, null, 0));
  // show the frames right after the breaking hit
  const bi = log.findIndex((x) => x[0] === 'HIT' && x[3] === 0);
  console.log('around the breaking blow:', J(log.slice(Math.max(0, bi - 3), bi + 12)));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
