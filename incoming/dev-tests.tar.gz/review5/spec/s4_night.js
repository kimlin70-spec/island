// Spec review 4: a full first night at 60 fps (stepped), several camp layouts.
// For each zombie: spawn time and place, time it first stands next to its target, hits.
// Looks for zombies that never reach their target (stuck) and checks hits/notice/speed rules.
const { setup } = require('../../p5/lib5.js');
const J = JSON.stringify;
const layout = process.argv[2] || 'open';
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  const R = await G((layout) => {
    const g = window.__game; g.loop.sleep();
    let now = performance.now();
    const step = (n, ms = 1000 / 60) => { for (let i = 0; i < n; i++) { now += ms; g.scene.update(now, ms); } };
    const s = g.scene.getScene('game'), p = s.player, m = s.map;
    const notes = []; s.events.on('notice', (t) => notes.push([+s.elapsed.toFixed(1), t]));
    s.hearts.max = 99; s.hearts.value = 99;   // keep the player alive to watch the whole night
    const pc = p.tile.col, pr = p.tile.row;
    if (layout === 'ring' || layout === 'tent') {
      // 7x7 ring of fences around the player (radius 3)
      for (let dc = -3; dc <= 3; dc++) for (let dr = -3; dr <= 3; dr++) {
        if (Math.max(Math.abs(dc), Math.abs(dr)) !== 3) continue;
        if (m.isOpen(pc + dc, pr + dr) && !m.structureAt(pc + dc, pr + dr)) s.build.place('fence', [{ col: pc + dc, row: pr + dr }]);
      }
      s.build.place('campfire', [{ col: pc - 1, row: pr - 1 }]);
    }
    if (layout === 'tent') {
      s.build.place('tent', [{ col: pc + 1, row: pr - 1 }, { col: pc + 2, row: pr - 1 }, { col: pc + 1, row: pr }, { col: pc + 2, row: pr }]);
      const tent = m.structures.find((x) => x.type === 'tent');
      s.rest.enter(tent);
    }
    const info = new Map();
    const speeds = {};
    s.debugNight();
    let frames = 0;
    while (s.clock.isNight && frames < 60 * 200) {
      step(1); frames++;
      if (!g.scene.isActive('game')) break;
      const key = s.speed; speeds[key] = (speeds[key] || 0) + 1;
      for (const e of s.enemies.list) {
        if (!info.has(e)) info.set(e, { spawnT: +s.elapsed.toFixed(1), at: [e.col, e.row], firstNext: null, smashT: 0, standT: 0, hitP: 0, maxStill: 0, still: 0, last: [e.col, e.row] });
        const I = info.get(e);
        const tgt = s.enemies.target();
        if (I.firstNext === null && e.nextTo(tgt) && !e.moving) I.firstNext = +s.elapsed.toFixed(1);
        if (e.smashing) I.smashT += 1 / 60;
        // time standing still while not next to target and not smashing
        const movedNow = e.col !== I.last[0] || e.row !== I.last[1];
        I.last = [e.col, e.row];
        if (!movedNow && !e.smashing && !e.nextTo(tgt)) { I.still += 1 / 60; I.maxStill = Math.max(I.maxStill, I.still); } else I.still = 0;
      }
    }
    const zs = [...info.values()].map((I) => ({ spawnT: I.spawnT, at: I.at, firstNext: I.firstNext, smash: +I.smashT.toFixed(1), maxStill: +I.maxStill.toFixed(2) }));
    return { layout, frames, zs, notes, speeds, hearts: s.hearts.value, defeated: s.enemies.defeated, structures: m.structures.map((x) => x.type + ':' + x.hp).join(' '), resting: s.rest.resting };
  }, layout);
  console.log(J(R));
  console.log('bad', J(await T.bad()));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
