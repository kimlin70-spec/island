// Spec review 1: debug window + craft window layout (both open), text of the debug items
const { setup, UI } = require('../../p5/lib5.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  // open the craft window and the test window (real clicks)
  await T.ui(...UI.craft);
  await T.ui(...UI.test);
  const info = await G(() => {
    const u = window.__game.scene.getScene('ui');
    const cw = u.craftWin, dw = u.debugWin;
    const cb = cw.getBounds(), db = dw.getBounds();
    return {
      craft: { x: cb.x, y: cb.y, w: cb.width, h: cb.height, depth: cw.depth, idx: u.children.getIndex(cw) },
      debug: { x: db.x, y: db.y, w: db.width, h: db.height, depth: dw.depth, idx: u.children.getIndex(dw) },
      items: u.debugLabels.map((d) => d.label.text),
      overlapY: Math.min(cb.y + cb.height, db.y + db.height) - Math.max(cb.y, db.y),
      overlapX: Math.min(cb.x + cb.width, db.x + db.width) - Math.max(cb.x, db.x),
    };
  });
  console.log(J(info, null, 1));
  await page.screenshot({ path: __dirname + '/s1_both_open.png' });
  await page.screenshot({ path: __dirname + '/s1_both_open_crop.png', clip: { x: 1300, y: 300, width: 620, height: 520 } });
  // click on the craft window's top-right area where the debug window overlaps: what does it hit?
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
