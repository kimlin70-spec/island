// Spec review 3: deterministic 60 fps stepping. Checks pictures and "what is shown when" for zombies:
// spawn poof, walk anim (walk1/walk2 at 6 fps), standing walk1, flip when walking screen-left, face target,
// hit: shake 3 px 0.1 s, fx_hit 0.15 s, white flash 0.1 s, hp bar only when damaged, death poof,
// tall object goes half transparent when a zombie is behind it, night 2 count, day 3 morning notice.
const { setup } = require('../../p5/lib5.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await G(() => {
    const g = window.__game; g.loop.sleep();
    window.__t = performance.now();
    window.__step = (n, ms = 1000 / 60) => { for (let i = 0; i < n; i++) { window.__t += ms; g.scene.update(window.__t, ms); } };
    const s = g.scene.getScene('game');
    window.__notes = []; s.events.on('notice', (t) => window.__notes.push([+s.elapsed.toFixed(2), t]));
  });
  const R = {};
  // 1. spawn: poof appears (an fx_poof image at depth 50000)
  R.spawn = await G(() => {
    const s = window.__game.scene.getScene('game');
    const before = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_poof').length;
    const e = s.enemies.spawn();
    const poofs = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_poof');
    return { at: [e.col, e.row], poofNew: poofs.length - before, poofDepth: poofs.map((p) => p.depth), frame: e.sprite.frame.name, bar: !!e.bar };
  });
  // 2. walking: record frames and flips for 3 s
  R.walk = await G(() => {
    const s = window.__game.scene.getScene('game'), e = s.enemies.list[0];
    const frames = [], flips = [];
    let wrongFlip = 0, n = 0;
    for (let i = 0; i < 180; i++) {
      const c0 = e.col, r0 = e.row;
      window.__step(1);
      const dsx = (e.col - c0) - (e.row - r0);
      if (e.moving && Math.abs(dsx) > 1e-6) { n++; if ((dsx < 0) !== e.sprite.flipX) wrongFlip++; }
      frames.push(e.sprite.frame.name);
    }
    // frame changes per second while walking
    let changes = 0; for (let i = 1; i < frames.length; i++) if (frames[i] !== frames[i - 1]) changes++;
    return { uniq: [...new Set(frames)], changesIn3s: changes, wrongFlip, n, anim: e.sprite.anims.currentAnim && e.sprite.anims.currentAnim.key, bar: !!e.bar };
  });
  // 3. bring the zombie next to the player and let it stand; check walk1 standing frame and facing the player
  R.stand = await G(() => {
    const s = window.__game.scene.getScene('game'), e = s.enemies.list[0], p = s.player;
    let i = 0; while (i++ < 60 * 60 && !(e.hitLeft !== null)) window.__step(1);
    const out = { steps: i, frame: e.sprite.frame.name, moving: e.moving, facingOk: (p.sprite.x - e.sprite.x < 0) === e.sprite.flipX || Math.abs(p.sprite.x - e.sprite.x) < 1,
      dz: [e.tile.col - p.tile.col, e.tile.row - p.tile.row] };
    // the player auto attacks? (player idle -> auto attack)
    out.playerAction = p.action ? 'enemy' : null;
    return out;
  });
  // 4. hit effects on the zombie: watch the first strike
  R.hit = await G(() => {
    const s = window.__game.scene.getScene('game'), e = s.enemies.list[0];
    const hp0 = e.hp; let i = 0;
    while (i++ < 600 && e.hp === hp0) window.__step(1);
    const t0 = s.elapsed;
    const base = (e.col - e.row) * 40;
    const log = [];
    const hits = () => s.children.list.filter((o) => o.texture && o.texture.key === 'fx_hit' && o.active).length;
    for (let k = 0; k < 15; k++) {
      log.push({ t: +(s.elapsed - t0).toFixed(3), dx: +(e.sprite.x - (e.col - e.row) * 40).toFixed(1), tint: e.sprite.isTinted && e.sprite.tintFill, fxhit: hits(), bar: !!(e.bar && e.bar.g.visible) });
      window.__step(1);
    }
    return { hpNow: e.hp, log };
  });
  // 5. kill it: poof, defeated
  R.kill = await G(() => {
    const s = window.__game.scene.getScene('game'), e = s.enemies.list[0];
    let i = 0; while (i++ < 1200 && e.alive) window.__step(1);
    const poofs = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_poof' && o.active).length;
    return { alive: e.alive, defeated: s.enemies.defeated, poofs, barGone: !e.bar, hearts: s.hearts.value };
  });
  // 6. occlusion: put a zombie behind a tree (tree in front) and step
  R.occl = await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    // find a tree whose tile (col-1,row-1) is walkable land (behind it on screen)
    const tree = m.objects.find((o) => o.kind === 'tree' && o.tall && m.isWalkable(o.col - 1, o.row - 1) && Math.hypot(o.col - s.player.col, o.row - s.player.row) > 14);
    const e = s.enemies.spawn();
    e.col = tree.col - 1; e.row = tree.row - 1; e.tile = { col: e.col, row: e.row }; e.path.length = 0; e.wantPath = false; e.repathLeft = 99;
    window.__step(20);
    return { tree: [tree.col, tree.row], alpha: +tree.sprite.alpha.toFixed(2), zDepth: e.sprite.depth, treeDepth: tree.sprite.depth };
  });
  // 7. night count on day 2 and 3, day 3 morning notice
  R.nights = await G(() => {
    const s = window.__game.scene.getScene('game');
    s.enemies.clearAll();
    const out = {};
    s.debugNight(); out.n1 = s.enemies.schedule.length; out.sched1 = s.enemies.schedule.map((x) => +x.toFixed(1));
    s.debugMorning(); window.__step(200);
    out.paused = !window.__game.scene.isActive('game');
    const u = window.__game.scene.getScene('ui'); out.modal = u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : null;
    window.__game.scene.getScene('game').resumeGame(); u.closeModal(); window.__step(2);
    s.debugNight(); out.n2 = s.enemies.schedule.length + s.enemies.list.length; out.label2 = s.clock.label;
    s.debugMorning(); window.__step(200);
    out.paused2 = !window.__game.scene.isActive('game');
    out.label3 = s.clock.label;
    out.notes = window.__notes.map((x) => x[1]).slice(-6);
    for (let d = 3; d <= 8; d++) { s.debugNight(); out['n' + d] = s.enemies.schedule.length + s.enemies.list.length; s.debugMorning(); }
    return out;
  });
  console.log(J(R, null, 1));
  await G(() => window.__game.loop.wake());
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
