// Session B: touch 1024x768 (tablet). Build a camp, night, fight by tapping, rest in the tent while zombies attack it,
// come out, get careless (chop trees at night) until down, 다시 시작.
const { setup, installFreeze, installTrace, zombieScreen, UI } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G } = T;
  await T.monitor();
  await installFreeze(T);
  await installTrace(T);
  await T.testItem(0);
  // tent, campfire, 8 fences (touch taps)
  await T.card(4);
  await T.tapWorld((39.5 - 37.5) * 40, (39.5 + 37.5) * 20, 300);
  await T.card(3);
  await T.tapTileW(36, 37, 300);
  await T.card(2);
  for (let c = 35; c <= 42; c++) await T.tapTileW(c, 36, 150);
  await T.shot('B01_build_touch');
  await T.closeCraft();
  let st = await T.state();
  log('camp', J(st.structs), J(st.inv), st.notice);
  await T.shot('B02_camp');
  // night, x3
  await T.testItem(1);
  await T.testItem(4);
  let t0 = Date.now();
  while (Date.now() - t0 < 120000) {
    st = await T.state();
    if (st.z.some((z) => Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]) < 7)) break;
    await page.waitForTimeout(500);
  }
  await T.testItem(4);
  st = await T.state();
  log('zombie near', J(st.z), 'clock', st.clockT);
  // tap the nearest zombie (touch)
  for (let k = 0; k < 6; k++) {
    st = await T.state();
    const order = st.z.map((z, i) => [Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]), i]).sort((a, b) => a[0] - b[0]);
    if (!order.length) break;
    const zs = await zombieScreen(T, order[0][1]);
    if (zs && zs.on) { await T.tapPage(zs.x, zs.y); log('tap zombie d', order[0][0].toFixed(1)); }
    await page.waitForTimeout(400);
    st = await T.state();
    if (st.action === 'zombie') break;
  }
  const hc = await T.capture(['hit'], 'B03_touch_fight_hit', 20000);
  log('hit', J(hc && hc.st.z));
  await page.waitForFunction(() => { const p = window.__game.scene.getScene('game').player; return !p.action; }, null, { timeout: 30000 });
  st = await T.state();
  log('after fight', J({ hearts: st.hearts, def: st.defeated, z: st.z }));
  // tap the tent to rest
  const tent = await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return { wx: t.sprite.x, wy: t.sprite.y - 60 }; });
  await T.tapWorld(tent.wx, tent.wy, 0);
  await page.waitForFunction(() => window.__game.scene.getScene('game').rest.resting, null, { timeout: 30000 });
  await page.waitForTimeout(500);
  await T.shot('B04_resting');
  st = await T.state();
  log('resting', st.resting, 'speed', st.speed, 'notice', st.notice);
  // wait until a zombie hits the tent (x3 test speed while waiting)
  await T.testItem(4);
  const sc = await T.capture(['smash'], 'B05_tent_smash', 150000);
  log('smash', J(sc && { info: sc.info, z: sc.st.z, speed: sc.st.speed, notice: sc.st.notice }));
  await T.testItem(4);
  await page.waitForTimeout(1500);
  await T.shot('B06_tent_attacked');
  st = await T.state();
  log('tent attacked', J({ notice: st.notice, structs: st.structs.filter((x) => x.startsWith('tent')), z: st.z, speed: st.speed, hearts: st.hearts }));
  // come out with the rest button (bottom middle)
  const rb = await G(() => { const u = window.__game.scene.getScene('ui'); const bg = u.restBox.list[0]; const r = bg.input.hitArea; return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; });
  await T.ui(rb.x, rb.y, 500);
  st = await T.state();
  log('out of the tent', J({ resting: st.resting, tile: st.tile, z: st.z.map((z) => z.tile) }));
  await T.shot('B07_out');
  // careless: chop trees with the dagger while zombies hit (no auto attack while chopping)
  t0 = Date.now();
  let lastTree = 0;
  while (Date.now() - t0 < 180000) {
    st = await T.state();
    if (!st.active) break;
    if (!st.action || st.action === 'zombie') {
      // tap the nearest tree that is on screen
      const tr = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
        const list = s.map.objects.filter((o) => o.node && ['tree', 'pine', 'palm'].includes(o.kind)).sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
        const o = list[0]; return o ? { wx: o.sprite.x, wy: o.sprite.y - 50, at: [o.col, o.row] } : null; });
      if (tr) { const pp = await T.w2p(tr.wx, tr.wy); if (pp.on) { await T.tapPage(pp.x, pp.y); lastTree = Date.now(); } }
    }
    await page.waitForTimeout(700);
  }
  st = await T.state();
  log('down?', J({ active: st.active, hearts: st.hearts, modal: st.modal, z: st.z.length }));
  await page.waitForTimeout(500);
  await T.shot('B08_down');
  log('monitor', J(await T.mon()));
  // 다시 시작
  await G(() => { window.__marker = 1; });
  await T.modalButton('다시 시작');
  await page.waitForFunction(() => window.__marker === undefined && window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  await page.waitForTimeout(800);
  st = await T.state();
  log('after restart', J({ hearts: st.hearts, label: st.label, z: st.z.length, structs: st.structs, inv: st.inv, notice: st.notice }));
  await T.shot('B09_restarted');
  console.log('errors', J(T.errors), 'bad', J(await T.bad().catch(() => 'n/a')));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
