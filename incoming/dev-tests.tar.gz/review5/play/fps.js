const { setup } = require('./pl.js');
(async () => {
  for (const [w, h, touch] of [[1920, 1200, false], [1024, 768, true]]) {
    const T = await setup({ w, h, touch });
    const { page, G } = T;
    await page.waitForTimeout(1000);
    const f0 = await G(() => window.__game.loop.frame), t0 = Date.now();
    await page.waitForTimeout(4000);
    const f1 = await G(() => window.__game.loop.frame);
    console.log(w, h, 'fps', ((f1 - f0) / ((Date.now() - t0) / 1000)).toFixed(1));
    // cost of one manual step
    const c = await G(() => { const g = window.__game; g.loop.sleep(); const t0 = performance.now(); let t = g.loop.now || performance.now();
      for (let i = 0; i < 10; i++) { t += 16.7; g.step(t, 16.7); } const ms = (performance.now() - t0) / 10; g.loop.wake(); return ms; });
    console.log('manual step ms', c.toFixed(1));
    console.log('errors', JSON.stringify(T.errors));
    await T.browser.close();
  }
})();
