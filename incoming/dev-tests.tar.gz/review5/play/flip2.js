// Zombie stops straight above the player on screen (grid diagonal neighbour); the standing player auto-attacks it.
// Track the zombie's flipX each 60 Hz frame and capture the frame right after a dagger hit.
const { setup, installFreeze, installTrace, installDriver } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installFreeze(T);
  await installDriver(T, 0.5);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.spawnPoint = () => ({ col: 33, row: 35 });
    window.__fl = []; let last = null;
    s.events.on('postupdate', () => { const e = s.enemies.list[0]; if (!e) return; const f = e.sprite.flipX;
      if (f !== last) { window.__fl.push([+s.elapsed.toFixed(3), f ? 'left' : 'right', e.tile.col + ',' + e.tile.row, e.moving ? 'walking' : 'standing', 'hp' + e.hp, 'x' + Math.round(e.sprite.x), 'px' + Math.round(s.player.sprite.x)]); last = f; } }); });
  await T.testItem(3);   // real click: 좀비 1마리 부르기 (spawn point forced to 33,35 for the test)
  const c = await T.capture(['hit'], 'F2_hit_vertical', 60000);
  // crop the zombie right at that frame
  console.log('flip changes [t, facing, tile, walking?, hp, zombie x, player x]:', J(await G(() => window.__fl)));
  await page.waitForFunction(() => window.__game.scene.getScene('game').enemies.list.length === 0, null, { timeout: 60000 });
  console.log('flip changes (whole fight):', J(await G(() => window.__fl)));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
