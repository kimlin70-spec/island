// 14 zombies (test tool, real clicks) converge on a fenced player; measure the JS cost of GameScene.update per frame.
const { setup, UI } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G } = T;
  await T.testItem(0); await T.testItem(0);
  await T.card(2);
  for (let c = 34; c <= 40; c++) { await T.tapTileW(c, 36, 80); await T.tapTileW(c, 42, 80); }
  for (let r = 37; r <= 41; r++) { await T.tapTileW(34, r, 80); await T.tapTileW(40, r, 80); }
  await T.closeCraft();
  await G(() => { const s = window.__game.scene.getScene('game'); window.__perf = []; let a = 0;
    s.events.on('update', () => { a = performance.now(); });
    s.events.on('postupdate', () => { window.__perf.push([performance.now() - a, s.enemies.list.length]); }); });
  await T.ui(...UI.test);
  for (let i = 0; i < 14; i++) await T.ui(...UI.testItem(3), 100);
  await T.ui(...UI.testItem(4));   // x3
  await T.ui(...UI.testItem(5));
  await page.waitForTimeout(60000);
  const r = await G(() => { const p = window.__perf.filter((x) => x[1] >= 10).map((x) => x[0]).sort((a, b) => a - b);
    return { n: p.length, median: +p[Math.floor(p.length / 2)].toFixed(2), p95: +p[Math.floor(p.length * 0.95)].toFixed(2), max: +p[p.length - 1].toFixed(2) }; });
  const st = await T.state();
  console.log('update ms with >=10 zombies', J(r), 'zombies', st.z.length, 'hearts', st.hearts, 'fences', st.structs.length);
  await T.shot('P1_crowd14');
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
