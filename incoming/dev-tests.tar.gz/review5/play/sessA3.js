// Session A2: mouse 1920x1200, no camp. Night 1; when a zombie is within N tiles, tap it once (like a user) and trace the fight.
const { setup, installFreeze, installTrace, zombieScreen, installDriver } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
const TAPD = +(process.argv[2] || 5);
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await T.monitor();
  await installTrace(T);
  await installDriver(T, 1);
  await T.testItem(1);       // night
  await T.testItem(4);       // x3
  let fast = true;
  const t0 = Date.now();
  const fights = [];
  while (Date.now() - t0 < 240000) {
    const st = await T.state();
    if (!st.active || st.clockT > 140) break;
    const order = st.z.map((z, i) => [Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]), i]).sort((a, b) => a[0] - b[0]);
    if (fast && order.length && order[0][0] < TAPD + 4) { await T.testItem(4); fast = false; }
    if (!fast && st.action !== 'zombie' && order.length && order[0][0] <= TAPD) {
      const i = order[0][1];
      const zs = await zombieScreen(T, i);
      if (zs && zs.on) {
        const te = await T.elapsed();
        await G((t) => window.__tr.ev.push([Math.round(t * 100) / 100, 'TAP', null]), te);
        await page.mouse.click(zs.x, zs.y);
        fights.push(te);
        log('tap zombie at d', order[0][0].toFixed(2), 'hearts', st.hearts);
      }
    }
    if (!fast && !order.length) { await T.testItem(4); fast = true; }
    if (!fast && order.length && order[0][0] > TAPD + 6 && st.action !== 'zombie') { await T.testItem(4); fast = true; }
    await page.waitForTimeout(250);
  }
  const st = await T.state();
  log('end', J({ hearts: st.hearts, def: st.defeated, z: st.z.length, clock: st.clockT }));
  const ev = await T.events();
  log('events', J(ev.filter((e) => e[1] !== 'pressEnemy' || true)));
  // dump trace around each zombie hit on the player
  for (const h of ev.filter((e) => e[1] === 'zhit')) {
    const tr = await T.trace(h[0] - 3, h[0] + 0.2);
    console.log('--- zhit at', h[0], 'by z' + h[2]);
    for (const f of tr.buf) console.log(f.t, 'P', J(f.p), f.pm ? 'mv[' + f.pm + ']' : '', f.act, f.sw || '', 'Z', J(f.z.filter((z) => z[0] === h[2]).map((z) => z.slice(1))));
  }
  log('monitor', J(await T.mon()));
  await T.shot('A3_end');
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
