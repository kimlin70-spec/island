// Same as flipcheck: zombie spawned 2 tiles up-left of the player; the player taps it while it walks in. Both stop on the same tile.
const { setup, installFreeze, installTrace, zombieScreen, installDriver } = require('./pl.js');
const J = JSON.stringify;
const variant = process.argv[2] || 'a';
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installTrace(T);
  await installFreeze(T);
  await installDriver(T, 0.3);
  await T.testItem(1);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.list.slice().forEach((e) => s.enemies.remove(e)); s.enemies.schedule = [];
    s.enemies.spawnPoint = () => ({ col: 34, row: 36 }); s.debugZombie(); });
  await page.waitForFunction(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return e && e.col >= 34.95; }, null, { timeout: 30000, polling: 10 });
  const zs = await zombieScreen(T, 0);
  const capP = T.capture(['hit'], 'O2_hit1', 15000);
  await page.mouse.click(zs.x, zs.y);
  const zAtClick = await G(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return [+e.col.toFixed(2), +e.row.toFixed(2)]; });
  const c1 = await capP;
  console.log('zombie at click ~', J(zAtClick), '| at the first dagger hit: player', J(c1.st.p), 'zombie', J(c1.st.z.map((z) => [z.at, z.mv ? 'moving' : 'standing', z.flip ? 'left' : 'right'])));
  await page.screenshot({ path: __dirname + '/O2_hit1_crop.png', clip: { x: 800, y: 440, width: 320, height: 220 } });
  const c2 = await T.capture(['hit'], 'O2_hit2', 15000);
  console.log('second hit: player', J(c2 && c2.st.p), 'zombie', J(c2 && c2.st.z.map((z) => [z.at, z.mv ? 'moving' : 'standing', z.flip ? 'left' : 'right'])));
  await page.screenshot({ path: __dirname + '/O2_hit2_crop.png', clip: { x: 800, y: 440, width: 320, height: 220 } });
  await page.waitForFunction(() => window.__game.scene.getScene('game').enemies.list.length === 0, null, { timeout: 30000 });
  const tr = await G(() => window.__tr.buf.filter((f) => f.z.length).map((f) => [f.t, f.pt.join(','), f.z[0][1] + ',' + f.z[0][2], f.z[0][3], f.z[0][7]]));
  let last = null; const flips = [];
  for (const f of tr) { if (last !== null && f[4] !== last) flips.push(f); last = f[4]; }
  console.log('zombie flipX changes [t, player tile, zombie pos, moving, flipX]:', J(flips));
  console.log('last frames:', J(tr.slice(-3)));
  console.log('errors', J(T.errors));
  await T.browser.close();
})();
