// Player boxed in by 7 fences and a campfire (NW corner, towards the forest). A night zombie comes; capture it hitting the campfire.
const { setup, installFreeze, installTrace, zombieScreen } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installFreeze(T);
  await installTrace(T);
  await T.testItem(0);
  await T.card(3); await T.tapTileW(36, 38, 300);
  await T.card(2); for (const [c, r] of [[37, 38], [38, 38], [36, 39], [38, 39], [36, 40], [37, 40], [38, 40]]) await T.tapTileW(c, r, 120);
  await T.closeCraft();
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.spawnPoint = () => ({ col: 30, row: 32 }); });
  await T.testItem(1);   // night: first zombie at (30,32) (forced spawn point for the test)
  const c = await T.capture(['smash'], 'C1_smash', 120000);
  console.log('first smash', J(c && c.info));
  const zs = await zombieScreen(T, 0);
  await page.screenshot({ path: __dirname + '/C1_smash_crop.png', clip: { x: zs.x - 160, y: zs.y - 130, width: 320, height: 220 } });
  // wait until it breaks through
  await page.waitForFunction(() => window.__game.scene.getScene('game').enemies.list.length === 0 || window.__game.scene.getScene('game').map.structures.length < 8, null, { timeout: 120000 });
  const st = await T.state();
  console.log('after', J({ structs: st.structs, z: st.z, hearts: st.hearts }));
  const ev = (await T.events()).filter((e) => e[1] === 'zsmash');
  console.log('smash events', J(ev));
  await page.waitForTimeout(500);
  await T.shot('C1_after_break');
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
