// Fence card selected; a zombie walks in; click its own tile, its next tile, and 2 tiles ahead (real clicks, slow game rate).
const { setup, installFreeze, installTrace, installDriver } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await T.monitor();
  await installTrace(T);
  await T.testItem(0);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.spawnPoint = () => ({ col: 29, row: 39 }); });
  await T.testItem(3);
  await T.card(2);
  await installDriver(T, 0.25);
  await page.waitForFunction(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return e && e.col >= 32.3; }, null, { timeout: 120000, polling: 20 });
  const z = await G(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return { at: [e.col, e.row], tile: [e.tile.col, e.tile.row], next: e.path[0] && [e.path[0].col, e.path[0].row], path: e.path.map((p) => [p.col, p.row]) }; });
  console.log('zombie', J(z));
  const out = [];
  for (const [c, r] of [z.tile, z.next, z.path[2] || z.path[z.path.length - 1]]) {
    const before = (await T.state()).structs.length;
    await T.tapTileW(c, r, 150);
    const after = (await T.state()).structs.length;
    out.push([c, r, before === after ? 'refused' : 'built']);
  }
  console.log('build attempts', J(out));
  await page.waitForTimeout(6000);
  const st = await T.state();
  console.log('after', J(st.z.map((z) => [z.at, z.smash, z.mv])), J(st.structs));
  console.log('monitor', J(await T.mon()));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
