// A zombie walks toward the player; the player taps it and steps toward it; both end on the same tile and fight there.
const { setup, installFreeze, installTrace, zombieScreen, installDriver } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installTrace(T);
  await installFreeze(T);
  await installDriver(T, 1);
  await T.testItem(1);      // night (more realistic look)
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.list.slice().forEach((e) => s.enemies.remove(e)); s.enemies.schedule = [];
    s.enemies.spawnPoint = () => ({ col: 33, row: 35 }); s.debugZombie(); });
  await page.waitForFunction(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return e && e.col >= 35.3; }, null, { timeout: 30000, polling: 20 });
  const zs = await zombieScreen(T, 0);
  const capP = T.capture(['hit'], 'O1_same_tile_hit', 15000);
  await page.mouse.click(zs.x, zs.y);
  const c1 = await capP;
  console.log('at the first dagger hit: player', J(c1.st.tile), 'zombie', J(c1.st.z.map((z) => [z.at, z.mv])));
  const c2 = await T.capture(['hit'], 'O1_second_hit', 15000);
  console.log('at the second dagger hit: player', J(c2.st.tile), 'zombie', J(c2.st.z.map((z) => [z.at, z.mv, z.flip])));
  await page.waitForFunction(() => window.__game.scene.getScene('game').enemies.list.length === 0, null, { timeout: 30000 });
  const tr = await G(() => window.__tr.buf.filter((f) => f.z.length).map((f) => [f.t, f.pt.join(','), f.z[0][1] + ',' + f.z[0][2], f.z[0][3], f.z[0][7]]));
  let last = null; const flips = [];
  for (const f of tr) { if (last !== null && f[4] !== last) flips.push(f); last = f[4]; }
  console.log('zombie flipX changes:', J(flips));
  console.log('errors', J(T.errors));
  await T.browser.close();
})();
