// Session E: mouse 1920x1200. Crowd: 6 zombies called with the test tool converge on (a) the tent with the player inside, (b) the player.
const { setup, installFreeze, installTrace, zombieScreen, UI } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
const mode = process.argv[2] || 'tent';
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await T.monitor();
  await installFreeze(T);
  await installTrace(T);
  await T.testItem(0);
  await T.card(4); await T.tapWorld((39.5 - 37.5) * 40, (39.5 + 37.5) * 20, 300);
  await T.card(3); await T.tapTileW(35, 38, 300);
  await T.closeCraft();
  if (mode === 'tent') {
    const tent = await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return { wx: t.sprite.x, wy: t.sprite.y - 60 }; });
    await T.tapWorld(tent.wx, tent.wy, 0);
    await page.waitForFunction(() => window.__game.scene.getScene('game').rest.resting, null, { timeout: 30000 });
  }
  // open the test window once and press "좀비 1마리 부르기" 6 times
  await T.ui(...UI.test);
  for (let i = 0; i < 6; i++) await T.ui(...UI.testItem(3), 150);
  await T.ui(...UI.testItem(5));
  let st = await T.state();
  log('called', st.z.length, 'resting', st.resting, 'speed', st.speed);
  const t0 = Date.now(); let k = 0;
  while (Date.now() - t0 < 150000) {
    st = await T.state();
    const standing = st.z.filter((z) => !z.mv).map((z) => z.tile.join(','));
    const dup = standing.filter((x, i) => standing.indexOf(x) !== i);
    log('t', st.clockT, 'resting', st.resting, 'hearts', st.hearts, 'z', J(st.z.map((z) => [z.tile.join(','), z.smash ? 'S' : z.hit !== null ? 'H' : z.mv ? 'mv' : 'st'])), dup.length ? 'STACKED ' + dup.join(' ') : '', J(st.structs.filter((s) => s.startsWith('tent'))));
    if (st.z.filter((z) => !z.mv).length >= 3 || dup.length) { await T.shot('E_' + mode + '_crowd' + (k++)); }
    if (!st.z.length || k >= 4 || !st.active) break;
    await page.waitForTimeout(1500);
  }
  log('monitor', J(await T.mon()));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
