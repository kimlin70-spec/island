const { setup } = require('./pl.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await page.waitForTimeout(500);
  // night so the lightmap is drawn too
  await G(() => window.__game.scene.getScene('game').debugNight());
  const r = await G(() => new Promise((res) => { const g = window.__game; g.loop.sleep(); let t = performance.now(); const t0 = t; let n = 0;
    const tick = () => { for (let i = 0; i < 4; i++) { t += 1000 / 60; g.step(t, 1000 / 60); n++; } if (n < 600) setTimeout(tick, 0); else res(performance.now() - t0); }; tick(); }));
  console.log('600 steps real ms', r.toFixed(0));
  await T.shot('fps2_after_manual');
  const e = await G(() => window.__game.scene.getScene('game').elapsed);
  console.log('elapsed', e);
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})();
