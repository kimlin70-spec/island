// Session D: mouse 1920x1200. Closed pen of fences with tent + campfire inside; night 1: zombies smash in; rest in the tent; night 2.
const { setup, installFreeze, installTrace, zombieScreen } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await T.monitor();
  await installFreeze(T);
  await installTrace(T);
  await T.testItem(0); await T.testItem(0);
  await T.card(4); await T.tapWorld((39.5 - 38.5) * 40, (39.5 + 38.5) * 20, 300);   // tent (39..40, 38..39)
  await T.card(3); await T.tapTileW(36, 38, 300);                                     // campfire
  await T.card(2);
  const ring = [];
  for (let c = 34; c <= 42; c++) { ring.push([c, 36]); ring.push([c, 42]); }
  for (let r = 37; r <= 41; r++) { ring.push([34, r]); ring.push([42, r]); }
  for (const [c, r] of ring) await T.tapTileW(c, r, 100);
  await page.mouse.move(960, 300);
  await T.closeCraft();
  let st = await T.state();
  log('pen', st.structs.length, J(st.inv), st.notice);
  await T.shot('D01_pen');
  await T.testItem(1);
  await T.testItem(4);
  // wait for first smash
  const c1 = await T.capture(['smash'], 'D02_first_smash', 200000);
  log('first smash', J(c1 && { info: c1.info, z: c1.st.z }));
  await T.testItem(4);
  // close-up of the smashing zombie
  if (c1) {
    const zi = c1.st.z.findIndex((z) => z.smash);
    const zs = await zombieScreen(T, zi);
    if (zs && zs.on) await page.screenshot({ path: __dirname + '/D03_smash_crop.png', clip: { x: Math.max(0, zs.x - 200), y: Math.max(0, zs.y - 150), width: 400, height: 260 } });
  }
  // let zombies work at x1 for a while; the player stands still inside (auto attack only)
  for (let i = 0; i < 6; i++) {
    await page.waitForTimeout(8000);
    st = await T.state();
    log('pen t', st.clockT, J({ hearts: st.hearts, def: st.defeated, z: st.z.map((z) => [z.tile, z.smash, z.mv ? 'mv' : 'st', z.hp]), fences: st.structs.filter((s) => s.startsWith('fence')).length, broken: st.structs.filter((s) => /:([0-5])$/.test(s)) }));
    await T.shot('D04_pen_' + i);
  }
  // go into the tent (tap the tent)
  const tent = await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return t ? { wx: t.sprite.x, wy: t.sprite.y - 60 } : null; });
  if (tent) { await T.tapWorld(tent.wx, tent.wy, 0); await page.waitForTimeout(3000); }
  st = await T.state();
  log('tent?', st.resting, st.speed);
  for (let i = 0; i < 4; i++) {
    await page.waitForTimeout(8000);
    st = await T.state();
    log('rest t', st.clockT, J({ resting: st.resting, speed: st.speed, hearts: st.hearts, z: st.z.map((z) => [z.tile, z.smash, z.mv ? 'mv' : 'st']), tent: st.structs.filter((s) => s.startsWith('tent')), notice: st.notice }));
    await T.shot('D05_rest_' + i);
    if (!st.resting) break;
  }
  log('monitor', J(await T.mon()));
  log('events', J((await T.events())));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
