// play helpers on top of p5/lib5.js (real clicks / taps only for actions; page reads for state)
const path = require('path');
const lib5 = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p5/lib5.js');
const OUT = __dirname;
exports.UI = lib5.UI;
exports.setup = async (opts = {}) => {
  const T = await lib5.setup(opts);
  const { page, G } = T;
  T.shot = async (name) => { const p = path.join(OUT, name + '.png'); await page.screenshot({ path: p }); return p; };
  // world point of a tile centre
  T.tileW = (c, r) => ({ wx: (c - r) * 40, wy: (c + r) * 20 });
  T.tapTileW = async (c, r, wait = 0) => { const w = T.tileW(c, r); return T.tapWorld(w.wx, w.wy, wait); };
  T.craftIsOpen = () => G(() => window.__game.scene.getScene('ui').craftOpen);
  T.openCraft = async () => { if (!(await T.craftIsOpen())) await T.ui(...lib5.UI.craft); };
  T.closeCraft = async () => { if (await T.craftIsOpen()) await T.ui(...lib5.UI.craft); };
  T.card = async (i) => { await T.openCraft(); await T.ui(...lib5.UI.card(i)); };
  T.elapsed = () => G(() => window.__game.scene.getScene('game').elapsed);
  T.waitGame = async (sec, timeout = 300000) => {
    const e0 = await T.elapsed();
    await page.waitForFunction((e) => window.__game.scene.getScene('game').elapsed >= e, e0 + sec, { timeout, polling: 100 });
  };
  T.state = () => G(() => { const s = window.__game.scene.getScene('game'), p = s.player, u = window.__game.scene.getScene('ui');
    return { t: +s.elapsed.toFixed(2), p: [+p.col.toFixed(2), +p.row.toFixed(2)], tile: [p.tile.col, p.tile.row], moving: p.moving, hearts: s.hearts.value,
      resting: s.rest.resting, speed: s.speed, action: p.action ? (p.action.target.kind || p.action.target.type) : null, swing: !!p.swing,
      frame: p.sprite.frame.name, flip: p.sprite.flipX, defeated: s.enemies.defeated, label: s.clock.label, clockT: +s.clock.t.toFixed(1),
      z: s.enemies.list.map((e) => ({ at: [+e.col.toFixed(2), +e.row.toFixed(2)], tile: [e.tile.col, e.tile.row], hp: e.hp, mv: e.moving,
        smash: e.smashing ? e.smashing.type + '@' + e.smashing.col + ',' + e.smashing.row : null, hit: e.hitLeft === null ? null : +e.hitLeft.toFixed(2),
        fr: e.sprite.frame.name, flip: e.sprite.flipX, path: e.path.length })),
      structs: s.map.structures.map((x) => x.type + '@' + x.col + ',' + x.row + ':' + x.hp),
      inv: { wood: s.inventory.count('wood'), stone: s.inventory.count('stone') },
      modal: u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : null,
      notice: u.noticeBox.visible ? u.noticeText.text : null,
      active: window.__game.scene.isActive('game') }; });
  // per-frame monitor: jitter (direction reversals), flip flicker, stuck zombies, standing overlaps, notices
  T.monitor = () => G(() => {
    const s = window.__game.scene.getScene('game');
    const M = window.__mon = { rev: [], flips: [], stuck: [], overlap: [], onPlayer: [], notices: [], pflip: [], hurt: [], log: [], frames: 0 };
    s.events.on('notice', (t) => M.notices.push([+s.elapsed.toFixed(2), t]));
    const prev = new Map();
    let pPrevFlip = s.player.sprite.flipX, pFlipT = [];
    s.events.on('postupdate', () => {
      M.frames++;
      const now = s.elapsed;
      const target = s.enemies.target();
      for (const e of s.enemies.list) {
        let q = prev.get(e);
        if (!q) { q = { c: e.col, r: e.row, dx: 0, dy: 0, flip: e.sprite.flipX, flipT: [], idleSince: null, id: prev.size }; prev.set(e, q); }
        const dx = e.col - q.c, dy = e.row - q.r;
        if (Math.hypot(dx, dy) > 1e-6) {
          if (Math.hypot(q.dx, q.dy) > 1e-6) {
            const dot = (dx * q.dx + dy * q.dy) / (Math.hypot(dx, dy) * Math.hypot(q.dx, q.dy));
            if (dot < -0.5) M.rev.push([+now.toFixed(2), q.id, +e.col.toFixed(2), +e.row.toFixed(2), +dot.toFixed(2)]);
          }
          q.dx = dx; q.dy = dy;
        }
        q.c = e.col; q.r = e.row;
        if (e.sprite.flipX !== q.flip) { q.flipT.push(now); q.flip = e.sprite.flipX; q.flipT = q.flipT.filter((t) => now - t < 1.5); if (q.flipT.length >= 3) M.flips.push([+now.toFixed(2), q.id, q.flipT.length]); }
        const near = target.tiles.some((t) => Math.max(Math.abs(t.col - e.tile.col), Math.abs(t.row - e.tile.row)) <= 1);
        const idle = !e.moving && !e.smashing && !near;
        if (idle) { if (q.idleSince === null) q.idleSince = now; else if (now - q.idleSince > 2) { M.stuck.push([+now.toFixed(2), q.id, e.tile.col, e.tile.row]); q.idleSince = now; } }
        else q.idleSince = null;
      }
      const standing = s.enemies.list.filter((e) => !e.moving).map((e) => e.tile.col + ',' + e.tile.row);
      const dup = standing.filter((k, i) => standing.indexOf(k) !== i);
      if (dup.length) { const last = M.overlap[M.overlap.length - 1]; if (!last || now - last[0] > 1) M.overlap.push([+now.toFixed(2), dup.join(' ')]); }
      // a standing zombie on the player's own tile while the player stands too (visible merge)
      for (const e of s.enemies.list) if (!e.moving && !s.player.moving && !s.rest.resting && e.tile.col === s.player.tile.col && e.tile.row === s.player.tile.row) {
        const q = prev.get(e); const last = M.onPlayer[M.onPlayer.length - 1]; if (!last || last[1] !== q.id || now - last[0] > 1) M.onPlayer.push([+now.toFixed(2), q.id, e.tile.col, e.tile.row]); }
      if (s.player.sprite.flipX !== pPrevFlip) { pPrevFlip = s.player.sprite.flipX; pFlipT.push(now); pFlipT = pFlipT.filter((t) => now - t < 1.0); if (pFlipT.length >= 4) M.pflip.push([+now.toFixed(2), pFlipT.length]); }
    });
    const orig = s.hurtPlayer.bind(s);
    s.hurtPlayer = (n) => { M.hurt.push([+s.elapsed.toFixed(2), s.hearts.value, s.rest.resting]); return orig(n); };
  });
  T.mon = (clear = false) => G((clear) => { const M = window.__mon; const out = JSON.parse(JSON.stringify({ ...M, log: undefined }));
    if (clear) { M.rev.length = 0; M.flips.length = 0; M.stuck.length = 0; M.overlap.length = 0; M.pflip.length = 0; } return out; }, clear);
  return T;
};

// freeze-capture: when a hooked event fires, sleep the game loop right after that frame is drawn, take a screenshot, wake.
exports.installFreeze = async (T) => {
  await T.G(() => {
    const g = window.__game, s = g.scene.getScene('game');
    const F = window.__fz = { want: null, req: false, frozen: false, what: null, info: null };
    g.events.on('postrender', (renderer) => { if (!renderer) return; if (F.req) { F.req = false; if (!window.__drv) g.loop.sleep(); F.frozen = true; } });
    const arm = (name, info) => { if (F.want && F.want.includes(name) && !F.req && !F.frozen) { F.req = true; F.what = name; F.info = info; } };
    const wrap = (obj, fn, name, infoFn) => { const o = obj[fn].bind(obj); obj[fn] = (...a) => { const r = o(...a); arm(name, infoFn ? infoFn(...a) : null); return r; }; };
    wrap(s.effects, 'flash', 'flash', (sp) => sp === s.player.sprite ? 'player' : 'zombie');
    wrap(s.effects, 'hit', 'hit');
    wrap(s.effects, 'poof', 'poof', (x, y) => [Math.round(x), Math.round(y)]);
    wrap(s.enemies, 'hitStructure', 'smash', (e, st) => st.type + '@' + st.col + ',' + st.row + ' hp' + st.hp);
    wrap(s.enemies, 'hitPlayer', 'hitPlayer');
  });
  T.capture = async (want, name, timeout = 60000) => {
    await T.G((w) => { const F = window.__fz; F.want = w; F.req = false; F.frozen = false; }, want);
    try {
      await T.page.waitForFunction(() => window.__fz.frozen, null, { timeout, polling: 50 });
    } catch (e) { await T.G(() => { window.__fz.want = null; }); return null; }
    const info = await T.G(() => ({ what: window.__fz.what, info: window.__fz.info }));
    const st = await T.state();
    const p = await T.shot(name);
    await T.G(() => { const F = window.__fz; F.want = null; F.frozen = false; if (!window.__drv) window.__game.loop.wake(); });
    return { ...info, file: p, st };
  };
};
// screen position (browser px) of zombie i's body centre; null if gone/off screen
exports.zombieScreen = async (T, i) => {
  const z = await T.zombiePoint(i);
  if (!z) return null;
  const p = await T.w2p(z.wx, z.wy);
  return { ...p, wx: z.wx, wy: z.wy };
};

// per-frame trace ring buffer: player + zombies, and events (strike, hurt, zhit)
exports.installTrace = async (T) => {
  await T.G(() => {
    const s = window.__game.scene.getScene('game');
    const R = window.__tr = { buf: [], ev: [], ids: new Map(), n: 0 };
    const id = (e) => { if (!R.ids.has(e)) R.ids.set(e, R.ids.size); return R.ids.get(e); };
    const r2 = (x) => Math.round(x * 100) / 100;
    s.events.on('postupdate', () => {
      const p = s.player;
      R.buf.push({ t: r2(s.elapsed), p: [r2(p.col), r2(p.row)], pt: [p.tile.col, p.tile.row], pm: p.moving ? p.path.map((q) => q.col + ',' + q.row).join(' ') : '',
        act: p.action ? (p.action.target.kind || p.action.target.type || 'z' + id(p.action.target)) : null, at: p.action && p.action.target.hp !== undefined && p.action.chase ? id(p.action.target) : null,
        sw: p.swing ? (p.swing.struck ? 'S' : 'R') + r2(p.swing.t) : null, cd: r2(p.cooldown), flip: p.sprite.flipX,
        z: s.enemies.list.map((e) => [id(e), r2(e.col), r2(e.row), e.moving ? 1 : 0, e.hitLeft === null ? null : r2(e.hitLeft), e.hp, e.path[0] ? e.path[0].col + ',' + e.path[0].row : '', e.sprite.flipX ? 1 : 0]) });
      if (R.buf.length > 3000) R.buf.shift();
    });
    const wrap = (obj, fn, name, info) => { const o = obj[fn].bind(obj); obj[fn] = (...a) => { R.ev.push([r2(s.elapsed), name, info ? info(...a) : null]); return o(...a); }; };
    wrap(s.enemies, 'hitPlayer', 'zhit', (e) => id(e));
    wrap(s.enemies, 'hitStructure', 'zsmash', (e, st) => [id(e), st.type, st.col, st.row, st.hp]);
    wrap(s.enemies, 'kill', 'kill', (e) => id(e));
    wrap(s, 'pressEnemy', 'pressEnemy', (e) => id(e));
    const ow = s.walkTo.bind(s); s.walkTo = (c, r) => { R.ev.push([r2(s.elapsed), 'walkTo', [c, r]]); return ow(c, r); };
  });
  T.trace = (from, to) => T.G(([a, b]) => ({ buf: window.__tr.buf.filter((f) => f.t >= a && f.t <= b), ev: window.__tr.ev.filter((e) => e[0] >= a && e[0] <= b) }), [from, to]);
  T.events = () => T.G(() => window.__tr.ev);
};

// 60 Hz logic driver: the RAF loop sleeps; logic steps of 1/60 s (headlessStep), one real render per tick.
// rate: game-step seconds per real second (1 = like a 60 fps device in real time, if the machine keeps up)
exports.installDriver = async (T, rate = 1) => {
  await T.G((rate) => {
    const g = window.__game; g.loop.sleep();
    const D = 1000 / 60;
    const V = window.__drv = { on: true, rate, steps: 0, renders: 0 };
    let t = performance.now(), last = performance.now(), acc = 0;
    const logic = () => { t += D; g.headlessStep(t, D); V.steps++; };
    const full = () => { t += D; g.step(t, D); V.steps++; V.renders++; };
    const tick = () => {
      if (!V.on) return;
      const F = window.__fz;
      if (F && F.frozen) { last = performance.now(); setTimeout(tick, 20); return; }
      const now = performance.now(); acc += (now - last) * V.rate; last = now;
      let n = Math.min(40, Math.floor(acc / D)); acc -= n * D; if (acc > 200) acc = 200;
      for (let i = 0; i < n - 1; i++) { logic(); if (F && F.req) { full(); n = 0; break; } }
      if (n > 0) full();
      setTimeout(tick, 0);
    };
    tick();
  }, rate);
  T.setRate = (r) => T.G((r) => { window.__drv.rate = r; }, r);
};
