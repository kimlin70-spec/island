const { setup, installDriver, installFreeze } = require('./pl.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installFreeze(T);
  await T.testItem(1);
  await installDriver(T, 1);
  const e0 = await T.elapsed(), t0 = Date.now();
  await page.waitForTimeout(5000);
  const e1 = await T.elapsed();
  console.log('game s per real s', ((e1 - e0) / ((Date.now() - t0) / 1000)).toFixed(2), JSON.stringify(await G(() => window.__drv)));
  // a click still works?
  const st0 = await T.state();
  await T.tapTileW(st0.tile[0] + 2, st0.tile[1], 0);
  await page.waitForTimeout(1500);
  const st1 = await T.state();
  console.log('walk', JSON.stringify(st0.p), '->', JSON.stringify(st1.p));
  const c = await T.capture(['poof'], 'drv_poof', 30000);
  console.log('cap', JSON.stringify(c && c.info));
  await T.shot('drv_shot');
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})();
