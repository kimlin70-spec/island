// Session F: touch 1024x768. Night 1 -> fight by tapping -> 아침으로 -> result window (touch 계속하기) -> night 2 (6 zombies) -> morning notice.
const { setup, installFreeze, installTrace, zombieScreen } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G } = T;
  await T.monitor();
  await installFreeze(T);
  await installTrace(T);
  await G(() => { const s = window.__game.scene.getScene('game'); window.__spawns = []; const o = s.enemies.spawn.bind(s.enemies);
    s.enemies.spawn = (k) => { const e = o(k); window.__spawns.push([s.clock.day, +s.clock.t.toFixed(1)]); return e; }; });
  const fight = async (maxReal, untilClock) => {
    const t0 = Date.now(); let fast = false; let taps = 0, ok = 0;
    while (Date.now() - t0 < maxReal) {
      const st = await T.state();
      if (!st.active || !st.label.endsWith('밤') || st.clockT >= untilClock) break;
      const order = st.z.map((z, i) => [Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]), i]).sort((a, b) => a[0] - b[0]);
      const near = order.length && order[0][0] < 7;
      if (!near && !fast) { await T.testItem(4); fast = true; }
      if (near && fast) { await T.testItem(4); fast = false; }
      if (near && order[0][0] <= 4 && st.action !== 'zombie' && !st.moving) {
        const zs = await zombieScreen(T, order[0][1]);
        if (zs && zs.on && zs.y > 120 && zs.y < 620) { await T.tapPage(zs.x, zs.y); taps++; await page.waitForTimeout(150); const s2 = await T.state(); if (s2.action === 'zombie') ok++; else log('tap did nothing?', J({ zs: [zs.x, zs.y], z: s2.z[order[0][1]], p: s2.p, act: s2.action })); }
      }
      await page.waitForTimeout(300);
    }
    if (fast) await T.testItem(4);
    return { taps, ok };
  };
  await T.testItem(1);
  let r = await fight(150000, 70);
  let st = await T.state();
  log('night1', J(r), J({ hearts: st.hearts, def: st.defeated, z: st.z.length, clock: st.clockT }));
  await T.testItem(2);
  await page.waitForFunction(() => !window.__game.scene.isActive('game'), null, { timeout: 60000 });
  await T.shot('F01_result_tablet');
  st = await T.state();
  log('result', J(st.modal));
  await T.modalButton('계속하기');
  await page.waitForTimeout(500);
  st = await T.state();
  log('continue', st.active, st.label, J(st.modal));
  await T.testItem(1);
  r = await fight(400000, 150);
  st = await T.state();
  log('night2', J(r), J({ hearts: st.hearts, def: st.defeated, z: st.z.length, clock: st.clockT, label: st.label, active: st.active }));
  await T.shot('F02_night2_end');
  if (st.active && st.label.endsWith('밤')) await T.testItem(2);
  await page.waitForTimeout(300);
  st = await T.state();
  log('day3', st.label, st.notice);
  await T.shot('F03_day3_notice');
  log('spawns', J(await G(() => window.__spawns)));
  log('monitor', J(await T.mon()));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
