// Session A: mouse 1920x1200. Build a camp with real clicks, night 1, fight, tent, morning, day 2, night 2.
const { setup, installFreeze, zombieScreen, UI } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G, W } = T;
  await T.monitor();
  await installFreeze(T);
  // 1. materials x2, tools
  await T.testItem(0); await T.testItem(0);
  await T.card(0); await T.card(1);
  let st = await T.state();
  log('after tools', J(st.inv), st.notice);
  // 2. tent (card 4): click the centre of its 4 tiles
  await T.card(4);
  await T.tapWorld((39.5 - 37.5) * 40, (39.5 + 37.5) * 20, 300);
  // 3. campfire (card 3)
  await T.card(3);
  await T.tapTileW(36, 37, 300);
  // 4. fences (card 2): row 36 cols 35..42, col 34 rows 37..41
  await T.card(2);
  for (let c = 35; c <= 42; c++) await T.tapTileW(c, 36, 150);
  for (let r = 37; r <= 41; r++) await T.tapTileW(34, r, 150);
  await page.mouse.move(960, 700);
  await page.waitForTimeout(300);
  await T.shot('A01_building');
  await T.closeCraft();
  await page.waitForTimeout(500);
  st = await T.state();
  log('camp', J(st.structs), J(st.inv), 'player', J(st.p));
  await T.shot('A02_camp_day');
  // 5. night
  const capSpawn = T.capture(['poof'], 'A03_spawn_poof', 20000);
  await T.testItem(1);
  log('spawn poof', J(await capSpawn));
  st = await T.state();
  log('night', st.label, J(st.z));
  // 6. speed x3 and wait for the first smash or a zombie within 7 tiles
  await T.testItem(4);
  const t0 = Date.now();
  let smashCap = null;
  while (Date.now() - t0 < 150000) {
    st = await T.state();
    const d = st.z.map((z) => Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]));
    if (st.z.some((z) => z.smash)) { break; }
    if (d.some((x) => x < 6)) break;
    await page.waitForTimeout(1000);
  }
  log('approach', J(st.z), 'clock', st.clockT);
  await T.testItem(4); // back to x1
  smashCap = await T.capture(['smash'], 'A04_first_smash', 20000);
  log('smash cap', J(smashCap && { what: smashCap.what, info: smashCap.info, z: smashCap.st.z }));
  await T.shot('A05_after_smash');
  log('monitor', J(await T.mon()));
  // 7. fight: tap reachable zombies for 60 s real
  const tf = Date.now();
  let taps = 0, hitShot = false, deathShot = false;
  while (Date.now() - tf < 90000) {
    st = await T.state();
    if (!st.active) break;
    if (st.action !== 'zombie' && !st.moving) {
      // nearest on-screen zombie
      const order = st.z.map((z, i) => [Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]), i]).sort((a, b) => a[0] - b[0]);
      for (const [d, i] of order) {
        if (d > 9) break;
        const zs = await zombieScreen(T, i);
        if (!zs || !zs.on || zs.y < 150 || zs.y > 1000 || zs.x < 350 || zs.x > 1550) continue;
        await page.mouse.click(zs.x, zs.y);
        taps++;
        await page.waitForTimeout(300);
        const st2 = await T.state();
        log('tap zombie', i, 'd', d.toFixed(1), '->', st2.action, 'moving', st2.moving, J(st2.z[i]));
        break;
      }
    }
    if (!hitShot && st.action === 'zombie') {
      const c = await T.capture(['hit'], 'A06_zombie_hit', 8000);
      if (c) { hitShot = true; log('hit cap', J({ info: c.info, z: c.st.z, frame: c.st.frame })); }
    }
    if (hitShot && !deathShot && st.action === 'zombie') {
      const c = await T.capture(['poof'], 'A07_zombie_poof', 8000);
      if (c) { deathShot = true; log('death cap', J({ info: c.info, def: c.st.defeated })); }
    }
    await page.waitForTimeout(500);
  }
  st = await T.state();
  log('after fight', J({ hearts: st.hearts, def: st.defeated, z: st.z, structs: st.structs, clock: st.clockT }));
  log('monitor', J(await T.mon(true)));
  await T.shot('A08_after_fight');
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
