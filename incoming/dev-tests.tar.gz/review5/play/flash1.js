// Is the white flash ever drawn? Record, at every real render, whether the player/zombie sprite is tint-filled.
const { setup, installDriver } = require('./pl.js');
const J = JSON.stringify;
const mode = process.argv[2] || 'raf';   // raf (this machine ~9 fps) | drv60 (60 Hz logic, render every step)
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await G(() => { const g = window.__game, s = g.scene.getScene('game'); window.__fr = { renders: 0, whiteZ: 0, whiteP: 0, flashes: 0, hitFx: 0, hitFxRenders: 0 };
    const of = s.effects.flash.bind(s.effects); s.effects.flash = (sp) => { window.__fr.flashes++; return of(sp); };
    g.events.on('postrender', (r) => { if (!r) return; const F = window.__fr; F.renders++;
      if (s.enemies.list.some((e) => e.sprite.tintFill)) F.whiteZ++; if (s.player.sprite.tintFill) F.whiteP++;
      if (s.children.list.some((o) => o.texture && o.texture.key === 'fx_hit')) F.hitFxRenders++; }); });
  if (mode === 'drv60') {
    // 60 Hz with a real render on every step (slow in real time but each frame is drawn)
    await G(() => { const g = window.__game; g.loop.sleep(); let t = performance.now(); const D = 1000 / 60;
      const tick = () => { for (let i = 0; i < 2; i++) { t += D; g.step(t, D); } setTimeout(tick, 0); }; tick(); });
  }
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.spawnPoint = () => ({ col: 34, row: 39 }); });
  await T.testItem(3);   // a zombie walks to the player; the standing player auto-attacks; it may hit the player once
  await page.waitForFunction(() => window.__game.scene.getScene('game').enemies.list.length === 0, null, { timeout: 300000 });
  console.log(mode, J(await G(() => window.__fr)), 'hearts', await G(() => window.__game.scene.getScene('game').hearts.value));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
