// Repro: zombie comes to the tile straight above the player on screen (grid diagonal), the player taps it; does the zombie flip on each hit?
const { setup, installFreeze, installTrace, zombieScreen, installDriver } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installTrace(T);
  await installDriver(T, 1);
  // put a zombie two tiles up the screen from the player (37,39) -> (35,37) and let it walk to (36,38) (straight above on screen)
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.spawnPoint = () => ({ col: 35, row: 37 }); s.debugZombie(); });
  await page.waitForFunction(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return e && !e.moving; }, null, { timeout: 30000 });
  const z0 = await G(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return [e.tile.col, e.tile.row, e.sprite.flipX, e.sprite.x, window.__game.scene.getScene('game').player.sprite.x]; });
  console.log('zombie stands at', J(z0));
  const zs = await zombieScreen(T, 0);
  await page.mouse.click(zs.x, zs.y);
  await page.waitForFunction(() => window.__game.scene.getScene('game').enemies.list.length === 0, null, { timeout: 30000 });
  const full = await G(() => window.__tr.buf.filter((f) => f.z.length).slice(-200));
  for (const f of full) console.log(f.t, J(f.p), f.act, f.sw || "", J(f.z[0]));
  const tr = full.map((f) => [f.t, f.sw, f.z[0][7], f.z[0][5]]);
  let last = null, flips = [];
  for (const f of tr) { if (last !== null && f[2] !== last) flips.push([f[0], f[2] ? 'left' : 'right', 'hp' + f[3]]); last = f[2]; }
  console.log('zombie flip changes while fighting:', J(flips));
  console.log('errors', J(T.errors));
  await T.browser.close();
})();
