// Session C: mouse 1920x1200. Camp, night 1 fought by tapping, morning result window, 계속하기, day 2, night 2 (6 zombies), 3일째 아침.
const { setup, installFreeze, installTrace, zombieScreen } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await T.monitor();
  await installFreeze(T);
  await installTrace(T);
  await G(() => { const s = window.__game.scene.getScene('game'); window.__spawns = []; const o = s.enemies.spawn.bind(s.enemies);
    s.enemies.spawn = (k) => { const e = o(k); window.__spawns.push([s.clock.day, s.clock.isNight, +s.clock.t.toFixed(1), e ? [e.col, e.row] : null]); return e; }; });
  await T.testItem(0);
  await T.card(0);   // axe
  await T.card(4); await T.tapWorld((39.5 - 37.5) * 40, (39.5 + 37.5) * 20, 300);
  await T.card(3); await T.tapTileW(36, 37, 300);
  await T.card(2); for (let c = 35; c <= 42; c++) await T.tapTileW(c, 36, 120);
  await T.closeCraft();
  const fight = async (label, untilClock, maxReal) => {
    const t0 = Date.now(); let fast = false, taps = 0;
    while (Date.now() - t0 < maxReal) {
      const st = await T.state();
      if (!st.active) return st;
      if (st.clockT >= untilClock || !st.label.endsWith('밤')) return st;
      const order = st.z.map((z, i) => [Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]), i]).sort((a, b) => a[0] - b[0]);
      const near = order.length && order[0][0] < 8;
      if (!near && !fast) { await T.testItem(4); fast = true; }
      if (near && fast) { await T.testItem(4); fast = false; }
      if (near && order[0][0] <= 3.5 && st.action !== 'zombie' && !st.moving) {
        const zs = await zombieScreen(T, order[0][1]);
        if (zs && zs.on && zs.y > 150 && zs.y < 1000) { await page.mouse.click(zs.x, zs.y); taps++; }
      }
      await page.waitForTimeout(300);
    }
    if (fast) await T.testItem(4);
    return T.state();
  };
  // night 1
  await T.testItem(1);
  let st = await fight('n1', 100, 240000);
  log('night1 fought', J({ hearts: st.hearts, def: st.defeated, z: st.z.length, clock: st.clockT, structs: st.structs.length }));
  await T.shot('C01_night1_late');
  // morning
  const hearts1 = (await T.state()).hearts;
  await T.testItem(2);
  await page.waitForFunction(() => !window.__game.scene.isActive('game'), null, { timeout: 60000 });
  st = await T.state();
  log('result', J(st.modal), 'hearts at end of night', hearts1, 'now', st.hearts, 'label', st.label);
  await T.shot('C02_result');
  await T.modalButton('계속하기');
  await page.waitForTimeout(600);
  st = await T.state();
  log('continued', st.active, st.label, st.clockT, J(st.modal));
  await T.shot('C03_day2');
  // night 2
  await T.testItem(1);
  st = await fight('n2', 150, 400000);
  log('night2', J({ hearts: st.hearts, def: st.defeated, z: st.z.length, clock: st.clockT, label: st.label, active: st.active }));
  await T.shot('C04_night2');
  if (st.active && st.label.endsWith('밤')) { await T.testItem(2); }
  await page.waitForTimeout(800);
  st = await T.state();
  log('day3', J({ label: st.label, notice: st.notice, modal: st.modal, hearts: st.hearts }));
  await T.shot('C05_day3');
  log('spawns', J(await G(() => window.__spawns)));
  log('monitor', J(await T.mon()));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
