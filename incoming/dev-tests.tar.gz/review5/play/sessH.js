// Session H: 60 Hz logic driver. Night 1 skipped (night -> morning -> 계속하기), night 2 with 6 zombies; the player stands still (auto attack).
const { setup, installFreeze, installTrace, installDriver } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G } = T;
  await T.monitor();
  await installFreeze(T);
  await installTrace(T);
  await installDriver(T, 2);
  await T.testItem(1); await T.testItem(2);
  await page.waitForFunction(() => window.__game.scene.getScene('ui').modal, null, { timeout: 60000 });
  await T.modalButton('계속하기');
  await page.waitForTimeout(500);
  await T.testItem(1);
  const t0 = Date.now();
  let last = null;
  while (Date.now() - t0 < 300000) {
    const st = await T.state();
    if (!st.active || !st.label.endsWith('밤') || st.clockT > 140) break;
    const line = J({ c: Math.round(st.clockT), h: st.hearts, d: st.defeated, z: st.z.map((z) => z.tile.join(',') + (z.mv ? 'm' : z.smash ? 'S' : z.hit !== null ? 'H' : 's')) });
    if (Date.now() - (last || 0) > 10000) { log(line); last = Date.now(); }
    await page.waitForTimeout(1000);
  }
  const st = await T.state();
  log('end', J({ hearts: st.hearts, def: st.defeated, z: st.z.length, clock: st.clockT, label: st.label, active: st.active }));
  log('monitor', J(await T.mon()));
  log('drv', J(await G(() => window.__drv)));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
