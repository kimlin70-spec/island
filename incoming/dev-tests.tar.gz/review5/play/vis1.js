// 60 Hz visuals: zombie white flash + fx_hit (player strike), zombie attack frame + player flash (zombie hit). Crops.
const { setup, installFreeze, installDriver } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installFreeze(T);
  await installDriver(T, 0.5);
  await T.testItem(1);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.list.slice().forEach((e) => s.enemies.remove(e)); s.enemies.schedule = [];
    s.enemies.spawnPoint = () => ({ col: 41, row: 35 }); s.hearts.value = 5; });
  // make the player busy chopping a tree so the zombie gets to hit first (no auto attack while chopping)
  const tree = await G(() => { const s = window.__game.scene.getScene('game'); const o = s.map.objects.find((x) => x.col === 38 && x.row === 40) ||
      s.map.objects.filter((x) => x.node && x.kind === 'tree').sort((a, b) => Math.hypot(a.col - 37, a.row - 39) - Math.hypot(b.col - 37, b.row - 39))[0];
    return { wx: o.sprite.x, wy: o.sprite.y - 50, at: [o.col, o.row] }; });
  await T.testItem(3);
  const crop = async (name) => { const p = await T.w2p(...(await G(() => { const s = window.__game.scene.getScene('game'); return [s.player.sprite.x, s.player.sprite.y - 30]; })));
    await page.screenshot({ path: __dirname + '/' + name + '.png', clip: { x: p.x - 150, y: p.y - 110, width: 300, height: 180 } }); };
  // wait for the zombie to be 2 tiles away, then tap the tree (chop) so the zombie can hit
  await page.waitForFunction(() => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[0]; return e && Math.hypot(e.col - 37, e.row - 39) < 3; }, null, { timeout: 120000, polling: 20 });
  await T.tapWorld(tree.wx, tree.wy, 0);
  const c1 = await T.capture(['hitPlayer'], 'V_hitPlayer', 30000);
  await crop('V_hitPlayer_crop');
  console.log('zombie hit the player: zombie frame', J(c1 && c1.st.z.map((z) => [z.fr, z.flip, z.tile])), 'player tint', await G(() => window.__game.scene.getScene('game').player.sprite.tintFill));
  // now tap the zombie and capture the strike
  const zp = await G(() => { const sp = window.__game.scene.getScene('game').enemies.list[0].sprite; return [sp.x, sp.y - 35]; });
  const cp = T.capture(['flash'], 'V_strike', 30000);
  await T.tapWorld(zp[0], zp[1], 0);
  const c2 = await cp;
  await crop('V_strike_crop');
  console.log('strike: zombie tintFill', await G(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return e ? e.sprite.tintFill : 'dead'; }), J(c2 && c2.st.z));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
