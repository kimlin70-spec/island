// Session G: mouse 1920x1200. Pen at distance 2; night; a zombie hits a fence; 치우기 that fence (real click) -> zombie comes in.
// Then build fences in front of the next zombie (fence card), and tap a zombie behind a fence.
const { setup, installFreeze, installTrace, zombieScreen, UI } = require('./pl.js');
const J = JSON.stringify;
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await T.monitor();
  await installFreeze(T);
  await installTrace(T);
  await T.testItem(0);
  await T.card(2);
  const ring = [];
  for (let c = 35; c <= 39; c++) { ring.push([c, 37]); ring.push([c, 41]); }
  for (let r = 38; r <= 40; r++) { ring.push([35, r]); ring.push([39, r]); }
  for (const [c, r] of ring) await T.tapTileW(c, r, 100);
  await T.closeCraft();
  await T.testItem(1); await T.testItem(4);
  const c1 = await T.capture(['smash'], 'G01_smash', 120000);
  await T.testItem(4);
  log('smash', J(c1 && c1.info));
  let st = await T.state();
  const zi = st.z.findIndex((z) => z.smash);
  const f = st.z[zi].smash.split('@')[1].split(',').map(Number);
  // tap the zombie behind the fence: nothing should happen (accepted)
  const zs = await zombieScreen(T, zi);
  await page.mouse.click(zs.x, zs.y); await page.waitForTimeout(400);
  st = await T.state();
  log('tap zombie behind fence ->', J({ action: st.action, moving: st.moving }));
  // remove the fence it is hitting (치우기 card 5, then click the fence)
  await T.card(5);
  await T.tapTileW(f[0], f[1], 400);
  await T.closeCraft();
  st = await T.state();
  log('removed', J(f), 'fences', st.structs.length, 'z', J(st.z.map((z) => [z.at, z.smash, z.mv])));
  await page.waitForTimeout(3000);
  st = await T.state();
  log('3s later', J({ hearts: st.hearts, def: st.defeated, z: st.z.map((z) => [z.at, z.smash, z.mv, z.hit]), p: st.p, action: st.action }));
  await T.shot('G02_after_remove');
  // wait for the next zombie; when it is 4-6 tiles away, build two fences across its path (fence card)
  await T.testItem(4);
  const t0 = Date.now();
  while (Date.now() - t0 < 120000) {
    st = await T.state();
    const near = st.z.map((z) => [Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]), z]).filter((x) => x[0] < 6.5 && x[0] > 3.5);
    if (near.length) break;
    await page.waitForTimeout(300);
  }
  await T.testItem(4);
  st = await T.state();
  const zz = st.z.map((z) => [Math.hypot(z.at[0] - st.p[0], z.at[1] - st.p[1]), z]).sort((a, b) => a[0] - b[0])[0][1];
  log('next zombie', J(zz), 'player', J(st.p));
  // fence on the zombie's current tile and next tile (should be refused: red), and one tile further along toward the player
  await T.card(2);
  const zt = zz.tile;
  const dir = [Math.sign(st.tile[0] - zt[0]), Math.sign(st.tile[1] - zt[1])];
  const tries = [[zt[0], zt[1]], [zt[0] + dir[0], zt[1] + dir[1]], [zt[0] + 2 * dir[0], zt[1] + 2 * dir[1]]];
  for (const [c, r] of tries) {
    const before = (await T.state()).structs.length;
    await T.tapTileW(c, r, 200);
    const after = (await T.state()).structs.length;
    log('build at', c, r, before === after ? 'refused' : 'built');
  }
  await T.closeCraft();
  await page.waitForTimeout(4000);
  st = await T.state();
  log('after building', J(st.z.map((z) => [z.at, z.smash, z.mv])));
  await T.shot('G03_after_build');
  log('monitor', J(await T.mon()));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
