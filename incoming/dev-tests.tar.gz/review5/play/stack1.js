// Deterministic stacking repro: tent behind a fence line with one gap; player resting; zombie A comes in and hits the tent;
// zombie B comes through the same gap. Where does B stop, and what was its planned goal?
const { setup, installFreeze, installTrace, UI } = require('./pl.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await installFreeze(T);
  // real clicks: materials, tent, fences row 36 cols 35..42 except 38 (gap)
  await T.testItem(0);
  await T.card(4); await T.tapWorld((39.5 - 37.5) * 40, (39.5 + 37.5) * 20, 300);
  await T.card(2); for (const c of [35, 36, 37, 39, 40, 41, 42]) await T.tapTileW(c, 36, 120);
  await T.closeCraft();
  // rest in the tent (real click)
  const tent = await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return { wx: t.sprite.x, wy: t.sprite.y - 60 }; });
  await T.tapWorld(tent.wx, tent.wy, 0);
  await page.waitForFunction(() => window.__game.scene.getScene('game').rest.resting, null, { timeout: 30000 });
  // zombie A from the north (spawn point forced only for the test), then B
  await G(() => { const s = window.__game.scene.getScene('game'); window.__goals = [];
    s.enemies.spawnPoint = () => ({ col: 38, row: 30 });
    const orig = s.enemies.list.constructor; });
  await T.testItem(3);
  await page.waitForFunction(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return e && e.smashing; }, null, { timeout: 60000 });
  const a = await G(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return [e.tile.col, e.tile.row, e.smashing.type]; });
  await T.testItem(3);
  // record B's planned goal (path end) each frame
  await G(() => { const s = window.__game.scene.getScene('game'); const b = s.enemies.list[1]; window.__bgoal = [];
    s.events.on('postupdate', () => { if (!b.alive) return; const end = b.path[b.path.length - 1]; const g = end ? end.col + ',' + end.row : null; const last = window.__bgoal[window.__bgoal.length - 1];
      if (!last || last[1] !== g) window.__bgoal.push([+s.elapsed.toFixed(2), g, b.tile.col + ',' + b.tile.row]); }); });
  await page.waitForFunction(() => { const e = window.__game.scene.getScene('game').enemies.list[1]; return e && e.smashing; }, null, { timeout: 60000 });
  await page.waitForTimeout(1500);
  const r = await G(() => { const s = window.__game.scene.getScene('game'); return s.enemies.list.map((e) => [e.tile.col, e.tile.row, e.moving, e.smashing && e.smashing.type]); });
  console.log('A stood at', J(a), '| now', J(r), '| B planned goals [t, goal, at]:', J(await G(() => window.__bgoal)));
  await T.shot('S1_stacked');
  const z = await G(() => { const e = window.__game.scene.getScene('game').enemies.list[0]; return { wx: e.sprite.x, wy: e.sprite.y }; });
  const p = await T.w2p(z.wx, z.wy);
  await page.screenshot({ path: __dirname + '/S1_stacked_crop.png', clip: { x: p.x - 160, y: p.y - 140, width: 320, height: 220 } });
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
