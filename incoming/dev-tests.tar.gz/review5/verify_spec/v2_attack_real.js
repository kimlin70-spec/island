// Verify spec-2 through the real UI and the real game loop:
// real clicks: 시험 -> 나무, 돌 +20; 만들기 -> 울타리 card -> 8 tiles around the player; 만들기 (close); 시험 -> 좀비 1마리 부르기.
// Then log (in game time) the zombie's shown frame on every frame, and how long 'attack' stays after each hit.
const path = require('path');
const { setup, UI } = require('../../p5/lib5.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  await T.testItem(0);                       // 나무, 돌 +20
  await T.ui(...UI.craft);                   // 만들기
  await T.ui(...UI.card(2));                 // 울타리
  const pt = await G(() => { const p = window.__game.scene.getScene('game').player; return [p.tile.col, p.tile.row]; });
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
    if (!dc && !dr) continue;
    const c = pt[0] + dc, r = pt[1] + dr;
    await T.tapWorld((c - r) * 40, (c + r) * 20, 250);
  }
  await T.ui(...UI.craft);                   // close the craft window (build mode ends)
  const fences = await G(() => window.__game.scene.getScene('game').build.count('fence'));
  console.log('player tile', pt, 'fences built by clicks:', fences);
  await G(() => {
    const s = window.__game.scene.getScene('game');
    window.__log = [];
    const origHit = s.enemies.hitStructure.bind(s.enemies);
    s.enemies.hitStructure = (e, st) => { window.__log.push({ ev: 'HIT', t: +s.elapsed.toFixed(3), type: st.type, hpAfter: st.hp - 1 }); return origHit(e, st); };
    s.events.on('postupdate', () => {
      const z = s.enemies.list[0]; if (!z) return;
      const names = s.map.assets[z.key].frames;
      window.__log.push({ ev: 'f', t: +s.elapsed.toFixed(3), frame: names[z.sprite.frame.name], anim: z.sprite.anims.isPlaying, moving: z.moving, attackLeft: +z.attackLeft.toFixed(3) });
    });
  });
  await T.testItem(3);                       // 좀비 1마리 부르기 (real clicks)
  await T.testItem(4);                       // 속도 ×3 until it starts hitting a fence
  await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.smashing), null, 180000);
  await T.testItem(4);                       // back to ×1
  await W((n) => window.__game.scene.getScene('game').build.count('fence') < n, fences, 120000);
  // catch the screen a moment after the breaking blow
  await page.waitForTimeout(120);
  await page.screenshot({ path: path.join(__dirname, 'v2_after_break.png') });
  await page.waitForTimeout(1500);
  const log = await G(() => window.__log);
  const fps = await G(() => window.__game.loop.actualFps.toFixed(1));
  console.log('actual fps', fps);
  const rows = [];
  for (let i = 0; i < log.length; i++) {
    if (log[i].ev !== 'HIT') continue;
    let n = 0, last = null;
    for (let j = i + 1; j < log.length; j++) { if (log[j].ev !== 'f') continue; if (log[j].frame === 'attack') { n++; last = log[j].t; } else break; }
    let next = log.slice(i + 1).find((x) => x.ev === 'f' && x.frame !== 'attack');
    rows.push({ hit: `${log[i].type} hp->${log[i].hpAfter}`, at: log[i].t, framesWithAttack: n, attackUntil: last, firstNonAttackFrameAt: next ? next.t : null, gap_s: next ? +(next.t - log[i].t).toFixed(3) : null });
  }
  console.table(rows);
  const bi = log.findIndex((x) => x.ev === 'HIT' && x.hpAfter === 0);
  console.log('around the breaking blow:');
  for (const x of log.slice(Math.max(0, bi - 1), bi + 6)) console.log(J(x));
  console.log('bad', J(await T.bad()), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
