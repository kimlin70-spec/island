// Phase 15 확인: 효과음 (15장)
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  // 모든 소리를 적어 둔다(이름, 크기, detune)
  const st0 = await G(() => { const s = window.__S = window.__game.scene.getScene('game'); const snd = s.sound; window.__played = [];
    const orig = snd.play.bind(snd); snd.play = (k, c) => { window.__played.push([k, +(c && c.volume || 0).toFixed(3), c && c.detune || 0, +s.elapsed.toFixed(2)]); return orig(k, c); };
    return { locked: snd.locked, n: Object.keys(s.cache.json.get('manifest').sounds).length, loaded: Object.keys(s.cache.json.get('manifest').sounds).filter((k) => s.cache.audio.exists(k)).length }; });
  ok('all 44 sounds are loaded', st0.n === 44 && st0.loaded === 44, J(st0));
  const before = await G(() => { window.__S.notice('x'); window.__S.sfx.play('ui_click'); return window.__played.length; });
  ok('before the first tap nothing plays (locked)', !st0.locked || before === 0, J({ st0, before }));
  // 첫 누름(땅) -> 풀림
  await T.tapWorld(...Object.values(await G(() => { const p = window.__S.player; return { x: (p.col - p.row + 1) * 40, y: (p.col + p.row + 1) * 20 }; })), 400);
  const un = await G(() => ({ locked: window.__S.sound.locked, loops: Object.fromEntries(Object.entries(window.__S.sfx.loops).map(([k, L]) => [k, { playing: L.snd.isPlaying, target: +L.target.toFixed(3) }])) }));
  ok('after the first tap sound is unlocked; day ambience loop playing at 0.5 x 0.8, night ambience at 0', !un.locked && un.loops.amb_day.playing && un.loops.amb_day.target === 0.4 && un.loops.amb_night.target === 0, J(un));
  await T.sleep(); await T.run(2);
  const log = async (fn, arg) => { await G(() => { window.__played.length = 0; }); await G(fn, arg); };
  const names = () => G(() => window.__played.map((p) => p[0]));
  // UI: 만들기 단추 -> ui_click, 모자란 카드 -> ui_error
  await G(() => { window.__played.length = 0; });
  await T.uiS(1824, 1104);
  let n = await names();
  ok('craft button plays ui_click', n.includes('ui_click'), J(n));
  await G(() => { window.__played.length = 0; const s = window.__S; s.pressCard({ id: 'tent', type: 'build', icon: 'icon_tent' }); });
  n = await names();
  ok('a card you cannot afford plays ui_error', n.includes('ui_error') && !n.includes('ui_click'), J(n));
  await T.uiS(1824, 1104);
  // 나무 베기: swing(0.5x), hit_wood(detune), tree_fall, pickup
  await G(() => { window.__played.length = 0; const s = window.__S, p = s.player;
    const t = s.map.objects.filter((o) => o.node && o.node.group === 'tree').sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0]; s.pressNode(t); });
  await T.run(60 * 12);
  let pl = await G(() => window.__played.slice());
  n = pl.map((p) => p[0]);
  const hw = pl.filter((p) => p[0] === 'hit_wood'), sw = pl.find((p) => p[0] === 'swing');
  ok('cutting a tree: swing (volume 0.5 x 0.8), hit_wood each hit with random detune, tree_fall, pickup', sw && Math.abs(sw[1] - 0.4) < 0.01 && hw.length >= 3 && hw.some((p) => p[2] !== 0) && n.includes('tree_fall') && n.includes('pickup'), J(n));
  // 짓기: construct. 소리 크기 거리: 멀리(>14칸)서는 틀지 않음
  await G(() => { window.__played.length = 0; const s = window.__S, p = s.player.tile; s.build.setMode('fence');
    for (const [dc, dr] of [[2, 0], [0, 2], [-2, 0], [0, -2]]) { const w = { x: (p.col + dc - p.row - dr) * 40, y: (p.col + dc + p.row + dr) * 20 }; if (s.build.canBuildAt(p.col + dc, p.row + dr)) { s.pressing = true; s.build.commit(w.x, w.y); break; } }
    s.build.setMode(null);
    const far = s.player; s.sfx.play('hit_stone', { at: { x: (far.col + 20 - far.row) * 40, y: (far.col + 20 + far.row) * 20 } });
    s.sfx.play('hit_iron', { at: { x: (far.col + 9 - far.row) * 40, y: (far.col + 9 + far.row) * 20 } }); });
  pl = await G(() => window.__played.slice());
  const iron = pl.find((p) => p[0] === 'hit_iron');
  ok('building plays construct; a sound 20 tiles away is skipped, one ~9 tiles away is quieter', pl.some((p) => p[0] === 'construct') && !pl.some((p) => p[0] === 'hit_stone') && iron && iron[1] > 0.1 && iron[1] < 0.6, J(pl));
  // 같은 소리 겹침: 0.05초 안에는 한 번, 동시에 4개까지
  const ov = await G(() => { const s = window.__S; window.__played.length = 0; for (let i = 0; i < 10; i++) s.sfx.play('hit_enemy'); const a = window.__played.length;
    s.sfx.last = {}; for (let i = 0; i < 10; i++) { s.sfx.last = {}; s.sfx.play('hit_enemy'); } s.sfx.last = {}; return { a, b: window.__played.length, playing: s.sound.getAll('hit_enemy').filter((x) => x.isPlaying).length }; });
  ok('same sound: once within 0.05 s, never more than 4 at the same time', ov.a === 1 && ov.b <= 4 && ov.playing <= 4, J(ov));
  // 저녁, 밤, 좀비, 싸움, 아침
  await G(() => { window.__played.length = 0; window.__S.clock.t = window.__S.clock.dayLength ? window.__S.clock.t : window.__S.clock.t; });
  await G(() => { const s = window.__S; window.__played.length = 0; s.events.emit('dusk'); });
  n = await names();
  const amb = await G(() => ({ day: window.__S.sfx.loops.amb_day.target, night: window.__S.sfx.loops.amb_night.target }));
  ok('dusk plays "dusk" and swaps the ambience to night', n.includes('dusk') && amb.day === 0 && Math.abs(amb.night - 0.4) < 1e-6, J({ n, amb }));
  await page.waitForTimeout(1500);                          // 앞의 소리들이 실제 시간으로 끝나게
  await G(() => { const s = window.__S; window.__played.length = 0; s.debugNight(); s.enemies.schedule = []; const p = s.player.tile;
    s.enemies.spawnPoint = () => ({ col: p.col + 2, row: p.row }); s.debugZombie(); });
  await T.run(60 * 10);
  n = await names();
  ok('night: night_start; zombie_rise; fighting: swing, hit_enemy, player_hurt or zombie_die', n.includes('night_start') && n.includes('zombie_rise') && n.includes('hit_enemy') && n.includes('swing'), J(n));
  await T.run(60 * 6);
  n = await names();
  ok('the zombie falls with zombie_die', n.includes('zombie_die'), J(n));
  await G(() => { window.__S.debugZombie(); });
  await T.run(60 * 2);                                     // 다 올라온 뒤
  await G(() => { window.__played.length = 0; window.__S.groanLeft = 0; });
  await T.run(5);
  n = await names();
  ok('during the night a zombie groans now and then', n.includes('zombie_groan'), J(n));
  await G(() => { const s = window.__S; for (const e of [...s.enemies.list]) s.enemies.remove(e); window.__played.length = 0; s.hearts.value = 3; s.debugMorning(); s.resultPending = false; });
  await T.run(30);
  n = await names();
  ok('morning plays morning and heal', n.includes('morning') && n.includes('heal'), J(n));
  // 소리 끄기 버튼: 하트 칸 오른쪽
  const mb = await G(() => { const u = window.__game.scene.getScene('ui'); const i = u.soundIcon; return { x: i.x, y: i.y, key: i.texture.key, mute: window.__S.sound.mute }; });
  await T.uiS(mb.x, mb.y);
  const mb2 = await G(() => { const u = window.__game.scene.getScene('ui'); let saved = null; try { saved = localStorage.getItem('island-survival.mute'); } catch (e) {} return { key: u.soundIcon.texture.key, mute: window.__S.sound.mute, saved }; });
  await T.uiS(mb.x, mb.y);
  const mb3 = await G(() => ({ key: window.__game.scene.getScene('ui').soundIcon.texture.key, mute: window.__S.sound.mute }));
  ok('sound button right of the hearts: tap mutes (icon_sound_off, remembered), tap again unmutes', mb.key === 'icon_sound_on' && !mb.mute && mb.x > 338 && mb2.mute && mb2.key === 'icon_sound_off' && mb2.saved === '1' && !mb3.mute && mb3.key === 'icon_sound_on', J({ mb, mb2, mb3 }));
  // 모닥불 곁
  const fire = await G(() => { const s = window.__S, p = s.player.tile; let at = null; for (const [dc, dr] of [[1, 1], [-1, 1], [1, -1], [2, 0]]) if (s.build.canBuildAt(p.col + dc, p.row + dr)) { at = { col: p.col + dc, row: p.row + dr }; break; }
    s.build.place('campfire', [at]); return at; });
  await T.run(5);
  const fv = await G(() => { const L = window.__S.sfx.loops.fire_loop; return L ? { v: +L.snd.volume.toFixed(3), playing: L.snd.isPlaying } : null; });
  ok('next to a campfire the fire loop plays at 0.6 x 0.8', fv && Math.abs(fv.v - 0.48) < 0.01 && fv.playing, J(fv));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
