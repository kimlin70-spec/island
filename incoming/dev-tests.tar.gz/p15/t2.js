const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 }); const { G, page } = T;
  await G(() => { const s = window.__S = window.__game.scene.getScene('game'); window.__played = []; const o = s.sound.play.bind(s.sound); s.sound.play = (k, c) => { window.__played.push(k); return o(k, c); }; });
  await T.tapWorld(...Object.values(await G(() => { const p = window.__S.player; return { x: (p.col - p.row + 1) * 40, y: (p.col + p.row + 1) * 20 }; })), 300);
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__S; s.enemies.schedule = []; s.startStage2(); s.debugGive(); s.tools.push('gun'); s.hurtPlayer = () => true; const p = s.player.tile;
    for (const [type, dc, dr] of [['watchtower', 2, -2], ['guntower', -2, 2]]) { const t = { col: p.col + dc, row: p.row + dr }; if (s.build.canBuildAt(t.col, t.row)) s.build.place(type, [t]); }
    s.clock.startNight(); s.enemies.schedule = []; window.__played.length = 0; s.debugPirates(); for (const e of s.enemies.list) e.hp = 99;
    const z = s.enemies.add('zombie', { col: p.col + 3, row: p.row }); z.hp = 99; });
  for (let i = 0; i < 8; i++) { await T.run(60); await page.waitForTimeout(150); }
  const n = await G(() => [...new Set(window.__played)]);
  ok('stage 2 night: ship_bell, gun_shot, arrow_shot are heard', n.includes('ship_bell') && n.includes('gun_shot') && n.includes('arrow_shot'), J(n));
  await G(() => { const s = window.__S; window.__played.length = 0; const st = s.map.structures.find((x) => x.type === 'watchtower'); s.build.destroy(st, true); });
  const c = await G(() => window.__played.slice());
  ok('a structure broken by enemies plays collapse', c.includes('collapse'), J(c));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close(); process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
