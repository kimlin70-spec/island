#!/bin/bash
# Phase 6 시험을 하나씩 차례로
cd "$(dirname "$0")"
for t in t1 t2 t3 t4 t5 t6; do echo "== p6/$t"; timeout 1500 node $t.js > out_$t.txt 2>&1; echo "exit $?"; grep -E "^FAIL|ALL PASS|FAILED|CRASH" out_$t.txt | head -8; done
echo DONE
