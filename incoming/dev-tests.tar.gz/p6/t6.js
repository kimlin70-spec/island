// Phase 6 검토 뒤 확인: 주인공 둘레가 꽉 찼을 때 적이 주인공의 칸에 서지 않는다.
// 주인공 (37,39), 울타리 (38,39), 나머지 일곱 칸에 좀비. 해적이 서쪽에서 온다. 주인공은 싸우지 않고 맞지도 않게 해 둔다.
// 1) 해적은 주인공의 칸을 밟지 않고 둘레로 돌아 다른 적의 칸에 겹쳐 선다(빈 칸이 없을 때의 규칙).
// 2) 좀비 하나가 사라져 빈 칸이 생기면, 겹쳐 서 있던 둘 중 하나가 그 칸으로 옮긴다.
// 3) 주인공이 적의 칸으로 걸어 들어가면 그 적은 시설이 없는 옆 칸으로 비켜서고, 주인공의 칸 위에서는 때리지 않는다.
const { setup, checker, J } = require('./lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => {
    const s = window.__game.scene.getScene('game'), E = s.enemies;
    E.spawn = () => null; s.hurtPlayer = () => {}; s.pressEnemy = () => {};
    s.build.place('fence', [{ col: 38, row: 39 }]);
    window.__zs = [[36, 38], [37, 38], [38, 38], [36, 39], [36, 40], [37, 40], [38, 40]].map(([c, r]) => E.add('zombie', { col: c, row: r }));
    window.__pir = E.add('pirate_1', { col: 33, row: 39 });
    window.__on = 0; window.__hitsOn = 0;
    const oh = E.hitPlayer.bind(E);
    E.hitPlayer = (e) => { const p = s.player.tile; if (e.tile.col === p.col && e.tile.row === p.row) window.__hitsOn++; oh(e); };
    s.events.on('postupdate', (t, d) => { const p = s.player.tile;
      for (const e of E.list) if (e.col === e.tile.col && e.row === e.tile.row && e.tile.col === p.col && e.tile.row === p.row) window.__on += Math.min(d / 1000, 0.1) * s.speed; });
  });
  await T.run(60 * 12);
  let st = await G(() => { const s = window.__game.scene.getScene('game'), P = window.__pir;
    const same = s.enemies.list.filter((e) => e !== P && e.tile.col === P.tile.col && e.tile.row === P.tile.row).length;
    return { pir: [P.tile.col, P.tile.row], mv: P.moving, stackedWith: same, on: +window.__on.toFixed(2), hitsOn: window.__hitsOn }; });
  ok('1) the pirate never stands on the player\'s tile; it goes round and stands next to the player', st.on === 0 && st.hitsOn === 0 && J(st.pir) !== J([37, 39]), J(st));
  // 2) (36,40)의 좀비를 없앤다
  await G(() => window.__game.scene.getScene('game').enemies.kill(window.__zs[4]));
  await T.run(60 * 4);
  st = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile;
    const tiles = s.enemies.list.map((e) => e.tile.col + ',' + e.tile.row);
    return { tiles, distinct: new Set(tiles).size, n: tiles.length, adj: s.enemies.list.every((e) => Math.max(Math.abs(e.tile.col - p.col), Math.abs(e.tile.row - p.row)) === 1) }; });
  ok('2) when a tile next to the player frees up, the doubled-up enemies spread out (all on different tiles next to the player)', st.distinct === st.n && st.adj, J(st));
  // 3) 주인공이 (36,39)의 좀비 칸으로 걸어 들어간다(땅 누르기)
  await G(() => { window.__on = 0; window.__hitsOn = 0; window.__game.scene.getScene('game').walkTo(36, 39); });
  await T.run(60 * 6);
  st = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile;
    return { p: [p.col, p.row], on: +window.__on.toFixed(2), hitsOn: window.__hitsOn,
      tiles: s.enemies.list.map((e) => [e.tile.col, e.tile.row, !!s.map.structureAt(e.tile.col, e.tile.row)]) }; });
  ok('3) the player walks onto an enemy\'s tile: it steps aside within about half a second and never hits from there',
    J(st.p) === J([36, 39]) && st.on <= 0.6 && st.hitsOn === 0 && !st.tiles.some((t) => t[0] === 36 && t[1] === 39), J(st));
  ok('per-frame: no one stood on a blocked tile', J(await T.bad()) === '[]', J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
