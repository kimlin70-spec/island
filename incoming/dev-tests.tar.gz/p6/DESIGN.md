# Phase 6 (해적) design draft

Spec: DEMO_SPEC.md 5.12, 3.7 (lamp light row), 3.5 (attack frame, poof), 5.7 (pirates not slowed), 6 (config.pirate), 9 Phase 6.
Phase 6 says: "5.12. `config.pirate.enabled`를 `true`로 바꾼다." Checks: at night a pirate ship appears in the sea at the
bottom-left of the island (preview_map.png position); a little later 2 pirates land on the beach and come to the player;
in the morning the pirates and the ships disappear.

## What exists (Phase 5)
- Enemy (src/systems/Enemy.js) = one enemy, kind table ENEMY_KINDS { zombie: { key, cfg: () => CONFIG.zombie, slowByFire } }.
  All numbers come from this.cfg (hp, speed, hitInterval, firstHitDelay, hitDamage, structureDamage, structureInterval,
  breakCost, repathInterval). Walk anim `${key}_walk` is already created by BootScene for every sheet with walk1/walk2
  (so char_pirate_1_walk / char_pirate_2_walk exist).
- EnemySystem: list, spawn(kind) at a zombieSpawns point (fx_poof), clearAll() at morning (fx_poof, not counted), defeated
  count, pickAt, near(tent), target(), takenTiles, fair re-plan budget.
- GameScene: lightSources() (campfires, tent door, player light) drawn by UIScene; 'night'/'morning' events from TimeSystem;
  clock.t = game seconds since the night started; onMorning(): enemies.clearAll(), hearts, repair, result window on day 2.

## Plan
1. config.pirate: enabled: true (Phase 6 instruction). Add, like zombie got in Phase 5: hitDamage: 1, repathInterval: 0.5,
   appearTime: 2 (ship fades in over 2 s), leaveTime: 2 (ship and boat fade out over 2 s in the morning). Spec numbers unchanged.
2. Enemy: ENEMY_KINDS gets pirate_1 { key 'char_pirate_1', cfg CONFIG.pirate, slowByFire false } and pirate_2 (char_pirate_2).
   Nothing else changes: "해적은 좀비와 같은 규칙으로 움직이고 공격한다. 다른 점은 숫자뿐이다".
3. EnemySystem.spawn(kind = 'zombie', at = null): at a given tile if `at`, else a zombie spawn point. Same fx_poof.
4. New src/systems/PirateSystem.js:
   - Makes two images at start: obj_ship at map.pirates.ship (35.92, 59.15) and obj_rowboat at map.pirates.boat
     (34.97, 53.18): origin from manifest, depth 10 + foot y (object rule), hidden (alpha 0). Not map objects: they do
     not block, are not picked by taps, no see-through (no land tile lies behind them).
   - 'night' event (only if CONFIG.pirate.enabled): arm two moments, shipAt × nightLength (52.5 s) and landAt × nightLength (67.5 s).
   - update(dt) (game time): at shipAt the ship fades in over appearTime (alpha 0 -> 1), notice "해적선이 나타났습니다".
     At landAt: the boat appears (at once), count pirates appear (fx_poof, like zombies): kinds pirate_1, pirate_2, ...
     on the landing tile (35, 51) and the next free land tiles around it, notice "해적이 상륙했습니다".
   - Landing tiles: all tiles that are walkable (land, no object, no structure) and not under any character's body
     (GameScene.characterTiles), sorted by straight-line distance from map.pirates.landing, ties by row then col; take count.
     So normally (35,51) and (35,50); if the player built on the landing tile or stands there, the nearest free tiles.
   - 'morning' event: cancel what has not happened yet; the ship and boat fade out over leaveTime, then hide.
     (Pirates vanish with fx_poof through the existing EnemySystem.clearAll.)
   - lights(): while the ship's alpha > 0, one light at ship + manifest lamp [-34, -60.1], radius 130, color #ffedc7,
     alpha 0.9 × ship alpha (so the lamp fades in and out with the ship). GameScene.lightSources() adds it.
   - Fades run on game time (dt): they stop while a window is up and run 3x with the test speed, like every other effect.
5. GameScene: create PirateSystem after EnemySystem; update it after enemies; add its light.
6. Every night (not only the first), as long as enabled. "아침으로 넘기기" before 35% -> nothing appears.
7. Defeated pirates count in the result window's "물리친 적" (they are enemies). Unit stays "마리"?? (see open question).
8. No new test button (spec section 8 has none). Manual check: 시험 -> 밤으로 넘기기 -> 속도 x3: ship after ~17 s, pirates after ~22 s.
   From the start tile (37,39) the ship is on screen near the left edge (world (-929, 1901) vs player (-80, 1520)).

## Old tests
Phase 4 tests stub enemies.spawn = () => null (no zombies). Phase 5 tests count zombies. Plan: the shared test helper turns
pirates off by default (dynamic import of /src/config.js in the page, CONFIG.pirate.enabled = false) unless a test asks for
them; new Phase 6 tests turn them on.

## Open questions (decide; ask the user only if it contradicts the spec)
Q1. Boat: appears at once at landAt (literal: "보트가 ... 나타나고"), or fades in like the ship?
Q2. Pirates appearing: with fx_poof like zombies (5.8 only says it for zombies), or without any effect?
Q3. Landing tile rule above (nearest free land tiles by distance; skip structures, objects, character bodies). Tie order OK?
Q4. Lamp light alpha follows the ship's fade alpha. OK?
Q5. Result window unit: "물리친 적 N마리" now also counts pirates (people). Keep "마리", or change? (Spec only says "물리친 적의 수".)
Q6. Should the second and later nights bring the ship too? (5.12 reads as every night.)
Q7. Anything in 5.12/3.7/3.5 or the Phase 6 checks this plan misses or gets wrong?
