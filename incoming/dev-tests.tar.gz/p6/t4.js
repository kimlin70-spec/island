// Phase 6 확인 4: 텐트 안에 있으면 해적도 텐트를 친다(각자 1.0초마다), "텐트가 공격받고 있습니다", 6칸 안에 오면 빠르기가 x1,
// 안의 주인공은 다치지 않는다. 텐트가 부서지면 주인공이 나오고 해적은 주인공을 노린다. 60Hz, 텐트는 실제 클릭으로 들어간다.
const { setup, checker, J } = require('./lib6.js');
const { ok, done } = checker();
const near = (a, b, tol) => Math.abs(a - b) <= tol;
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'), E = s.enemies, u = window.__game.scene.getScene('ui');
    E.spawn = () => null;                                                       // 좀비는 끈다
    window.__shown = []; const os = u.showNotice.bind(u); u.showNotice = (t) => { window.__shown.push([+s.elapsed.toFixed(3), t]); return os(t); };
    window.__th = []; const oh = E.hitStructure.bind(E);
    E.hitStructure = (e, x) => { window.__th.push([+s.elapsed.toFixed(3), e.kind, x.type, x.hp]); oh(e, x); };
    window.__speed = []; let nearT = null;
    s.events.on('update', () => { nearT = s.rest.resting ? s.enemies.near(s.rest.tent, 6) : null; });
    s.events.on('postupdate', () => { if (nearT !== null && s.rest.resting && s.enemies.list.length) window.__speed.push([s.speed, nearT]); });
    window.__hurt = 0; const hp = s.hearts.damage.bind(s.hearts); s.hearts.damage = (n) => { window.__hurt += n; hp(n); }; });
  const tent = await G(() => { const s = window.__game.scene.getScene('game');
    const t = s.build.place('tent', [{ col: 39, row: 37 }, { col: 40, row: 37 }, { col: 39, row: 38 }, { col: 40, row: 38 }]);
    return { wx: t.sprite.x, wy: t.sprite.y - t.sprite.displayHeight * t.sprite.originY * 0.5 }; });
  await T.run(2);
  await T.tapWorld(tent.wx, tent.wy);                                           // 실제 클릭: 텐트에 들어간다
  let r = await T.until('return s.rest.resting;', 60 * 10);
  ok('the player goes into the tent', r.ok);
  await T.testItemS(1);                                                         // 밤으로 넘기기
  r = await T.until('return s.enemies.list.length > 0;', 60 * 80);
  ok('pirates land while the player rests (4x time until they come near)', r.ok);
  r = await T.until('return s.enemies.list.filter((e) => e.smashing && e.smashing.type === "tent").length === 2;', 60 * 60);
  const st = await T.pir();
  ok('both pirates go for the tent and hit it, from different tiles', r.ok && st.enemies[0].tile.join() !== st.enemies[1].tile.join(), J(st.enemies));
  await T.run(60 * 4);
  const th = await G(() => window.__th.slice());
  const per = ['pirate_1', 'pirate_2'].map((k) => th.filter((h) => h[1] === k).map((h) => h[0]));
  const gaps = per.map((ts) => ts.slice(1).map((t, i) => +(t - ts[i]).toFixed(3)));
  ok('each pirate hits the tent every 1.0 s', per.every((ts) => ts.length >= 3) && gaps.every((g) => g.every((x) => near(x, 1.0, 0.02))), J(gaps));
  const sp = await G(() => [...new Set(window.__speed.map((x) => x.join('/')))]);
  ok('the speed is x4 while no pirate is within 6 tiles of the tent, x1 once one is', J(sp.sort()) === J(['1/true', '4/false']), J(sp));
  const shown = await G(() => window.__shown.filter((x) => x[1] === '텐트가 공격받고 있습니다'));
  ok('notice "텐트가 공격받고 있습니다" once when the attack starts', shown.length === 1 && near(shown[0][0], th[0][0], 0.02), J({ shown, first: th[0] }));
  ok('the player inside is not hurt', (await G(() => window.__hurt)) === 0);
  r = await T.until('return !s.rest.resting;', 60 * 30);
  const out = await G(() => { const s = window.__game.scene.getScene('game'); return { tent: s.map.structures.some((x) => x.type === 'tent'), tile: [s.player.tile.col, s.player.tile.row], target: s.enemies.target().structure }; });
  ok('the tent breaks (24 hp): the player comes out next to it and the pirates go for the player', r.ok && !out.tent && out.target === null, J(out));
  ok('per-frame: no one stood on a blocked tile', J(await T.bad()) === '[]', J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
