// Phase 6 확인 1: 밤 -> 35% 해적선(2초에 걸쳐, 알림, 등불 빛) -> 45% 보트와 해적 2명(상륙 칸과 옆 칸, 알림, 효과 없음)
// -> 초당 1.8칸으로 걸어온다 -> 붙으면 1.0초 뒤 첫 공격, 그다음 1.6초마다 하트 1 -> 해적을 누르면 단검 4번에 사라진다
// -> 아침: 남은 해적은 먼지와 함께 사라지고(물리친 수에 안 넣음), 배와 보트는 2초에 걸쳐 사라진다 -> 결과 창.
// 60Hz 고정 간격. 누르기는 실제 마우스 클릭. 좀비는 끈다(해적만 본다).
const { setup, checker, J } = require('./lib6.js');
const { ok, done } = checker();
const near = (a, b, tol) => Math.abs(a - b) <= tol;
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => {
    const s = window.__game.scene.getScene('game'), E = s.enemies;
    E.spawn = () => null;                                         // 좀비는 끈다
    window.__poofs = []; const op = s.effects.poof.bind(s.effects);
    s.effects.poof = (x, y) => { window.__poofs.push([+s.elapsed.toFixed(3), Math.round(x), Math.round(y)]); op(x, y); };
    window.__hits = []; const oh = E.hitPlayer.bind(E);
    E.hitPlayer = (e) => { window.__hits.push([+s.elapsed.toFixed(3), e.kind, e.__tid || (e.__tid = E.list.indexOf(e) + 1), s.hearts.value]); oh(e); };
    window.__added = []; const oa = E.add.bind(E);
    E.add = (k, t) => { const e = oa(k, t); window.__added.push([+s.clock.t.toFixed(3), k, t.col, t.row]); return e; };
  });

  // 1. 밤으로 넘기기(실제 클릭)
  await T.testItemS(1);
  let st = await T.pir();
  ok('night: no ship, no boat, no lamp light yet', st.night && !st.ship.v && !st.boat.v && st.lights.length === 1, J(st));
  await T.until('return s.clock.t >= 52.4;', 60 * 60);
  st = await T.pir();
  ok('just before 35% of the night (52.5 s): still no ship', !st.ship.v && st.ship.a === 0, J(st.ship));

  // 2. 해적선: 35%에 나타나기 시작, 2초에 걸쳐
  let r = await T.until('return s.pirates.ship.visible;', 60 * 2);
  const t0 = (await T.pir()).t;
  ok('the ship starts to appear at 35% of the night', r.ok && near(t0, 52.5, 0.05), J({ r, t0 }));
  const notes = await T.notices();
  ok('notice "해적선이 나타났습니다" at that moment', notes.some((n) => n[2] === '해적선이 나타났습니다' && near(n[1], 52.5, 0.05)), J(notes));
  const samples = [];
  for (let i = 0; i < 14; i++) { await T.run(10); samples.push(await T.pir()); }
  const ramp = samples.map((p) => [+(p.t - t0).toFixed(2), p.ship.a]);
  const half = samples.find((p) => near(p.t - t0, 1.0, 0.09));
  ok('ship alpha rises evenly over 2 s (about 0.5 after 1 s)', half && near(half.ship.a, 0.5, 0.06), J(ramp));
  const full = samples.filter((p) => p.t - t0 >= 2.02);
  ok('ship fully shown after 2 s and stays', full.length && full.every((p) => p.ship.a === 1), J(ramp));
  const ship = samples[samples.length - 1].ship;
  const lampOk = samples.every((p) => { const L = p.lights.find((l) => l.r === 130); return L && L.c === 0xffedc7 && near(L.a, 0.9 * p.ship.a, 0.002)
    && near(L.x, p.ship.x - 34, 0.2) && near(L.y, p.ship.y - 60.1, 0.2); });
  ok('lamp light: at ship + lamp, radius 130, #ffedc7, alpha 0.9 x ship alpha', lampOk, J(samples.slice(0, 3).map((p) => p.lights)));
  ok('ship depth is 10 + its foot y (object rule)', near(ship.d, 10 + ship.y, 0.01), J(ship));
  // 등불이 바다를 밝힌다: 등불 빛만 껐다 켰다 하며 같은 자리의 밝기를 잰다
  const g = await T.w2g(ship.x - 34, ship.y - 60.1 + 40);
  const lit = await T.lumS(g.x, g.y, 10);
  await G(async () => { const m = await import('/src/config.js'); window.__la = m.CONFIG.pirate.lampLight.alpha; m.CONFIG.pirate.lampLight.alpha = 0; });
  const unlit = await T.lumS(g.x, g.y, 10);
  await G(async () => { const m = await import('/src/config.js'); m.CONFIG.pirate.lampLight.alpha = window.__la; });
  ok('the lamp light brightens the ship and sea at night', lit > unlit + 15, J({ at: g, lit, unlit }));
  await T.shot('t1_ship');

  // 3. 상륙: 45%
  r = await T.until('return s.enemies.list.length > 0;', 60 * 20);
  st = await T.pir();
  ok('pirates land at 45% of the night (67.5 s)', r.ok && near(st.t, 67.5, 0.05), J({ r, t: st.t }));
  ok('the boat appears at once at its place', st.boat.v && st.boat.a === 1 && near(st.boat.d, 10 + st.boat.y, 0.01), J(st.boat));
  const kinds = st.enemies.map((e) => e.kind + ':' + e.key + '@' + e.tile.join(','));
  ok('2 pirates: char_pirate_1 on the landing tile (35,51), char_pirate_2 on the tile next to it (35,50)',
    J(kinds) === J(['pirate_1:char_pirate_1@35,51', 'pirate_2:char_pirate_2@35,50']), J(kinds));
  ok('notice "해적이 상륙했습니다"', (await T.notices()).some((n) => n[2] === '해적이 상륙했습니다' && near(n[1], 67.5, 0.05)), J(await T.notices()));
  ok('no dust puff when they land (5.12 has no effect)', (await G(() => window.__poofs.length)) === 0, J(await G(() => window.__poofs)));
  ok('pirates have 4 hp', st.enemies.every((e) => e.hp === 4), J(st.enemies));

  // 4. 걸어오는 빠르기: 1초 동안 걸은 길이
  await G(() => { const s = window.__game.scene.getScene('game'); window.__walk = s.enemies.list.map((e) => ({ e, d: 0, last: [e.col, e.row] }));
    window.__walkT = 0; window.__walkOn = true;
    s.events.on('postupdate', (t, d) => { if (!window.__walkOn) return; window.__walkT += Math.min(d / 1000, 0.1) * s.speed;
      for (const w of window.__walk) { w.d += Math.hypot(w.e.col - w.last[0], w.e.row - w.last[1]); w.last = [w.e.col, w.e.row]; } }); });
  await T.run(60);
  const sp = await G(() => { window.__walkOn = false; return window.__walk.map((w) => +(w.d / window.__walkT).toFixed(3)); });
  ok('pirates walk at 1.8 tiles/s', sp.every((v) => near(v, 1.8, 0.02)), J(sp));
  const look = await G(() => window.__game.scene.getScene('game').enemies.list.map((e) => ({ anim: e.sprite.anims.isPlaying && e.sprite.anims.currentAnim.key, depth: +e.sprite.depth.toFixed(2), y: +e.sprite.y.toFixed(2) })));
  // Phase 10: 걷기는 manifest 의 walk(앞모습)나 bwalk(뒷모습). 그림은 밀릴 때만 발에서 벗어나므로 depth 는 발 기준.
  ok('walking pirates play their own walk animation (walk or bwalk), depth 10 + foot y + 0.5', look.every((l, i) => ['walk', 'bwalk'].map((a) => ['char_pirate_1', 'char_pirate_2'][i] + ':' + a).includes(l.anim) && near(l.depth, 10 + l.y + 0.5, 0.01)), J(look));

  // 5. 주인공은 가만히(자동 공격도 끈다): 붙은 뒤 1.0초 뒤 첫 공격, 그다음 1.6초마다
  await G(() => { const s = window.__game.scene.getScene('game'); window.__press = s.pressEnemy; s.pressEnemy = () => {};
    window.__adj = new Map();
    s.events.on('postupdate', () => { const p = s.player.tile;
      for (const e of s.enemies.list) { const atC = e.col === e.tile.col && e.row === e.tile.row;
        const adj = atC && !e.moving && Math.max(Math.abs(e.tile.col - p.col), Math.abs(e.tile.row - p.row)) <= 1;
        if (adj && !window.__adj.has(e)) window.__adj.set(e, +s.elapsed.toFixed(3)); } }); });
  r = await T.until('return window.__hits.length >= 4;', 60 * 40);
  const fight = await G(() => { const s = window.__game.scene.getScene('game');
    return { adj: [...window.__adj.entries()].map(([e, t]) => [e.kind, t]), hits: window.__hits.slice(), hearts: s.hearts.value }; });
  const per = (k) => fight.hits.filter((h) => h[1] === k).map((h) => h[0]);
  const gaps = ['pirate_1', 'pirate_2'].map((k) => { const a = fight.adj.find((x) => x[0] === k), h = per(k); return a && h.length >= 2 ? [+(h[0] - a[1]).toFixed(3), +(h[1] - h[0]).toFixed(3)] : null; });
  ok('each pirate: first hit 1.0 s after standing next to the player, then every 1.6 s', r.ok && gaps.every((x) => x && near(x[0], 1.0, 0.02) && near(x[1], 1.6, 0.02)), J({ gaps, fight }));
  ok('each hit takes 1 heart', fight.hits.every((h, i) => i === 0 || h[3] === fight.hits[i - 1][3] - 1) && fight.hearts === 5 - fight.hits.length, J(fight.hits));

  // 6. 해적을 누른다(실제 클릭): 단검 4번에 사라진다
  await G(() => { const s = window.__game.scene.getScene('game'); s.pressEnemy = window.__press; s.hearts.value = 5; s.events.emit('hearts-changed');
    window.__strikes = []; const proto = Object.getPrototypeOf(s.enemies.list[0]); const oh = proto.hurt;
    proto.hurt = function (n, ...rest) { window.__strikes.push([+s.elapsed.toFixed(3), this.kind, this.hp, n]); return oh.call(this, n, ...rest); }; });
  const pt = await T.enemyPoint(0);
  // 두 해적의 그림이 겹치면 앞에 있는 쪽이 골라진다(3.5). 그 점에서 게임이 고르는 해적을 따라간다.
  pt.kind = await G(([x, y]) => window.__game.scene.getScene('game').enemies.pickAt(x, y).kind, [pt.wx, pt.wy]);
  await T.tapWorld(pt.wx, pt.wy);
  await T.run(2);
  const act = await G(() => { const a = window.__game.scene.getScene('game').player.action; return a && a.chase ? a.target.kind : null; });
  ok('a click on the pirate makes the player fight it', act === pt.kind, J({ act, pt }));
  r = await T.until(`return !s.enemies.list.some((e) => e.kind === '${pt.kind}');`, 60 * 15);
  await G(() => { const s = window.__game.scene.getScene('game'); s.pressEnemy = () => {}; s.player.stopAction(); });   // 남은 해적은 아침까지 둔다
  const strikes = await G(() => window.__strikes.slice());
  const mine = strikes.filter((x) => x[1] === pt.kind);
  ok('4 dagger hits (1 each) and it is gone', r.ok && mine.length === 4 && mine.every((x) => x[3] === 1) && mine[3][2] === 1, J(strikes));
  st = await T.pir();
  // Phase 10 (12.3): 쓰러진 해적은 die 를 보여 주고 흐려지며 fx_dust 로 사라진다(fx_poof 가 아니다)
  ok('it counts as defeated; it falls (die) instead of a dust puff', st.defeated === 1 && (await G(() => window.__poofs.length)) === 0
    && (await G(() => window.__game.scene.getScene('game').children.list.some((o) => o.texture && /^char_pirate/.test(o.texture.key) && o.anims && o.anims.currentAnim && /:die$/.test(o.anims.currentAnim.key)))),
    J({ d: st.defeated, poofs: await G(() => window.__poofs) }));

  // 7. 아침으로 넘기기(실제 클릭): 남은 해적은 먼지와 함께 사라지고, 배와 보트는 2초에 걸쳐
  const before = await T.pir();
  await T.testItemS(2);
  st = await T.pir();
  const m0 = st.t;
  ok('morning: the last pirate vanishes at once, with a dust puff, not counted', st.enemies.length === 0 && st.defeated === before.defeated
    && (await G(() => window.__poofs.length)) === 1, J({ st, poofs: await G(() => window.__poofs) }));
  const fade = [];
  for (let i = 0; i < 14; i++) { await T.run(10); fade.push(await T.pir()); }
  const mid = fade.find((p) => near(p.t - m0, 1.0, 0.09));
  ok('ship and boat fade out together (about 0.5 after 1 s)', mid && near(mid.ship.a, 0.5, 0.06) && near(mid.boat.a, 0.5, 0.06), J(fade.map((p) => [+(p.t - m0).toFixed(2), p.ship.a, p.boat.a])));
  const gone = fade.filter((p) => p.t - m0 >= 2.02);
  ok('after 2 s both are gone, and so is the lamp light', gone.length && gone.every((p) => !p.ship.v && !p.boat.v && !p.lights.some((l) => l.r === 130)), J(gone.map((p) => [p.ship, p.boat, p.lights.length])));
  ok('the lamp light faded with the ship', fade.every((p) => { const L = p.lights.find((l) => l.r === 130); return p.ship.a === 0 ? !L : L && near(L.a, 0.9 * p.ship.a, 0.002); }));

  // 8. 결과 창: 물리친 적에 해적이 들어간다
  r = await T.until('return !g.scene.isActive("game");', 60 * 5);
  await T.run(1);
  const texts = await T.modalTexts();
  ok('result window counts the pirate', r.ok && texts && texts[0] === '첫 밤을 넘겼습니다' && texts[2] === '1마리', J(texts));
  ok('per-frame: no one stood on a blocked tile', J(await T.bad()) === '[]', J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
