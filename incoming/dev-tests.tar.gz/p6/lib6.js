// Phase 6 시험 도구: p5/lib5.js 위에, 해적을 켜고(pirates: true), 고정 간격으로 게임을 돌리는 도구(60Hz 기기처럼)를 더한다.
const path = require('path');
const lib5 = require('../p5/lib5.js');
const OUT = __dirname;
exports.UI = lib5.UI;
exports.J = JSON.stringify;
exports.checker = lib5.checker;
exports.setup = async (opts = {}) => {
  const T = await lib5.setup(Object.assign({ pirates: true }, opts));
  const { page, G } = T;
  T.shot = async (name, clip) => { const p = path.join(OUT, name + '.png'); await page.screenshot(clip ? { path: p, clip } : { path: p }); return p; };
  T.tileW = (c, r) => ({ wx: (c - r) * 40, wy: (c + r) * 20 });
  T.tapTileW = async (c, r, wait = 0) => { const w = T.tileW(c, r); return T.tapWorld(w.wx, w.wy, wait); };
  // 고정 간격 돌리기: 게임 반복을 재우고 D ms 씩 손으로 돌린다
  T.sleep = () => G(() => { const g = window.__game; if (!window.__S) window.__S = { t: performance.now() }; window.__S.asleep = true; g.loop.sleep(); });
  T.wake = () => G(() => { window.__S.asleep = false; window.__game.loop.wake(); });
  T.asleep = () => G(() => !!(window.__S && window.__S.asleep));
  T.run = (n, D = 1000 / 60) => G(([n, D]) => {
    const g = window.__game, S = window.__S;
    for (let i = 0; i < n; i++) { S.t += D; if (i === n - 1) g.step(S.t, D); else g.headlessStep(S.t, D); }
    return window.__game.scene.getScene('game').elapsed;
  }, [n, D]);
  // cond(s, g) 가 참이 될 때까지(최대 max 프레임). 마지막 프레임은 그린다.
  T.until = (src, max = 36000, D = 1000 / 60) => G(([src, max, D]) => {
    const g = window.__game, S = window.__S, s = g.scene.getScene('game');
    const cond = new Function('s', 'g', src);
    for (let i = 0; i < max; i++) {
      S.t += D; g.headlessStep(S.t, D);
      if (cond(s, g)) { S.t += D; g.step(S.t, D); return { ok: true, t: +s.elapsed.toFixed(3) }; }
    }
    S.t += D; g.step(S.t, D);
    return { ok: false, t: +s.elapsed.toFixed(3) };
  }, [src, max, D]);
  // 재운 상태에서 UI 를 누를 때: 누른 뒤 한 프레임 돌려서 반영
  T.uiS = async (x, y) => { await T.ui(x, y, 0); if (await T.asleep()) await T.run(2); else await page.waitForTimeout(250); };
  T.testItemS = async (i) => { await T.uiS(...lib5.UI.test); await T.uiS(...lib5.UI.testItem(i)); await T.uiS(...lib5.UI.testItem((await G(() => window.__game.scene.getScene('ui').debugLabels.length - 1)))); };
  // 해적 상태
  T.pir = () => G(() => { const s = window.__game.scene.getScene('game'), P = s.pirates;
    return { t: +s.clock.t.toFixed(3), night: s.clock.isNight, ship: P ? { v: P.ship.visible, a: +P.ship.alpha.toFixed(3), x: P.ship.x, y: P.ship.y, d: P.ship.depth } : null,
      boat: P ? { v: P.boat.visible, a: +P.boat.alpha.toFixed(3), x: P.boat.x, y: P.boat.y, d: P.boat.depth } : null,
      enemies: s.enemies.list.map((e) => ({ kind: e.kind, key: e.key, at: [+e.col.toFixed(2), +e.row.toFixed(2)], tile: [e.tile.col, e.tile.row], hp: e.hp, mv: e.moving })),
      lights: s.lightSources().map((L) => ({ x: +L.x.toFixed(1), y: +L.y.toFixed(1), r: +L.radius.toFixed(1), c: L.color, a: +L.alpha.toFixed(3) })),
      defeated: s.enemies.defeated }; });
  T.enemyPoint = (i = 0) => G((i) => { const e = window.__game.scene.getScene('game').enemies.list[i]; if (!e) return null;
    const sp = e.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5, kind: e.kind }; }, i);
  // 화면(게임 1920×1200 좌표) (x, y) 둘레 r 픽셀의 평균 밝기. 재운 상태에서: 요청한 뒤 한 프레임(거의 0초)을 그린다.
  T.lumS = (x, y, r = 12) => G(([x, y, r]) => new Promise((res) => {
    const g = window.__game;
    g.renderer.snapshotArea(Math.round(x - r), Math.round(y - r), r * 2, r * 2, (img) => {
      const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
      const d = ctx.getImageData(0, 0, c.width, c.height).data;
      let s = 0; for (let i = 0; i < d.length; i += 4) s += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      res(+(s / (d.length / 4)).toFixed(1));
    });
    window.__S.t += 0.0001; g.step(window.__S.t, 0.0001);
  }), [x, y, r]);
  // 월드 좌표 -> 게임 화면 좌표(1920×1200)
  T.w2g = (wx, wy) => G(([wx, wy]) => { const cam = window.__game.scene.getScene('game').cameras.main;
    return { x: (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, y: (wy - cam.midPoint.y) * cam.zoom + cam.height / 2 }; }, [wx, wy]);
  // fx_poof 그림 수(지금 화면에 있는 것)
  T.poofs = () => G(() => window.__game.scene.getScene('game').children.list.filter((o) => o.texture && o.texture.key === 'fx_poof').length);
  // 알림 기록
  await G(() => { const s = window.__game.scene.getScene('game'); window.__notices = [];
    s.events.on('notice', (t) => window.__notices.push([+s.elapsed.toFixed(3), +s.clock.t.toFixed(3), t])); });
  T.notices = () => G(() => window.__notices.slice());
  return T;
};
