// Phase 6 확인 2: 해적의 숫자. 울타리 앞에서 1.0초마다 치고(첫 대는 1.0초 뒤) 6대에 부순다, 칠 때 attack 의 hit 그림(Phase 10),
// 모닥불 둘레에서도 느려지지 않는다(같은 자리의 좀비는 0.5배), 맞으면 체력 막대(3/4), 단검 4번에 사라진다.
// 해적은 코드로 둔다(enemies.add: 상륙과 같은 길). 60Hz 고정 간격.
const { setup, checker, J } = require('./lib6.js');
const { ok, done } = checker();
const near = (a, b, tol) => Math.abs(a - b) <= tol;
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => {
    const s = window.__game.scene.getScene('game'), E = s.enemies;
    window.__sh = []; const os = E.hitStructure.bind(E);
    E.hitStructure = (e, x) => { window.__sh.push([+s.elapsed.toFixed(3), e.kind, x.type + '@' + x.col + ',' + x.row, x.hp]); os(e, x); };
    window.__frames = [];
    s.events.on('postupdate', () => { for (const e of E.list) if (e.kind !== 'zombie') window.__frames.push([+s.elapsed.toFixed(3), e.asset.frames[+e.sprite.frame.name], e.body.attacking(), +e.col.toFixed(3), +e.row.toFixed(3)]); });
  });

  // A. 주인공 둘레 8칸 울타리, 해적 한 명을 상륙 칸에 둔다 -> 울타리 앞에 서서 1.0초마다
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row + dr }]);
    s.enemies.add('pirate_1', { col: 35, row: 51 }); window.__stop = null;
    s.events.on('postupdate', () => { const e = s.enemies.list[0]; if (e && e.smashing && window.__stop === null) window.__stop = +s.elapsed.toFixed(3); }); });
  let r = await T.until('return s.build.count("fence") === 7;', 60 * 40);
  const sh = await G(() => window.__sh.slice()), stop = await G(() => window.__stop);
  const gaps = sh.slice(1).map((x, i) => +(x[0] - sh[i][0]).toFixed(3));
  ok('the pirate stands in front of a fence and hits it 1.0 s after stopping', sh.length && near(sh[0][0] - stop, 1.0, 0.02), J({ stop, sh: sh.slice(0, 2) }));
  ok('then every 1.0 s, 6 hits break the fence (hp 6)', r.ok && sh.length === 6 && gaps.every((g) => near(g, 1.0, 0.02)) && sh[0][3] === 6, J({ gaps, sh }));
  await T.run(30);                                               // 마지막 한 대 뒤 0.5초를 더 본다
  const fr = await G(() => window.__frames.slice());
  // Phase 10 (12.3, 12.4): 칠 때 attack 의 hit 그림이 나오고 0.05초 멈칫한다. 휘두르는 동작이 끝날 때까지 걷지 않는다(부순 마지막 한 대도).
  const hitFrames = sh.map((h) => fr.filter((f) => f[0] >= h[0] - 1e-6 && f[0] < h[0] + 0.05 - 1e-6));
  ok('each hit shows the attack hit frame at the hit and holds it for the 0.05 s hit stop (the breaking blow too)', hitFrames.every((fs) => fs.length >= 3 && fs.every((f) => /attack$/.test(f[1]))),
    J(hitFrames.map((fs) => [fs.length, [...new Set(fs.map((f) => f[1]))]])));
  const last = sh[sh.length - 1][0], after = fr.filter((f) => f[0] >= last - 1e-6);
  const firstMove = after.find((f) => f[3] !== after[0][3] || f[4] !== after[0][4]), endSwing = after.find((f) => !f[2]);
  ok('after the breaking blow it finishes the swing (0.16-0.25 s + 0.05 s) before walking on', endSwing && endSwing[0] - last >= 0.2 && endSwing[0] - last <= 0.32 && (!firstMove || firstMove[0] >= endSwing[0] - 1e-6),
    J({ last, endSwing, firstMove }));

  // B. 들어와서 가만히 선 주인공과 싸운다: 자동으로 싸우고, 단검 4번에 사라진다
  await G(() => { const s = window.__game.scene.getScene('game'); window.__hp = [];
    const proto = Object.getPrototypeOf(s.enemies.list[0]), oh = proto.hurt;
    proto.hurt = function (n, ...rest) { const r = oh.call(this, n, ...rest); window.__hp.push([this.kind, this.hp]); return r; };
    window.__bar = []; s.events.on('postupdate', () => { for (const e of s.enemies.list) window.__bar.push([e.hp, !!(e.bar && e.bar.g.visible)]); }); });
  r = await T.until('return s.enemies.list.length === 0;', 60 * 30);
  const hp = await G(() => window.__hp.slice());
  ok('the standing player fights it by itself; 4 dagger hits', r.ok && J(hp.map((h) => h[1])) === J([3, 2, 1, 0]), J(hp));
  const bars = await G(() => [...new Set(window.__bar.map((b) => b.join(':')))]);
  ok('the hp bar shows only while damaged (from the first hit on)', J(bars) === J(['4:false', '3:true', '2:true', '1:true']), J(bars));
  const def = await G(() => window.__game.scene.getScene('game').enemies.defeated);
  ok('it counts as defeated', def === 1, J(def));

  // C. 모닥불 둘레: 해적은 느려지지 않는다. 같은 때의 좀비는 0.5배.
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    for (const f of s.map.structures.slice()) s.build.destroy(f);
    s.build.place('campfire', [{ col: p.tile.col, row: p.tile.row - 1 }]);
    s.hurtPlayer = () => {}; s.pressEnemy = () => {};                              // 이 시험에서는 싸우지 않는다
    const cf = { col: p.tile.col, row: p.tile.row - 1 }; window.__sp = { pirate_1: [], zombie: [] }; const last = new Map();
    s.events.on('postupdate', (t, d) => { const dt = Math.min(d / 1000, 0.1) * s.speed;
      for (const e of s.enemies.list) { const l = last.get(e);
        if (l && e.moving) { const dd = Math.hypot(e.col - l[0], e.row - l[1]); if (dd > 0 && dt > 0) window.__sp[e.kind].push([dd / dt, Math.hypot(e.col - cf.col, e.row - cf.row)]); }
        last.set(e, [e.col, e.row]); } });
    s.enemies.add('pirate_1', { col: 35, row: 51 }); s.debugZombie(); });
  r = await T.until('return s.enemies.list.every((e) => !e.moving && Math.hypot(e.col - s.player.col, e.row - s.player.row) < 1.6);', 60 * 60);
  const spd = await G(() => { const avg = (a) => a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(3) : null;
    const o = {}; for (const k of ['pirate_1', 'zombie']) { const n = window.__sp[k].filter((x) => x[1] <= 2.9).map((x) => x[0]), f = window.__sp[k].filter((x) => x[1] >= 3.1).map((x) => x[0]);
      o[k] = { near: avg(n), nNear: n.length, far: avg(f), nFar: f.length }; } return o; });
  ok('near a campfire the pirate still walks at 1.8 tiles/s', spd.pirate_1.nNear > 5 && near(spd.pirate_1.near, 1.8, 0.02) && near(spd.pirate_1.far, 1.8, 0.02), J(spd));
  ok('the zombie next to it is slowed to 0.6 (only zombies are slowed)', spd.zombie.nNear > 5 && near(spd.zombie.near, 0.6, 0.02) && near(spd.zombie.far, 1.2, 0.02), J(spd));

  ok('per-frame: no one stood on a blocked tile', J(await T.bad()) === '[]', J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
