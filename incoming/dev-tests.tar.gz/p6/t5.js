// Phase 6 확인 5: 태블릿 크기(1024×768) 터치. 밤으로 넘기기 -> 해적선과 알림(화면 글자) -> 상륙 알림 -> 다가오는 해적을 터치하면 싸운다.
// 실제 반복(재우지 않음), 속도 x3.
const { setup, checker, J } = require('./lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'); s.enemies.spawn = () => null;
    window.__shown = []; const os = u.showNotice.bind(u); u.showNotice = (t) => { window.__shown.push(t); return os(t); }; });
  await T.testItem(1);                                                          // 밤으로 넘기기(터치)
  await T.testItem(4);                                                          // 속도 x3(터치)
  await W(() => window.__game.scene.getScene('game').pirates.ship.visible, null, 240000);
  await page.waitForTimeout(800);
  ok('touch: the ship notice is shown on screen', (await G(() => window.__shown)).includes('해적선이 나타났습니다'), J(await G(() => window.__shown)));
  await W(() => window.__game.scene.getScene('game').enemies.list.length > 0, null, 120000);
  await page.waitForTimeout(800);
  ok('touch: the landing notice is shown on screen', (await G(() => window.__shown)).includes('해적이 상륙했습니다'), J(await G(() => window.__shown)));
  await page.screenshot({ path: __dirname + '/t5_tablet_landing.png' });
  await W(() => { const s = window.__game.scene.getScene('game'), p = s.player; return s.enemies.list.some((e) => Math.hypot(e.col - p.col, e.row - p.row) < 5); }, null, 120000);
  await T.testItem(4);                                                          // 속도 x1 로
  const pt = await T.enemyPoint(0);
  pt.kind = await G(([x, y]) => { const e = window.__game.scene.getScene('game').enemies.pickAt(x, y); return e && e.kind; }, [pt.wx, pt.wy]);
  await T.tapWorld(pt.wx, pt.wy);
  await page.waitForTimeout(200);
  const act = await G(() => { const a = window.__game.scene.getScene('game').player.action; return a && a.chase ? a.target.kind : null; });
  ok('touch: tapping a pirate makes the player go for it', act === pt.kind, J({ act, pt }));
  await W((k) => !window.__game.scene.getScene('game').enemies.list.some((e) => e.kind === k), pt.kind, 120000);
  ok('touch: that pirate is beaten', (await G(() => window.__game.scene.getScene('game').enemies.defeated)) >= 1);
  ok('per-frame: no one stood on a blocked tile', J(await T.bad()) === '[]', J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
