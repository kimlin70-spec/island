// 빠른 확인: 밤으로 넘기고 해적선·상륙·아침을 본다(고정 간격 60Hz)
const { setup, J } = require('./lib6.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await T.testItemS(1);                                   // 밤으로 넘기기
  console.log('night', J(await T.pir()));
  let r = await T.until('return s.pirates.ship.visible;', 60 * 80);
  console.log('ship', J(r), J(await T.pir()));
  await T.run(60 * 2);
  console.log('ship +2s', J((await T.pir()).ship), J((await T.pir()).lights));
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie");', 60 * 30);
  console.log('land', J(r), J(await T.pir()));
  await T.shot('smoke_land');
  await T.run(60 * 5);
  console.log('+5s', J((await T.pir()).enemies));
  await T.testItemS(2);                                   // 아침으로 넘기기
  console.log('morning', J(await T.pir()));
  await T.run(60);
  console.log('morning +1s', J((await T.pir()).ship), J((await T.pir()).boat));
  await T.run(65);
  console.log('morning +2.1s', J((await T.pir()).ship), J((await T.pir()).boat), J((await T.pir()).lights.length));
  console.log('notices', J(await T.notices()));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
