// Phase 6 확인 3: 상륙 자리와 밤·아침 버튼.
// A. 상륙 칸에 울타리가 있으면 그다음으로 가까운 빈 칸(35,50),(34,51)에 내린다.
// B. 아침이 해적선이 나타나는 도중(알파 0.5)에 오면, 그 자리에서부터 천천히 사라진다(1로 튀지 않는다). 보트와 해적은 그 밤에 오지 않는다.
// C. 다음 밤에도 35%에 해적선, 45%에 해적 2명. 주인공이 상륙 칸에 서 있으면 그 칸을 비워 둔다.
// D. 해적선이 사라지는 도중에 밤이 되어도(3일째부터) 끝까지 사라졌다가 35%에 다시 나타난다.
// E. 해적을 끈 시험 도구(기본값)로 열면 밤이 지나도 배·보트·해적·등불이 없다.
const { setup, checker, J } = require('./lib6.js');
const { ok, done } = checker();
const near = (a, b, tol) => Math.abs(a - b) <= tol;
(async () => {
  let T = await setup({ w: 960, h: 600 });
  let G = T.G;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.spawn = () => null; s.hurtPlayer = () => {}; s.pressEnemy = () => {}; });

  // A. 상륙 칸에 울타리
  await G(() => window.__game.scene.getScene('game').build.place('fence', [{ col: 35, row: 51 }]));
  await T.testItemS(1);                                                    // 밤으로 넘기기
  let r = await T.until('return s.enemies.list.length > 0;', 60 * 75);
  let st = await T.pir();
  ok('A. landing tile fenced: pirates land on the nearest free tiles (35,50) and (34,51)', r.ok && J(st.enemies.map((e) => e.tile)) === J([[35, 50], [34, 51]]), J(st.enemies));

  // B. 아침으로 넘기기(실제 클릭) -> 다음 밤 -> 해적선이 반쯤 나왔을 때 아침
  await T.testItemS(2);
  r = await T.until('return !g.scene.isActive("game");', 60 * 5);           // 첫 아침: 결과 창
  await T.modalButton('계속하기'); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); for (const x of s.map.structures.slice()) s.build.destroy(x); });
  await T.testItemS(1);                                                    // 2일째 밤
  r = await T.until('return s.pirates.ship.alpha >= 0.5;', 60 * 60);
  const a0 = (await T.pir()).ship.a;
  await T.testItemS(2);                                                    // 3일째 아침
  const seq = [];
  for (let i = 0; i < 80; i++) { await T.run(1); const p = await T.pir(); seq.push([p.ship.a, p.ship.v]); }
  const down = seq.every((x, i) => i === 0 || x[0] <= seq[i - 1][0]);
  ok('B. morning during the fade-in: the ship fades out from where it was (no jump), in about 1 s from 0.5',
    near(a0, 0.5, 0.03) && seq[0][0] <= a0 && down && seq.findIndex((x) => x[0] === 0) <= 64 && seq.findIndex((x) => x[0] === 0) >= 55, J({ a0, seq: seq.filter((x, i) => i % 8 === 0) }));
  await T.run(60 * 20);
  st = await T.pir();
  ok('B. that night the boat and pirates never came', !st.boat.v && st.enemies.length === 0 && !st.night, J(st));

  // C. 다음 밤: 주인공이 상륙 칸에 서 있다
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; p.col = 35; p.row = 51; p.tile = { col: 35, row: 51 }; p.path.length = 0; p.syncSprite(); });
  await T.testItemS(1);                                                    // 3일째 밤
  r = await T.until('return s.pirates.ship.visible;', 60 * 60);
  st = await T.pir();
  ok('C. the next night the ship comes again at 35%', r.ok && near(st.t, 52.5, 0.05), J(st.t));
  r = await T.until('return s.enemies.list.length > 0;', 60 * 20);
  st = await T.pir();
  ok('C. the player stands on the landing tile: pirates land on (35,50) and (34,51), not on the player',
    r.ok && near(st.t, 67.5, 0.05) && J(st.enemies.filter((e) => e.kind !== 'pirate_3').map((e) => e.tile)) === J([[35, 50], [34, 51]]), J(st));   // (Phase 9) 2단계에서는 총잡이가 그다음 칸에 하나 더

  // D. 4일째 아침 바로 뒤 밤(배가 사라지는 도중)
  await T.testItemS(2);                                                    // 4일째 아침
  await T.run(30);                                                         // 0.5초 사라지는 중
  const b0 = (await T.pir()).ship.a;
  await T.testItemS(1);                                                    // 4일째 밤
  const seq2 = [];
  for (let i = 0; i < 60 * 3; i++) { await T.run(1); seq2.push((await T.pir()).ship.a); }
  ok('D. night during the fade-out: the ship keeps fading out and is gone', b0 > 0.6 && b0 < 0.85 && seq2.every((a, i) => i === 0 || a <= seq2[i - 1]) && seq2[seq2.length - 1] === 0 && !(await T.pir()).ship.v,
    J({ b0, seq2: seq2.filter((x, i) => i % 20 === 0) }));
  r = await T.until('return s.pirates.ship.visible;', 60 * 60);
  st = await T.pir();
  ok('D. ... and comes back at 35% of that night', r.ok && near(st.t, 52.5, 0.05) && st.ship.a < 0.05, J(st.ship));
  ok('A-D: per-frame no one on a blocked tile, no console errors', J(await T.bad()) === '[]' && T.errors.length === 0, J([await T.bad(), T.errors]));
  await T.browser.close();

  // E. 해적을 끈 시험 도구(옛 시험): 밤이 지나도 아무것도 없다
  const lib5 = require('../p5/lib5.js');
  T = await lib5.setup({ w: 960, h: 600 });
  G = T.G;
  await G(() => { const g = window.__game, s = g.scene.getScene('game'); g.loop.sleep(); s.enemies.spawn = () => null; s.debugNight();
    let t = performance.now(); window.__seen = { ship: false, boat: false, pirates: false, lamp: false };
    for (let i = 0; i < 60 * 100; i++) { t += 1000 / 60; g.headlessStep(t, 1000 / 60);
      const P = s.pirates; if (P.ship.visible) window.__seen.ship = true; if (P.boat.visible) window.__seen.boat = true;
      if (s.enemies.list.length) window.__seen.pirates = true; if (s.lightSources().some((L) => L.radius === 130)) window.__seen.lamp = true; } });
  const seen = await G(() => ({ seen: window.__seen, t: window.__game.scene.getScene('game').clock.t }));
  ok('E. pirates off (old-test helper): a whole night past 70 s shows no ship, boat, pirate or lamp', seen.t > 99 && J(seen.seen) === J({ ship: false, boat: false, pirates: false, lamp: false }), J(seen));
  ok('E. no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
