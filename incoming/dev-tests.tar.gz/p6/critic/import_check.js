// Does a dynamic import of /src/config.js from page.evaluate reach the game's own CONFIG object? Does it survive a reload?
const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 960, height: 600 } })).newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  const ready = () => page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  await page.goto('http://127.0.0.1:8765/');
  await ready();
  const r1 = await page.evaluate(async () => {
    const m = await import('/src/config.js');
    m.CONFIG.zombie.hp = 77;
    const s = window.__game.scene.getScene('game');
    s.debugZombie();
    return { enabledNow: m.CONFIG.pirate.enabled, zombieHp: s.enemies.list[0] && s.enemies.list[0].hp };
  });
  console.log('same instance check (expect zombieHp 77):', JSON.stringify(r1));
  await page.reload();
  await ready();
  const r2 = await page.evaluate(async () => {
    const m = await import('/src/config.js');
    const s = window.__game.scene.getScene('game');
    s.debugZombie();
    return { hpAfterReload: m.CONFIG.zombie.hp, zombieHp: s.enemies.list[0] && s.enemies.list[0].hp };
  });
  console.log('after reload (expect 3 = flip lost):', JSON.stringify(r2));
  console.log('page errors:', JSON.stringify(errs));
  await browser.close();
})();
