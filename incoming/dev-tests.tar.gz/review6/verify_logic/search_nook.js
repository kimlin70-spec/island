// Static search: the player stands on P and builds ONE fence on a neighbour F. P then has k plain (walkable) neighbours.
// Enemies 1..k stand on those k tiles (claimed). Where does enemy k+1, coming from the pirate landing (35,50), go?
// Report P where its route passes through P (it would stand on the player's tile, held by the fence).
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const out = await T.G(() => {
    const g = window.__game, s = g.scene.getScene('game'), m = s.map, E = s.enemies;
    g.loop.sleep();
    const K = (q) => q.col + ',' + q.row;
    const nb8 = (c, r) => { const o = []; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) o.push({ col: c + dc, row: r + dr }); return o; };
    const start = { col: 37, row: 39 };
    const seen = new Set([K(start)]); const q = [start];
    while (q.length) { const t = q.shift(); for (const n of nb8(t.col, t.row)) { if (seen.has(K(n)) || !m.isWalkable(n.col, n.row)) continue;
      const diag = n.col !== t.col && n.row !== t.row; if (diag && (!m.isWalkable(n.col, t.row) || !m.isWalkable(t.col, n.row))) continue; seen.add(K(n)); q.push(n); } }
    const res = [];
    const sources = [{ col: 35, row: 50 }, { col: 35, row: 51 }];
    for (const key of seen) {
      const [c, r] = key.split(',').map(Number);
      const w = nb8(c, r).filter((n) => m.isWalkable(n.col, n.row));
      if (w.length > 4) continue;
      for (const F of w) {
        const plain = w.filter((x) => x !== F);
        const fence = s.build.place('fence', [F]);
        const claimers = plain.map((t) => E.add('zombie', t));
        const oldT = E.target; E.target = () => ({ tiles: [{ col: c, row: r }], structure: null });
        let hits = 0, routes = [];
        for (const src of sources) {
          if (Math.max(Math.abs(src.col - c), Math.abs(src.row - r)) <= 1) continue;
          const e = E.add('pirate_2', src);
          const goals = e.goalsAround([{ col: c, row: r }]);
          const route = e.findRoute(goals.free.length ? goals.free : goals.all);
          if (route && route.slice(0, -1).some((t) => t.col === c && t.row === r)) hits++;
          routes.push(route ? route.length : null);
          E.remove(e);
        }
        E.target = oldT;
        if (hits) res.push({ P: key, F: K(F), plain: plain.map(K).join(' '), k: plain.length, hits, routes: routes.join(','), distStart: +Math.hypot(c - 37, r - 39).toFixed(1), distLand: +Math.hypot(c - 35, r - 51).toFixed(1) });
        for (const z of claimers) E.remove(z);
        s.build.destroy(fence);
      }
    }
    return res.sort((a, b) => a.k - b.k || a.distLand - b.distLand);
  });
  console.log('count', out.length);
  for (const x of out.slice(0, 40)) console.log(JSON.stringify(x));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
