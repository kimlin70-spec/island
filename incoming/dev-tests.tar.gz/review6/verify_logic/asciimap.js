const m = require('/home/user/island/data/map.json');
const man = require('/home/user/island/assets/manifest.json');
console.log(Object.keys(m), m.cols, m.rows, JSON.stringify(m.pirates), JSON.stringify(m.playerStart || m.start || null));
const grid = [];
for (let r = 0; r < m.rows; r++) { grid.push([]); for (let c = 0; c < m.cols; c++) grid[r].push(m.terrain[r][c] === 0 ? '~' : '.'); }
const kinds = {};
for (const o of m.objects) {
  kinds[o.kind] = (kinds[o.kind] || 0) + 1;
  const blocks = !['stump', 'rubble'].includes(o.kind);
  const ch = o.kind === 'tree' ? 'T' : o.kind === 'pine' ? 'P' : o.kind === 'palm' ? 'Y' : o.kind === 'rock' ? 'R' : o.kind === 'bush' ? 'B' : (o.kind[0] || '?');
  const tiles = o.tiles || [{ col: o.col, row: o.row }];
  for (const t of tiles) grid[t.row][t.col] = blocks ? ch : ch.toLowerCase();
}
console.log(JSON.stringify(kinds), JSON.stringify(m.objects[0]));
const [c0, c1, r0, r1] = process.argv.slice(2).map(Number);
let hdr = '     '; for (let c = c0; c <= c1; c++) hdr += (c % 10); console.log(hdr);
for (let r = r0; r <= r1; r++) { let line = String(r).padStart(4) + ' '; for (let c = c0; c <= c1; c++) line += grid[r][c]; console.log(line); }
