const { setup, J } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/fix5/vlib.js');
(async () => {
  const T = await setup({ w: 960, h: 600, pirates: true });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await T.testItem(0);
  await T.tapTileW(24, 41, 0);
  const w1 = await T.until('const p = s.player; return !p.moving && p.tile.col === 24 && p.tile.row === 41;', 1200);
  await T.run(120);   // let the camera settle
  await T.card(2); await T.run(2);
  const mode = await G(() => window.__game.scene.getScene('game').build.mode);
  const p = await T.tapTileW(24, 40, 50); await T.run(2);
  const st = await G(() => window.__game.scene.getScene('game').map.structures.map((x) => x.type + '@' + x.col + ',' + x.row));
  console.log(J({ w1, mode, tap: p, st }));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
