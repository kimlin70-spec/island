// Static search: tiles P with exactly two walkable neighbours (N1, F). If the player stands on P and builds a fence on F,
// P has one plain neighbour. With one enemy claiming N1, where does a second enemy (coming from the pirate landing tiles) stand?
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const out = await T.G(() => {
    const g = window.__game, s = g.scene.getScene('game'), m = s.map, E = s.enemies;
    g.loop.sleep();
    const K = (q) => q.col + ',' + q.row;
    const nb8 = (c, r) => { const o = []; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) o.push({ col: c + dc, row: r + dr }); return o; };
    // reachable from the start for the player
    const start = { col: 37, row: 39 };
    const seen = new Set([K(start)]); const q = [start];
    while (q.length) { const t = q.shift(); for (const n of nb8(t.col, t.row)) { if (seen.has(K(n)) || !m.isWalkable(n.col, n.row)) continue;
      const diag = n.col !== t.col && n.row !== t.row; if (diag && (!m.isWalkable(n.col, t.row) || !m.isWalkable(t.col, n.row))) continue; seen.add(K(n)); q.push(n); } }
    const res = [];
    for (const key of seen) {
      const [c, r] = key.split(',').map(Number);
      const w = nb8(c, r).filter((n) => m.isWalkable(n.col, n.row));
      if (w.length !== 2) continue;
      for (const F of w) {
        const N1 = w.find((x) => x !== F);
        // place fence on F, one enemy standing on N1, a second enemy at the landing tile next to (35,50)
        const fence = s.build.place('fence', [F]);
        const e1 = E.add('pirate_1', N1);
        const e2 = E.add('pirate_2', { col: 35, row: 50 });
        // fake target: player at P
        const oldT = E.target; E.target = () => ({ tiles: [{ col: c, row: r }], structure: null });
        const goals = e2.goalsAround([{ col: c, row: r }]);
        const route = e2.findRoute(goals.free.length ? goals.free : goals.all);
        E.target = oldT;
        const viaP = route && route.slice(0, -1).some((t) => t.col === c && t.row === r);
        res.push({ P: key, F: K(F), N1: K(N1), free: goals.free.map(K).join(' '), route: route ? route.map(K).join('>') : null, viaP, dist: Math.hypot(c - 35, r - 51) });
        E.remove(e1); E.remove(e2); s.build.destroy(fence);
      }
    }
    return res.filter((x) => x.viaP).sort((a, b) => a.dist - b.dist).slice(0, 15);
  });
  for (const x of out) console.log(JSON.stringify(x));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
