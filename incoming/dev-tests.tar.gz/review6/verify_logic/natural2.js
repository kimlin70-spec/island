// Same natural play as natural1.js (seed 2), plus: a trace of each pirate's re-plans (free goals, chosen end), and a picture
// of the screen around the player while a pirate stands on the player's tile.
const { setup, J } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/fix5/vlib.js');
const seed = +(process.argv[2] || 2);
const P = [24, 41], F = [24, 40];
(async () => {
  const T = await setup({ w: 960, h: 600, pirates: true });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G((seed) => { let a = seed >>> 0; Math.random = () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }, seed);
  await T.testItem(0);
  await T.tapTileW(P[0], P[1], 0);
  await T.until(`const p = s.player; return !p.moving && p.tile.col === ${P[0]} && p.tile.row === ${P[1]};`, 1200);
  await T.run(120);
  await T.card(2); await T.run(2);
  await T.tapTileW(F[0], F[1], 50); await T.run(2);
  await T.closeCraft(); await T.run(2);
  console.log('setup', J(await G(() => { const s = window.__game.scene.getScene('game'); return { st: s.map.structures.map((x) => x.type + '@' + x.col + ',' + x.row), player: [s.player.tile.col, s.player.tile.row] }; })));
  await G(() => {
    const s = window.__game.scene.getScene('game'), E = s.enemies, p = s.player;
    const K = (q) => q.col + ',' + q.row;
    const ids = new Map(); const id = (e) => { if (!ids.has(e)) ids.set(e, (e.kind === 'zombie' ? 'z' : 'P') + ids.size); return ids.get(e); };
    window.__id = id;
    const M = window.__M = { trace: [], firstOn: null };
    const proto = Object.getPrototypeOf(E.list[0] || {}) ;
    const oa = E.add.bind(E); E.add = (k, t) => { const e = oa(k, t); id(e);
      if (k !== 'zombie') { const orig = e.repath.bind(e); e.repath = (target, key) => { const before = e.path.map(K).join(' ');
        const g = e.goalsAround(target.tiles); const taken = [...E.takenTiles(e)].filter((x) => g.all.some((a) => K(a) === x));
        orig(target, key);
        M.trace.push([+s.clock.t.toFixed(2), id(e), 'at ' + e.col.toFixed(2) + ',' + e.row.toFixed(2), 'free [' + g.free.map(K).join(' ') + ']', 'claimed by others [' + taken.join(' ') + ']', 'new path end ' + (e.path.length ? K(e.path[e.path.length - 1]) : '-')]); }; }
      return e; };
    s.events.on('postupdate', () => { if (M.firstOn) return; const here = p.here();
      for (const e of E.list) if (!p.moving && e.col === here.col && e.row === here.row) { M.firstOn = { t: +s.clock.t.toFixed(2), who: id(e) }; } });
  });
  await T.testItem(1);
  const r = await T.until('return !!window.__M.firstOn || s.clock.t >= 140;', 60 * 150);
  console.log('first on-tile', J(r), J(await G(() => window.__M.firstOn)));
  // let it settle half a second, then look
  await T.run(30);
  const look = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, E = s.enemies, list = s.children.list;
    return { t: +s.clock.t.toFixed(2), hearts: s.hearts.value, player: { x: p.sprite.x, y: p.sprite.y, depth: p.sprite.depth, idx: list.indexOf(p.sprite), w: p.sprite.displayWidth, h: p.sprite.displayHeight },
      enemies: E.list.map((e) => ({ id: window.__id(e), at: [e.col, e.row], path: e.path.map((q) => q.col + ',' + q.row), x: e.sprite.x, y: e.sprite.y, depth: e.sprite.depth, idx: list.indexOf(e.sprite), frame: e.sprite.frame.name, w: e.sprite.displayWidth, h: e.sprite.displayHeight })) }; });
  console.log('look', J(look));
  const pic = await T.snapWorld('natural2_on_tile', look.player.x, look.player.y, 360, 300, -50, 2);
  console.log('picture', pic);
  const tr = await G(() => window.__M.trace);
  for (const x of tr) console.log('  ', J(x));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
