// config.pirate.count = 0 / 1 / 3 with pirates enabled: what happens at 35% and 45% of the night? (zombies off, 60 Hz steps)
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const { page, G } = T;
  for (const count of [0, 1, 3]) {
    await page.reload();
    await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
    await page.waitForTimeout(300);
    const out = await G(async (count) => {
      const C = (await import('/src/config.js')).CONFIG; C.pirate.count = count;
      const g = window.__game, s = g.scene.getScene('game');
      g.loop.sleep(); s.enemies.spawn = () => null;
      const notes = []; s.events.on('notice', (t) => notes.push([+s.clock.t.toFixed(2), t]));
      let t = performance.now();
      s.debugNight();
      for (let i = 0; i < 60 * 70; i++) { t += 1000 / 60; g.headlessStep(t, 1000 / 60); }
      const P = s.pirates;
      return { enabled: C.pirate.enabled, count, t: +s.clock.t.toFixed(2), notices: notes, enemies: s.enemies.list.map((e) => e.kind + '@' + e.tile.col + ',' + e.tile.row),
               ship: { visible: P.ship.visible, alpha: P.ship.alpha }, boat: { visible: P.boat.visible, alpha: P.boat.alpha } };
    }, count);
    console.log(JSON.stringify(out));
  }
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
