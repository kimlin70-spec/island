// Natural play, no stubs: the player walks (real tap) into the rock corridor at (24,41), builds ONE fence (real craft menu + tap)
// on (24,40) to close the corridor behind, then uses the test window (real clicks) to start the night and waits there.
// Zombies spawn at their random places (seeded), pirates land by themselves. The player auto-fights, takes real hits.
// Per frame: does an enemy stand on the player's own tile while the player stands still? How long, and does it hit from there?
const { setup, J } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/fix5/vlib.js');
const seed = +(process.argv[2] || 1);
const P = (process.argv[3] || '24,41').split(',').map(Number), F = (process.argv[4] || '24,40').split(',').map(Number);
(async () => {
  const T = await setup({ w: 960, h: 600, pirates: true });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G((seed) => { let a = seed >>> 0; Math.random = () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }, seed);
  await T.testItem(0);                                         // +20 materials (test window, real clicks)
  await T.tapTileW(P[0], P[1], 0);                             // walk there (real tap on the ground)
  const w1 = await T.until(`const p = s.player; return !p.moving && p.tile.col === ${P[0]} && p.tile.row === ${P[1]};`, 1200);
  await T.run(120);                                            // let the camera settle
  await T.card(2); await T.run(2);                             // craft menu -> fence card
  await T.tapTileW(F[0], F[1], 50); await T.run(2);            // build the fence
  await T.closeCraft(); await T.run(2);
  const setupState = await G(([F]) => { const s = window.__game.scene.getScene('game'); const f = s.map.structureAt(F[0], F[1]);
    return { fence: f ? f.type : null, fences: s.map.structures.map((x) => x.type + "@" + x.col + "," + x.row).join(" "), player: [s.player.tile.col, s.player.tile.row], hearts: s.hearts.value }; }, [F]);
  console.log('seed', seed, 'walked', J(w1), 'setup', J(setupState));
  await G(() => {
    const s = window.__game.scene.getScene('game'), E = s.enemies, p = s.player;
    const ids = new Map(); const id = (e) => { if (!ids.has(e)) ids.set(e, (e.kind === 'zombie' ? 'z' : 'P') + ids.size); return ids.get(e); };
    const M = window.__M = { on: new Map(), events: [], hitsFromTile: 0, smashFromTile: 0, down: null, maxOn: {} };
    const K = (q) => q.col + ',' + q.row;
    const oh = E.hitPlayer.bind(E);
    E.hitPlayer = (e) => { const here = p.here(); if (K(e.tile) === K(here) && e.col === e.tile.col && e.row === e.tile.row) { M.hitsFromTile++; M.events.push([+s.clock.t.toFixed(2), id(e), 'hits player FROM THE PLAYER TILE', 'hearts before', s.hearts.value]); } return oh(e); };
    s.events.on('down', () => { M.down = +s.clock.t.toFixed(2); });
    s.events.on('postupdate', (t, d) => {
      const dt = Math.min(d / 1000, 0.1) * s.speed, here = p.here();
      for (const e of E.list) {
        const on = !p.moving && e.col === here.col && e.row === here.row;
        const prev = M.on.get(e) || 0;
        if (on) {
          if (!prev) M.events.push([+s.clock.t.toFixed(2), id(e), 'stops on player tile ' + K(here), 'path [' + e.path.map(K).join(' ') + ']', 'player action ' + (p.action ? id(p.action.target) : '-'),
            'neighbours ' + [[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[-1,1],[0,1],[1,1]].map(([dc, dr]) => { const c = here.col + dc, r = here.row + dr; return (!s.map.isOpen(c, r) ? 'X' : s.map.structureAt(c, r) ? 'F' : E.list.filter((o) => o !== e && o.col === c && o.row === r).map(id).join('+') || '.'); }).join(' ')]);
          M.on.set(e, prev + dt); M.maxOn[id(e)] = Math.max(M.maxOn[id(e)] || 0, prev + dt);
        } else if (prev) { M.events.push([+s.clock.t.toFixed(2), id(e), 'leaves/ends after ' + prev.toFixed(2) + ' s', e.alive ? 'alive at ' + e.col.toFixed(2) + ',' + e.row.toFixed(2) : 'defeated', 'player moving ' + p.moving]); M.on.set(e, 0); }
      }
    });
    const ok = E.kill.bind(E); E.kill = (e) => { M.events.push([+s.clock.t.toFixed(2), id(e), 'defeated by the player']); return ok(e); };
    const oa = E.add.bind(E); E.add = (k, t) => { const e = oa(k, t); M.events.push([+s.clock.t.toFixed(2), id(e), 'appears at ' + K(t)]); return e; };
  });
  await T.testItem(1);                                         // 밤으로 넘기기 (real clicks)
  const r = await T.until('return !!window.__M.down || s.clock.t >= 140 || !s.clock.isNight;', 60 * 150);
  const out = await G(() => { const s = window.__game.scene.getScene('game'), M = window.__M;
    return { t: +s.clock.t.toFixed(2), night: s.clock.isNight, hearts: s.hearts.value, down: M.down, hitsFromTile: M.hitsFromTile, maxOn: M.maxOn, events: M.events.filter((e) => !/appears/.test(e[2]) || true) }; });
  console.log('end', J({ r, t: out.t, hearts: out.hearts, down: out.down, hitsFromPlayerTile: out.hitsFromTile, maxSecondsOnPlayerTile: out.maxOn }));
  for (const e of out.events) console.log('  ', J(e));
  console.log('errors', J(T.errors), 'bad', J(await T.bad()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
