// config.pirate.count = 0 (pirates still enabled): what happens at 45% of the night?
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const out = await T.G(async () => {
    const C = (await import('/src/config.js')).CONFIG; C.pirate.count = 0;
    const g = window.__game, s = g.scene.getScene('game');
    g.loop.sleep(); s.enemies.spawn = () => null;
    const notes = []; s.events.on('notice', (t) => notes.push([+s.clock.t.toFixed(2), t]));
    let t = performance.now();
    s.debugNight();
    for (let i = 0; i < 60 * 70; i++) { t += 1000 / 60; g.headlessStep(t, 1000 / 60); }
    const P = s.pirates;
    return { t: +s.clock.t.toFixed(2), notices: notes, enemies: s.enemies.list.length, ship: [P.ship.visible, P.ship.alpha], boat: [P.boat.visible, P.boat.alpha] };
  });
  console.log(JSON.stringify(out));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
