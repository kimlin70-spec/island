// Repro: a pirate stops on the player's own tile and hits the player from there, because the only unclaimed
// tile next to the player is a fence. Player at the start tile (37,39). Fence at (38,39).
// Zombies stand on the other 7 neighbours (they are next to the player, so they stay and attack).
// A pirate comes from the west (33,39). Nothing else happens (player does not fight back, hearts do not drop).
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const { G } = T;
  const out = await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), E = s.enemies, p = s.player;
    g.loop.sleep();
    let t = performance.now();
    const step = (n) => { for (let i = 0; i < n; i++) { t += 1000 / 60; g.headlessStep(t, 1000 / 60); } };
    s.enemies.spawn = () => null;                 // no night zombies
    s.hurtPlayer = () => {};                      // hearts stay
    s.pressEnemy = () => {};                      // the player does not fight back (auto-attack off)
    step(2);
    const K = (q) => q.col + ',' + q.row;
    s.build.place('fence', [{ col: 38, row: 39 }]);
    for (const [c, r] of [[36, 38], [37, 38], [38, 38], [36, 39], [36, 40], [37, 40], [38, 40]]) E.add('zombie', { col: c, row: r });
    const pir = E.add('pirate_1', { col: 33, row: 39 });
    const log = [];
    let onTile = 0, hitsFromTile = 0, smashes = 0;
    const origHit = E.hitPlayer.bind(E);
    E.hitPlayer = (e) => { if (e === pir && K(e.tile) === K(p.here())) hitsFromTile++; return origHit(e); };
    const origHS = E.hitStructure.bind(E);
    E.hitStructure = (e, x) => { if (e === pir) smashes++; return origHS(e, x); };
    for (let sec = 0; sec < 20; sec++) {
      step(60);
      const at = { col: pir.col, row: pir.row };
      if (pir.col === 37 && pir.row === 39) onTile++;
      if (sec % 4 === 3) log.push(`t=${sec + 1}s pirate at ${+pir.col.toFixed(2)},${+pir.row.toFixed(2)} path[${pir.path.map(K).join(' ')}] hitLeft ${pir.hitLeft === null ? '-' : pir.hitLeft.toFixed(2)} smashing ${pir.smashing ? pir.smashing.type : '-'}; player tile ${K(p.here())}`);
    }
    const zs = E.list.filter((e) => e.kind === 'zombie').map((e) => K(e.tile)).join(' ');
    return { log, secondsOnPlayerTile: onTile, hitsFromPlayerTile: hitsFromTile, pirateSmashes: smashes, fenceHp: s.map.structureAt(38, 39) && s.map.structureAt(38, 39).hp, zombies: zs,
             pirateDepth: pir.sprite.depth, playerDepth: p.sprite.depth, sameScreenPos: pir.sprite.x === p.sprite.x && pir.sprite.y === p.sprite.y };
  });
  console.log(JSON.stringify(out, null, 1));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
