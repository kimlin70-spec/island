// Variant of repro_ontile.js: after 6 s one zombie (at 36,40) is defeated, so a plain tile next to the player is free.
// Does the pirate leave the player's tile? Also the same set-up with a zombie in place of the pirate.
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const { G, page } = T;
  const run = (kind) => G((kind) => {
    const g = window.__game, s = g.scene.getScene('game'), E = s.enemies, p = s.player;
    g.loop.sleep();
    let t = window.__t || performance.now();
    const step = (n) => { for (let i = 0; i < n; i++) { t += 1000 / 60; g.headlessStep(t, 1000 / 60); } window.__t = t; };
    s.enemies.spawn = () => null; s.hurtPlayer = () => {}; s.pressEnemy = () => {};
    step(2);
    const K = (q) => q.col + ',' + q.row;
    for (const e of [...E.list]) E.remove(e);
    for (const x of [...s.map.structures]) s.build.destroy(x);
    s.build.place('fence', [{ col: 38, row: 39 }]);
    const zs = [[36, 38], [37, 38], [38, 38], [36, 39], [36, 40], [37, 40], [38, 40]].map(([c, r]) => E.add('zombie', { col: c, row: r }));
    const who = E.add(kind, { col: 33, row: 39 });
    const log = [];
    for (let sec = 1; sec <= 16; sec++) {
      step(60);
      if (sec === 6) E.kill(zs[4]);
      log.push(`${sec}s ${+who.col.toFixed(2)},${+who.row.toFixed(2)} path[${who.path.map(K).join(' ')}]${who.smashing ? ' smash' : ''}`);
    }
    return log;
  }, kind);
  console.log('pirate:', JSON.stringify(await run('pirate_1'), null, 0));
  console.log('zombie:', JSON.stringify(await run('zombie'), null, 0));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
