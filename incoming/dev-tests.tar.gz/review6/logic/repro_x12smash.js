// Pirate smashing a fence far from the tent while the player rests (x4) with the test speed x3 => x12.
// 10 fps (delta 100 ms -> dt 1.2 s game time). Compare with 60 fps. Fence hp 6, pirate structureInterval 1.0 s.
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const { G } = T;
  const run = (delta) => G((delta) => {
    const g = window.__game, s = g.scene.getScene('game'), E = s.enemies, p = s.player, b = s.build;
    g.loop.sleep();
    let t = window.__t || performance.now();
    const step = () => { t += delta; g.headlessStep(t, delta); window.__t = t; };
    s.enemies.spawn = () => null;
    for (const e of [...E.list]) E.remove(e);
    for (const x of [...s.map.structures]) b.destroy(x);
    if (s.rest.resting) s.rest.exit();
    // tent next to the player (start 37,39): tiles 38..39 x 38..39; the player rests in it
    const tent = b.place('tent', [{ col: 38, row: 38 }, { col: 39, row: 38 }, { col: 38, row: 39 }, { col: 39, row: 39 }]);
    s.rest.enter(tent);
    if (s.debugSpeed === 1) s.debugToggleSpeed();      // x3
    // a fence 12 tiles away blocks a pirate's only way (pirate boxed in by a fence ring at 26,30)
    const c0 = 26, r0 = 30;
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) b.place('fence', [{ col: c0 + dc, row: r0 + dr }]);
    const pir = E.add('pirate_1', { col: c0, row: r0 });
    const hits = [];
    const orig = E.hitStructure.bind(E);
    E.hitStructure = (e, x) => { if (e === pir) hits.push(+s.elapsed.toFixed(3)); return orig(e, x); };
    const e0 = s.elapsed;
    let firstBreak = null;
    const ringLeft = () => s.map.structures.filter((x) => x.type === 'fence').length;
    for (let i = 0; i < 4000 && s.elapsed - e0 < 30; i++) {
      step();
      if (firstBreak === null && ringLeft() < 8) firstBreak = +(s.elapsed - e0).toFixed(2);
    }
    const near = E.near(tent, 6);
    E.hitStructure = orig;
    const gaps = hits.slice(1).map((h, i) => +(h - hits[i]).toFixed(3));
    const res = { delta, speed: s.speed, pirateNearTent: near, firstFenceBrokenAfter: firstBreak, hitsIn30s: hits.length, gapsFirst8: gaps.slice(0, 8), smashLeft: +pir.smashLeft.toFixed(2) };
    if (s.debugSpeed !== 1) s.debugToggleSpeed();
    s.rest.exit();
    return res;
  }, delta);
  console.log(JSON.stringify(await run(1000 / 60)));
  console.log(JSON.stringify(await run(100)));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
