// node replay.js <seed> '<json opts incl. stopAtFrame, traceIds, traceFrom>'  -> prints trace and fails
const fs = require('fs');
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const src = fs.readFileSync(__dirname + '/pfuzz_page.js', 'utf8');
const seed = +process.argv[2]; const opts = JSON.parse(process.argv[3] || '{}');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const { page, G } = T;
  await G(async () => { window.__CFG = (await import('/src/config.js')).CONFIG; });
  await page.addScriptTag({ content: src });
  await G(([seed, o]) => window.__pf.init(seed, o), [seed, opts]);
  let r;
  const frames = opts.stopAtFrame || 30000;
  for (;;) { r = await G((n) => window.__pf.run(n), 1000); if (r.frame >= frames) break; }
  const res = await G(() => ({ trace: window.__pf.trace, fails: window.__pf.fails.map((f) => ({ kind: f.kind, frame: f.frame, info: f.info })), log: window.__pf.log.slice(-(window.__pf.logTail || 60)) }));
  console.log('frame', r.frame);
  if (opts.showLog) for (const l of res.log) console.log('LOG', JSON.stringify(l));
  for (const t of res.trace) console.log('TR', JSON.stringify(t));
  for (const f of res.fails) console.log('FAIL', JSON.stringify(f).slice(0, 400));
  if (opts.eval) console.log('EVAL', JSON.stringify(await G(new Function('return (' + opts.eval + ')()'))));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
