// Scenario C: tablet 1024x768, real touch taps, real game loop (not asleep). Night + x3, ship, landing, tap pirates to fight,
// morning, result window "계속하기", day 2, night 2 (zombies + pirates), morning of day 3.
const { setup, J, UI } = require('./plib.js');
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G, W } = T;
  const log = (...a) => console.log(...a);
  const fps = await G(() => window.__game.loop.actualFps); log('fps', fps);
  await T.shot('c00_start');
  await T.testItem(1); await T.testItem(4);
  log('night', J(await T.state()));
  await W(() => window.__game.scene.getScene('game').pirates.ship.visible, null, 300000);
  await page.waitForTimeout(150); await T.shot('c01_ship_fading'); log('ship', J(await T.state()), J(await T.uiText()));
  await page.waitForTimeout(1500); await T.shot('c02_ship'); log('ship2', J(await T.state()));
  await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.kind !== 'zombie'), null, 300000);
  await page.waitForTimeout(100); await T.shot('c03_landing'); log('landing', J(await T.state()), J(await T.uiText()));
  // back to x1 when a pirate is within 6 tiles; then tap it
  await W(() => { const s = window.__game.scene.getScene('game'), p = s.player; return s.enemies.list.some((e) => e.kind !== 'zombie' && Math.hypot(e.col - p.col, e.row - p.row) < 6) || s.hearts.value <= 0; }, null, 300000);
  await T.testItem(4);
  log('near', J(await T.state()));
  await T.shot('c04_near');
  for (let k = 0; k < 4; k++) {
    const pick = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
      const ps = s.enemies.list.filter((e) => e.kind !== 'zombie').sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
      if (!ps.length) return null; const e = ps[0], sp = e.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5, id: e.__id, kind: e.kind }; });
    if (!pick) break;
    try { await T.tapWorld(pick.wx, pick.wy); } catch (e) { log('tap fail', e.message); await page.waitForTimeout(500); continue; }
    await page.waitForTimeout(400);
    log('tapped', J(pick), J(await T.state()));
    await T.shot('c05_fight_' + k);
    try { await W((id) => !window.__game.scene.getScene('game').enemies.list.some((e) => e.__id === id) || window.__game.scene.getScene('game').hearts.value <= 0, pick.id, 30000); } catch (e) { log('not beaten in 30 s', J(await T.state())); }
  }
  log('REC1', J(await T.rec()));
  await T.testItem(4);   // x3 again
  await W(() => !window.__game.scene.getScene('game').clock.isNight || window.__game.scene.getScene('game').hearts.value <= 0, null, 300000);
  log('morning', J(await T.state()));
  await page.waitForTimeout(200); await T.shot('c06_morning');
  await W(() => !!window.__game.scene.getScene('ui').modal, null, 60000);
  await page.waitForTimeout(300); await T.shot('c07_result'); log('modal', J(await T.uiText()));
  if ((await T.uiText()).modal.includes('계속하기')) {
    await T.modalButton('계속하기'); await page.waitForTimeout(500);
    log('continued', J(await T.state()), J(await T.uiText()));
    await T.shot('c08_day2');
    // night 2
    await T.testItem(1);
    log('night2', J(await T.state()));
    await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.kind !== 'zombie'), null, 300000);
    await page.waitForTimeout(100); await T.shot('c09_night2_landing'); log('night2 landing', J(await T.state()));
    for (let i = 0; i < 6; i++) { await page.waitForTimeout(2500); log('n2', i, J(await T.state())); await T.shot('c10_night2_' + i); }
    await W(() => !window.__game.scene.getScene('game').clock.isNight || window.__game.scene.getScene('game').hearts.value <= 0, null, 400000);
    await page.waitForTimeout(300); log('end night2', J(await T.state()), J(await T.uiText())); await T.shot('c11_day3');
  }
  log('REC', J(await T.rec()));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
