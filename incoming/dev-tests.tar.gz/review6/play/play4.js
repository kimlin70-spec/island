// Scenario D: desktop, real mouse. Camp (fence ring + campfire + tent). Night + x3. The player stays inside the ring and fights
// the zombies, goes into the tent just before the landing, the pirates break in and hit the tent; then "아침으로 넘기기" while
// they attack: pirates vanish (poof), ship and boat fade, tent repaired. Shots along the way.
const { setup, J, UI } = require('./plib.js');
const MORNING = process.argv[2] !== 'natural';
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(0)); await T.uiS(...UI.testItem(0)); await T.uiS(...UI.testItem(5));
  await T.uiS(...UI.craft); await T.uiS(...UI.card(2));
  const ring = [];
  for (let c = 36; c <= 41; c++) { ring.push([c, 36]); ring.push([c, 41]); }
  for (let r = 37; r <= 40; r++) { ring.push([36, r]); ring.push([41, r]); }
  for (const [c, r] of ring) { await T.tapTileW(c, r); await T.run(2); }
  await T.uiS(...UI.card(3)); await T.tapTileW(40, 40); await T.run(2);
  await T.uiS(...UI.card(4));
  { const w = T.tileW(39.5, 37.5); await T.tapWorld(w.wx, w.wy); await T.run(2); }
  await T.uiS(...UI.craft);
  log('structs', (await T.structs()).length);
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  // stay inside, fight zombies automatically (hearts may drop). Wait until 64 s of the night.
  let r = await T.until('return s.clock.t >= 64 || s.hearts.value <= 0;', 60 * 70);
  log('before landing', J(await T.state()), J(await T.structs()));
  // go into the tent (real click), if it still stands
  const tp = await G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
    return t ? { wx: t.sprite.x, wy: t.sprite.y - t.sprite.displayHeight * t.sprite.originY * 0.5 } : null; });
  if (tp) { await T.tapWorld(tp.wx, tp.wy); await T.run(2); r = await T.until('return s.rest.resting;', 60 * 6); log('resting', J(r)); }
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie");', 60 * 30);
  log('landing', J(r), J(await T.state()));
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie" && e.smashing && e.smashing.type === "tent") || !s.rest.resting;', 60 * 40);
  log('pirate on tent', J(r), J(await T.state()), J(await T.uiText()), J(await T.structs()));
  await T.runR(25); await T.shot('d01_tent_attack');
  for (let i = 0; i < 4; i++) { await T.run(12); log('att', i, J(await T.state()), J(await T.uiText())); }
  await T.runR(2); await T.shot('d02_tent_attack2');
  if (MORNING) {
    await T.uiS(...UI.test); await T.uiS(...UI.testItem(2));
    log('morning pressed', J(await T.state()), J(await T.uiText()), J(await T.structs()));
    await T.shot('d03_morning_pressed_testwin_open');
    await T.uiS(...UI.testItem(5));
    await T.runR(4); await T.shot('d04_morning_4');
    await T.runR(10); await T.shot('d05_morning_14'); log(J(await T.state()));
    await T.runR(30); await T.shot('d06_morning_44'); log(J(await T.state()));
  } else {
    r = await T.until('return !s.clock.isNight || s.hearts.value <= 0;', 60 * 200);
    log('end', J(r), J(await T.state()), J(await T.structs()));
    await T.runR(4); await T.shot('d04_morning_4');
  }
  r = await T.until('return !window.__game.scene.isActive("game");', 60 * 10);
  await T.run(2); log('result', J(await T.uiText())); await T.shot('d07_result');
  log('REC', J(await T.rec()));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
