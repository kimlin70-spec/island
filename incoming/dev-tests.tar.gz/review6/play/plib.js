// Play-review helpers on top of p6/lib6.js: screenshots into this folder, a per-frame recorder for enemies
// (jitter, stuck, jumps, moonwalk, frames), and small wrappers for real clicks/taps.
const path = require('path');
const lib6 = require('../../p6/lib6.js');
const OUT = __dirname;
exports.J = JSON.stringify;
exports.UI = lib6.UI;
exports.setup = async (opts = {}) => {
  const T = await lib6.setup(opts);
  const { page, G } = T;
  T.shot = async (name) => { const p = path.join(OUT, name + '.png'); await page.screenshot({ path: p }); console.log('SHOT', p); return p; };
  // per-frame recorder
  await G(() => {
    const s = window.__game.scene.getScene('game');
    const R = window.__rec = { flips: [], stuck: [], jumps: [], moon: [], frames: {}, maxStill: {}, overlapStand: [], log: [], hurt: [], bars: [] };
    const st = new Map();
    s.events.on('postupdate', (t, d) => {
      const dt = Math.min(d / 1000, 0.1) * s.speed, now = s.elapsed;
      const tgt = s.enemies.target();
      for (const e of s.enemies.list) {
        let m = st.get(e);
        if (!m) { m = { col: e.col, row: e.row, flip: e.sprite.flipX, flipT: [], stillFrom: now, id: st.size + 1 }; st.set(e, m); e.__id = m.id; }
        const dx = e.col - m.col, dy = e.row - m.row, dist = Math.hypot(dx, dy);
        const sp = e.cfg.speed;
        if (dist > sp * dt * 1.01 + 1e-6) R.jumps.push([+now.toFixed(3), e.kind, e.__id, +dist.toFixed(3), +(sp * dt).toFixed(3)]);
        // moonwalk: moving on screen to the right while flipped (looking left), or the reverse
        const sx = dx - dy;
        if (dist > 1e-6 && Math.abs(sx) > 1e-4 && !e.attackLeft) {
          if ((sx > 0 && e.sprite.flipX) || (sx < 0 && !e.sprite.flipX)) R.moon.push([+now.toFixed(3), e.kind, e.__id, +sx.toFixed(4), e.sprite.flipX]);
        }
        if (e.sprite.flipX !== m.flip) { m.flipT.push(now); m.flip = e.sprite.flipX; m.flipT = m.flipT.filter((x) => now - x <= 1.0);
          if (m.flipT.length >= 3) R.flips.push([+now.toFixed(3), e.kind, e.__id, m.flipT.length, [e.tile.col, e.tile.row], e.moving]); }
        if (dist > 1e-6) m.stillFrom = now;
        const still = now - m.stillFrom;
        const busy = e.smashing || e.hitLeft !== null || e.attackLeft > 0;
        if (still > 3 && !busy && !e.inPlace(tgt)) { if (!m.stuckLogged) { m.stuckLogged = true; R.stuck.push([+now.toFixed(3), e.kind, e.__id, [e.tile.col, e.tile.row], e.path.length, J2(tgt.tiles)]); } }
        else if (still <= 3) m.stuckLogged = false;
        R.maxStill[e.__id] = Math.max(R.maxStill[e.__id] || 0, +still.toFixed(2));
        const fr = e.sprite.frame.name; R.frames[e.kind] = R.frames[e.kind] || {}; R.frames[e.kind][fr] = (R.frames[e.kind][fr] || 0) + 1;
        m.col = e.col; m.row = e.row;
      }
      // two enemies standing still on the same tile centre
      const standing = s.enemies.list.filter((e) => !e.moving && e.col === e.tile.col && e.row === e.tile.row);
      for (let i = 0; i < standing.length; i++) for (let j = i + 1; j < standing.length; j++) {
        const a = standing[i], b = standing[j];
        if (a.tile.col === b.tile.col && a.tile.row === b.tile.row) {
          const k = a.__id + '-' + b.__id + '@' + a.tile.col + ',' + a.tile.row;
          if (!R.overlapStand.some((x) => x[1] === k)) R.overlapStand.push([+now.toFixed(3), k, a.kind, b.kind]);
        }
      }
    });
    function J2(x) { return JSON.stringify(x); }
    const oh = s.hurtPlayer.bind(s); s.hurtPlayer = (n) => { R.hurt.push([+s.elapsed.toFixed(3), +s.clock.t.toFixed(2), s.hearts.value, s.rest.resting]); oh(n); };
  });
  T.rec = () => G(() => { const R = window.__rec; return { flips: R.flips.slice(0, 12), nFlips: R.flips.length, stuck: R.stuck.slice(0, 12), nStuck: R.stuck.length,
    jumps: R.jumps.slice(0, 8), nJumps: R.jumps.length, moon: R.moon.slice(0, 8), nMoon: R.moon.length, frames: R.frames, maxStill: R.maxStill, overlapStand: R.overlapStand.slice(0, 10), hurt: R.hurt }; });
  T.state = () => G(() => { const s = window.__game.scene.getScene('game'), p = s.player, P = s.pirates;
    return { t: +s.clock.t.toFixed(2), day: s.clock.day, night: s.clock.isNight, label: s.clock.label, hearts: s.hearts.value, speed: s.speed, resting: s.rest.resting,
      p: [+p.col.toFixed(2), +p.row.toFixed(2)], act: p.action ? (p.action.target.kind || p.action.target.type) : null,
      ship: [P.ship.visible, +P.ship.alpha.toFixed(2)], boat: [P.boat.visible, +P.boat.alpha.toFixed(2)],
      en: s.enemies.list.map((e) => e.kind[0] + (e.kind[7] || '') + '#' + e.__id + '@' + e.col.toFixed(1) + ',' + e.row.toFixed(1) + (e.moving ? 'm' : 's') + ' hp' + e.hp + (e.smashing ? ' smash:' + e.smashing.type + '@' + e.smashing.col + ',' + e.smashing.row : '') + ' f' + e.sprite.frame.name + (e.sprite.flipX ? 'L' : 'R')),
      defeated: s.enemies.defeated, active: window.__game.scene.isActive('game') }; });
  T.uiText = () => G(() => { const u = window.__game.scene.getScene('ui');
    return { notice: u.noticeBox.visible ? u.noticeText.text : null, noticeAlpha: +u.noticeBox.alpha.toFixed(2), modal: u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : null }; });
  // pirate sprite (screen) rect in game coords, to crop screenshots
  T.enemyScreen = (i) => G((i) => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[i]; if (!e) return null; const cam = s.cameras.main, sp = e.sprite;
    const x = (sp.x - cam.midPoint.x) * cam.zoom + cam.width / 2, y = (sp.y - cam.midPoint.y) * cam.zoom + cam.height / 2; return { x, y, kind: e.kind, id: e.__id }; }, i);
  // rendered frames (the camera follow only moves on rendered frames)
  T.runR = (n, D = 1000 / 60) => G(([n, D]) => { const g = window.__game, S = window.__S; for (let i = 0; i < n; i++) { S.t += D; g.step(S.t, D); } }, [n, D]);
  T.structs = () => G(() => window.__game.scene.getScene('game').map.structures.map((s) => s.type[0] + '@' + s.col + ',' + s.row + ':' + s.hp));
  return T;
};
