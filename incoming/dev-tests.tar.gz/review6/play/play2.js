// Scenario B: desktop 1920x1200, real mouse. Build a camp (fence ring, campfire, tent) by clicks, night + x3,
// pirates land and break fences, the player rests in the tent while they attack, survive to the morning.
const { setup, J, UI } = require('./plib.js');
const MODE = process.argv[2] || 'rest';   // 'rest': go into the tent before the landing; 'stand': stay inside the ring
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  // materials: +20 twice
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(0)); await T.uiS(...UI.testItem(0)); await T.uiS(...UI.testItem(5));
  // craft -> fence
  await T.uiS(...UI.craft); await T.uiS(...UI.card(2));
  const ring = [];
  for (let c = 36; c <= 41; c++) { ring.push([c, 36]); ring.push([c, 41]); }
  for (let r = 37; r <= 40; r++) { ring.push([36, r]); ring.push([41, r]); }
  for (const [c, r] of ring) { await T.tapTileW(c, r); await T.run(2); }
  log('fences', (await T.structs()).length);
  await T.uiS(...UI.card(3)); await T.tapTileW(40, 40); await T.run(2);
  await T.uiS(...UI.card(4));
  { const w = T.tileW(39.5, 37.5); await T.tapWorld(w.wx, w.wy); await T.run(2); }
  await T.uiS(...UI.craft);   // close
  log('structs', J(await T.structs()));
  await T.runR(30);
  await T.shot('b00_camp');
  // night, x3
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  if (MODE === 'rest') {
    // into the tent before the ship (real click on the tent)
    const tp = await G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
      return { wx: t.sprite.x, wy: t.sprite.y - t.sprite.displayHeight * t.sprite.originY * 0.5 }; });
    await T.tapWorld(tp.wx, tp.wy); await T.run(2);
    let r0 = await T.until('return s.rest.resting;', 60 * 10); log('resting', J(r0));
  }
  let r = await T.until('return s.pirates.ship.visible;', 60 * 60);
  log('ship', J(r), J(await T.state()));
  await T.runR(30); await T.shot('b01_ship_camp');
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie");', 60 * 30);
  log('landing', J(r), J(await T.state()), J(await T.uiText()));
  await T.runR(3); await T.shot('b02_landing');
  // follow until a pirate smashes something or 30 s game time
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie" && e.smashing);', 60 * 20 * 3);
  log('smash start', J(r), J(await T.state()), J(await T.structs()));
  await T.runR(20); await T.shot('b03_smash');
  for (let i = 0; i < 12; i++) {
    await T.run(30);
    const st = await T.state(); log('t', i, J(st), J(await T.uiText()));
    if (i % 3 === 2) { await T.runR(3); await T.shot('b04_attack_' + i); }
  }
  log('structs', J(await T.structs()));
  r = await T.until('return !s.clock.isNight || s.hearts.value <= 0;', 60 * 200);
  log('end of night', J(r), J(await T.state()), J(await T.uiText()), J(await T.structs()));
  await T.runR(10); await T.shot('b05_morning');
  r = await T.until('return !window.__game.scene.isActive("game");', 60 * 10);
  await T.run(2); await T.shot('b06_result'); log('result', J(await T.uiText()));
  log('REC', J(await T.rec()));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
