// Scenario E: desktop, real mouse. The player walks down to the beach next to the landing tile and waits there.
// Watch the ship from the beach, the boat, the landing right next to the player, the fight on the beach (depth vs boat/palms).
const { setup, J, UI } = require('./plib.js');
const SPOT = (process.argv[2] || '36,50').split(',').map(Number);
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  // walk in steps toward the spot (tap tiles on screen)
  const hops = [[36, 44], [36, 48], SPOT];
  for (const [c, r] of hops) {
    await T.runR(20);
    try { await T.tapTileW(c, r); } catch (e) { log('tap fail', c, r, e.message); }
    await T.run(2); await T.until('return !s.player.moving;', 60 * 10);
  }
  await T.runR(40);
  log('at', J(await T.state()));
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  let r = await T.until('return s.pirates.ship.visible || s.hearts.value <= 0;', 60 * 40);
  log('ship', J(r), J(await T.state()));
  await T.run(20); await T.runR(2); await T.shot('e01_ship_half_beach');
  await T.run(25); await T.runR(2); await T.shot('e02_ship_beach');
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie") || s.hearts.value <= 0;', 60 * 20);
  log('landing', J(r), J(await T.state()));
  await T.runR(2); await T.shot('e03_landing_beach');
  // x1 and watch the fight
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  for (let i = 0; i < 10; i++) { await T.run(14); await T.runR(1); log('f', i, J(await T.state())); if (i % 2 === 0) await T.shot('e04_fight_' + i); }
  log('REC', J(await T.rec()));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
