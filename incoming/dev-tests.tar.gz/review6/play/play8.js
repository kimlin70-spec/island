// Scenario H: tablet 1024x768 touch, fixed 60 Hz. Build a tent (taps), zombies off (so the tent stands when pirates come),
// rest in the tent at night (x3 -> 12x), pirates come and hit the tent, tap "쉬는 중" to come out, tap pirates to fight.
const { setup, J, UI } = require('./plib.js');
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  await G(() => { window.__game.scene.getScene('game').enemies.spawn = () => null; });   // zombies off: pirates only
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(0)); await T.uiS(...UI.testItem(5));
  await T.uiS(...UI.craft); await T.uiS(...UI.card(4));
  { const w = T.tileW(39.5, 37.5); await T.tapWorld(w.wx, w.wy); await T.run(2); }
  await T.uiS(...UI.craft);
  log('structs', J(await T.structs()));
  const tp = await G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
    return { wx: t.sprite.x, wy: t.sprite.y - t.sprite.displayHeight * t.sprite.originY * 0.5 }; });
  await T.tapWorld(tp.wx, tp.wy); await T.run(2);
  let r = await T.until('return s.rest.resting;', 600); log('resting', J(r));
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  r = await T.until('return s.pirates.ship.visible;', 60 * 20); log('ship', J(r), J(await T.state()), J(await T.uiText()));
  await T.runR(3); await T.shot('h01_ship_resting');
  r = await T.until('return s.enemies.list.length > 0;', 60 * 20); log('landing', J(r), J(await T.state()), J(await T.uiText()));
  r = await T.until('return s.enemies.list.some((e) => e.smashing && e.smashing.type === "tent");', 60 * 30);
  log('tent hit', J(r), J(await T.state()), J(await T.uiText()));
  await T.run(30); await T.runR(30); await T.shot('h02_tent_attack'); log(J(await T.state()), J(await T.structs()));
  // come out with the rest button (tap)
  await T.uiS(...UI.rest);
  log('after rest button', J(await T.state()));
  await T.runR(3); await T.shot('h03_out');
  for (let k = 0; k < 2; k++) {
    await T.runR(10);
    const pick = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
      const ps = s.enemies.list.slice().sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
      if (!ps.length) return null; const e = ps[0], sp = e.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5, id: e.__id, kind: e.kind }; });
    if (!pick) break;
    try { await T.tapWorld(pick.wx, pick.wy); } catch (e) { log('tap fail', e.message); }
    await T.run(2); log('tapped', J(pick), J(await T.state()));
    r = await T.until(`return !s.enemies.list.some((e) => e.__id === ${pick.id}) || s.hearts.value <= 0;`, 60 * 20);
    log('gone?', J(r), J(await T.state()));
    await T.runR(3); await T.shot('h04_fight_' + k);
  }
  log('REC', J(await T.rec()));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
