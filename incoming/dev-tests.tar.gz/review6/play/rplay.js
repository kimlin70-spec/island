// Random real-UI play with pirates ON: real mouse clicks (1920x1200) or touch taps (1024x768), fixed 60 Hz steps between actions.
// Actions: tap nearest/random enemy, tap ground near the player, test window (night / morning / x3 / zombie / +20), craft fence/campfire/tent near
// the player, tap the tent, rest button, modal buttons. Checks: console errors, bodies on blocked tiles, recorder (stuck/jumps/flip jitter).
// usage: node rplay.js <seed> <steps> <touch 0|1>
const { setup, J, UI } = require('./plib.js');
const seed0 = +process.argv[2] || 1, STEPS = +process.argv[3] || 150, TOUCH = process.argv[4] === '1';
let s = seed0; const rnd = () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  const hist = [];
  let restarts = 0;
  for (let step = 0; step < STEPS; step++) {
    const st = await T.state();
    const ui = await T.uiText();
    let act;
    if (ui.modal) {
      act = ui.modal.includes('계속하기') && rnd() < 0.85 ? 'modal:계속하기' : 'modal:다시 시작';
    } else {
      const r = rnd();
      if (r < 0.25 && st.en.length) act = 'tapEnemy';
      else if (r < 0.40) act = 'ground';
      else if (r < 0.50) act = pick(['night', 'night', 'night', 'morning', 'speed', 'speed', 'zombie', 'give']);
      else if (r < 0.62) act = pick(['fence', 'fence', 'fence', 'campfire', 'tent']);
      else if (r < 0.70) act = 'tapTent';
      else if (r < 0.74) act = 'restButton';
      else act = 'wait';
    }
    try {
      if (act.startsWith('modal:')) {
        const text = act.slice(6);
        if (text === '다시 시작') { log('DOWN/RESTART wanted at step', step, J(ui.modal)); break; }
        await T.modalButton(text); await T.run(2);
      } else if (act === 'tapEnemy') {
        const p = await G((k) => { const sc = window.__game.scene.getScene('game'), L = sc.enemies.list; if (!L.length) return null;
          const pir = L.filter((e) => e.kind !== 'zombie'); const arr = pir.length && k < 0.7 ? pir : L; const e = arr[Math.floor(k * 997) % arr.length], sp = e.sprite;
          return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5 }; }, rnd());
        if (p) { const q = await T.w2p(p.wx, p.wy); if (q.on) await T.tapPage(q.x, q.y); else act += '(off)'; }
      } else if (act === 'ground') {
        const dc = Math.round((rnd() - 0.5) * 12), dr = Math.round((rnd() - 0.5) * 12);
        const w = await G(([dc, dr]) => { const p = window.__game.scene.getScene('game').player; return { c: p.tile.col + dc, r: p.tile.row + dr }; }, [dc, dr]);
        const ww = T.tileW(w.c, w.r); const q = await T.w2p(ww.wx, ww.wy); if (q.on) await T.tapPage(q.x, q.y); else act += '(off)';
      } else if (['night', 'morning', 'speed', 'zombie', 'give'].includes(act)) {
        const i = { give: 0, night: 1, morning: 2, zombie: 3, speed: 4 }[act];
        await T.ui(...UI.test, 0); await T.run(2); await T.ui(...UI.testItem(i), 0); await T.run(2); await T.ui(...UI.testItem(5), 0); await T.run(2);
      } else if (['fence', 'campfire', 'tent'].includes(act)) {
        const card = { fence: 2, campfire: 3, tent: 4 }[act];
        await T.ui(...UI.craft, 0); await T.run(2); await T.ui(...UI.card(card), 0); await T.run(2);
        const n = act === 'fence' ? 1 + Math.floor(rnd() * 4) : 1;
        for (let k = 0; k < n; k++) {
          const dc = Math.round((rnd() - 0.5) * 8), dr = Math.round((rnd() - 0.5) * 8);
          const w = await G(([dc, dr]) => { const p = window.__game.scene.getScene('game').player; return { c: p.tile.col + dc + 0.5 * (dc % 2 === 0 ? 0 : 0), r: p.tile.row + dr }; }, [dc, dr]);
          const ww = act === 'tent' ? T.tileW(w.c + 0.5, w.r + 0.5) : T.tileW(w.c, w.r);
          const q = await T.w2p(ww.wx, ww.wy); if (q.on && q.y < (TOUCH ? 64 + 640 * 720 / 1200 : 720)) { await T.tapPage(q.x, q.y); await T.run(2); }
        }
        const open = await G(() => !!window.__game.scene.getScene('ui').craftOpen || window.__game.scene.getScene('game').build.mode !== null);
        await T.ui(...UI.craft, 0); await T.run(2);
      } else if (act === 'tapTent') {
        const p = await G(() => { const sc = window.__game.scene.getScene('game'), t = sc.map.structures.find((x) => x.type === 'tent'); if (!t) return null;
          return { wx: t.sprite.x, wy: t.sprite.y - t.sprite.displayHeight * t.sprite.originY * 0.5 }; });
        if (p) { const q = await T.w2p(p.wx, p.wy); if (q.on) await T.tapPage(q.x, q.y); }
      } else if (act === 'restButton') {
        await T.ui(...UI.rest, 0);
      }
    } catch (e) { log('action error', act, e.message); }
    if (process.env.HEAL) await G(() => { const sc = window.__game.scene.getScene('game'); if (sc.hearts.value > 0 && sc.hearts.value <= 2) { sc.hearts.value = 5; sc.events.emit('hearts-changed'); } });
    const frames = 10 + Math.floor(rnd() * 150);
    await T.run(frames);
    if (step % 10 === 0) await T.runR(2);
    hist.push(act);
    if (step % 25 === 0) log('step', step, act, J(await T.state()));
  }
  const rec = await T.rec();
  log('ACTIONS', J(hist.reduce((m, a) => (m[a] = (m[a] || 0) + 1, m), {})));
  log('REC', J({ stuck: rec.stuck, nStuck: rec.nStuck, jumps: rec.jumps, nJumps: rec.nJumps, flips: rec.flips, nFlips: rec.nFlips, overlapStand: rec.overlapStand, frames: rec.frames, maxStill: rec.maxStill }));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  log('FINAL', J(await T.state()));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
