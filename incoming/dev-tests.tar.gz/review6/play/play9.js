// Scenario I: desktop, real mouse, fixed 60 Hz. Zombies off (pirates only), the player walks away from the pirates (kiting) -
// night 1 -> morning button -> result -> 계속하기 -> night 2 -> landing -> morning button -> "3일째 아침입니다" + ship fade;
// then "밤으로 넘기기" right away during the fade-out (night 3), watch the ship fade out in the dark and come back at 35%.
const { setup, J, UI } = require('./plib.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  await G(() => { window.__game.scene.getScene('game').enemies.spawn = () => null; });
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  let r = await T.until('return s.enemies.list.length > 0;', 60 * 40);
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(2)); await T.uiS(...UI.testItem(5));
  r = await T.until('return !window.__game.scene.isActive("game");', 60 * 10);
  log('result', J(await T.uiText()));
  await T.modalButton('계속하기'); await T.run(2);
  log('day2', J(await T.state()));
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(5));
  r = await T.until('return s.enemies.list.length > 0;', 60 * 40);
  log('night2 landing', J(r), J(await T.state()));
  await T.run(20);
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(2));
  log('day3 morning', J(await T.state()), J(await T.uiText()));
  await T.runR(3); await T.shot('i01_day3_morning');
  // night right away (test window still open)
  await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(5));
  log('night3 right away', J(await T.state()), J(await T.uiText()));
  await T.runR(3); await T.shot('i02_night3_during_fadeout');
  r = await T.until('return !s.pirates.ship.visible;', 60 * 10); log('ship gone', J(r), J(await T.state()));
  await T.runR(3); await T.shot('i03_night3_ship_gone');
  r = await T.until('return s.pirates.ship.visible;', 60 * 40); log('ship back', J(r), J(await T.state()), J(await T.uiText()));
  await T.run(40); await T.runR(3); await T.shot('i04_night3_ship_back');
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
