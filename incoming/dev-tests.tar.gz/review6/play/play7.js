// Scenario G: desktop, real mouse, fixed 60 Hz with rendering. Player walks toward the beach (36,47); night + x3; after the landing
// switch to x1 and, while the pirates walk up, press "아침으로 넘기기": capture poofs, ship/boat fade, lamp, dawn frame by frame.
const { setup, J, UI } = require('./plib.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  await T.tapTileW(36, 44); await T.run(2); await T.until('return !s.player.moving;', 600); await T.runR(30);
  await T.tapTileW(36, 46); await T.run(2); await T.until('return !s.player.moving;', 600); await T.runR(40);
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  let r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie") || s.hearts.value <= 0;', 60 * 40);
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  await T.run(30); await T.runR(10);
  log('before morning', J(await T.state()));
  await T.shot('g00_before_morning');
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(2)); await T.ui(...UI.testItem(5), 0);
  // frame by frame (rendered)
  const seq = [];
  for (let i = 0; i < 200; i++) {
    await T.runR(1);
    if ([1, 3, 6, 10, 20, 40, 60, 90, 120, 150, 180].includes(i)) { await T.shot('g_m' + String(i).padStart(3, '0')); seq.push([i, J(await T.state()), J(await T.uiText())]); }
  }
  for (const s of seq) log(...s);
  log('REC', J(await T.rec()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
