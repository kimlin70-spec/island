// Scenario A: desktop 1920x1200, real mouse. No camp. Night with the test window, x3, watch the ship from the start tile,
// walk toward the beach, watch the landing, let the pirates come, fight them by clicking, morning, result window, day 2, night 2.
const { setup, J, UI } = require('./plib.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log(...a);
  await T.sleep(); await T.run(2);
  await T.shot('a00_start');
  // test window: night, x3, close (real clicks)
  await T.uiS(...UI.test); await T.shot('a01_testwin');
  await T.uiS(...UI.testItem(1)); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  log('after night+x3', J(await T.state()));
  // ship: wait until visible, then shots at ~0.5 and 1
  let r = await T.until('return s.pirates.ship.visible;', 60 * 40);
  log('ship visible', J(r), J(await T.state()), J(await T.uiText()));
  await T.run(19); log('mid fade', J(await T.state())); await T.shot('a02_ship_half');
  await T.run(30); log('full', J(await T.state()), J(await T.uiText())); await T.shot('a03_ship_full_start_tile');
  // walk toward the beach: a tile 4 down-left (+row) of the start, then further to the sand
  await T.tapTileW(37, 43); await T.run(2);
  r = await T.until('return !s.player.moving;', 60 * 10); await T.run(40);
  log('at 37,43', J(await T.state())); await T.shot('a04_from_37_43');
  // wait for landing
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie");', 60 * 30);
  log('landing', J(r), J(await T.state()), J(await T.uiText())); await T.shot('a05_landing');
  await T.run(10); await T.shot('a06_landing_plus');
  // pirates walk to the player. Take shots every ~1 s game time (20 frames at x3)
  for (let i = 0; i < 6; i++) { await T.run(20); log('walk', i, J(await T.state())); if (i % 2 === 1) await T.shot('a07_walk_' + i); }
  // x1 for the fight
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  r = await T.until('const p = s.player; return s.enemies.list.some((e) => e.kind !== "zombie" && Math.hypot(e.col - p.col, e.row - p.row) < 3);', 60 * 30);
  log('pirate near', J(r), J(await T.state()));
  await T.shot('a08_pirate_near');
  // click the nearest pirate (real click)
  const pick = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    const ps = s.enemies.list.filter((e) => e.kind !== 'zombie').sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
    const e = ps[0], sp = e.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5, id: e.__id, kind: e.kind }; });
  await T.tapWorld(pick.wx, pick.wy); await T.run(2);
  log('clicked', J(pick), J(await T.state()));
  for (let i = 0; i < 8; i++) { await T.run(15); if (i === 1 || i === 3 || i === 5) await T.shot('a09_fight_' + i); log('fight', i, J(await T.state())); }
  r = await T.until(`return !s.enemies.list.some((e) => e.__id === ${pick.id});`, 60 * 15);
  log('first pirate gone', J(r), J(await T.state()));
  await T.shot('a10_after_first');
  // second pirate
  const pick2 = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    const ps = s.enemies.list.filter((e) => e.kind !== 'zombie'); if (!ps.length) return null;
    const e = ps[0], sp = e.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5, id: e.__id, kind: e.kind, at: [e.col, e.row] }; });
  log('pick2', J(pick2));
  if (pick2) {
    try { await T.tapWorld(pick2.wx, pick2.wy); } catch (e) { log('tap2 fail', e.message); }
    await T.run(2);
    r = await T.until(`return !s.enemies.list.some((e) => e.__id === ${pick2.id});`, 60 * 25);
    log('second pirate gone?', J(r), J(await T.state()));
  }
  await T.shot('a11_after_second');
  log('REC', J(await T.rec()));
  // morning: wait for it at x3
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(4)); await T.uiS(...UI.testItem(5));
  r = await T.until('return !s.clock.isNight || s.hearts.value <= 0;', 60 * 200);
  log('morning?', J(r), J(await T.state()), J(await T.uiText()));
  await T.shot('a12_morning_0');
  await T.run(10); await T.shot('a13_morning_10'); log(J(await T.state()));
  await T.run(30); await T.shot('a14_morning_40'); log(J(await T.state()), J(await T.uiText()));
  r = await T.until('return !window.__game.scene.isActive("game");', 60 * 10);
  log('result?', J(r), J(await T.uiText()));
  await T.run(2); await T.shot('a15_result');
  log('REC', J(await T.rec()));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
