// Scenario F: desktop 1920x1200, real mouse, REAL loop (slow headless fps ~ slow PC). Camp, rest in the tent from nightfall at x3 (12x),
// watch ship, landing, pirates (and zombies) on the tent; tent breaks or morning. Recorder flags jitter/stuck/jumps.
const { setup, J, UI } = require('./plib.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G, W } = T;
  const log = (...a) => console.log(...a);
  // build with the loop asleep (exact), then wake
  await T.sleep(); await T.run(2);
  await T.uiS(...UI.test); await T.uiS(...UI.testItem(0)); await T.uiS(...UI.testItem(0)); await T.uiS(...UI.testItem(5));
  await T.uiS(...UI.craft); await T.uiS(...UI.card(2));
  const ring = [];
  for (let c = 36; c <= 41; c++) { ring.push([c, 36]); ring.push([c, 41]); }
  for (let r = 37; r <= 40; r++) { ring.push([36, r]); ring.push([41, r]); }
  for (const [c, r] of ring) { await T.tapTileW(c, r); await T.run(2); }
  await T.uiS(...UI.card(3)); await T.tapTileW(40, 40); await T.run(2);
  await T.uiS(...UI.card(4));
  { const w = T.tileW(39.5, 37.5); await T.tapWorld(w.wx, w.wy); await T.run(2); }
  await T.uiS(...UI.craft);
  log('structs', (await T.structs()).length);
  const tp = await G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
    return { wx: t.sprite.x, wy: t.sprite.y - t.sprite.displayHeight * t.sprite.originY * 0.5 }; });
  await T.tapWorld(tp.wx, tp.wy); await T.run(2);
  let r = await T.until('return s.rest.resting;', 60 * 10); log('resting', J(r));
  await T.wake();
  const fps = await G(() => window.__game.loop.actualFps); log('fps', fps);
  await T.testItem(1); await T.testItem(4);
  log('night', J(await T.state()));
  await W(() => window.__game.scene.getScene('game').pirates.ship.visible, null, 300000);
  log('ship', J(await T.state()), J(await T.uiText())); await T.shot('f01_ship');
  await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.kind !== 'zombie'), null, 300000);
  log('landing', J(await T.state()), J(await T.uiText())); await T.shot('f02_landing');
  for (let i = 0; i < 16; i++) {
    await page.waitForTimeout(2000);
    const st = await T.state(); log('t', i, J(st), J(await T.uiText()), J(await T.structs()));
    if (i % 3 === 0) await T.shot('f03_' + i);
    if (!st.night || st.hearts <= 0) break;
  }
  log('REC', J(await T.rec()));
  log('BAD', J(await T.bad()));
  log('ERRORS', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
