// spec review 2: two natural day/night cycles with pirates (no debug night/morning): notices, ship/boat/pirates per night,
// first morning result window, "계속하기", second night pirates again, "3일째 아침입니다" only.
const { setup, J } = require('../../p6/lib6.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  const D = 50;   // 20 Hz steps (inside maxFrameTime 0.1)
  await T.sleep(); await T.run(2, D);
  await G(() => {
    const s = window.__game.scene.getScene('game');
    window.__hurt = []; s.hurtPlayer = (n) => window.__hurt.push(+s.elapsed.toFixed(2));   // keep the player alive
    window.__poofs = []; const op = s.effects.poof.bind(s.effects);
    s.effects.poof = (x, y) => { window.__poofs.push([s.clock.day, s.clock.isNight, +s.clock.t.toFixed(2)]); op(x, y); };
    window.__adds = []; const oa = s.enemies.add.bind(s.enemies);
    s.enemies.add = (k, t) => { window.__adds.push([s.clock.day, +s.clock.t.toFixed(2), k, t.col, t.row]); return oa(k, t); };
  });
  const state = async (tag) => { const p = await T.pir(); console.log(tag, J({ day: await G(() => window.__game.scene.getScene('game').clock.day), t: p.t, night: p.night, ship: [p.ship.v, p.ship.a], boat: [p.boat.v, p.boat.a], en: p.enemies.map((e) => e.kind), lamp: p.lights.filter((l) => l.r === 130).map((l) => l.a), def: p.defeated })); };

  let r = await T.until('return s.clock.isNight;', 6000, D); await state('night1 start ' + J(r));
  r = await T.until('return s.clock.t >= 52.45;', 2000, D); await state('n1 52.45');
  r = await T.until('return s.pirates.ship.visible;', 100, D); await state('n1 ship ' + J(r));
  r = await T.until('return s.clock.t >= 67.45;', 1000, D); await state('n1 67.45');
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie");', 100, D); await state('n1 landed ' + J(r));
  r = await T.until('return !s.clock.isNight;', 3000, D); await state('morning2 ' + J(r));
  r = await T.until('return !window.__game.scene.isActive("game");', 200, D); await state('paused ' + J(r));
  console.log('modal', J(await T.modalTexts()));
  await T.modalButton('계속하기'); await T.run(2, D);
  console.log('after continue', J(await T.modalTexts()), await G(() => window.__game.scene.isActive('game')));
  r = await T.until('return s.clock.isNight;', 6000, D); await state('night2 start ' + J(r));
  r = await T.until('return s.clock.t >= 52.45;', 2000, D); await state('n2 52.45');
  r = await T.until('return s.pirates.ship.visible;', 100, D); await state('n2 ship ' + J(r));
  r = await T.until('return s.enemies.list.some((e) => e.kind !== "zombie");', 1000, D); await state('n2 landed ' + J(r));
  r = await T.until('return !s.clock.isNight;', 3000, D); await state('morning3 ' + J(r));
  await T.run(50, D); await state('morning3 +2.5s');
  console.log('active', await G(() => window.__game.scene.isActive('game')), 'modal', J(await T.modalTexts()));
  console.log('notices', J(await T.notices()));
  console.log('adds', J(await G(() => window.__adds)));
  console.log('poofs', J(await G(() => window.__poofs)));
  console.log('hurt count', await G(() => window.__hurt.length));
  console.log('bad', J(await T.bad()), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(1); });
