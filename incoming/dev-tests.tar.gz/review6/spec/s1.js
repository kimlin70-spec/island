// spec review 1: what is shown when (night 52.5 s / 67.5 s, fades), where (screenshots vs preview_night), notices on screen.
const path = require('path');
const { setup, J } = require('../../p6/lib6.js');
const OUT = __dirname;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.sleep(); await T.run(2);
  await G(() => {
    const s = window.__game.scene.getScene('game');
    s.enemies.spawn = () => null;          // no zombies: only pirates in the pictures
    window.__poofs = []; const op = s.effects.poof.bind(s.effects);
    s.effects.poof = (x, y) => { window.__poofs.push([+s.clock.t.toFixed(3), Math.round(x), Math.round(y)]); op(x, y); };
  });
  const uiNotice = () => G(() => { const u = window.__game.scene.getScene('ui'); return { vis: u.noticeBox.visible, a: +u.noticeBox.alpha.toFixed(2), text: u.noticeText.text }; });
  const shotAt = async (name) => { const p = path.join(OUT, name + '.png'); await page.screenshot({ path: p }); return p; };
  // camera like preview_night: centre (-320, 1580)
  const camPreview = () => G(() => { const s = window.__game.scene.getScene('game'), cam = s.cameras.main; cam.stopFollow(); cam.centerOn(-320, 1580); });

  await T.testItemS(1);
  await camPreview();
  let r = await T.until('return s.clock.t >= 52.45;', 60 * 60);
  console.log('before ship', J(await T.pir()), J(await uiNotice()));
  r = await T.until('return s.pirates.ship.visible;', 60 * 2);
  console.log('ship visible at', J(r), J((await T.pir()).ship), J(await uiNotice()));
  await T.run(59);   // ~1 s
  let st = await T.pir();
  console.log('1 s after', J({ t: st.t, ship: st.ship, lamp: st.lights.filter((l) => l.r === 130) }), J(await uiNotice()));
  await shotAt('s1_ship_half');
  await T.run(70);
  st = await T.pir();
  console.log('2.2 s after', J({ t: st.t, ship: st.ship.a, lamp: st.lights.filter((l) => l.r === 130) }), J(await uiNotice()));
  await shotAt('s1_ship_full');
  r = await T.until('return s.enemies.list.length > 0;', 60 * 20);
  st = await T.pir();
  console.log('landed', J(r), J({ t: st.t, boat: st.boat, en: st.enemies }), J(await uiNotice()));
  await shotAt('s1_landed');
  // walk ~3 s
  await T.run(180);
  st = await T.pir();
  console.log('3 s later', J({ t: st.t, en: st.enemies.map((e) => [e.kind, e.at, e.mv]) }), J(await uiNotice()));
  const look = await G(() => window.__game.scene.getScene('game').enemies.list.map((e) => ({ k: e.kind, flip: e.sprite.flipX, frame: e.sprite.frame.name, anim: e.sprite.anims.isPlaying ? e.sprite.anims.currentAnim.key : null, fps: e.sprite.anims.currentAnim ? e.sprite.anims.currentAnim.frameRate : null })));
  console.log('look', J(look));
  await shotAt('s1_walking');
  // morning
  await T.testItemS(2);
  st = await T.pir();
  console.log('morning', J({ t: st.t, ship: st.ship.a, boat: st.boat.a, en: st.enemies.length, poofs: await G(() => window.__poofs) }), J(await uiNotice()));
  await T.run(60);
  st = await T.pir();
  console.log('morning +1 s', J({ t: st.t, ship: st.ship.a, boat: st.boat.a, lamp: st.lights.filter((l) => l.r === 130) }));
  await shotAt('s1_morning_1s');
  await T.run(70);
  st = await T.pir();
  console.log('morning +2.2 s', J({ t: st.t, ship: [st.ship.v, st.ship.a], boat: [st.boat.v, st.boat.a], lamp: st.lights.filter((l) => l.r === 130) }));
  r = await T.until('return !window.__game.scene.isActive("game");', 60 * 3);
  console.log('result', J(r), J(await T.modalTexts()));
  console.log('bad', J(await T.bad()), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(1); });
