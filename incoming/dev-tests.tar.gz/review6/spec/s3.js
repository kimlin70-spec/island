// spec review 3: a pirate hitting the player: frames (walk1 while standing, attack 0.3 s per hit), facing the player, player flash.
const { setup, J } = require('../../p6/lib6.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => {
    const s = window.__game.scene.getScene('game');
    s.enemies.spawn = () => null;
    s.pressEnemy = () => {};                     // the player does not fight back (only watch the pirate)
    window.__log = [];
    s.events.on('postupdate', () => {
      const p = s.player;
      for (const e of s.enemies.list) {
        const sp = e.sprite;
        window.__log.push([+s.elapsed.toFixed(3), e.kind, sp.frame.name, sp.anims.isPlaying ? 1 : 0, sp.flipX ? 1 : 0, Math.sign(Math.round(p.sprite.x - sp.x)), e.moving ? 1 : 0, s.hearts.value, p.sprite.isTintFill ? 1 : 0]);
      }
    });
  });
  await T.testItemS(1);
  let r = await T.until('return s.enemies.list.length > 0;', 60 * 70);
  // the player walks to the beach to meet them: stand at (36,47)
  await G(() => window.__game.scene.getScene('game').player.goTo(36, 47));
  r = await T.until('return s.hearts.value <= 2;', 60 * 30);
  const log = await G(() => window.__log);
  // summarise per pirate: runs of (frame, anim) with durations, while standing next to the player
  for (const kind of ['pirate_1', 'pirate_2']) {
    const L = log.filter((x) => x[1] === kind);
    const runs = [];
    for (const x of L) {
      const key = x[2] + (x[3] ? 'a' : '') + ' f' + x[4] + ' dir' + x[5] + ' m' + x[6];
      if (!runs.length || runs[runs.length - 1].key !== key) runs.push({ key, t0: x[0], t1: x[0] }); else runs[runs.length - 1].t1 = x[0];
    }
    console.log(kind, J(runs.slice(-14).map((u) => [u.key, u.t0, +(u.t1 - u.t0 + 1 / 60).toFixed(3)])));
  }
  const hearts = []; let prev = null; for (const x of log) { if (x[7] !== prev) { hearts.push([x[0], x[7]]); prev = x[7]; } }
  console.log('hearts', J(hearts));
  const flash = log.filter((x) => x[8]).map((x) => x[0]);
  console.log('player flash frames', flash.length, J(flash.slice(0, 12)));
  console.log('bad', J(await T.bad()), 'errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(1); });
