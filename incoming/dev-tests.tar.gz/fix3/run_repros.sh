#!/bin/bash
# Re-run the second review's reproduction scripts against the fixed code, one at a time.
R=/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/review2
O=/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/fix3
run() { local name=$1; shift; echo "== $name"; ( cd "$(dirname "$1")" && timeout 900 node "$@" ) > "$O/$name.out" 2>&1; echo "exit $?"; tail -25 "$O/$name.out"; echo; }
run repro_strand_side $R/movement/repro_strand.js side
run repro_strand_tile $R/movement/repro_strand.js tile
run act_retap $R/movement/act_retap.js
run rt_retap $R/verify_movement/rt_retap.js
run rt_strand $R/verify_movement/rt_strand.js 22 26 24 29 22 25 5 24 27
run v1_rim_walk $R/verify/v1_rim_walk.js
run v2_rim_remove $R/verify/v2_rim_remove.js
run rim $R/input/rim.js
run rimremove $R/input/rimremove.js
