#!/bin/bash
# Old tests, one at a time
S=/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad
O=$S/p5/regress; mkdir -p $O
cd $S
for t in "$@"; do
  n=${t//\//_}; echo "== $t"; timeout 900 node $t > "$O/$n.out" 2>&1; echo "exit $?"
  grep -cE "^PASS" "$O/$n.out" | sed 's/^/PASS lines: /'; grep -E "^FAIL|CRASH|ALL PASS|FAILED" "$O/$n.out" | head -8
done
echo DONE
