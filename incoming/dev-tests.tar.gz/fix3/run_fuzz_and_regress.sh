#!/bin/bash
# Fuzz (the reviewer's harness, on the real code) and then my regression tests, one at a time.
S=/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad
O=$S/fix3
cd $S/review2/movement
for args in "201 10 40000 150 1" "101 10 30000 150 3" "301 8 30000 random 1" "401 4 30000 33.333 1"; do
  echo "== fuzz $args"; timeout 1800 node fuzz.js $args > "$O/fuzz_${args// /_}.out" 2>&1; echo "exit $?"
  grep -E "^seed|page errors" "$O/fuzz_${args// /_}.out" | tail -12
done
cd $S
for t in p4/t6.js p4/t7.js p4/t2.js p4/t3.js p4/t4.js p4/t5.js p2/t2.js p2/t3.js p3/t2.js p3/t3.js; do
  n=${t//\//_}; echo "== $t"; timeout 900 node $t > "$O/$n.out" 2>&1; echo "exit $?"
  grep -cE "^PASS" "$O/$n.out" | sed 's/^/PASS lines: /'; grep -E "^FAIL|CRASH|ALL PASS|FAILED|errors" "$O/$n.out" | head -8
done
echo DONE
