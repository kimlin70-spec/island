const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 } });
  page.on('pageerror', (e) => console.log('pageerror', e.message));
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui'));
  console.log(await page.evaluate(() => {
    const g = window.__game.scene.getScene('game');
    g.player.teleport(27, 22);
    const m = g.mapSystem;
    return {
      vis: m.objects.filter(o => o.sprite.visible).map(o => [o.type, o.col, o.row, !!o.node, o.node && o.node.kind]),
      near: m.objects.filter(o => Math.hypot(o.col - 27, o.row - 22) < 3.5).map(o => [o.type, o.col, o.row, o.sprite.visible, g.fog.isRevealed(o.col, o.row)]),
    };
  }));
  await browser.close();
})();
