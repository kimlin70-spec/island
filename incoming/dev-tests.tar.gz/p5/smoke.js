// 첫 확인: 좀비를 불러서 걸어오게 하고, 때리게 하고, 주인공이 자동으로 싸우는지
const { open } = require('../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  const snap = () => G(() => {
    const s = window.__game.scene.getScene('game'), p = s.player;
    return { p: [+p.col.toFixed(2), +p.row.toFixed(2)], hearts: s.hearts.value, act: p.action ? (p.action.target.kind || p.action.target.type) : null,
      z: s.enemies.list.map((e) => ({ at: [+e.col.toFixed(2), +e.row.toFixed(2)], hp: e.hp, path: e.path.length, frame: e.sprite.frame.name })), defeated: s.enemies.defeated };
  });
  await G(() => window.__game.scene.getScene('game').debugZombie());
  console.log('spawned', JSON.stringify(await snap()));
  for (let i = 0; i < 12; i++) { await page.waitForTimeout(2500); console.log(i, JSON.stringify(await snap())); }
  console.log('errors', JSON.stringify(T.errors));
  await page.screenshot({ path: __dirname + '/smoke.png' });
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
