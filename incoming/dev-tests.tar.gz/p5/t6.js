// Phase 5 확인 6: 태블릿 크기(1024×768) 터치. 좀비 부르기, 좀비를 터치해서 공격, 결과 창 "계속하기", 쓰러짐 창 "다시 시작".
const { setup, checker } = require('./lib5.js');
const J = JSON.stringify;
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G, W } = T;
  // 1. 시험 창에서 좀비 부르기(터치), 속도 ×3 으로 빨리 오게
  await T.testItem(3);
  ok('touch: the test tool calls a zombie', (await T.snap()).z.length === 1);
  await T.testItem(4);
  await W(() => { const s = window.__game.scene.getScene('game'), p = s.player; const e = s.enemies.list[0];
    return e && Math.hypot(e.col - p.col, e.row - p.row) < 6; }, null, 120000);
  await T.testItem(4);
  // 2. 좀비를 터치한다
  const z = await T.zombiePoint(0);
  await T.tapWorld(z.wx, z.wy);
  await page.waitForTimeout(150);
  let st = await T.snap();
  ok('touch: tapping the zombie makes the player go for it', st.action === 'zombie', J({ action: st.action, z: st.z }));
  await W(() => window.__game.scene.getScene('game').enemies.list.length === 0, null, 60000);
  st = await T.snap();
  ok('touch: the zombie is beaten', st.defeated === 1, J(st));
  // 3. 밤 -> 아침(터치) -> 결과 창 -> 계속하기(터치)
  await T.testItem(1);
  await T.testItem(2);
  await W(() => !window.__game.scene.isActive('game'), null, 30000);
  ok('touch: result window shows', J((await T.modalTexts()).slice(0, 1)) === J(['첫 밤을 넘겼습니다']));
  await T.modalButton('계속하기');
  await page.waitForTimeout(400);
  ok('touch: 계속하기 closes it and the game goes on', (await T.modalTexts()) === null && await G(() => window.__game.scene.isActive('game')));
  // 4. 쓰러짐 -> 다시 시작(터치)
  await G(() => { const s = window.__game.scene.getScene('game'); s.hearts.value = 1; s.hurtPlayer(1); });
  await W(() => !window.__game.scene.isActive('game'), null, 20000);   // Phase 10 (12.3): down 을 1초(게임 시간) 보여 준 뒤 창
  await page.waitForTimeout(300);
  ok('touch: down window shows', J(await T.modalTexts()) === J(['쓰러졌습니다', '다시 시작']));
  await G(() => { window.__marker = 1; });
  await T.modalButton('다시 시작');
  await page.waitForFunction(() => window.__marker === undefined && window.__game && window.__game.scene.isActive('game'), null, { timeout: 120000 });
  ok('touch: 다시 시작 starts a new game', (await G(() => window.__game.scene.getScene('game').hearts.value)) === 5);
  await page.screenshot({ path: __dirname + '/t6_tablet.png' });
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
