// 두 번째 확인: 쓰러짐 창, 텐트 공격, 첫 아침 결과 창
const { open } = require('../p4/lib.js');
const J = JSON.stringify;
(async () => {
  // A. 쓰러짐: 하트를 1로 줄이고, 나무를 베는 중(자동 공격 안 함)에 좀비가 때리게 한다
  let T = await open({ w: 960, h: 600 });
  let { page, G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); s.hearts.value = 1; s.events.emit('hearts-changed');
    const tree = s.map.objects.filter((o) => o.node && o.node.group === 'tree').sort((a, b) => Math.hypot(a.col - 37, a.row - 39) - Math.hypot(b.col - 37, b.row - 39))[0];
    s.pressNode(tree); window.__tree = tree; });
  // 나무를 베기 시작하면 바로 옆에 좀비를 부른다(자동 공격은 가만히 서 있을 때만)
  await W(() => { const p = window.__game.scene.getScene('game').player; return p.action && !p.moving && p.swing; }, null, 60000);
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    s.enemies.spawnPoint = () => ({ col: p.tile.col - 1, row: p.tile.row + 1 }); s.debugZombie(); });
  await W(() => !window.__game.scene.isActive('game'), null, 90000);
  let r = await G(() => { const g = window.__game, u = g.scene.getScene('ui'), s = g.scene.getScene('game');
    return { paused: g.scene.isPaused('game'), modal: !!u.modal, texts: u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : [], hearts: s.hearts.value }; });
  console.log('A down', J(r));
  await page.screenshot({ path: __dirname + '/down.png' });
  console.log('A errors', J(T.errors));
  await T.browser.close();

  // B. 텐트: 주인공을 텐트에 넣고 좀비 2마리
  T = await open({ w: 960, h: 600 }); ({ page, G, W } = T);
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    const tiles = [{ col: 39, row: 37 }, { col: 40, row: 37 }, { col: 39, row: 38 }, { col: 40, row: 38 }];
    const tent = s.build.place('tent', tiles); s.rest.enter(tent); s.debugZombie(); s.debugZombie();
    window.__speeds = []; s.events.on('update', () => window.__speeds.push(s.speed));
    window.__notes = []; s.events.on('notice', (t) => window.__notes.push([+s.elapsed.toFixed(1), t])); });
  for (let i = 0; i < 10; i++) {
    await page.waitForTimeout(3000);
    r = await G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
      return { resting: s.rest.resting, speed: s.speed, tentHp: t ? t.hp : null, z: s.enemies.list.map((e) => [+e.col.toFixed(1), +e.row.toFixed(1), e.smashing ? e.smashing.type : null]), notes: window.__notes }; });
    console.log('B', i, J(r));
    if (r.tentHp === null) break;
  }
  console.log('B speeds seen', J([...new Set(await G(() => window.__speeds))]));
  console.log('B errors', J(T.errors));
  await T.browser.close();

  // C. 첫 아침 결과 창: 밤으로 → 좀비 하나 물리치기 → 아침으로 → 3초 뒤 창
  T = await open({ w: 960, h: 600 }); ({ page, G, W } = T);
  await G(() => { const s = window.__game.scene.getScene('game'); s.debugNight(); });
  await W(() => window.__game.scene.getScene('game').enemies.defeated >= 1, null, 120000);
  await G(() => { const s = window.__game.scene.getScene('game'); s.debugMorning(); window.__m0 = s.elapsed; });
  await W(() => !window.__game.scene.isActive('game'), null, 60000);
  r = await G(() => { const g = window.__game, u = g.scene.getScene('ui'), s = g.scene.getScene('game');
    return { after: +(s.elapsed - window.__m0).toFixed(2), dawn: s.clock.dawn, label: s.clock.label, zombies: s.enemies.list.length, todo6: s.todo.isDone('morning'),
      texts: u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : [] }; });
  console.log('C result', J(r));
  await page.screenshot({ path: __dirname + '/result.png' });
  // 계속하기
  const btn = await G(() => { const u = window.__game.scene.getScene('ui'), g = window.__game, c = g.canvas.getBoundingClientRect();
    const t = u.modal.list.find((o) => o.type === 'Text' && o.text === '계속하기'); return { x: c.left + t.x * c.width / g.canvas.width, y: c.top + t.y * c.height / g.canvas.height }; });
  await page.mouse.click(btn.x, btn.y);
  await page.waitForTimeout(800);
  r = await G(() => { const g = window.__game, u = g.scene.getScene('ui'), s = g.scene.getScene('game'); return { active: g.scene.isActive('game'), modal: !!u.modal, label: s.clock.label }; });
  console.log('C continue', J(r));
  console.log('C errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
