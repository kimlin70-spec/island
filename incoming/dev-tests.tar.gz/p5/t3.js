// Phase 5 확인 3: 텐트 안에 있으면 좀비가 텐트를 공격하고, 알림이 뜨며, 시간이 원래 빠르기로 돌아온다.
// 텐트가 부서지면 주인공은 텐트 옆에 나타나고, 좀비는 다시 주인공을 노린다. (실제 클릭)
const { setup, UI, checker } = require('./lib5.js');
const J = JSON.stringify;
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui');
    window.__notes = []; s.events.on('notice', (t) => window.__notes.push([+s.elapsed.toFixed(2), t]));
    window.__shown = []; const orig = u.showNotice.bind(u); u.showNotice = (t) => { window.__shown.push(t); return orig(t); };
    // 'update' 이벤트는 GameScene.update 바로 앞에 온다: 그때의 "6칸 안에 좀비가 있는가"로 그 프레임의 빠르기가 정해진다
    window.__speeds = []; let near = null;
    s.events.on('update', () => { near = s.rest.resting ? s.enemies.near(s.rest.tent, 6) : null; });
    s.events.on('postupdate', () => { if (near !== null && s.rest.resting) window.__speeds.push([s.speed, near]); }); });
  // 텐트를 주인공 옆에 놓고, 텐트를 눌러 들어간다
  const tent = await G(() => { const s = window.__game.scene.getScene('game');
    const t = s.build.place('tent', [{ col: 39, row: 37 }, { col: 40, row: 37 }, { col: 39, row: 38 }, { col: 40, row: 38 }]);
    return { wx: t.sprite.x, wy: t.sprite.y - t.sprite.displayHeight * t.sprite.originY * 0.5 }; });
  await page.waitForTimeout(300);
  await T.tapWorld(tent.wx, tent.wy);
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await page.waitForTimeout(300);
  let st = await T.snap();
  ok('tapping the tent: the player goes in', st.resting && st.speed === 4, J(st));
  const hearts0 = st.hearts;
  // 좀비 둘을 부른다(시험 창, 실제 클릭)
  await T.testItem(3); await T.testItem(3);
  await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.smashing && e.smashing.type === 'tent'), null, 120000);
  st = await T.snap();
  ok('zombies go for the tent and hit it', st.z.some((z) => z.smash === 'tent'), J(st.z));
  ok('the speed is back to x1 while a zombie is near the tent', st.speed === 1, 'speed ' + st.speed);
  await W(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return t && t.hp < t.maxHp; }, null, 30000);
  await page.waitForTimeout(300);
  // 두 마리가 모두 텐트를 치기 시작하면, 서로 다른 칸에 서 있다(한 칸에 겹쳐 서지 않는다)
  await W(() => window.__game.scene.getScene('game').enemies.list.filter((e) => e.smashing && e.smashing.type === 'tent').length === 2, null, 120000);
  const spots = await G(() => window.__game.scene.getScene('game').enemies.list.map((e) => e.tile.col + ',' + e.tile.row));
  ok('two zombies hitting the tent stand on different tiles', spots.length === 2 && spots[0] !== spots[1], J(spots));
  await page.waitForTimeout(600);
  const shown = await G(() => window.__shown);
  ok('notice "텐트가 공격받고 있습니다" is shown', shown.includes('텐트가 공격받고 있습니다'), J(shown.slice(-3)));
  // 속도 기록: 쉬는 동안 좀비가 6칸 안이면 1, 아니면 4
  const sp = await G(() => window.__speeds);
  ok('resting speed: 4 when no zombie within 6 tiles, 1 when there is', sp.length > 10 && sp.every(([v, near]) => v === (near ? 1 : 4)) && sp.some(([v]) => v === 4) && sp.some(([v]) => v === 1),
    J({ n: sp.length, kinds: [...new Set(sp.map((x) => x.join('/')))] }));
  // 텐트 체력 막대
  st = await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return { hp: t.hp, bar: !!(t.bar && t.bar.g.visible) }; });
  ok('the tent shows its hp bar while damaged', st.hp < 24 && st.bar, J(st));
  // 빨리: 속도 ×3 으로 텐트가 부서질 때까지
  await T.testItem(4);
  await W(() => !window.__game.scene.getScene('game').map.structures.some((x) => x.type === 'tent'), null, 180000);
  st = await T.snap();
  ok('the player was not hurt while inside', st.hearts === hearts0, `hearts ${hearts0} -> ${st.hearts}`);
  const notes = (await G(() => window.__notes)).filter((n) => n[1] === '텐트가 공격받고 있습니다').map((n) => n[0]);
  const gaps = notes.slice(1).map((t, i) => +(t - notes[i]).toFixed(2));
  ok('the tent notice comes when the attack starts, not on every hit (at most once every 5 s)', notes.length >= 1 && gaps.every((g) => g >= 5), J({ n: notes.length, at: notes, gaps }));
  ok('tent at 0 hp: it disappears and the player comes out next to where it was', !st.resting && await G(() => window.__game.scene.getScene('game').player.sprite.visible)
    && Math.max(Math.abs(st.tile[0] - 39.5), Math.abs(st.tile[1] - 37.5)) <= 1.5, J({ tile: st.tile, resting: st.resting }));
  await page.waitForTimeout(1500);
  const target = await G(() => window.__game.scene.getScene('game').enemies.target());
  ok('zombies now go for the player', target.structure === null, J(target));
  await T.testItem(4);
  ok('per-frame: no one stood on a blocked tile', (await T.bad()).length === 0, J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await page.screenshot({ path: __dirname + '/t3_end.png' });
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
