// Phase 5 확인 4: 하트가 0이 되면 "쓰러졌습니다" 창 → "다시 시작"을 누르면 처음부터 다시 시작한다.
// 좀비에게 맞으면 하트가 하나 줄고 주인공이 하얗게 번쩍인다. 붙은 뒤 1.5초에 첫 공격, 그다음 2초마다.
const { setup, checker } = require('./lib5.js');
const J = JSON.stringify;
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G, W } = T;
  // 주인공이 나무를 베는 중(가만히 서 있지 않아서 자동으로 싸우지 않는다)에 바로 옆에 좀비를 부른다
  await G(() => { const s = window.__game.scene.getScene('game');
    s.tools.push('axe');
    const tree = s.map.objects.filter((o) => o.node && o.node.group === 'tree').sort((a, b) => Math.hypot(a.col - 37, a.row - 39) - Math.hypot(b.col - 37, b.row - 39))[0];
    s.pressNode(tree); s.tools.pop();                 // 단검으로 천천히(약 5초)
    window.__hits = []; window.__tints = [];
    const orig = s.hurtPlayer.bind(s); s.hurtPlayer = (n) => { window.__hits.push(+s.elapsed.toFixed(2)); orig(n); window.__tints.push(s.player.sprite.isTinted && s.player.sprite.tintFill); }; });
  await W(() => { const p = window.__game.scene.getScene('game').player; return p.action && !p.moving && p.swing; }, null, 60000);
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    s.enemies.spawnPoint = () => ({ col: p.tile.col - 1, row: p.tile.row + 1 }); s.debugZombie(); window.__z0 = s.elapsed; });
  await W(() => window.__hits.length >= 1, null, 30000);
  let st = await T.snap();
  const first = (await G(() => window.__hits[0] - window.__z0));
  // Phase 10 (12.3): 시험용 좀비는 땅에서 올라온다(rise 0.78초). 그 뒤 붙어 서서 1.5초.
  ok('the first hit comes 1.5 s after the zombie is next to the player (after its 0.78 s rise)', Math.abs(first - 0.78 - 1.5) < 0.15, first.toFixed(2) + ' s');
  ok('one heart lost, and the player flashes white', st.hearts === 4 && (await G(() => window.__tints[0])) === true, J({ hearts: st.hearts }));
  await W(() => window.__hits.length >= 2 || window.__game.scene.getScene('game').enemies.list.length === 0, null, 30000);
  const hits = await G(() => window.__hits);
  if (hits.length >= 2) ok('then every 2 s', Math.abs(hits[1] - hits[0] - 2) < 0.15, (hits[1] - hits[0]).toFixed(2) + ' s');
  // 하트를 1로 하고, 다시 나무를 베는 중에 좀비 -> 쓰러짐
  await G(() => { const s = window.__game.scene.getScene('game'); for (const e of s.enemies.list.slice()) s.enemies.remove(e);
    s.hearts.value = 1; s.events.emit('hearts-changed');
    const tree = s.map.objects.filter((o) => o.node && o.node.group === 'tree').sort((a, b) => Math.hypot(a.col - s.player.col, a.row - s.player.row) - Math.hypot(b.col - s.player.col, b.row - s.player.row))[0];
    tree.node.hp = 99;                                // Phase 10: 좀비가 올라오는(0.78초) 동안 나무를 다 베고 싸우러 가지 않게, 나무를 오래 벤다
    s.pressNode(tree); });
  await W(() => { const p = window.__game.scene.getScene('game').player; return p.action && !p.moving && p.swing; }, null, 60000);
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    s.enemies.spawnPoint = () => ({ col: p.tile.col + 1, row: p.tile.row - 1 }); s.debugZombie(); });
  await W(() => !window.__game.scene.isActive('game'), null, 30000);
  st = await T.snap();
  const texts = await T.modalTexts();
  ok('hearts 0: the game stops and "쓰러졌습니다" shows with "다시 시작"', st.hearts === 0 && J(texts) === J(['쓰러졌습니다', '다시 시작']), J(texts));
  await page.screenshot({ path: __dirname + '/t4_down.png' });
  const e1 = await G(() => window.__game.scene.getScene('game').elapsed);
  await page.waitForTimeout(800);
  ok('game time stops', (await G(() => window.__game.scene.getScene('game').elapsed)) === e1);
  // 다시 시작 -> 페이지를 새로 읽는다
  await G(() => { window.__marker = 1; });
  await T.modalButton('다시 시작');
  await page.waitForFunction(() => window.__marker === undefined && window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  await page.waitForTimeout(500);
  st = await G(() => { const s = window.__game.scene.getScene('game'); return { hearts: s.hearts.value, label: s.clock.label, zombies: s.enemies.list.length, tile: [s.player.tile.col, s.player.tile.row], wood: s.inventory.count('wood') }; });
  ok('다시 시작: a new game from the beginning', st.hearts === 5 && st.label === '1일째 낮' && st.zombies === 0 && J(st.tile) === J([37, 39]) && st.wood === 0, J(st));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
