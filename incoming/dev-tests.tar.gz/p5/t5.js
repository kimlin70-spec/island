// Phase 5 확인 5: 좀비가 울타리를 부수기 시작하면, 울타리 안의 주인공이 이리저리 움직여도 그 울타리를 마저 부순다.
// 결과 창의 "남은 하트"는 밤을 넘긴 때의 하트(아침에 2 차기 전). 결과 창을 기다리는 동안 "밤으로 넘기기"는 아무 일도 없다.
const { setup, checker } = require('./lib5.js');
const J = JSON.stringify;
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  // 5×5 울타리 고리(안쪽 3×3). 주인공은 한가운데.
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, c0 = p.tile.col, r0 = p.tile.row;
    for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) if (Math.max(Math.abs(dc), Math.abs(dr)) === 2) s.build.place('fence', [{ col: c0 + dc, row: r0 + dr }]);
    s.debugZombie(); window.__smashLog = [];
    s.events.on('postupdate', () => { const e = s.enemies.list[0]; if (e && e.smashing) { const k = e.smashing.col + ',' + e.smashing.row; if (window.__smashLog[window.__smashLog.length - 1] !== k) window.__smashLog.push(k); } }); });
  await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.smashing), null, 120000);
  // 주인공이 안쪽에서 계속 움직인다(0.6초마다 다른 칸으로)
  const inside = await G(() => { const p = window.__game.scene.getScene('game').player; const out = [];
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) out.push([p.tile.col + dc, p.tile.row + dr]); return out; });
  let broke = false;
  for (let i = 0; i < 40 && !broke; i++) {
    const t = inside[(i * 4) % inside.length];
    await G((t) => window.__game.scene.getScene('game').player.goTo(t[0], t[1]), t);
    await page.waitForTimeout(600);
    broke = await G(() => window.__game.scene.getScene('game').build.count('fence') < 16);
  }
  const log = await G(() => window.__smashLog);
  ok('while the player moves inside the pen, the zombie keeps hitting the same fence until it breaks', broke && log.length === 1, J({ broke, log }));
  // 하트를 2로 줄여 두고 아침으로: 결과 창의 "남은 하트"는 2
  await G(() => { const s = window.__game.scene.getScene('game'); s.hearts.value = 2; s.events.emit('hearts-changed'); s.debugNight(); s.debugMorning(); });
  const pending = await G(() => { const s = window.__game.scene.getScene('game'); s.debugNight(); return { night: s.clock.isNight, pending: s.resultPending }; });
  ok('"밤으로 넘기기" does nothing while the result window is pending', !pending.night && pending.pending, J(pending));
  await W(() => !window.__game.scene.isActive('game'), null, 30000);
  const texts = await T.modalTexts();
  const h = await G(() => window.__game.scene.getScene('game').hearts.value);
  ok('result window: 남은 하트 is the hearts at the end of the night (before the morning +2)', texts && texts[6] === '2칸' && h === 4, J({ texts, now: h }));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
