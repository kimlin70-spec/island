# Phase 5 design (zombies and the first night) — draft for review

Spec: /home/user/island/DEMO_SPEC.md 5.5–5.11, 3.4–3.5, 8, 9 (Phase 5). Project rules: /home/user/island/CLAUDE.md.
Agreed decisions so far: /home/user/island/PROGRESS.md ("사용자 요청으로 바꾼 것", "사용자와 정한 것", the "문서에 없지만 정한 것" sections).
Key user change already in place: ALL structures (fence, campfire, tent) block the PLAYER (spec 5.1 let the player pass its own fences).

## Code structure

- `Pathfinder.findPath(cols, rows, start, goal, costAt, sideOk?)`: `goal` may be one tile or an array (path to the cheapest goal, heuristic = min octile distance over goals). `sideOk(c, r)` decides whether a diagonal step's two side tiles are open (default `costAt > 0`, i.e. unchanged for the player).
- New `Walker` base class (moved verbatim from Player): `col,row` (fractional), `tile` (stood on / just left), `path` (path[0] = tile being entered), `routeTo` continuation logic (continue if the new route passes path[0], else walk back to `tile`), `occupiedTiles()` (box over tile, position, path[0]), `canStep`, `onMapChanged` (cut before the first illegal step), the per-frame movement loop `walk(dt, speed, stopBefore?)`. Player extends Walker (behaviour unchanged). Enemy extends Walker.
- New `Enemy` (one zombie; pirates in Phase 6 would reuse it with CONFIG.pirate) and `EnemySystem` (list, night spawning, debug spawn, picking, morning clear-out, defeated count).
- `Hearts.damage(n)`; `BuildSystem.damage(s, n)` / `repairAll()`; `Effects.flash(sprite)` (white 0.1 s), character shake as an offset (zombies move every frame, so the existing sprite-x shake cannot be used); enemy hp bars follow the sprite.
- UIScene: test-window item "좀비 1마리 부르기"; two modal windows ("쓰러졌습니다" + "다시 시작"; result window). A full-screen blocker under the window stops clicks reaching other UI.
- New numbers in config.js: zombie.repathInterval 0.5, anim.attackTime 0.3, fx.flashTime 0.1, input.enemyPad 12, build.tent.attackNoticeInterval 5, player.chaseInterval (re-plan while chasing), ui.modal layout.

## Zombie rules

- Spawning: on 'night', count = min(wave.max, wave.base + wave.perNight × (day − 1)); spawn i at t = i × (spawnWindow × nightLength / count), i = 0..count−1 (first one right at nightfall). Spawn point: random among `map.zombieSpawns` whose tile is open land without a structure and straight-line distance ≥ spawnMinDistance (12) from the player; if none is far enough, the farthest free one. `fx_poof` at spawn. Unspawned ones are dropped at morning.
- Target: the player; while the player rests in the tent, the tent. Goals = tiles around the target (8 neighbours, excluding the target's own tiles) that a zombie can stand on. Player's tile for zombies = the tile under the player's body centre (rounded position).
- Path costs for zombies: open land 1, structure tile `breakCost` (8), water / tree / rock / bush impassable. A diagonal step needs both side tiles open AND without a structure (so zombies cannot squeeze diagonally between two fences without breaking one; same corner rule as everyone).
- One multi-goal A* per re-path. Re-path when the target tile changes or a structure is built/removed, at most once per `repathInterval` (0.5 s) per zombie. On a structure change the current path is also cut before its first illegal step (like the player), so a zombie never steps diagonally past a new fence while waiting for its re-path.
- Movement: speed 1.2 tiles/s, ×0.5 while within 3 tiles (straight line) of any campfire. Zombies overlap each other and the player (no collisions). Building is not allowed on tiles a zombie's body is on (same box rule as the player).
- Breaking: when standing on a tile centre and the next path tile is a structure, stand and hit it: `structureDamage` (1) every `structureInterval` (1.5 s; first hit after 1.5 s). At hp 0 the structure disappears with fx_poof and paths are recomputed.
- Attacking the player: when standing on a tile within one tile (8 directions, Chebyshev ≤ 1) of the player's tile, stop and attack: first hit after `firstHitDelay` (1.5 s), then every `hitInterval` (2 s); each hit −1 heart, `attack` frame for 0.3 s, the player flashes white for 0.1 s. Leaving adjacency resets the timer.
- Attacking the tent (player inside): stand next to a tent tile and hit it like a structure. Notice "텐트가 공격받고 있습니다" at most once per 5 s (game time). While a zombie is within `wakeRange` (6) of the tent, the 4× rest speed is off. Tent at hp 0 → disappears, the player comes out on the tile they went in from (next to the tent).
- Morning: all zombies vanish with fx_poof (not counted as defeated); structures back to full hp (bars hidden); hearts +2; todo 6.
- Pictures: walking = walk1/walk2 at 6 fps, standing = walk1, attack = `attack` for 0.3 s, flip when facing left, depth 10 + foot y (+0.5 like the player), tall objects turn half-transparent when a zombie is behind them. Hp bar only while damaged.

## Player combat

- Tap priority: UI → enemy (sprite rectangle grown by 12 px on each side, front-most) → objects/structures → ground. While resting, taps still only exit via the tent. In build/remove mode, taps build/remove as before.
- Tapping a zombie: `player.act` with a moving target (its `tiles` is a getter = the zombie's current tile), `chase: true`. The player walks to a tile next to the zombie; while walking, when the zombie's tile changes the route is re-planned (at most every chaseInterval); when it stops and is not next to the zombie it re-plans instead of dropping the action (drops it if no route). Swings the dagger every actionInterval (0.55 s), damage 1 at the strike moment if still next to the zombie: shake ±3 px 0.1 s, fx_hit 0.15 s, white flash 0.1 s, hp bar. Zombie at hp 0 → fx_poof, removed, defeated +1.
- Auto attack: when the player stands still (no path, no action, not in the tent) and a zombie is within one tile, the player starts attacking it (nearest first).

## Hearts, game over, result

- Hearts 5. Zombie hit −1. At 0: the game (GameScene) pauses and the window "쓰러졌습니다" with the button "다시 시작" appears. "다시 시작" reloads the page (the spec says reloading restarts from the beginning; no save).
- First morning (the morning after night 1, also via the test tool): no "2일째 아침입니다" notice; instead, after the 3 s dawn fade, the game pauses and the result window shows "첫 밤을 넘겼습니다", 물리친 적 N마리 (zombies the player killed), 남은 울타리 N개, 남은 하트 N개 (after the morning +2), buttons "계속하기" (resume; day 2 continues) and "다시 시작" (reload). Later mornings: notice "N일째 아침입니다" only.
- Windows pause game time (agreed earlier). Test window "좀비 1마리 부르기" spawns one zombie now by the same spawn rule (also in the daytime).

## Open points I resolved myself (tell me if any contradicts the spec or a stated decision)

1. Corner rule for zombies treats structures as closed for the side-tile check.
2. Result window after the dawn fade instead of at the first instant of morning.
3. Restart = page reload.
4. "Player's tile" for zombies = rounded position (not `player.tile`, which lags by up to one tile while walking).
5. No auto attack while the player is chopping or walking.
6. Strike only lands if the zombie is still within one tile at the strike moment.
7. Zombies may attack diagonally across a gap between two diagonal fences (adjacency is Chebyshev ≤ 1, no corner rule for attacks).
8. "물리친 적" counts zombies killed by the player (including test-tool zombies), not the ones that vanish at morning.
