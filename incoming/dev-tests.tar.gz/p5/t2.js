// Phase 5 확인 2: 울타리로 둘러싸면 좀비가 돌아가거나 부순다. 깎인 시설은 체력 막대, 아침에 다시 가득.
// 좀비가 서 있는 칸에는 지을 수 없다. 모닥불 둘레에서는 느려진다.
const { setup, checker } = require('./lib5.js');
const J = JSON.stringify;
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { page, G, W } = T;
  // A. 주인공을 울타리 고리 안에 두고 좀비를 부른다 -> 울타리 하나를 부수고 들어온다
  const ring = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, out = [];
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) { s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row + dr }]); out.push([p.tile.col + dc, p.tile.row + dr]); }
    s.debugZombie(); return out; });
  await W(() => window.__game.scene.getScene('game').enemies.list.some((e) => e.smashing), null, 120000);
  let st = await G(() => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[0];
    return { at: [e.col, e.row], smash: e.smashing.type + '@' + e.smashing.col + ',' + e.smashing.row, next: e.path[0] && [e.path[0].col, e.path[0].row] }; });
  ok('a fenced-in player: the zombie stands in front of a fence and hits it', st.smash.startsWith('fence') && st.next && ring.some((f) => f[0] === st.next[0] && f[1] === st.next[1]), J(st));
  // 서 있는 좀비의 칸에는 지을 수 없다(바닥 표시도 빨강)
  const nb = await G(() => { const s = window.__game.scene.getScene('game'), e = s.enemies.list[0];
    s.build.setMode('fence'); const w = { x: (e.tile.col - e.tile.row) * 40, y: (e.tile.col + e.tile.row) * 20 }; s.build.point(w.x, w.y);
    const r = { can: s.build.canBuildAt(e.tile.col, e.tile.row), mark: s.build.marks[0].texture.key }; s.build.setMode(null); return r; });
  ok('cannot build on the tile a zombie stands on (red mark)', !nb.can && nb.mark === 'overlay_no', J(nb));
  await W(() => window.__game.scene.getScene('game').map.structures.some((x) => x.type === 'fence' && x.hp < x.maxHp), null, 30000);
  st = await G(() => { const s = window.__game.scene.getScene('game'), f = s.map.structures.find((x) => x.type === 'fence' && x.hp < x.maxHp);
    return { hp: f.hp, bar: !!(f.bar && f.bar.g.visible) }; });
  ok('a hit fence shows its hp bar', st.bar && st.hp < 6, J(st));
  const t0 = await G(() => window.__game.scene.getScene('game').elapsed);
  await W(() => window.__game.scene.getScene('game').build.count('fence') === 7, null, 60000);
  const t1 = await G(() => window.__game.scene.getScene('game').elapsed);
  ok('6 hits, one every 1.5 s, break the fence', t1 - t0 > 6 && t1 - t0 < 9, (t1 - t0).toFixed(2) + ' s after the first hit');
  await W(() => window.__game.scene.getScene('game').enemies.list.length === 0, null, 30000);
  st = await T.snap();
  ok('the zombie comes in and the standing player beats it', st.defeated === 1, J(st));

  // B. 아침에 깎인 시설의 체력이 가득 찬다
  await G(() => { const s = window.__game.scene.getScene('game'); const f = s.map.structures.find((x) => x.type === 'fence'); s.build.damage(f, 3); window.__f = f; });
  await G(() => { const s = window.__game.scene.getScene('game'); s.debugNight(); s.debugMorning(); });
  st = await G(() => ({ hp: window.__f.hp, bar: !!(window.__f.bar && window.__f.bar.g.visible) }));
  ok('morning: structures back to full hp, bar hidden', st.hp === 6 && !st.bar, J(st));
  await W(() => !window.__game.scene.isActive('game'), null, 30000);
  await T.modalButton('계속하기');
  await page.waitForTimeout(300);

  // C. 울타리 벽이 짧으면 돌아온다(부수지 않는다)
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    for (const f of s.map.structures.slice()) s.build.destroy(f);
    window.__smashed = 0; for (let dc = -2; dc <= 2; dc++) s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row - 2 }]);
    const e = s.debugZombie(); });
  await G(() => { const s = window.__game.scene.getScene('game'); s.events.on('postupdate', () => { if (s.enemies.list.some((e) => e.smashing)) window.__smashed++; }); });
  await W(() => { const s = window.__game.scene.getScene('game'); return s.enemies.list.length === 0 || s.hearts.value < 5; }, null, 120000);
  st = await G(() => ({ smashed: window.__smashed, fences: window.__game.scene.getScene('game').build.count('fence') }));
  ok('a short wall: the zombie walks around it instead of breaking it', st.smashed === 0 && st.fences === 5, J(st));

  // D. 모닥불 3칸 안에서는 느려진다(0.5배)
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    for (const f of s.map.structures.slice()) s.build.destroy(f);
    s.hearts.value = s.hearts.max; for (const e of [...s.enemies.list]) s.enemies.remove(e);   // (Phase 9) 2단계는 체력이 2배라 앞 칸의 좀비가 남아 있을 수 있다
    s.build.place('campfire', [{ col: p.tile.col, row: p.tile.row - 1 }]);
    window.__sp = []; let last = null; const cf = { col: p.tile.col, row: p.tile.row - 1 };
    s.events.on('postupdate', () => { const e = s.enemies.list[0]; if (!e) { last = null; return; }
      if (last && last.e === e && e.moving) { const d = Math.hypot(e.col - last.c, e.row - last.r); const dt = Math.min(s.game.loop.delta / 1000, 0.1) * s.speed;
        if (d > 0 && dt > 0) window.__sp.push([d / dt, Math.hypot(e.col - cf.col, e.row - cf.row)]); }
      last = { e, c: e.col, r: e.row }; });
    s.debugZombie(); });
  const def0 = await G(() => window.__game.scene.getScene('game').enemies.defeated);
  await W((d) => window.__game.scene.getScene('game').enemies.defeated > d || window.__game.scene.getScene('game').hearts.value < 5, def0, 120000);
  st = await G(() => { const sp = window.__sp; const near = sp.filter((x) => x[1] <= 2.9).map((x) => x[0]), far = sp.filter((x) => x[1] >= 3.1).map((x) => x[0]);
    const avg = (a) => a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(3) : null; return { near: avg(near), nNear: near.length, far: avg(far), nFar: far.length }; });
  ok('near a campfire a zombie walks at 0.6 tiles/s, elsewhere 1.2', st.nNear > 5 && Math.abs(st.near - 0.6) < 0.02 && Math.abs(st.far - 1.2) < 0.02, J(st));

  ok('per-frame: no one stood on a blocked tile', (await T.bad()).length === 0, J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
