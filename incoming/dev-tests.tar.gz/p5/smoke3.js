// 세 번째 확인: 울타리로 둘러싸면 좀비가 울타리를 부수고 들어온다. 좀비는 시설 칸이나 시설 사이 비스듬한 틈을 지나가지 않는다.
// 모닥불 둘레에서는 느려진다. 밤에 나오는 수와 시각.
const { open } = require('../p4/lib.js');
const J = JSON.stringify;
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G, W } = T;
  // 좀비마다 프레임마다: 몸이 걸친 칸(floor..ceil)에 시설이나 자연 사물이 있으면 안 된다. 비스듬한 걸음의 양옆이 시설이면 안 된다.
  await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    window.__bad = []; window.__maxSpeed = {};
    s.events.on('postupdate', () => {
      for (const e of s.enemies.list) {
        const e9 = 1e-9;
        for (let c = Math.floor(e.col + e9); c <= Math.ceil(e.col - e9); c++) for (let r = Math.floor(e.row + e9); r <= Math.ceil(e.row - e9); r++) {
          if (!m.isWalkable(c, r)) window.__bad.push(['body-on-blocked', +e.col.toFixed(3), +e.row.toFixed(3), c, r]);
        }
      }
    });
  });
  // 주인공 둘레에 울타리 고리(8칸)
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) s.build.place('fence', [{ col: p.tile.col + dc, row: p.tile.row + dr }]);
    s.debugZombie(); });
  let r;
  for (let i = 0; i < 20; i++) {
    await page.waitForTimeout(3000);
    r = await G(() => { const s = window.__game.scene.getScene('game');
      return { hearts: s.hearts.value, fences: s.map.structures.filter((x) => x.type === 'fence').map((f) => [f.col, f.row, f.hp]).filter((f) => f[2] < 6),
        nFences: s.build.count('fence'), z: s.enemies.list.map((e) => [+e.col.toFixed(2), +e.row.toFixed(2), e.smashing ? e.smashing.type + '@' + e.smashing.col + ',' + e.smashing.row : null]), defeated: s.enemies.defeated, bad: window.__bad.slice(0, 3) }; });
    console.log('ring', i, J(r));
    if (r.defeated >= 1) break;
  }
  // 모닥불: 좀비 빠르기 재기(모닥불 3칸 안에서 0.6칸/초)
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    s.build.place('campfire', [{ col: p.tile.col, row: p.tile.row - 4 }]); s.debugZombie();
    window.__sp = []; let last = null;
    s.events.on('postupdate', () => { const e = s.enemies.list[0]; if (!e) return;
      if (last && last.e === e) { const d = Math.hypot(e.col - last.c, e.row - last.r); const dt = Math.min(s.game.loop.delta / 1000, 0.1) * s.speed; if (d > 0 && dt > 0) window.__sp.push([+(d / dt).toFixed(2), +Math.hypot(e.col - p.tile.col, e.row - (p.tile.row - 4)).toFixed(1)]); }
      last = { e, c: e.col, r: e.row }; }); });
  await W(() => window.__game.scene.getScene('game').enemies.defeated >= 2 || window.__game.scene.getScene('game').hearts.value < 3, null, 120000);
  r = await G(() => { const sp = window.__sp; const near = sp.filter((x) => x[1] <= 2.9).map((x) => x[0]), far = sp.filter((x) => x[1] >= 3.1).map((x) => x[0]);
    const avg = (a) => a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(3) : null; return { near: avg(near), nNear: near.length, far: avg(far), nFar: far.length }; });
  console.log('campfire speeds', J(r));
  // 밤: 1일째 밤은 4마리, 0 / 22.5 / 45 / 67.5 초
  const n = await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.list.slice().forEach((e) => s.enemies.remove(e)); s.debugNight(); return s.enemies.schedule.slice(); });
  console.log('night 1 schedule', J(n));
  console.log('bad', J(await G(() => window.__bad.slice(0, 5))), 'errors', J(T.errors));
  await page.screenshot({ path: __dirname + '/smoke3.png' });
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
