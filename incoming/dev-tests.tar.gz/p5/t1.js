// Phase 5 확인 1 (마우스, 1920×1200, 실제 클릭):
// 밤이 되면 좀비가 숲에서 나와 주인공에게 걸어온다 → 좀비를 누르면 가서 단검으로 친다 → 사라진다
// → 아침으로 넘기면 남은 좀비가 사라지고, 3초 뒤 "첫 밤을 넘겼습니다" 창 → 계속하기
const { setup, UI, checker } = require('./lib5.js');
const J = JSON.stringify;
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); window.__notes = []; s.events.on('notice', (t) => window.__notes.push(t));
    window.__spawned = []; const orig = s.enemies.spawn.bind(s.enemies);
    s.enemies.spawn = (k) => { const e = orig(k); if (e) window.__spawned.push([e.col, e.row, +Math.hypot(e.col - s.player.col, e.row - s.player.row).toFixed(1)]); return e; };
    window.__morningAt = null; s.events.on('morning', () => { window.__morningAt = s.elapsed; }); });

  // 1. 밤으로 넘기기(실제 클릭)
  await T.testItem(1);
  let st = await T.snap();
  const spawns = await G(() => window.__game.scene.getScene('game').mapData.zombieSpawns.map((t) => t.col + ',' + t.row));
  ok('night: label and notice', st.label === '1일째 밤' && (await G(() => window.__notes)).includes('밤이 되었습니다'), st.label);
  ok('night: the first zombie appears at once', st.z.length === 1, J(st.z));
  const sp0 = (await G(() => window.__spawned))[0];
  const spawnKey = sp0[0] + ',' + sp0[1];
  const d0 = sp0[2];
  ok('it comes out at a zombie spawn point (forest), 12+ tiles away', spawns.includes(spawnKey) && d0 >= 12, spawnKey + ' dist ' + d0);
  ok('night 1 brings 4 zombies, the first 60% of the night', J(await G(() => window.__game.scene.getScene('game').enemies.schedule)) === J([22.5, 45, 67.5]));

  // 2. 좀비 1마리 부르기(실제 클릭) + 속도 ×3 으로 빨리
  await T.testItem(3);
  st = await T.snap();
  ok('test tool: one more zombie', st.z.length === 2, J(st.z));
  await T.testItem(4);
  await page.waitForTimeout(1500);
  const mid = await T.snap();
  const dist = (z) => Math.hypot(z.at[0] - mid.p[0], z.at[1] - mid.p[1]);
  ok('zombies walk toward the player', mid.z.length >= 1 && dist(mid.z[0]) < d0, `${d0.toFixed(1)} -> ${dist(mid.z[0]).toFixed(1)}`);

  // 3. 가까이 오면 좀비를 누른다(실제 클릭)
  await W(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return s.enemies.list.some((e) => Math.hypot(e.col - p.col, e.row - p.row) < 6); }, null, 120000);
  await T.testItem(4);                                              // 속도 ×1 로
  const target = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    const e = s.enemies.list.slice().sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0];
    window.__target = e; window.__hits = []; const orig = e.hurt.bind(e); e.hurt = (n) => { window.__hits.push([s.player.swing ? s.player.swing.tool : null, e.hp]); return orig(n); };
    const sp = e.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5, hp: e.hp }; });
  const before = await T.snap();
  await T.tapWorld(target.wx, target.wy);
  await page.waitForTimeout(200);
  st = await T.snap();
  ok('tapping a zombie: the player goes to attack it', st.action === 'zombie', J({ action: st.action }));
  await W(() => !window.__target.alive, null, 60000);
  await page.waitForTimeout(300);
  st = await T.snap();
  const hits = await G(() => window.__hits);
  ok('it is hit with the dagger, 3 times', hits.length === 3 && hits.every((h) => h[0] === 'dagger'), J(hits));
  // Phase 10 (12.3): 목록에서는 바로 빠지고, 그림은 쓰러져(die) 흐려지며 사라진다(약 1.4초)
  const out = await G(() => !window.__target.alive && !window.__game.scene.getScene('game').enemies.list.includes(window.__target));
  const g0 = await G(() => window.__game.scene.getScene('game').elapsed);
  await W(() => !window.__target.sprite.active, null, 20000);
  const gone = (await G(() => window.__game.scene.getScene('game').elapsed)) - g0 < 1.6;   // 게임 시간으로 1.4초쯤
  ok('the zombie leaves at once, falls and fades out, and counts as defeated', st.defeated === before.defeated + 1 && out && gone, `defeated ${before.defeated} -> ${st.defeated}, out ${out}, gone ${gone}`);

  // 4. 아침으로 넘기기: 남은 좀비는 사라지고, 화면이 밝아진 뒤(3초) 결과 창
  const heartsAtNightEnd = (await T.snap()).hearts;
  await T.testItem(2);
  const t0 = await G(() => window.__morningAt);
  st = await T.snap();
  ok('morning: remaining zombies vanish at once', st.z.length === 0 && st.label === '2일째 낮', J(st));
  ok('no "2일째 아침입니다" notice on the first morning', !(await G(() => window.__notes)).includes('2일째 아침입니다'));
  await W(() => !window.__game.scene.isActive('game'), null, 30000);
  const t1 = await G(() => window.__game.scene.getScene('game').elapsed);
  const texts = await T.modalTexts();
  // 창이 뜬 뒤(게임이 멈춘 뒤)의 값과 비교한다. 아침으로 넘기는 클릭 사이(실제 시간)에 좀비가 때리거나 쓰러질 수 있어서.
  const hearts = await G(() => window.__game.scene.getScene('game').nightEndHearts);
  st.defeated = await G(() => window.__game.scene.getScene('game').enemies.defeated);
  ok('result window after the 3 s dawn', Math.abs(t1 - t0 - 3) < 0.25, (t1 - t0).toFixed(2) + ' s');
  ok('result window: title, defeated, fences, hearts, two buttons',
    J(texts) === J(['첫 밤을 넘겼습니다', '물리친 적', st.defeated + '마리', '남은 울타리', '0개', '남은 하트', hearts + '칸', '계속하기', '다시 시작']), J(texts));
  ok('todo 6 is checked', await G(() => window.__game.scene.getScene('game').todo.isDone('morning')));
  await page.screenshot({ path: __dirname + '/t1_result.png' });
  // 창이 떠 있는 동안 게임 시간이 멈춘다
  const e1 = await G(() => window.__game.scene.getScene('game').elapsed);
  await page.waitForTimeout(800);
  ok('game time stops while the window is up', (await G(() => window.__game.scene.getScene('game').elapsed)) === e1);
  // 만들기 버튼은 창에 가려 눌리지 않는다
  await T.ui(...UI.craft);
  ok('the craft button does not open under the window', !(await G(() => window.__game.scene.getScene('ui').craftOpen)));
  await T.modalButton('계속하기');
  await page.waitForTimeout(500);
  st = await T.snap();
  ok('계속하기: the window closes and day 2 goes on', st.active && (await T.modalTexts()) === null && st.label === '2일째 낮', J({ active: st.active, label: st.label }));
  const e2 = await G(() => window.__game.scene.getScene('game').elapsed);
  await page.waitForTimeout(800);
  ok('game time runs again', (await G(() => window.__game.scene.getScene('game').elapsed)) > e2);

  ok('per-frame: no one stood on a blocked tile', (await T.bad()).length === 0, J(await T.bad()));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
