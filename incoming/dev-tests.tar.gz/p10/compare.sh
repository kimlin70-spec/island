#!/bin/bash
# 같은 무작위 시험을 예전 코드(8001)와 새 코드(8000)에
cd "$(dirname "$0")"
for a in "31 3 25000 random {} cmpR" "41 3 25000 100 {} cmp100"; do
  set -- $a
  echo "== OLD $*"; (cd old/fuzz && timeout 2400 node pfuzz.js $1 $2 $3 $4 "$5" $6 2>&1 | grep -E "^seed|page errors|CRASH")
  echo "== NEW $*"; (cd fuzz && timeout 2400 node pfuzz.js $1 $2 $3 $4 "$5" $6 2>&1 | grep -E "^seed|page errors|CRASH")
done
echo CMPDONE
