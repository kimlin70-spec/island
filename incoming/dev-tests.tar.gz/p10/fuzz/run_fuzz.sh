#!/bin/bash
cd "$(dirname "$0")"
for a in "1 4 30000 random {} n1x" "11 3 30000 16.7 {} n2" "21 3 25000 100 {} n3"; do set -- $a; timeout 2400 node pfuzz.js $1 $2 $3 $4 "$5" $6 2>&1 | grep -E "^seed|page errors|CRASH"; done
echo FUZZDONE
