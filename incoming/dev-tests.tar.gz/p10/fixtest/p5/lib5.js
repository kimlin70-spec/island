// Phase 5 시험 도구 (p4/lib.js 위에)
const { open } = require('../p4/lib.js');
exports.UI = {
  craft: [1824, 1104],
  card: (i) => [776 + 20 + i * 182 + 85, 898],   // 0 axe, 1 pickaxe, 2 fence, 3 campfire, 4 tent, 5 remove
  test: [1852, 328],
  testItem: (i) => [1746, 398 + i * 56],          // 0 +20, 1 night, 2 morning, 3 zombie, 4 speed, 5 close
  rest: [960, 1132],
};
exports.setup = async (opts = {}) => {
  const T = await open(opts);
  const { page, G } = T;
  T.touch = !!opts.touch;
  // 게임 화면 좌표(1920×1200) -> 브라우저 좌표
  T.g2p = (x, y) => G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect();
    return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
  // 월드 좌표 -> 브라우저 좌표
  T.w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, on: sx >= 0 && sy >= 0 && sx < cam.width && sy < cam.height }; }, [wx, wy]);
  T.tapPage = async (x, y) => { if (T.touch) await page.touchscreen.tap(x, y); else await page.mouse.click(x, y); };
  T.ui = async (x, y, wait = 300) => { const p = await T.g2p(x, y); await T.tapPage(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  T.tapWorld = async (wx, wy, wait = 0) => { const p = await T.w2p(wx, wy); if (!p.on) throw new Error('off screen ' + wx + ',' + wy); await T.tapPage(p.x, p.y); if (wait) await page.waitForTimeout(wait); return p; };
  T.testItem = async (i) => { await T.ui(...exports.UI.test); await T.ui(...exports.UI.testItem(i)); await T.ui(...exports.UI.testItem(5)); };
  // 창의 단추를 글로 찾아 누른다
  T.modalButton = async (text) => {
    const p = await G((text) => { const u = window.__game.scene.getScene('ui'); if (!u.modal) return null;
      const t = u.modal.list.find((o) => o.type === 'Text' && o.text === text); return t ? { x: t.x, y: t.y } : null; }, text);
    if (!p) throw new Error('no button ' + text);
    await T.ui(p.x, p.y, 0);
  };
  T.modalTexts = () => G(() => { const u = window.__game.scene.getScene('ui'); return u.modal ? u.modal.list.filter((o) => o.type === 'Text').map((t) => t.text) : null; });
  // 좀비의 몸 한가운데(누를 곳)
  T.zombiePoint = (i = 0) => G((i) => { const e = window.__game.scene.getScene('game').enemies.list[i]; if (!e) return null;
    const sp = e.sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5 }; }, i);
  T.snap = () => G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return { p: [+p.col.toFixed(2), +p.row.toFixed(2)], tile: [p.tile.col, p.tile.row], hearts: s.hearts.value, resting: s.rest.resting, speed: s.speed,
      action: p.action ? (p.action.target.kind || p.action.target.type) : null, frame: p.sprite.frame.name, defeated: s.enemies.defeated,
      z: s.enemies.list.map((e) => ({ at: [+e.col.toFixed(2), +e.row.toFixed(2)], hp: e.hp, smash: e.smashing ? e.smashing.type : null })),
      label: s.clock.label, active: window.__game.scene.isActive('game') }; });
  // 프레임마다: 좀비의 몸(floor..ceil)이 시설·자연 사물·물 칸에 걸치면 안 된다. 주인공도.
  await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    window.__bad = [];
    const check = (who, w) => { const e9 = 1e-9;
      for (let c = Math.floor(w.col + e9); c <= Math.ceil(w.col - e9); c++) for (let r = Math.floor(w.row + e9); r <= Math.ceil(w.row - e9); r++)
        if (!m.isWalkable(c, r)) window.__bad.push([who, 'body-on-blocked', +w.col.toFixed(3), +w.row.toFixed(3), c, r]); };
    s.events.on('postupdate', () => { check('player', s.player); for (const e of s.enemies.list) check('zombie', e); });
  });
  T.bad = () => G(() => window.__bad.slice(0, 6));
  return T;
};
exports.checker = () => {
  let fails = 0;
  const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
  return { ok, done: () => { console.log(fails ? `\n${fails} FAILED` : '\nALL PASS'); return fails; } };
};
