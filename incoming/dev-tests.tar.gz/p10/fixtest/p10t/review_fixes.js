// 검토에서 나온 네 가지가 고쳐졌는가
// A) 적의 피해 순간과 같은 프레임에 주인공이 비켜 가면: 피해 없음, hit 그림 없이 바로 걷는다(timing-2)
// B) ×3, 고르지 않은 프레임(33ms, 100ms)에서도 주인공이 맞히는 프레임에 hit 그림과 궤적(timing-1)
// C) 적이 맞은 뒤 hurt 는 0.2초 + 멈칫 0.05초만큼(한 프레임 더 길지 않다)(timing-3)
// D) 나무 뒤에서 쓰러진 적: 쓰러지는 동안 나무가 반투명으로 남는다(spec-1)
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = []; window.__press = s.pressEnemy; s.pressEnemy = () => {}; });

  // A) 여러 번: 피해 직전 프레임 사이에 주인공을 두 칸 옮긴다
  const resA = [];
  for (let k = 0; k < 4; k++) {
    await G((k) => { const s = window.__S, E = s.enemies; for (const e of [...E.list]) E.remove(e);
      s.player.stopAction(); s.hearts.value = 5;
      const p = s.player.tile; const z = window.__z = E.add('zombie', { col: p.col + 1, row: p.row }); z.hp = 99; z.hitLeft = 0.6 + k * 0.004; }, k);
    for (let i = 0; i < 300; i++) { await T.run(1); if (await G(() => window.__z.hitLeft !== null && window.__z.hitLeft <= 1 / 60 + 1e-9 && window.__z.body.winding())) break; }
    const r = await G(() => { const s = window.__S, z = window.__z, p = s.player;
      // 주인공을 좀비 반대쪽으로 두 칸(걸을 수 있는 칸)
      const c = p.tile.col - 2, rr = p.tile.row; if (s.map.isWalkable(c, rr)) { p.col = c; p.row = rr; p.tile = { col: c, row: rr }; p.path = []; }
      window.__h0 = s.hearts.value; window.__zx = [z.col, z.row]; return { hitLeft: z.hitLeft, act: z.body.act && z.body.act.name, t: z.body.act && +z.body.act.t.toFixed(3) }; });
    await T.run(1);
    const a = await G(() => { const s = window.__S, z = window.__z; return { hearts: s.hearts.value, act: z.body.act ? z.body.act.name : null, f: z.asset.frames[+z.sprite.frame.name], moved: z.col !== window.__zx[0] || z.row !== window.__zx[1] }; });
    await T.run(2);
    const b = await G(() => { const z = window.__z; return { moved: z.col !== window.__zx[0] || z.row !== window.__zx[1], f: z.asset.frames[+z.sprite.frame.name] }; });
    resA.push({ r, a, b });
  }
  ok('A) player leaves in the damage frame: no damage, no hit picture, the zombie walks at once', resA.every((x) => x.a.hearts === 5 && x.a.act === null && !/attack$/.test(x.a.f) && (x.a.moved || x.b.moved)), J(resA));

  // B) ×3, 프레임 33ms/100ms 번갈아: 맞히는 프레임마다 dagger2 와 궤적
  await G(() => { const s = window.__S, E = s.enemies; for (const e of [...E.list]) E.remove(e); s.debugSpeed = 3; s.hearts.value = 5; s.hurtPlayer = () => false;
    const p = s.player.tile; const z = window.__z = E.add('zombie', { col: p.col + 1, row: p.row }); z.hp = 999;
    window.__bad = []; window.__n = 0; const oh = z.hurt.bind(z);
    z.hurt = (n, f) => { window.__n++; window.__mark = true; return oh(n, f); };
    s.events.on('postupdate', () => { if (!window.__mark) return; window.__mark = false; const pl = s.player;
      const f = pl.asset.frames[+pl.sprite.frame.name], trails = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_swing' && o.anims && o.anims.currentFrame && o.anims.currentFrame.index === 1).length;
      if (!/dagger2$/.test(f) || !pl.sprite.anims.isPaused || trails < 1) window.__bad.push({ f, paused: pl.sprite.anims.isPaused, trails }); });
    window.__press.call(s, z); });
  for (let i = 0; i < 40; i++) { await T.run(1, 33.3); await T.run(1, 100); }
  for (let i = 0; i < 30; i++) { await T.run(2, 16.7); await T.run(1, 100); }
  const rb = await G(() => ({ n: window.__n, bad: window.__bad.slice(0, 5), nbad: window.__bad.length }));
  ok('B) x3 with uneven frames: every player hit shows dagger2, frozen, with a fresh swing trail', rb.n >= 20 && rb.nbad === 0, J(rb));

  // C) 50ms 프레임, ×1: 맞은 적의 hurt 가 보이는 시간
  await G(() => { const s = window.__S, E = s.enemies; for (const e of [...E.list]) E.remove(e); s.debugSpeed = 1; s.player.stopAction();
    const p = s.player.tile; const z = window.__z = E.add('zombie', { col: p.col + 1, row: p.row }); z.hp = 999; z.hitLeft = 99; z.cfg = Object.assign({}, z.cfg, { firstHitDelay: 99, hitInterval: 99 });
    window.__hl = []; window.__hitT = null; const oh = z.hurt.bind(z);
    z.hurt = (n, f) => { if (window.__hitT === null) window.__hitT = s.elapsed; return oh(n, f); };
    s.events.on('postupdate', () => { if (window.__hitT !== null && window.__hl.length < 20) window.__hl.push([+(s.elapsed - window.__hitT).toFixed(3), z.asset.frames[+z.sprite.frame.name]]); });
    window.__press.call(s, z); });
  await T.until('return window.__hitT !== null && window.__hl.length >= 12', 600, 50);
  const hl = await G(() => window.__hl.slice());
  const firstNot = hl.find((h) => h[1] !== 'hurt');
  ok('C) 50 ms frames: an enemy shows hurt for 0.2 s + 0.05 s hit stop (first non-hurt frame at 0.25-0.30 s)', firstNot && firstNot[0] >= 0.249 && firstNot[0] <= 0.301, J(hl));

  // D) 나무 바로 위(화면 위쪽)에 좀비: 나무가 반투명. 쓰러뜨린 뒤 0.6초에도 반투명
  const d = await G(() => { const s = window.__S, E = s.enemies, m = s.map; for (const e of [...E.list]) E.remove(e); s.player.stopAction();
    // 나무 하나와, 그 위쪽(col-1,row-1) 칸이 걸을 수 있고, 그 옆에 주인공이 설 칸이 있는 곳
    for (const o of m.objects) { if (o.kind !== 'tree' || !o.node) continue;
      const zc = o.col - 1, zr = o.row - 1, pc = o.col - 2, pr = o.row;
      if (m.isWalkable(zc, zr) && m.isWalkable(pc, pr) && m.isWalkable(o.col - 2, o.row - 1)) {
        const p = s.player; p.col = pc; p.row = pr; p.tile = { col: pc, row: pr }; p.path = [];
        const z = window.__z = E.add('zombie', { col: zc, row: zr }); z.hp = 1; z.hitLeft = 99; window.__tree = o; return { tree: [o.col, o.row], z: [zc, zr], p: [pc, pr] }; } }
    return null; });
  await T.run(30);
  const a0 = await G(() => +window.__tree.sprite.alpha.toFixed(2));
  await G(() => { window.__press.call(window.__S, window.__z); });
  await T.until('return !window.__z.alive', 300);
  await T.run(36);
  const a1 = await G(() => ({ alpha: +window.__tree.sprite.alpha.toFixed(2), corpse: window.__z.sprite.active }));
  ok('D) a zombie dying behind a tree keeps the tree see-through while it falls', d && a0 < 0.6 && a1.corpse && a1.alpha < 0.6, J({ d, a0, a1 }));
  await T.run(60);
  const a2 = await G(() => ({ alpha: +window.__tree.sprite.alpha.toFixed(2), corpse: window.__z.sprite.active, corpses: window.__S.effects.corpses.length }));
  ok('D2) after the body is gone the tree turns solid again and nothing is left in the list', !a2.corpse && a2.alpha === 1 && a2.corpses === 0, J(a2));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
