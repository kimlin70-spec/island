// 텐트에서 자는 동안(×4): 하트 조각이 텐트 문에서, 애니메이션 빠르기 = 게임 시간/실제 시간. ×3 에서 쓰러짐 1초(게임 시간).
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const tent = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; s.enemies.schedule = [];
    let spot = null;
    for (let d = 2; d < 6 && !spot; d++) for (const [dc, dr] of [[d, 0], [0, d], [-d, 0], [0, -d]]) {
      const ts = [[0, 0], [1, 0], [0, 1], [1, 1]].map(([a, b]) => ({ col: p.col + dc + a, row: p.row + dr + b }));
      if (!spot && ts.every((t) => s.build.canBuildAt(t.col, t.row))) spot = ts; }
    const t = s.build.place('tent', spot); s.hearts.value = 2; s.pressTent(t); window.__tent = t; return spot; });
  await T.until('return window.__game.scene.getScene("game").rest.resting', 600);
  const st = await G(() => { const s = window.__game.scene.getScene('game'); window.__hp = []; const hu = s.heartsUp.bind(s);
    s.heartsUp = () => { let n0 = 0; for (const [id, em] of s.effects.emitters) if (id.startsWith('hearts')) n0 += em.getAliveParticleCount(); hu(); window.__hp.push({ n0, speed: s.speed, gts: window.__game.anims.globalTimeScale, resting: s.rest.resting }); };
    return { speed: s.speed }; });
  await T.until('return window.__hp.length >= 1', 60 * 10);
  const hp = await G(() => { const s = window.__game.scene.getScene('game'); let pos = null;
    for (const [id, em] of s.effects.emitters) if (id.startsWith('hearts') && em.getAliveParticleCount()) { const p = em.alive[0]; pos = { x: +p.x.toFixed(1), y: +p.y.toFixed(1) }; }
    const door = s.map.assets.build_tent.door, t = window.__tent.sprite; return { hp: window.__hp, pos, door: { x: t.x + door[0], y: t.y + door[1] }, hearts: s.hearts.value }; });
  ok('sleeping x4: a heal shows hearts rising from the tent door; animations run at x4 game time', hp.hp[0].speed === 4 && Math.abs(hp.hp[0].gts - 4) < 1e-9 && hp.hp[0].resting && hp.pos && Math.hypot(hp.pos.x - hp.door.x, hp.pos.y - hp.door.y) < 30, J(hp));
  // ×3 에서 쓰러짐: 1초(게임 시간) = 실제 1/3초
  await G(() => { const s = window.__game.scene.getScene('game'); s.rest.exit(); s.debugToggleSpeed(); s.hearts.value = 1; window.__downAt = null; window.__d0 = null;
    s.events.once('down', () => { window.__downAt = s.elapsed; });
    const p = s.player.tile; const z = s.enemies.add('zombie', { col: p.col - 1, row: p.row }); z.hp = 99; z.hitLeft = 0.3; });
  await T.until('return window.__game.scene.getScene("game").player.downed', 300);
  await G(() => { window.__d0 = window.__game.scene.getScene('game').elapsed; });
  await T.until('return !window.__game.scene.isActive("game")', 300);
  const dn = await G(() => ({ wait: +(window.__downAt - window.__d0).toFixed(3), speed: window.__game.scene.getScene('game').speed }));
  ok('x3: the down window opens after 1 s of game time (one frame tolerance)', dn.speed === 3 && Math.abs(dn.wait - 1) <= 0.051, J(dn));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
