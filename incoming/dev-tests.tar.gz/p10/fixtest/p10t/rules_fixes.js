// 규칙 검토에서 나온 두 가지
// R1) 밤이 끝나기 직전에 쓰러지면: 1초 동안 아침이 오지 않는다(할 일, 날짜, 적 그대로), 그 뒤 "쓰러졌습니다"
// R2) 10fps(100ms 프레임)에서 단검: 붙자마자 싸우면 0.3 / 0.9 / 1.5초에 맞히고, 좀비는 첫 공격(1.5초) 전에 쓰러진다(Phase 5 와 같다)
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  // R2 먼저(창이 뜨기 전에)
  await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = [];
    const p = s.player.tile; window.__t0 = s.elapsed; window.__hits = []; window.__hearts = [];
    const z = window.__z = s.enemies.add('zombie', { col: p.col + 1, row: p.row }); const oh = z.hurt.bind(z);
    z.hurt = (n, f) => { window.__hits.push(+(s.elapsed - window.__t0).toFixed(3)); return oh(n, f); };
    s.events.on('hearts-changed', () => window.__hearts.push([+(s.elapsed - window.__t0).toFixed(3), s.hearts.value])); });
  await T.run(25, 100);
  const r2 = await G(() => ({ hits: window.__hits, hearts: window.__hearts, alive: window.__z.alive, h: window.__S.hearts.value }));
  ok('R2) 10 fps: dagger hits at 0.3, 0.9, 1.5 s and the zombie falls before its first hit (no heart lost)', J(r2.hits) === J([0.3, 0.9, 1.5]) && !r2.alive && r2.h === 5, J(r2));
  // R1
  await G(() => { const s = window.__S; s.debugNight(); s.enemies.schedule = []; s.clock.t = 150 - 0.6; s.hearts.value = 1; s.player.stopAction();
    window.__ev = []; s.events.on('morning', () => window.__ev.push(['morning', +s.elapsed.toFixed(3)])); s.events.once('down', () => window.__ev.push(['down', +s.elapsed.toFixed(3)]));
    const p = s.player.tile; const z = s.enemies.add('zombie', { col: p.col - 1, row: p.row }); z.hp = 99; z.hitLeft = 0.1; z.cfg = Object.assign({}, z.cfg);
    s.pressEnemy = () => {}; window.__e0 = s.elapsed; });
  await T.until('return !window.__game.scene.isActive("game")', 300);
  const r1 = await G(() => { const s = window.__S; return { ev: window.__ev, label: s.clock.label, night: s.clock.isNight, todo: s.todo.isDone('morning'), enemies: s.enemies.list.length, result: s.resultPending, e0: +window.__e0.toFixed(3) }; });
  ok('R1) down in the last second of the night: no morning before the down window', r1.ev.length === 1 && r1.ev[0][0] === 'down' && r1.night && !r1.todo && r1.enemies >= 1 && !r1.result, J(r1));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
