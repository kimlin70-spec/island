// Phase 10 기능 확인 2: 발자국과 발걸음 먼지, 앞뒤 바뀜, 해적 상륙 물보라, 돌 부서짐, 주인공 밀림, 밤 하나 뒤 남는 효과
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__S2 = window.__game.scene.getScene('game'); s.enemies.schedule = []; });
  const kinds = () => G(() => { const s = window.__S2, out = {};
    for (const o of s.children.list) { const k = o.texture && o.texture.key; if (k && /^fx_/.test(k) && o.type !== 'ParticleEmitter') out[k] = (out[k] || 0) + 1; }
    let parts = 0; for (const em of s.effects.emitters.values()) parts += em.getAliveParticleCount();
    out.particles = parts; out.running = s.effects.running.length; out.prints = s.effects.prints.length; return out; });

  // 1) 모래 위를 걸으면 발자국(최대 20), 디딜 때마다 작은 먼지. 3초 + 1초 뒤 사라진다.
  const sand = await G(() => { const s = window.__S2, m = s.map, p = s.player;
    // 주인공에서 가까운 모래 칸 줄(가로로 8칸 이상 걸을 수 있는 곳)
    let best = null;
    for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols - 9; c++) {
      let okk = true; for (let k = 0; k < 9; k++) if (!m.isSand(c + k, r) || !m.isWalkable(c + k, r)) { okk = false; break; }
      if (okk) { const d = Math.hypot(c - p.col, r - p.row); if (!best || d < best.d) best = { c, r, d }; }
    }
    return best; });
  await G((b) => { const s = window.__S2; s.player.col = b.c; s.player.row = b.r; s.player.tile = { col: b.c, row: b.r }; s.player.path = []; s.cameras.main.centerOn((b.c - b.r) * 40, (b.c + b.r) * 20);
    window.__steps = 0; s.player.sprite.on('animationupdate', (a, f) => { if (/walk[12]$/.test(s.player.asset.frames[+f.textureFrame])) window.__steps++; });
    s.walkTo(b.c + 8, b.r); }, sand);
  await T.until('return !s.player.moving', 600);
  let k = await kinds();
  const steps = await G(() => window.__steps);
  ok('1a) walking 8 tiles on sand leaves footprints (one per step frame) and step dust', k.prints >= 8 && k.prints <= 20 && k.fx_footprint === k.prints, J({ k, steps }));
  const fp = await G(() => { const s = window.__S2; const f = s.effects.prints[0].img; return { depth: f.depth, flip: f.flipX, a: f.alpha }; });
  ok('1b) footprints lie on the ground (depth 2), not flipped when walking right', fp.depth === 2 && fp.flip === false, J(fp));
  await T.run(60 * 4.2);
  k = await kinds();
  ok('1c) footprints are gone after 3 s + 1 s fade', !k.fx_footprint && k.prints === 0, J(k));
  // 20개 넘게: 한꺼번에 25개
  await G(() => { const s = window.__S2; for (let i = 0; i < 25; i++) s.effects.footprint(s.player.sprite.x + i * 3, s.player.sprite.y, true); });
  k = await kinds();
  ok('1d) at most 20 footprints at a time', k.prints === 20 && k.fx_footprint === 20, J(k));
  await G((b) => { const s = window.__S2; for (const p of [...s.effects.prints]) s.effects.dropPrint(p); s.walkTo(b.c, b.r); }, sand);
  await T.run(20);
  const fl = await G(() => window.__S2.effects.prints.map((p) => p.img.flipX));
  ok('1e) footprints are flipped when walking left (screen x going down)', fl.length > 0 && fl.every(Boolean), J(fl));
  await T.until('return !s.player.moving', 600);

  // 2) 앞뒤: 화면 가로로만(칸으로는 (-1,+1)씩) 걸으면 뒷모습이 나오지 않는다(뒷모습으로 서 있다가 걸어도).
  //    비스듬히 가는 길은 앞뒤가 한 번 이하로 바뀐다.
  const hz = await G(() => { const s = window.__S2, m = s.map, p = s.player.tile;
    for (let k = 5; k >= 2; k--) for (const sg of [1, -1]) { let okk = true; for (let i = 1; i <= k; i++) if (!m.isWalkable(p.col - sg * i, p.row + sg * i)) okk = false;
      if (okk) return { dc: -sg * k, dr: sg * k }; }
    return null; });
  await G((d) => { const s = window.__S2; window.__anims = []; s.player.body.back = true; s.player.body.show(false);
    s.player.sprite.on('animationstart', (a) => window.__anims.push(a.key)); const p = s.player.tile; s.walkTo(p.col + d.dc, p.row + d.dr); }, hz);
  await T.until('return !s.player.moving', 600);
  let an = await G(() => window.__anims.splice(0));
  ok('2a) walking straight along the screen never shows the back, even from a back idle', hz && an.length && !an.some((a) => /:b/.test(a)), J({ hz, an }));
  // (c, r) -> (c-7, r+3) 같은 비스듬한 길(화면 왼쪽 위)
  const dest = await G((b) => { const s = window.__S2, m = s.map, p = s.player.tile;
    for (const [dc, dr] of [[-7, 3], [-3, -7], [7, -3], [3, 7], [-6, -2], [-2, -6]]) if (m.isWalkable(p.col + dc, p.row + dr)) { const f = s.player.findRoute([{ col: p.col + dc, row: p.row + dr }]); if (f && f.length <= 12) return { dc, dr }; }
    return null; }, sand);
  await G((d) => { const s = window.__S2, p = s.player.tile; window.__viewLog = []; s.events.on('postupdate', () => { if (s.player.moving) { const v = s.player.body.back ? 'B' : 'F'; if (window.__viewLog[window.__viewLog.length - 1] !== v) window.__viewLog.push(v); } });
    s.walkTo(p.col + d.dc, p.row + d.dr); }, dest);
  await T.until('return !s.player.moving', 600);
  const vl = await G(() => window.__viewLog);
  ok('2b) a slanted walk changes front/back at most once', vl.length <= 2, J({ dest, vl }));

  // 3) 돌 부수기(곡괭이): 돌 부스러기 바로, 먼지와 돌 조각, poof 없음
  const rock = await G(() => { const s = window.__S2, p = s.player; s.tools.push('pickaxe');
    const rocks = s.map.objects.filter((o) => o.kind === 'rock' && o.node);
    rocks.sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
    const o = window.__rock = rocks[0]; o.node.hp = 1; window.__rk = null;
    s.events.on('postupdate', () => { if (!window.__rk && o.kind === 'rubble') { let st = 0; for (const [id, em] of s.effects.emitters) if (id.includes('stone')) st += em.getAliveParticleCount();
      window.__rk = { poof: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_poof').length, dust: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_dust' && c.scaleX === 1).length, stones: st }; } });
    s.pressNode(o); return [o.col, o.row]; });
  await T.until('return !!window.__rk', 1500);
  let rk = await G(() => window.__rk);
  ok('3) breaking a rock: rubble, dust, stone chips (3 + 6), no poof', rk && rk.poof === 0 && rk.dust >= 1 && rk.stones >= 9, J(rk));

  // 4) 주인공이 맞으면 6px 밀렸다가(hurt 동안) 돌아온다. 카메라가 흔들린다.
  const pk = await G(() => { const s = window.__S2, p = s.player.tile; s.player.stopAction();
    const z = window.__zz = s.enemies.add('zombie', { col: p.col + 1, row: p.row }); z.hp = 99; z.hitLeft = 0.5;
    s.pressEnemy = () => {}; window.__pk = [];
    s.events.on('postupdate', () => { const f = s.player.foot(); window.__pk.push({ t: +s.elapsed.toFixed(3), dx: +(s.player.sprite.x - f.x).toFixed(2), dy: +(s.player.sprite.y - f.y).toFixed(2), shake: s.cameras.main.shakeEffect.isRunning, f: s.player.asset.frames[+s.player.sprite.frame.name] }); });
    window.__h0 = s.hearts.value; return null; });
  await T.until('return window.__S2.hearts.value < window.__h0', 300);
  await T.run(30);
  const pkl = await G(() => window.__pk);
  const hi = pkl.findIndex((r) => r.f === 'hurt'), maxd = Math.max(...pkl.map((r) => Math.hypot(r.dx, r.dy))), last = pkl[pkl.length - 1];
  ok('4) player knocked back up to 6 px away from the zombie while hurt, then back; camera shakes', hi >= 0 && pkl[hi].shake && maxd > 5 && maxd <= 6.01 && last.dx === 0 && last.dy === 0 && pkl[hi + 3].dx < 0, J(pkl.slice(hi, hi + 18).filter((r, i) => i % 3 === 0)));
  await G(() => { const s = window.__S2; s.enemies.remove(window.__zz); delete s.pressEnemy; });

  // 5) 해적 상륙: 물보라
  const sp = await G(() => { const s = window.__S2; s.debugNight(); s.clock.t = 0.45 * 150 - 0.01; window.__spl = 0;
    s.events.on('postupdate', () => { window.__spl = Math.max(window.__spl, s.children.list.filter((c) => c.texture && c.texture.key === 'fx_splash').length); }); return null; });
  await T.run(5);
  const spl = await G(() => { const s = window.__S2; return { spl: window.__spl, pir: s.enemies.list.filter((e) => e.kind !== 'zombie').length }; });
  ok('5) pirates land with a splash', spl.spl === 1 && spl.pir === 2, J(spl));

  // 6) 밤 하나(14마리 + 해적 둘)를 빨리 돌린 뒤: 효과가 남지 않는다
  await G(() => { const s = window.__S2; s.debugMorning(); s.resultPending = false; });
  await T.run(60 * 3);
  await G(() => { const s = window.__S2; s.clock.day = 6; s.debugNight(); s.hurtPlayer = () => false; s.debugSpeed = 3; });
  await T.until('return !s.clock.isNight', 60 * 200);
  await T.run(60 * 6);
  k = await kinds();
  const left = await G(() => ({ enemies: window.__S2.enemies.list.length, sprites: window.__S2.children.list.length }));
  ok('6) after a full 14-zombie night and morning: no effect sprites, particles or timers left', Object.keys(k).filter((x) => /^fx_/.test(x)).length === 0 && k.particles === 0 && k.running === 0 && left.enemies === 0, J({ k, left }));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
