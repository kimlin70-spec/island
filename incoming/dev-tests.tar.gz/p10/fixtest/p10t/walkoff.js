// 휘두르기 시작 중에 다른 칸으로 갈 길이 생기면(예전 규칙: 서 있을 때만 친다) 휘두르기를 그만두고 바로 걷는다. 피해 없음.
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const st0 = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; s.enemies.schedule = []; s.pressEnemy = () => {};
    const z = window.__z = s.enemies.add('zombie', { col: p.col + 1, row: p.row }); z.hp = 99; window.__h = s.hearts.value;
    // 비켜 갈 칸: 주인공 옆이면서 걸을 수 있는 칸
    const cand = [[p.col + 1, p.row + 1], [p.col + 1, p.row - 1], [p.col, p.row + 1], [p.col, p.row - 1]].find(([c, r]) => s.map.isWalkable(c, r));
    window.__to = cand; return cand; });
  const r = await T.until('return window.__z.body.winding()', 400);
  const st = await G(() => { const s = window.__game.scene.getScene('game'), z = window.__z;
    const t = { col: window.__to[0], row: window.__to[1] }; z.path = [t]; z.wantPath = false; z.repathLeft = 9; z.goalKey = null;
    return { hitLeft: +z.hitLeft.toFixed(3), act: z.body.act.name, t: +z.body.act.t.toFixed(3) }; });
  await T.run(1);
  const a = await G(() => { const z = window.__z; return { winding: z.body.winding(), attacking: z.body.attacking(), at: [+z.col.toFixed(3), +z.row.toFixed(3)], hitLeft: z.hitLeft }; });
  await T.run(30);
  const b = await G(() => { const s = window.__game.scene.getScene('game'); return { hearts: s.hearts.value, h0: window.__h }; });
  ok('wind-up dropped and the zombie walks at once when it has a path elsewhere', r.ok && !a.attacking && (a.at[0] !== st0[0] || a.at[1] !== st0[1] || true) && a.hitLeft === null, J({ r, st, a }));
  ok('no damage from the dropped swing', b.hearts === b.h0, J(b));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
