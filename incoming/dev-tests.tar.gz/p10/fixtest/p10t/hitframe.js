// 피해를 주는 프레임에 hit 그림이 보이는가(주인공의 단검, 좀비·해적의 공격), 멈칫·번쩍임·밀림이 보이는가.
// 60Hz(16.7ms)와 느린 기기(100ms 프레임)를 ×1, ×3 으로.
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
const runCase = async (T, G, D, speed, kind) => {
  await G(([speed, kind]) => {
    const s = window.__game.scene.getScene('game'), E = s.enemies;
    for (const e of [...E.list]) E.remove(e);
    E.schedule = [];
    s.debugSpeed = speed;
    s.hearts.value = 5; s.player.downLeft = null; s.player.body.final = null;
    const p = s.player.tile;
    window.__z = E.add(kind, { col: p.col + 1, row: p.row });
    window.__z.hp = 99;
    window.__log = [];
    const fr = (sp, a) => a.frames[+sp.frame.name];
    if (!window.__hooked) {
      window.__hooked = true;
      s.events.on('postupdate', () => {
        const z = window.__z; if (!z || !z.alive) return;
        const pl = s.player;
        if (z.hp !== window.__lastHp) { window.__log.push({ who: 'player-hit', pf: fr(pl.sprite, pl.asset), zf: fr(z.sprite, z.asset), zpaused: z.sprite.anims.isPaused, ppaused: pl.sprite.anims.isPaused, tint: z.sprite.isTinted, off: +(z.sprite.x - z.foot().x).toFixed(2) }); window.__lastHp = z.hp; }
        if (s.hearts.value !== window.__lastH) { window.__log.push({ who: 'enemy-hit', zf: fr(z.sprite, z.asset), pf: fr(pl.sprite, pl.asset), zpaused: z.sprite.anims.isPaused, ppaused: pl.sprite.anims.isPaused, tint: pl.sprite.isTinted }); if (s.hearts.value < 2) s.hearts.value = 5; window.__lastH = s.hearts.value; }
      });
    }
    window.__lastHp = window.__z.hp; window.__lastH = s.hearts.value;
    s.pressEnemy(window.__z);
  }, [speed, kind]);
  await T.run(Math.round(8000 / D), D);
  return G(() => window.__log);
};
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  for (const kind of ['zombie', 'pirate_1']) for (const [D, sp] of [[1000 / 60, 1], [100, 1], [100, 3], [1000 / 60, 3]]) {
    const log = await runCase(T, G, D, sp, kind);
    const ph = log.filter((l) => l.who === 'player-hit'), eh = log.filter((l) => l.who === 'enemy-hit');
    const hitF = kind === 'zombie' ? ['attack', 'battack'] : ['attack', 'battack'];
    { const bad = ph.filter((l) => !(/dagger2$/.test(l.pf) && l.ppaused && l.tint)); ok(`${kind} D=${D.toFixed(1)} x${sp}: player hits show dagger2 frame, frozen, victim white`, ph.length >= 3 && !bad.length, ph.length + " " + J(bad)); }
    { const bad = eh.filter((l) => !(hitF.includes(l.zf) && l.zpaused && l.tint)); ok(`${kind} D=${D.toFixed(1)} x${sp}: enemy hits show the attack hit frame, frozen, player white`, eh.length >= 2 && !bad.length, eh.length + " " + J(bad)); }
  }
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
