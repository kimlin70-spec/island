# Phase 10 (움직임과 타격감 다듬기) design draft — stage 1 scope

The user uploaded a third bundle (motion assets) and asked to reflect it in the build. Bundle extracted at
/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/bundle_v4/island-survival (read its DEMO_SPEC.md chapter 12,
Phase 10 in chapter 9, 3.1 `anims`, 3.8 asset list; its assets/manifest.json `anims`; preview/preview_motion.gif and .png;
tools/reference_map.html `mode=motion`; tools/render_motion.py). It will be copied over the project's assets/, data/, preview/, tools/,
DEMO_SPEC.md, CLAUDE.md, README.md (game code kept). Only the character sheets changed (bigger, multi-row, new origins; old frame
names keep their numbers) and 10 effect sheets were added. Phase 10 rules: game rules (damage, times, numbers) unchanged; only what
is seen changes; where 3.5/5/11 differ in how things look, chapter 12 wins from Phase 10 on. Stage 2 (Phase 7-9: towers, gun,
gunner, iron mining) is NOT built yet; its parts of chapter 12 (gun/bgun, fx_smoke_puff, proj_arrow_stuck, iron hit particles)
are left for when those phases are built (Phase 10 text says so).

## Current code (read it): src/scenes/BootScene.js (makeAnimations: `${key}_walk` 6 fps, campfire burn), src/systems/Player.js
(swing: CONFIG.anim.toolRaise 0.2 s then strike, toolStrike 0.15 s, frames dagger1/2 etc., idle, `_walk`), src/systems/Enemy.js
(walk anim, walk1 standing, attack frame 0.3 s at the hit via attackLeft, shake ±3 px 0.1 s, fx_hit, flash 0.1 s, kill -> poof),
EnemySystem.js (spawn poof, kill/remove poof, clearAll poof), NodeSystem.js (tree/rock hits: shake 3 px 0.1 s, fx_hit, poof when
exhausted, popup), BuildSystem.js (commit: poof; destroy: poof; damage -> destroy at 0), Effects.js (run(life, step, done) on game
time, poof, hit, shake, flash, popup, bars), GameScene.js (hurtPlayer: flash; stopGame('down') at once; onMorning heal),
RestSystem.js (tent heal), PirateSystem.js (landing), config.js (fx, anim).

## Plan
1. BootScene: create every manifest `anims` entry as `key:name` (frames by name, per-frame duration, repeat -1 when loop).
   Drop the old `${key}_walk`; keep the campfire burn (no `anims` for it in the manifest).
2. New src/systems/Body.js, shared by Player and Enemy, owning the character sprite's animation state:
   - loop(base, dx, dy): idle/walk (walk while moving, idle while standing). Back view when dy < 0 and a `b` variant exists
     (player: bidle, bwalk; enemies: bwalk only, so a standing enemy is always front `idle`). flipX when dx < 0; keep the last flip
     when |dx| is tiny.
   - once(name, dx, dy): one-shot (dagger/axe/pick, attack, die, rise, down, blink) with the `b` variant when facing back and it exists;
     the loop resumes when it completes unless another state took over.
   - hurt(): pause the current animation, show the `hurt` frame for its manifest duration (player 0.22 s, enemies 0.2 s), then resume
     what was playing ("하던 애니메이션으로 돌아간다").
   - hitStop(sec): anims.pause() for 0.05 s of game time, then resume. Game logic keeps running.
   - knock(fromX, fromY): visual offset 6 px away from the attacker over 0.12 s (out and back), added in syncSprite.
   - step callback on step frames (walk1, walk2, bwalk1, bwalk2) via 'animationupdate' -> step dust / footprint.
   - blink (player only, front idle): every random 3-5 s, `blink` 0.12 s, back to idle.
   - Timers (hurt, hit stop, knockback, blink) run on game time (dt). Phaser animations run with anims.globalTimeScale = game speed
     (already set when the speed changes).
3. Player:
   - Swing logic stays on game time: hit time = sum of the manifest durations before the `hit` frame (dagger 0.14 s, axe/pick
     0.19 s); the swing ends when the animation ends (dagger 0.37 s, axe/pick 0.43 s); actionInterval 0.55 s unchanged (idle in the
     remaining time). The Phaser animation is started at the swing start (front/back from the screen direction to the target).
     CONFIG.anim.toolRaise/toolStrike (3.5's 0.2/0.15) are no longer used.
   - At the hit: strike (damage) as now, then hit feel (12.4): fx_impact at the hit point (character: foot - 40 px; tree/rock/structure:
     origin - 30 px, pulled 6 px toward the player), fx_swing trail (12.5: anim from the tool's `swing`, at the player's foot, same
     flip, depth player ± 0.5 front/back), hit stop 0.05 s on both, particles (12.6).
   - Hit by an enemy: hurt 0.22 s, white flash 0.06 s, knockback 6 px away from the attacker, camera shake (120 ms, 0.004).
   - Hearts reach 0: play `down`; 1 s (game time) later stopGame('down') (window). Taps are ignored during that second; further hits
     are already ignored.
4. Enemies (zombie, pirate_1, pirate_2):
   - walk/bwalk by the screen direction of the step; idle when standing.
   - Attack (player or structure): the damage moments stay on the existing game-time timers (first hit 1.5/1.0 s, then 2.0/1.6 s;
     structures 1.5/1.0 s). The attack animation (front/back by the direction to the target) is started when the timer is within the
     wind-up (zombie attack0 0.26 s, pirate attack0 0.22 s), so its `hit` frame shows exactly at the damage. Walking waits until the
     whole attack animation is over (wind-up + follow-through: zombie 0.48 s, pirate 0.47 s front / 0.38 s back) — this replaces
     Phase 5's "0.3 s attack frame, finish the swing before walking". Pirates' attacks also play fx_swing heavy/bheavy.
     If the target leaves during the wind-up, the swing plays out with no damage (the damage check is unchanged).
   - Struck by the player: hurt 0.2 s, flash 0.06 s, knockback 6 px, goo x3, fx_impact at foot - 40 px (replaces 3.5's shake/fx_hit).
   - Killed: leaves the enemy list at once (logic, defeated count, building, targeting as now); its sprite stays as a corpse that plays
     `die` (0.99 s, last frame held 0.7 s), then fades over 0.4 s with fx_vanish (zombie) or fx_dust (pirate).
   - Zombies that come out (night schedule and the test button): `rise` (3 x 0.26 s) + dirt x6 + dust x2 at the feet instead of fx_poof.
     While rising they do not move, re-plan or attack and cannot be tapped, struck or auto-attacked; their tile still counts as occupied.
     Pirates land without rise (5.12 decision: no effect), plus the 12.9 splash.
   - Morning clear-out keeps fx_poof (5.10/5.12; chapter 12 says nothing about it).
5. Trees/rocks (NodeSystem): each hit: tree shakes 3 px for 0.16 s; particles (tree: wood1/wood2 x3 + leaf x2, leaf3 for obj_tree_w1;
   rock: stone1/stone2 x3 + dust x1); fx_impact. Tree felled: the stump appears at once; a copy of the tree sprite falls away from
   the player (rotation about the foot origin to 80° over 0.5 s, ease-in like render_motion.py: angle·(t/T)^1.6), fades from 0.3 s to
   0.5 s; at the end fx_dust + leaves x8 (slow) 60 px along the fall. Rock broken: rubble at once + fx_dust + stone x6. (Replaces the
   poof.) Stump/rubble digging (user request, not in the spec): hits dirt x3; removed: fx_dust + dirt x4 (replaces the poof).
6. Structures (BuildSystem): built from the build mode: scale 0.8 -> 1.06 -> 1.0 over 0.25 s, fx_dust 0.6x, fx_sparkle, dust x4
   (replaces the poof). Destroyed by damage: wood x6 + fx_dust (replaces the poof). 치우기 (removal) keeps the poof. Hit by an enemy:
   fx_impact at origin - 30 px.
7. Campfire at night: one ember every 0.3 s per campfire at the flame (angle 255-285, speed 30-60, gravityY -15, lifespan 1200).
8. Hearts going up (tent heal tick, morning +2): heart x2 rising slowly, at the player (or the tent door while resting).
9. Walking (12.9): on each step frame, fx_dust 0.4x 8 px behind the foot (opposite the walking direction); on sand (terrain 1) also
   fx_footprint at depth 2 (lives 3 s, fades 1 s, at most 20 at a time, flipX when walking left). Applied to every walker
   (player, zombies, pirates).
10. Pirate landing: fx_splash 30 px from the landing tile toward the ship.
11. Effects.js grows: play(key, anim, x, y, opts) (one-shot sprite destroyed on animationcomplete), impact, dust, sparkle, vanish,
    splash, swing trail, burst(names, n, x, y, profile) with a few reusable Phaser particle emitters (profiles: chips, leaves, hearts,
    embers; count = max(1, round(n x config.fx.particleCount)); emitter timeScale follows the game speed), footprint, flash(time),
    shake(px, time), fall, pop. All timers on game time; everything pauses with the windows (scene.pause).
12. config.fx gets 12.10's numbers plus the few needed here (downDelay 1, dieFade 0.4, impact heights 40/30, step back 8, splash 30,
    ember interval 0.3, fall ease 1.6 and dust distance 60, footprint fade 1). Unused old ones (toolRaise, toolStrike, attackTime,
    hitTime, shakePx/shakeTime for characters) are removed.
13. Tests: new Phase 10 tests (fixed-step) for each 12.x item; old tests that check the old looks (3.5 swing frames and 0.2 s strike,
    zombie walk1 standing, 0.3 s attack frame, 0.1 s flash, poof on spawn/kill/build/exhaust) are updated to the chapter-12 looks.

## Open questions
Q1. Damage on game-time timers derived from the manifest durations (animations only visual, started together), versus damage fired
    by Phaser 'animationstart'/'animationupdate' events as in the spec's sample code. (Timers keep rules on game time with the 0.1 s
    frame cap, the x3/x4 speeds and pauses; animations may drift by a frame on very slow devices.)
Q2. Attack animation started so its hit frame lands on the existing damage moment, and no walking during the whole animation. OK?
Q3. Hurt = pause current animation, show hurt for its duration, resume. During an enemy's wind-up this delays the visual hit frame by
    up to 0.2 s (damage still on time). Acceptable, or should hurt not interrupt an attack wind-up?
Q4. Killed enemies leave the logic at once and a separate corpse sprite plays die + fade + vanish/dust. OK?
Q5. Rising zombies: untargetable/immobile 0.78 s but occupying their tile. OK? Do they count for the tent's "enemy within 6 tiles"?
Q6. Step dust and footprints for every walker, or the player only?
Q7. Keep fx_poof for the morning clear-out and for 치우기; dust/dirt for stump/rubble digging. OK?
Q8. Hearts particles position (player, or tent door while resting). OK?
Q9. The player's 1 s `down` before the window: the world keeps running (enemies move, effects play) but taps are ignored. OK?
Q10. Tap area: the spec's "picture rectangle + 12 px" now uses the much wider new frames (zombie frame 139 px wide vs 69 before).
     Keep as the spec says, or shrink to the visible body?
Q11. Anything in chapter 12 for stage-1 content that this plan misses or gets wrong; anything that would hurt tablet performance.
