#!/bin/bash
# Phase 10 뒤의 모든 시험: Phase 10 시험, 검토 뒤 시험, 새 묶음 확인, Phase 2~6 시험(12장 모습에 맞게 고친 것), 무작위 시험
S=/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad
$S/fix3/run_regress.sh p15/t1.js p15/t2.js p9/t1.js p9/t2.js p7/t1.js p7/t2.js p7/t3.js p7/t4.js p8/t1.js p8/t2.js p10/t/smoke.js p10/t/hitframe.js p10/t/features.js p10/t/features2.js p10/t/features3.js p10/t/walkoff.js p10/t/trail.js p10/t/review_fixes.js p10/t/rules_fixes.js p6b/b1.js p6/t1.js p6/t2.js p6/t3.js p6/t4.js p6/t5.js p6/t6.js p5/t1.js p5/t2.js p5/t3.js p5/t4.js p5/t5.js p5/t6.js p2/t1.js p2/t2.js p2/t3.js p3/t1.js p3/t2.js p3/t3.js p4/t1.js p4/t2.js p4/t3.js p4/t4.js p4/t5.js p4/t6.js p4/t7.js p4/t8.js
echo "== pfuzz"
$S/p10/fuzz/run_fuzz.sh
echo ALLDONE
