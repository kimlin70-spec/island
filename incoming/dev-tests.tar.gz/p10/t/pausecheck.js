const { setup, checker, J } = require('../../p6/lib6.js');
(async () => {
  const T = await setup({ w: 640, h: 400 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const r = await G(() => { const s = window.__game.scene.getScene('game');
    const sp = s.add.sprite(0, 0, 'char_zombie'); sp.play('char_zombie:walk'); sp.anims.pause();
    const a = sp.anims.isPaused; sp.play('char_zombie:die'); const b = sp.anims.isPaused; const c = sp.anims.isPlaying;
    sp.destroy(); return { pausedBefore: a, pausedAfterPlay: b, playing: c }; });
  console.log(J(r));
  await T.browser.close();
})();
