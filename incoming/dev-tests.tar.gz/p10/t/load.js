// 효과가 얼마나 많이 생기는가: 14마리 밤 + 해적, 주인공은 가만히 싸운다(맞아도 안 다침). 60Hz 고정 간격.
const { setup, J } = require('../../p6/lib6.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); s.clock.day = 6; s.debugNight(); s.hurtPlayer = () => false;
    window.__made = 0; window.__peak = { children: 0, sprites: 0, particles: 0, running: 0 }; window.__sum = { children: 0, n: 0, ms: 0 };
    const add = s.add.sprite.bind(s.add); s.add.sprite = (...a) => { window.__made++; return add(...a); };
    const addI = s.add.image.bind(s.add); s.add.image = (...a) => { window.__made++; return addI(...a); };
    s.events.on('postupdate', () => { const ch = s.children.list.length; let parts = 0; for (const em of s.effects.emitters.values()) parts += em.getAliveParticleCount();
      const fx = s.children.list.filter((o) => o.texture && /^fx_/.test(o.texture.key) && o.type !== 'ParticleEmitter').length;
      const P = window.__peak; P.children = Math.max(P.children, ch); P.sprites = Math.max(P.sprites, fx); P.particles = Math.max(P.particles, parts); P.running = Math.max(P.running, s.effects.running.length);
      window.__sum.children += fx; window.__sum.n++; }); });
  const t0 = Date.now();
  await T.run(60 * 60);
  const ms = Date.now() - t0;
  const r = await G(() => ({ made: window.__made, peak: window.__peak, avgFx: +(window.__sum.children / window.__sum.n).toFixed(1), enemies: window.__game.scene.getScene('game').enemies.list.length,
    defeated: window.__game.scene.getScene('game').enemies.defeated }));
  console.log(J({ ...r, perSecond: +(r.made / 60).toFixed(1), wallMsPerFrame: +(ms / 3600).toFixed(2) }));
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
