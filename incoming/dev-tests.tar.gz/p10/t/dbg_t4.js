const { setup } = require('../../p5/lib5.js'); const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, W } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); s.tools.push('axe');
    const tree = s.map.objects.filter((o) => o.node && o.node.group === 'tree').sort((a, b) => Math.hypot(a.col - 37, a.row - 39) - Math.hypot(b.col - 37, b.row - 39))[0];
    s.pressNode(tree); s.tools.pop(); window.__hits = [];
    const orig = s.hurtPlayer.bind(s); s.hurtPlayer = (n) => { window.__hits.push(+s.elapsed.toFixed(2)); orig(n); }; });
  await W(() => { const p = window.__game.scene.getScene('game').player; return p.action && !p.moving && p.swing; }, null, 60000);
  await G(() => { const s = window.__game.scene.getScene('game'); s.hearts.value = 1; const p = s.player;
    s.enemies.spawnPoint = () => ({ col: p.tile.col + 1, row: p.tile.row - 1 }); s.debugZombie(); });
  for (let i = 0; i < 12; i++) {
    await new Promise((r) => setTimeout(r, 1500));
    console.log(J(await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, z = s.enemies.list[0];
      return { el: +s.elapsed.toFixed(2), active: window.__game.scene.isActive('game'), hearts: s.hearts.value, downed: p.downed, downLeft: p.downLeft, hits: window.__hits,
        z: z ? { at: [z.col, z.row], tile: [z.tile.col, z.tile.row], rising: z.rising, hitLeft: z.hitLeft, act: z.body.act && z.body.act.name + '@' + z.body.act.t.toFixed(2) + (z.body.act.struck ? 'S' : ''), path: z.path.length } : null,
        p: [p.tile.col, p.tile.row], swing: !!p.swing }; })));
  }
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
