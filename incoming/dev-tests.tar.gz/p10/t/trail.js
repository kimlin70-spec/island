// 휘두른 궤적의 자리와 깊이(앞모습: 캐릭터 +0.5, 뒷모습: -0.5, 같은 좌우), 맞은 곳(기준점 30px 위를 주인공 쪽으로 6px)
const { setup, checker, J } = require('../../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const r = await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.tools.push('axe');
    window.__log = []; const p = s.player;
    const fxp = s.effects.play.bind(s.effects);
    s.effects.play = (key, x, y, o = {}) => { const sp = fxp(key, x, y, o); window.__log.push({ key, x: +x.toFixed(1), y: +y.toFixed(1), depth: sp ? +sp.depth.toFixed(2) : null, flip: sp ? sp.flipX : null,
      pd: +p.sprite.depth.toFixed(2), pf: p.sprite.flipX, back: p.body.back, px: +p.sprite.x.toFixed(1), py: +p.sprite.y.toFixed(1) }); return sp; };
    // 위쪽(뒷모습)에 있는 나무와 아래쪽(앞모습)에 있는 나무
    const trees = s.map.objects.filter((o) => o.kind === 'tree' && o.node).sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
    window.__trees = trees.slice(0, 6).map((t) => [t.col, t.row]);
    s.pressNode(trees[0]); window.__t = trees[0]; return window.__trees; });
  await T.until('return window.__log.some((l) => l.key === "fx_swing")', 2000);
  const log = await G(() => window.__log.slice());
  const sw = log.find((l) => l.key === 'fx_swing'), im = log.find((l) => l.key === 'fx_impact');
  const t = await G(() => { const o = window.__t; return { x: (o.col - o.row) * 40, y: (o.col + o.row) * 20 }; });
  ok('swing trail at the player foot, same flip, depth +0.5 front / -0.5 back', sw && sw.x === sw.px && sw.y === sw.py && sw.flip === sw.pf && Math.abs(sw.depth - (sw.pd + (sw.back ? -0.5 : 0.5))) < 1e-6, J(sw));
  const ix = t.x, iy = t.y - 30, L = Math.hypot(sw.px - ix, sw.py - iy);
  const ex = ix + (sw.px - ix) / L * 6, ey = iy + (sw.py - iy) / L * 6;
  ok('impact at the tree origin - 30 px, pulled 6 px toward the player', im && Math.abs(im.x - ex) < 0.2 && Math.abs(im.y - ey) < 0.2, J({ im, ex: +ex.toFixed(1), ey: +ey.toFixed(1) }));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
