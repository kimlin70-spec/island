// 사용자에게 보여 줄 화면: 도끼로 나무를 베는 순간(궤적, 조각, 맞은 곳), 밤에 좀비와 싸우는 순간
const { setup, J } = require('../../p6/lib6.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.sleep(); await T.run(2);
  // 1) 도끼로 나무 베기: 두 번째 내려치는 프레임에서 찍는다
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.tools.push('axe');
    const p = s.player; const trees = s.map.objects.filter((o) => o.kind === 'tree' && o.node);
    trees.sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
    window.__tree = trees[0]; window.__hits = 0; const oh = s.nodes.hit.bind(s.nodes); s.nodes.hit = (o, t) => { window.__hits++; return oh(o, t); };
    s.pressNode(trees[0]); });
  await T.until('return window.__hits >= 2', 2000);
  await T.run(3);
  await page.screenshot({ path: __dirname + '/../shot_chop.png' });
  // 다 베는 순간 + 0.2초(넘어가는 나무)
  await G(() => { window.__tree.node.hp = 1; });
  await T.until('return window.__tree.kind === "stump"', 2000);
  await T.run(14);
  await page.screenshot({ path: __dirname + '/../shot_fall.png' });
  // 2) 밤: 좀비 셋이 다가와 싸운다. 하나를 칠 때 찍는다.
  await G(() => { const s = window.__game.scene.getScene('game'); s.debugNight(); s.enemies.schedule = []; const p = s.player.tile;
    const spots = [[p.col + 3, p.row - 1], [p.col - 2, p.row + 3], [p.col + 2, p.row + 3]];
    for (const [c, r] of spots) if (s.map.isWalkable(c, r)) { s.enemies.spawnPoint = () => ({ col: c, row: r }); s.debugZombie(); }
    window.__zh = 0; s.hurtPlayer = () => false; const E = s.enemies;
    for (const e of E.list) { const oh = e.hurt.bind(e); e.hurt = (n, f) => { window.__zh++; return oh(n, f); }; } });
  await T.until('return window.__zh >= 2', 3000);
  await T.run(2);
  await page.screenshot({ path: __dirname + '/../shot_fight.png' });
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
