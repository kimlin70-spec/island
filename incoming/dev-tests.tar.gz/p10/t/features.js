// Phase 10 기능 확인(고정 간격 60Hz): 쓰러짐, 올라오기, 나무 넘어감, 돌 부서짐, 짓기, 부서짐, 불티, 하트, 주인공 쓰러짐, 발자국
const { setup, checker, J } = require('../../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.schedule = []; window.__S2 = s; });
  const fxCount = () => G(() => { const s = window.__S2, out = {};
    for (const o of s.children.list) { const k = o.texture && o.texture.key; if (k && /^fx_/.test(k)) out[k] = (out[k] || 0) + 1; }
    let parts = 0; for (const em of s.effects.emitters.values()) parts += em.getAliveParticleCount();
    out.particles = parts; out.running = s.effects.running.length; return out; });

  // 1) 좀비를 쓰러뜨리기: 바로 목록에서 빠지고 die -> 흐려짐 -> fx_vanish -> 없어짐
  let st = await G(() => { const s = window.__S2, p = s.player.tile, E = s.enemies;
    const z = window.__z = E.add('zombie', { col: p.col + 1, row: p.row }); z.hp = 1;
    window.__corpse = null; window.__cl = [];
    const old = E.kill.bind(E); E.kill = (e, dx, dy) => { window.__corpse = e.sprite; window.__killT = s.elapsed; window.__base = { x: e.foot().x, y: e.foot().y }; old(e, dx, dy); };
    s.events.on('postupdate', () => { const c = window.__corpse; if (!c) return;
      window.__cl.push({ t: +(s.elapsed - window.__killT).toFixed(3), active: c.active, anim: c.active && c.anims.currentAnim ? c.anims.currentAnim.key : null, a: c.active ? +c.alpha.toFixed(2) : null,
        dx: c.active ? +(c.x - window.__base.x).toFixed(2) : null, vanish: s.children.list.filter((o) => o.texture && o.texture.key === 'fx_vanish').length }); });
    s.pressEnemy(z); return null; });
  await T.until('return !window.__z.alive', 600);
  st = await G(() => { const s = window.__S2; return { inList: s.enemies.list.includes(window.__z), defeated: s.enemies.defeated, active: window.__corpse.active, anim: window.__corpse.anims.currentAnim.key }; });
  ok('1a) killed zombie leaves the list at once, its sprite plays die', !st.inList && st.defeated === 1 && st.active && st.anim === 'char_zombie:die', J(st));
  await T.run(60 * 2);
  const cl = await G(() => window.__cl);
  const fadeStart = cl.find((r) => r.a !== null && r.a < 1), vanish = cl.find((r) => r.vanish > 0), gone = cl.find((r) => !r.active);
  const pushed = cl.find((r) => r.t >= 0.15);
  ok('1b) corpse pushed 6 px away from the player and stays there', pushed && Math.abs(pushed.dx) > 4 && Math.abs(pushed.dx) <= 6.01, J(pushed));
  ok('1c) fade starts ~0.99 s, vanish smoke with it, gone at ~1.39 s', fadeStart && fadeStart.t >= 0.98 && fadeStart.t <= 1.03 && vanish && Math.abs(vanish.t - fadeStart.t) < 0.03 && gone && gone.t >= 1.38 && gone.t <= 1.43, J([fadeStart, vanish, gone]));

  // 2) 올라오기: 시험용 좀비 -> rise 0.78초, 그동안 맞지 않고 자동 공격 대상도 아니다
  st = await G(() => { const s = window.__S2, E = s.enemies, p = s.player.tile;
    E.spawnPoint = () => ({ col: p.col + 1, row: p.row + 1 });
    s.debugZombie(); const z = window.__r = E.list[E.list.length - 1]; window.__riseT = s.elapsed;
    window.__parts0 = 0; for (const [id, em] of s.effects.emitters) if (/dirt|dust/.test(id)) window.__parts0 += em.getAliveParticleCount();
    return { rising: z.rising, anim: z.sprite.anims.currentAnim.key, auto: !!E.nextTo(s.player.tile), dirt: window.__parts0 }; });
  ok('2a) a spawned zombie rises (rise anim, dirt and dust), not auto-attacked', st.rising && st.anim === 'char_zombie:rise' && !st.auto && st.dirt >= 8, J(st));
  await T.run(20);
  st = await G(() => { const s = window.__S2, z = window.__r; s.pressEnemy(z); return { act: !!s.player.action }; });
  await T.run(20);
  st = await G(() => { const s = window.__S2, z = window.__r; return { hp: z.hp, rising: z.rising, swing: !!s.player.swing, moving: z.moving, t: +(s.elapsed - window.__riseT).toFixed(3) }; });
  ok('2b) while rising: player waits (no swing), zombie does not move, no damage', st.hp === 3 && st.rising && !st.swing && !st.moving, J(st));
  const r2 = await T.until('return !window.__r.rising', 100);
  const riseT = await G(() => window.__riseT);
  ok('2c) rise lasts 0.78 s of game time (+1 frame for until)', (r2.t - riseT) - 1 / 60 >= 0.779 && (r2.t - riseT) - 1 / 60 < 0.78 + 1 / 60, J({ r2, riseT, d: +(r2.t - riseT).toFixed(4) }));
  await T.until('return !window.__r.alive', 600);
  ok('2d) after rising it can be fought and killed', await G(() => !window.__r.alive), '');
  await T.run(60 * 2);

  // 3) 나무 넘어가기(도끼): 그루터기 바로, 넘어가는 그림 0.5초, 0.38초에 먼지
  st = await G(() => { const s = window.__S2, p = s.player;
    s.tools.push('axe');
    const trees = s.map.objects.filter((o) => o.kind === 'tree' && o.node);
    trees.sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
    const o = window.__tree = trees[0]; o.node.hp = 1;
    window.__fallLog = [];
    const key = o.key;
    s.events.on('postupdate', () => { const imgs = s.children.list.filter((c) => c.type === 'Image' && c.texture.key === key && c !== o.sprite && c.rotation !== 0);
      if (imgs.length || window.__fallLog.length) window.__fallLog.push({ t: +s.elapsed.toFixed(3), n: imgs.length, rot: imgs[0] ? +(imgs[0].rotation * 180 / Math.PI).toFixed(1) : null, a: imgs[0] ? +imgs[0].alpha.toFixed(2) : null,
        dust: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_dust' && c.scaleX === 1).length, kind: o.kind }); });
    s.pressNode(o); return { at: [o.col, o.row], key }; });
  await T.until('return window.__tree.kind === "stump"', 1200);
  await T.run(60);
  const fl = await G(() => window.__fallLog);
  const f0 = fl[0], fEnd = fl.find((r) => r.n === 0), fd = fl.find((r) => r.dust > 0);
  ok('3a) felled tree: stump at once and a falling copy that turns to ~80 deg', f0 && f0.kind === 'stump' && fl.some((r) => r.rot && Math.abs(r.rot) > 70), J(fl.filter((r, i) => i % 4 === 0).slice(0, 9)));
  ok('3b) the falling copy is gone after ~0.5 s; dust at ~0.38 s', fEnd && fEnd.t - f0.t <= 0.52 && fd && fd.t - f0.t >= 0.34 && fd.t - f0.t <= 0.42, J([f0, fd, fEnd]));

  // 4) 짓기: 크기 0.8 -> 1.06 -> 1.0, 반짝임, 먼지
  st = await G(() => { const s = window.__S2, p = s.player.tile;
    s.inventory.add('wood', 20); s.inventory.add('stone', 20);
    let spot = null;
    for (let d = 2; d < 5 && !spot; d++) for (const [dc, dr] of [[d, 0], [0, d], [-d, 0], [0, -d]]) if (!spot && s.build.canBuildAt(p.col + dc, p.row + dr)) spot = { col: p.col + dc, row: p.row + dr };
    s.build.setMode('fence'); const w = { x: (spot.col - spot.row) * 40, y: (spot.col + spot.row) * 20 };
    s.pressing = true; s.build.commit(w.x, w.y);
    const f = window.__fence = s.map.structureAt(spot.col, spot.row);
    window.__popLog = [];
    s.events.on('postupdate', () => { if (window.__popLog.length < 30) window.__popLog.push(+window.__fence.sprite.scaleX.toFixed(3)); });
    s.build.setMode(null);
    return { spot, scale: f.sprite.scaleX, sparkle: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_sparkle').length, poof: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_poof').length }; });
  await T.run(30);
  const pl = await G(() => window.__popLog);
  ok('4) building pops 0.8 -> ~1.06 -> 1.0 with sparkle, no poof', st.scale === 0.8 && Math.max(...pl) >= 1.05 && Math.max(...pl) <= 1.061 && pl[pl.length - 1] === 1 && st.sparkle === 1 && st.poof === 0, J({ st, pl }));

  // 5) 적이 울타리를 부순다: poof 없이 조각과 먼지
  st = await G(() => { const s = window.__S2, f = window.__fence, E = s.enemies;
    f.hp = 1; s.player.stopAction();
    const z = window.__smasher = E.add('pirate_1', { col: f.col + 1, row: f.row });
    z.hp = 99; z.path = [{ col: f.col, row: f.row }]; z.wantPath = false; z.repathLeft = 99;
    s.hurtPlayer = () => false;
    window.__brk = null;
    s.events.on('postupdate', () => { if (!window.__brk && !s.map.structures.includes(f)) window.__brk = { poof: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_poof').length,
      dust: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_dust').length, impact: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_impact').length,
      swing: s.children.list.filter((c) => c.texture && c.texture.key === 'fx_swing').length, zf: z.asset.frames[+z.sprite.frame.name] }; });
    return null; });
  await T.until('return !!window.__brk', 300);
  st = await G(() => window.__brk);
  ok('5) pirate smashes the fence: impact, swing trail, dust, no poof; hit frame shown', st && st.poof === 0 && st.dust >= 1 && st.impact >= 1 && st.swing === 1 && /attack$/.test(st.zf), J(st));
  await G(() => { const s = window.__S2; s.enemies.remove(window.__smasher); });

  // 6) 밤의 모닥불 불티
  st = await G(() => { const s = window.__S2, p = s.player.tile;
    let spot = null;
    for (let d = 2; d < 6 && !spot; d++) for (const [dc, dr] of [[d, 1], [1, d], [-d, 1], [1, -d]]) if (!spot && s.build.canBuildAt(p.col + dc, p.row + dr)) spot = { col: p.col + dc, row: p.row + dr };
    s.build.place('campfire', [spot]); s.debugNight(); return spot; });
  await T.run(60);
  st = await G(() => { const s = window.__S2; let n = 0; for (const [id, em] of s.effects.emitters) if (id.startsWith('ember')) n += em.getAliveParticleCount(); return { n, night: s.clock.isNight }; });
  ok('6) embers rise from the campfire at night (about 1 per 0.3 s, live 1.2 s)', st.night && st.n >= 3 && st.n <= 5, J(st));

  // 7) 아침에 하트가 차면 하트 조각
  st = await G(() => { const s = window.__S2; s.hearts.value = 2; s.debugMorning(); let n = 0; for (const [id, em] of s.effects.emitters) if (id.startsWith('hearts')) n += em.getAliveParticleCount(); return { n, hearts: s.hearts.value }; });
  ok('7) morning heal shows rising hearts', st.n === 2 && st.hearts === 4, J(st));
  await T.run(60 * 4);
  await G(() => { const s = window.__S2; if (s.resultPending) { s.resultPending = false; } if (!window.__game.scene.isActive('game')) s.resumeGame(); });

  // 8) 주인공 쓰러짐: down 을 1초 보여 준 뒤 창. 그동안 누르기 무시.
  st = await G(() => { const s = window.__S2, p = s.player.tile;
    delete s.hurtPlayer; s.hearts.value = 1; s.player.stopAction();
    window.__downAt = null; s.events.once('down', () => { window.__downAt = s.elapsed; });
    const z = window.__killer = s.enemies.add('zombie', { col: p.col - 1, row: p.row }); z.hp = 99; z.hitLeft = 0.3;
    return null; });
  await T.until('return window.__S2.player.downed', 200);
  st = await G(() => { const s = window.__S2; window.__downT = s.elapsed; const t = s.player.tile; s.onPress({ wasTouch: true, worldX: (t.col + 3 - t.row) * 40, worldY: (t.col + 3 + t.row) * 20 }); return { f: s.player.asset.frames[+s.player.sprite.frame.name], hearts: s.hearts.value, moving: s.player.moving, active: window.__game.scene.isActive('game') }; });
  ok('8a) at 0 hearts the player shows down, taps ignored, game still runs', st.f === 'down' && st.hearts === 0 && !st.moving && st.active, J(st));
  await T.until('return !window.__game.scene.isActive("game")', 200);
  st = await G(() => ({ wait: +(window.__downAt - window.__downT).toFixed(3), f: window.__S2.player.asset.frames[+window.__S2.player.sprite.frame.name] }));
  ok('8b) the down window opens ~1 s later, still showing down', Math.abs(st.wait - 1) < 0.03 && st.f === 'down', J(st));

  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
