const { setup, J } = require('../../p6/lib6.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.schedule = [];
    const p = s.player; p.col = 35; p.row = 45; p.tile = { col: 35, row: 45 }; p.path = []; p.syncSprite();
    s.cameras.main.centerOn(p.sprite.x, p.sprite.y);
    s.debugNight(); s.enemies.schedule = []; s.clock.t = 0.35 * 150 + 1.8; s.pirates.shipDue = false; s.pirates.ship.setVisible(true).setAlpha(1);
    s.clock.t = 0.45 * 150 - 0.02; });
  await T.run(8);
  await page.screenshot({ path: __dirname + '/../shot_pirates.png' });
  console.log('errors', J(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
