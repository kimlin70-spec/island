// Phase 10 첫 확인: 콘솔 오류 없이 뜨는가, 애니메이션이 다 만들어졌는가, 걷기/서기/깜빡임/때리기가 도는가
const { setup, checker, J } = require('../../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const a = await G(() => { const g = window.__game, m = g.cache.json.get('manifest').assets; const out = []; let n = 0;
    for (const [k, v] of Object.entries(m)) for (const [name, an] of Object.entries(v.anims || {})) { n++;
      const A = g.anims.get(k + ':' + name); if (!A) { out.push('missing ' + k + ':' + name); continue; }
      A.frames.forEach((f, i) => { if (+f.textureFrame < 0 || +f.textureFrame !== v.frames.indexOf(an.frames[i][0])) out.push(k + ':' + name + ' frame ' + i); }); }
    return { n, out }; });
  ok('all manifest anims made with right frames', a.out.length === 0 && a.n >= 50, J(a));
  let st = await G(() => { const s = window.__game.scene.getScene('game'); return { anim: s.player.sprite.anims.currentAnim && s.player.sprite.anims.currentAnim.key, frame: s.player.asset.frames[+s.player.sprite.frame.name] }; });
  ok('player starts on idle', st.anim === 'char_player:idle', J(st));
  // 위쪽(뒷모습)으로 걷기: (col-1,row-1) 방향 = 화면 위
  const p0 = await G(() => { const s = window.__game.scene.getScene('game'); return [s.player.tile.col, s.player.tile.row]; });
  await G(([c, r]) => window.__game.scene.getScene('game').walkTo(c - 3, r - 3), p0);
  await T.run(10);
  st = await G(() => { const s = window.__game.scene.getScene('game'); return { anim: s.player.sprite.anims.currentAnim.key, back: s.player.body.back, moving: s.player.moving }; });
  ok('walking up shows bwalk', st.anim === 'char_player:bwalk' && st.back, J(st));
  await T.run(120);
  st = await G(() => { const s = window.__game.scene.getScene('game'); return { anim: s.player.sprite.anims.currentAnim.key, moving: s.player.moving }; });
  ok('standing after walking up shows bidle', st.anim === 'char_player:bidle' && !st.moving, J(st));
  await G(([c, r]) => window.__game.scene.getScene('game').walkTo(c, r), p0);
  await T.run(150);
  st = await G(() => { const s = window.__game.scene.getScene('game'); return { anim: s.player.sprite.anims.currentAnim.key, moving: s.player.moving }; });
  ok('standing after walking down shows idle', st.anim === 'char_player:idle', J(st));
  // 깜빡임: 6초 서 있으면 한 번은 blink
  await G(() => { const s = window.__game.scene.getScene('game'); window.__blinks = 0; s.player.sprite.on('animationstart', (an) => { if (an.key === 'char_player:blink') window.__blinks++; }); });
  await T.run(60 * 6);
  ok('blinks while standing', await G(() => window.__blinks) >= 1, String(await G(() => window.__blinks)));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
