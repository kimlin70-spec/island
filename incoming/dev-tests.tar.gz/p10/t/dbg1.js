const { setup, checker, J } = require('../../p6/lib6.js');
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const D = +process.argv[2] || 1000 / 60, sp = +process.argv[3] || 1;
  await G(([sp]) => {
    const s = window.__game.scene.getScene('game'), E = s.enemies;
    E.schedule = []; s.debugSpeed = sp;
    const p = s.player.tile;
    const z = window.__z = E.add('zombie', { col: p.col + 1, row: p.row }); z.hp = 99;
    window.__rows = [];
    let lastHp = z.hp, lastH = s.hearts.value;
    s.events.on('postupdate', () => {
      const b = z.body, pb = s.player.body;
      const row = { f: s.frame, hitLeft: z.hitLeft === null ? null : +z.hitLeft.toFixed(3), act: b.act ? b.act.name + '@' + b.act.t.toFixed(3) : null, hurt: +b.hurtLeft.toFixed(3), frz: +b.freezeLeft.toFixed(3),
        zf: z.asset.frames[+z.sprite.frame.name], pact: pb.act ? pb.act.name + '@' + pb.act.t.toFixed(3) : null, pf: s.player.asset.frames[+s.player.sprite.frame.name], ev: [] };
      if (z.hp !== lastHp) { row.ev.push('P-HIT'); lastHp = z.hp; }
      if (s.hearts.value !== lastH) { row.ev.push('Z-HIT'); lastH = s.hearts.value; if (s.hearts.value < 2) s.hearts.value = 5; }
      window.__rows.push(row);
    });
    s.pressEnemy(z);
  }, [sp]);
  await T.run(Math.round(9000 / D), D);
  const rows = await G(() => window.__rows);
  const bad = rows.findIndex((r) => r.ev.includes('Z-HIT') && !/attack$/.test(r.zf));
  const bad2 = rows.findIndex((r) => r.ev.includes('P-HIT') && !/dagger2$/.test(r.pf));
  console.log('bad Z', bad, 'bad P', bad2);
  for (const b of [bad, bad2]) if (b >= 0) for (const r of rows.slice(Math.max(0, b - 22), b + 2)) console.log(J(r));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
