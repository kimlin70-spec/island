// Page-side fuzz for Phase 6: zombies + pirates, structures, taps, tent, nights/mornings at random moments.
// Installed as window.__pf. The game loop is asleep; GameScene is stepped by hand (same update code), queued scene ops
// are applied the way SceneManager.update does, and invariants are checked after every frame.
// Based on fix5/zfuzz_page.js. Differences: every enemy is tagged through EnemySystem.add (pirates land through it),
// all timing checks use the enemy's own cfg, walk speed is checked, and the ship/boat/lamp/landing state is checked
// against a model built from the spec decisions.
(() => {
  const g = window.__game, s = g.scene.getScene('game'), ui = g.scene.getScene('ui');
  const m = s.map, p = s.player, b = s.build, E = s.enemies, P = s.pirates, CFG = window.__CFG;
  const K = (t) => t.col + ',' + t.row;
  const W = (c, r) => m.isWalkable(c, r);
  const cheb = (a, z) => Math.max(Math.abs(a.col - z.col), Math.abs(a.row - z.row));
  const RUNNING = 5;   // Phaser.Scenes.RUNNING
  const LAND = s.mapData.pirates.landing;

  const pf = { seed: 0, frame: 0, time: 0, gt: 0, now: 0, log: [], fails: [], stats: {}, perKind: {}, zid: 0, kills: 0,
               pendingHits: [], pendingSmash: [], lastHearts: s.hearts.value, maxDtSinceMorning: 0, debugCall: false, natural: true,
               nights: [], curNight: null };
  window.__pf = pf;
  const stat = (k, n = 1) => { pf.stats[k] = (pf.stats[k] || 0) + n; };

  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const ri = (n) => Math.floor(pf.rnd() * n);
  const pick = (arr) => arr[ri(arr.length)];
  const U = (a, z) => a + pf.rnd() * (z - a);

  const zs = (e) => `${e.kind === 'zombie' ? 'z' : 'P'}${e.__id}@${+e.col.toFixed(3)},${+e.row.toFixed(3)} t${K(e.tile)} p[${e.path.slice(0, 5).map(K).join(' ')}${e.path.length > 5 ? ' …' + e.path.length : ''}]` +
    `${e.smashing ? ' smash:' + e.smashing.type + '@' + K(e.smashing) : ''}${e.hitLeft !== null ? ' hit:' + e.hitLeft.toFixed(2) : ''} want:${e.wantPath ? 1 : 0} rl:${e.repathLeft.toFixed(2)} hp:${e.hp} gk:${e.goalKind} atk:${e.attackLeft.toFixed(2)}`;
  const ps = () => `${+p.col.toFixed(3)},${+p.row.toFixed(3)} t${K(p.tile)} here${K(p.here())} path[${p.path.map(K).join(' ')}] act:${p.action ? (p.action.chase ? 'enemy ' + p.action.target.__id : (p.action.target.kind || p.action.target.type || '?')) : '-'} swing:${p.swing ? p.swing.t.toFixed(2) : '-'} cd:${p.cooldown.toFixed(2)} chaseLeft:${p.chaseLeft.toFixed(2)} rest:${s.rest.resting}`;
  const shipS = () => `ship a${P.ship.alpha.toFixed(4)} v${P.ship.visible ? 1 : 0} f${P.ship.fade ? P.ship.fade.to : '-'} | boat a${P.boat.alpha.toFixed(4)} v${P.boat.visible ? 1 : 0} f${P.boat.fade ? P.boat.fade.to : '-'} | due ${P.shipDue ? 1 : 0}${P.landDue ? 1 : 0}`;
  const snap = () => ({
    gt: +pf.gt.toFixed(3), day: s.clock.day, night: s.clock.isNight, t: +s.clock.t.toFixed(3), hearts: s.hearts.value, speed: s.speed,
    p: ps(), z: E.list.map(zs), st: m.structures.map((x) => x.type[0] + K(x) + ':' + x.hp).join(' '), ship: shipS(),
  });
  const L = (what) => { pf.log.push({ f: pf.frame, gt: +pf.gt.toFixed(3), t: +s.clock.t.toFixed(3), what }); if (pf.log.length > 800) pf.log.shift(); };
  const fail = (kind, info) => {
    pf.perKind[kind] = (pf.perKind[kind] || 0) + 1;
    stat('FAIL:' + kind);
    if (pf.perKind[kind] <= 3) pf.fails.push({ kind, info, frame: pf.frame, seed: pf.seed, st: snap(), recent: pf.log.slice(-80) });
  };

  // ── enemy ids and bookkeeping (every enemy comes through EnemySystem.add) ──
  const meta = new Map();
  const tag = (e) => {
    if (e.__id === undefined) {
      e.__id = ++pf.zid;
      meta.set(e, { still: 0, lastPos: [e.col, e.row], reported: false, run: null, hitsInRun: 0, smashObj: null, smashAcc: 0, smashHits: 0 });
    }
    return e;
  };
  const origAdd = E.add.bind(E);
  E.add = function (kind, t) {
    const e = origAdd(kind, t);
    tag(e);
    const cfgWant = kind === 'zombie' ? CFG.zombie : CFG.pirate;
    if (e.cfg !== cfgWant) fail('wrong-cfg', { kind });
    if (e.hp !== cfgWant.hp || e.maxHp !== cfgWant.hp) fail('wrong-hp', { kind, hp: e.hp });
    if (kind !== 'zombie') {
      stat('pirate-added');
      if (!pf.inLand) fail('pirate-added-outside-landing', { kind, t: K(t) });
      if (e.slowByFire) fail('pirate-slowByFire', {});
    }
    if (!W(t.col, t.row)) fail('added-on-blocked', { kind, t: K(t) });
    return e;
  };
  const origSpawn = E.spawn.bind(E);
  E.spawn = function (kind) {
    const night = s.clock.isNight, dbg = pf.debugCall;
    const e = origSpawn(kind);
    if (e) {
      L(`spawn z${e.__id}@${K(e.tile)}${dbg ? ' (test tool)' : ''}`); stat(dbg ? 'spawned:test' : 'spawned:night');
      if (e.kind !== 'zombie') fail('spawn-not-zombie', { kind: e.kind });
      if (!dbg && !night) fail('night-spawn-in-daytime', {});
      if (!dbg && pf.curNight) pf.curNight.zSpawns++;
    } else stat('spawn-null');
    return e;
  };

  // ── pirate landing: check the tiles (walkable, not under any character, the nearest such tiles, distinct) ──
  const charTilesNow = () => {
    const out = new Set();
    for (const t of p.occupiedTiles()) out.add(K(t));
    for (const e of E.list) for (const t of e.occupiedTiles()) out.add(K(t));
    return out;
  };
  const bodyTiles = (w) => {
    const out = [], e9 = 1e-9;
    for (let c = Math.floor(w.col + e9); c <= Math.ceil(w.col - e9); c++) for (let r = Math.floor(w.row + e9); r <= Math.ceil(w.row - e9); r++) out.push({ col: c, row: r });
    return out;
  };
  const origLand = P.land.bind(P);
  P.land = function () {
    const n = CFG.pirate.count;
    const busy = charTilesNow();
    const bodies = new Set([...bodyTiles(p), ...E.list.flatMap(bodyTiles)].map(K));
    const free = [];
    for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) if (W(c, r) && !busy.has(c + ',' + r)) free.push({ col: c, row: r, d: Math.hypot(c - LAND.col, r - LAND.row) });
    free.sort((a, z) => a.d - z.d || a.row - z.row || a.col - z.col);
    const want = free.slice(0, Math.max(0, n)).map(K);
    const landingBlocked = !W(LAND.col, LAND.row) ? 'blocked' : busy.has(K(LAND)) ? 'occupied' : 'free';
    const nearBusy = [K(LAND), K({ col: LAND.col, row: LAND.row - 1 }), K({ col: LAND.col - 1, row: LAND.row })].filter((k) => busy.has(k)).length;
    stat('landing:near-busy-' + nearBusy);
    if (E.list.some((e) => !(e.col === e.tile.col && e.row === e.tile.row) && e.occupiedTiles().some((t) => cheb(t, LAND) <= 1))) stat('landing:walker-mid-step-near');
    stat('landing:' + landingBlocked);
    if (s.rest.resting) stat('landing:resting');
    const before = E.list.length;
    pf.inLand = true;
    let r;
    try { r = origLand(); } finally { pf.inLand = false; }
    const added = E.list.slice(before);
    const got = added.map((e) => K(e.tile));
    L(`LAND n=${n} got ${got.join(' ')} want ${want.join(' ')} landing ${landingBlocked}${s.rest.resting ? ' (resting)' : ''}`);
    if (pf.curNight) { pf.curNight.landed++; pf.curNight.pirates += added.length; pf.curNight.landT = s.clock.t; }
    if (got.join(' ') !== want.join(' ')) fail('landing-tiles-differ', { got, want });
    if (new Set(got).size !== got.length) fail('landing-tiles-duplicate', { got });
    for (const k of got) if (bodies.has(k)) fail('landing-under-body', { k });
    added.forEach((e, i) => { const wk = ['pirate_1', 'pirate_2'][i % 2]; if (e.kind !== wk) fail('landing-kind-order', { i, kind: e.kind, wk }); });
    if (added.length !== Math.min(Math.max(0, n), free.length)) fail('landing-count', { added: added.length, n });
    if (!P.boat.visible || P.boat.alpha !== 1) fail('landing-boat-not-shown', { ship: shipS() });
    if (!s.clock.isNight) fail('landing-in-daytime', {});
    return r;
  };

  // ── hooks ──
  const origHitPlayer = E.hitPlayer.bind(E);
  E.hitPlayer = function (e) {
    pf.pendingHits.push(e);
    if (s.rest.resting) fail('enemy-hit-player-in-tent', { z: zs(e) });
    stat(e.kind + '-hit-player');
    L(`${e.kind[0]}${e.__id} hits player (hearts ${s.hearts.value})`);
    return origHitPlayer(e);
  };
  const origHitStructure = E.hitStructure.bind(E);
  E.hitStructure = function (e, x) {
    const atC = e.col === e.tile.col && e.row === e.tile.row;
    if (!atC) fail('smash-while-not-standing', { z: zs(e) });
    if (!m.structures.includes(x)) fail('smash-gone-structure', { z: zs(e), x: x.type + K(x) });
    if (!x.tiles.some((t) => cheb(t, e.tile) <= 1)) fail('smash-from-afar', { z: zs(e), x: x.type + K(x) });
    pf.pendingSmash.push([e, x]);
    stat(e.kind + '-smash:' + x.type);
    L(`${e.kind[0]}${e.__id} hits ${x.type}@${K(x)} hp ${x.hp}->${x.hp - e.cfg.structureDamage}`);
    return origHitStructure(e, x);
  };
  // walk speed per kind: the speed passed to walk, and the distance actually walked this frame
  let protoPatched = false;
  pf.patchEnemyProto = (proto) => {
    if (protoPatched) return;
    protoPatched = true;
    const origAP = proto.attackPlayer;
    proto.attackPlayer = function (dt) { this.__ap = pf.stepNo; return origAP.call(this, dt); };
    const origHurt = proto.hurt;
    proto.hurt = function (n) {
      if (!this.alive) fail('hurt-dead-enemy', { z: zs(this) });
      if (!p.isNextTo(this.tiles)) fail('hurt-not-next-to', { z: zs(this) });
      if (s.rest.resting) fail('hurt-while-resting', { z: zs(this) });
      stat('player-hit-' + this.kind);
      L(`player hits ${this.kind[0]}${this.__id} hp ${this.hp}->${this.hp - n}`);
      return origHurt.call(this, n);
    };
    const origRepath = proto.repath;
    proto.repath = function (target, key) {
      const N = segOther(this), before = this.path.map(K).join(' '), p0 = this.path[0] ? K(this.path[0]) : null;
      stat('repath:' + this.kind);
      pf.repathsThisFrame = (pf.repathsThisFrame || 0) + 1;
      const r = origRepath.call(this, target, key);
      if (N && this.path.length && K(this.path[0]) !== p0) fail('enemy-turned-back', { z: zs(this), N: K(N), before });
      if (N && !this.path.length) fail('enemy-dropped-path-mid-step', { z: zs(this), before });
      return r;
    };
    const baseWalk = Object.getPrototypeOf(proto).walk;   // Walker.prototype.walk
    const origArrive = proto.onArrive;
    proto.onArrive = function () { if (this.__arr) this.__arr.push({ col: this.col, row: this.row }); return origArrive.call(this); };
    proto.walk = function (dt, speed) {
      const cfg = this.cfg;
      const C = CFG.build.campfire;
      const nearFire = m.structures.some((x) => x.type === 'campfire' && Math.hypot(x.col - this.col, x.row - this.row) <= C.slowRange);
      const want = this.kind === 'zombie' ? cfg.speed * (nearFire ? C.slow : 1) : cfg.speed;
      if (Math.abs(speed - want) > 1e-12) fail(this.kind === 'zombie' ? 'zombie-wrong-speed' : 'pirate-wrong-speed', { z: zs(this), speed, want, nearFire });
      if (this.kind !== 'zombie' && nearFire) stat('pirate-walk-near-fire');
      const c0 = this.col, r0 = this.row;
      this.__arr = [];
      const r = baseWalk.call(this, dt, speed);
      const arr = this.__arr; this.__arr = null;
      let d = 0, fc = c0, fr = r0;
      for (const a of arr) { d += Math.hypot(a.col - fc, a.row - fr); fc = a.col; fr = a.row; }
      d += Math.hypot(this.col - fc, this.row - fr);
      const lim = speed * dt;
      if (d > lim + 1e-9) fail('walked-too-far', { z: zs(this), d, lim });
      // still has a path and is not standing in front of a structure: it must have used the whole distance
      const atC = this.col === this.tile.col && this.row === this.tile.row;
      const next = this.path[0];
      const heldByStructure = atC && next && (next.col !== this.tile.col || next.row !== this.tile.row) && !this.mayEnter(next);
      if (this.path.length && !heldByStructure && Math.abs(d - lim) > 1e-6) fail('walked-too-little', { z: zs(this), d, lim });
      return r;
    };
  };
  // the player chasing must finish the step in progress (never turn back)
  const origChase = p.chase.bind(p);
  p.chase = function (a, dt) {
    const N = segOther(p), before = p.path.map(K).join(' '), p0 = p.path[0] ? K(p.path[0]) : null;
    const r = origChase(a, dt);
    if (N && p.path.length && K(p.path[0]) !== p0) fail('chase-turned-back', { N: K(N), before, after: p.path.map(K).join(' ') });
    if (N && !p.path.length) fail('chase-dropped-path-mid-step', { N: K(N), before });
    return r;
  };
  const origKill = E.kill.bind(E);
  E.kill = function (e) { const r = origKill(e); pf.kills++; if (E.list.includes(e)) fail('killed-still-listed', { z: zs(e) }); stat('killed:' + e.kind); L(`kill ${e.kind[0]}${e.__id}`); return r; };
  const origDZ = s.debugZombie.bind(s);
  s.debugZombie = function () { pf.debugCall = true; try { return origDZ(); } finally { pf.debugCall = false; } };
  const origDM = s.debugMorning.bind(s);
  s.debugMorning = function () { pf.natural = false; try { return origDM(); } finally { pf.natural = true; } };

  // ── model of the ship and boat (spec decisions), notices ──
  const SH = { a: 0, to: 0, rate: 0 }, BO = { a: 0, to: 0, rate: 0 };
  let mShipDue = false, mLandDue = false, mNight = false, mMorningGT = -Infinity;
  const notices = [];
  s.events.on('notice', (t) => { notices.push(t); if (/해적/.test(t)) L('notice ' + t); });
  s.events.on('night', () => {
    L('night ' + s.clock.day + ' ' + shipS()); stat('night');
    if (SH.a > 0) stat('cov:night-during-ship-fade-out'); if (BO.a > 0) stat('cov:night-during-boat-fade-out');
    if (s.resultPending) stat('cov:night-while-result-pending');
    mNight = true; mShipDue = CFG.pirate.enabled; mLandDue = CFG.pirate.enabled;
    pf.curNight = { day: s.clock.day, startGT: pf.now, zSpawns: 0, landed: 0, pirates: 0, shipNotices: 0, landNotices: 0, reachedShip: false, reachedLand: false, enabled: CFG.pirate.enabled, count: CFG.pirate.count };
    pf.nights.push(pf.curNight);
    if (pf.nights.length > 400) pf.nights.shift();
  });
  s.events.on('morning', (day) => {
    pf.morningAt = pf.now; pf.morningDay = day; pf.maxDtSinceMorning = 0; pf.heartsAtMorning = pf.lastHearts;
    L('morning ' + day + (pf.natural ? '' : ' (test tool)') + ' ' + shipS()); stat('morning');
    if (E.list.length) fail('morning-enemies-left', { n: E.list.length });
    if (E.schedule.length) fail('morning-schedule-left', { n: E.schedule.length });
    if (P.shipDue || P.landDue) fail('morning-flags-left', { ship: shipS() });
    const n = pf.curNight;
    if (n) {
      n.endedNaturally = pf.natural; n.endT = s.clock.t;
      if (pf.natural) {
        const want = Math.min(14, 4 + 2 * (n.day - 1));
        if (n.zSpawns !== want && !pf.stats['spawn-null']) fail('night-spawn-count', { got: n.zSpawns, want });
      }
      // exactly `count` pirates per night that reached the landing time, none otherwise
      const wantP = n.enabled && n.reachedLand ? n.count : 0;
      if (n.pirates !== wantP) fail('night-pirate-count', { got: n.pirates, want: wantP, n });
      if (n.landed !== (n.enabled && n.reachedLand ? 1 : 0)) fail('night-landings', { n });
      if (n.shipNotices !== (n.enabled && n.reachedShip ? 1 : 0)) fail('night-ship-notices', { n });
      if (n.landNotices !== (n.enabled && n.reachedLand ? 1 : 0)) fail('night-land-notices', { n });
    }
    if (SH.to === 1 && SH.a < 1) stat('cov:morning-during-ship-fade-in');
    if (!mShipDue && mLandDue) stat('cov:morning-between-ship-and-landing');
    if (mShipDue) stat('cov:morning-before-ship');
    if (!mLandDue && n && n.reachedLand) stat('cov:morning-after-landing');
    if (s.rest.resting) stat('cov:morning-while-resting');
    if (pf.inStep) stat('cov:morning-natural-in-step');
    pf.curNight = null;
    mNight = false; mShipDue = false; mLandDue = false; mMorningGT = pf.now;
    SH.to = 0; SH.rate = 1 / CFG.pirate.leaveTime; BO.to = 0; BO.rate = 1 / CFG.pirate.leaveTime;
  });
  s.events.on('down', () => { pf.down = true; stat('down'); if (s.hearts.value > 0) fail('down-with-hearts', { h: s.hearts.value }); L('DOWN'); });
  s.events.on('result', (r) => {
    pf.result = r; stat('result'); L('RESULT ' + JSON.stringify(r));
    if (pf.morningDay !== 2) fail('result-not-day2', { day: pf.morningDay });
    const since = pf.now - pf.morningAt;
    if (since < 3 - 1e-6) fail('result-too-early', { since });
    const mx = Math.max(pf.maxDtSinceMorning, pf.curDt || 0);
    if (since > 3 + mx + 1e-6) fail('result-too-late', { since, maxDt: mx });
    if (r.defeated !== pf.kills) fail('result-defeated-mismatch', { r, kills: pf.kills });
    if (r.hearts !== pf.heartsAtMorning) fail('result-hearts-mismatch', { r, h: pf.heartsAtMorning });
    if (r.fences !== b.count('fence')) fail('result-fences-mismatch', { r });
    if (P.ship.alpha !== 0 || P.ship.visible || P.boat.alpha !== 0 || P.boat.visible) fail('result-window-ship-still-shown', { ship: shipS() });
  });
  s.events.on('rest-changed', () => { if (pf.inStep) pf.restChanged = true; stat(s.rest.resting ? 'rest:enter' : 'rest:exit'); L(s.rest.resting ? 'rest enter' : 'rest exit'); });

  const stepModel = (M, dt) => { M.a = M.a < M.to ? Math.min(M.to, M.a + M.rate * dt) : Math.max(M.to, M.a - M.rate * dt); };
  function checkPirates(dt, noticesThisFrame) {
    const ship = P.ship, boat = P.boat, C = s.clock, Pc = CFG.pirate, len = CFG.time.nightLength;
    // model: what should have happened this frame (same order as the game: clock -> ... -> pirates)
    const n = pf.curNight;
    let shipNow = false, landNow = false;
    if (mNight && mShipDue && C.t >= Pc.shipAt * len) { mShipDue = false; SH.to = 1; SH.rate = 1 / Pc.appearTime; shipNow = true; if (n) n.reachedShip = true; }
    if (mNight && mLandDue && C.t >= Pc.landAt * len) { mLandDue = false; BO.a = 1; BO.to = 1; landNow = true; if (n) n.reachedLand = true; }
    stepModel(SH, dt); stepModel(BO, dt);
    const shipN = noticesThisFrame.filter((t) => t === '해적선이 나타났습니다').length;
    const landN = noticesThisFrame.filter((t) => t === '해적이 상륙했습니다').length;
    if (n) { n.shipNotices += shipN; n.landNotices += landN; }
    if (shipN !== (shipNow ? 1 : 0)) fail('ship-notice-mismatch', { shipN, shipNow, t: C.t });
    if (landN !== (landNow ? 1 : 0)) fail('land-notice-mismatch', { landN, landNow, t: C.t });
    if (shipNow) { stat('ship-appear'); L('ship appears (model) t=' + C.t.toFixed(3) + ' dt=' + dt); }
    for (const [name, img, M] of [['ship', ship, SH], ['boat', boat, BO]]) {
      const a = img.alpha;
      if (!Number.isFinite(a) || a < 0 || a > 1) fail(name + '-alpha-bad', { a });
      if (Math.abs(a - M.a) > 1e-9) { fail(name + '-alpha-vs-model', { a, model: M.a, to: M.to, dt }); M.a = a; }
      if (a > 0 && !img.visible) fail(name + '-alpha-but-hidden', { a, f: img.fade });
      if (img.visible && a === 0 && !(img.fade && img.fade.to > 0)) fail(name + '-visible-at-zero', { f: img.fade });
      // the model says it should be on screen (alpha > 0) -> it must be drawn
      if (M.a > 0 && !img.visible) fail(name + '-should-be-visible', { a, model: M.a });
      if (img.fade && !Number.isFinite(img.fade.rate)) fail(name + '-fade-rate-bad', { f: img.fade });
    }
    if (!C.isNight && pf.now - mMorningGT > CFG.pirate.leaveTime + 1e-6) {
      if (ship.alpha !== 0 || ship.visible || boat.alpha !== 0 || boat.visible) fail('day-ship-or-boat-left', { ship: shipS(), since: pf.now - mMorningGT });
    }
    if (C.isNight && n && n.enabled && C.t >= Pc.shipAt * len + Pc.appearTime + 1e-6 && n.reachedShip && ship.alpha !== 1) fail('night-ship-not-full', { ship: shipS() });
    if (C.isNight && n && n.enabled && n.reachedLand && boat.alpha !== 1) fail('night-boat-not-full', { ship: shipS() });
    // lamp light: exactly while the ship's alpha > 0 (and it is drawn), alpha 0.9 x ship alpha, at ship + lamp
    const lamps = s.lightSources().filter((Lt) => Lt.radius === Pc.lampLight.radius && Lt.color === Pc.lampLight.color);
    const shown = ship.visible && ship.alpha > 0;
    if (lamps.length !== (shown ? 1 : 0)) fail('lamp-count', { lamps: lamps.length, shown, ship: shipS() });
    if (lamps.length === 1) {
      const lp = m.assets.obj_ship.lamp, Lt = lamps[0];
      if (Math.abs(Lt.alpha - Pc.lampLight.alpha * ship.alpha) > 1e-9 || Math.abs(Lt.x - (ship.x + lp[0])) > 1e-9 || Math.abs(Lt.y - (ship.y + lp[1])) > 1e-9) fail('lamp-wrong', { Lt, ship: shipS() });
    }
    for (const e of E.list) if (e.kind !== 'zombie' && !C.isNight) fail('pirate-in-daytime', { z: zs(e) });
    if (P.shipDue !== mShipDue || P.landDue !== mLandDue) fail('flags-vs-model', { ship: shipS(), mShipDue, mLandDue });
  }

  const segOther = (w) => {
    let dc = w.col - w.tile.col, dr = w.row - w.tile.row;
    if (Math.abs(dc) < 1e-9) dc = 0;
    if (Math.abs(dr) < 1e-9) dr = 0;
    if (dc === 0 && dr === 0) return null;
    return { col: w.tile.col + Math.sign(dc), row: w.tile.row + Math.sign(dr) };
  };

  function checkWalker(who, w, isZ) {
    const t = w.tile, Z = () => (isZ ? zs(w) : ps());
    if (!Number.isInteger(t.col) || !Number.isInteger(t.row)) fail(who + ':tile-not-integer', {});
    if (!Number.isFinite(w.col) || !Number.isFinite(w.row)) fail(who + ':pos-not-finite', { w: Z() });
    for (const x of bodyTiles(w)) if (!W(x.col, x.row)) fail(who + ':body-on-blocked', { blocked: K(x), struct: !!m.structureAt(x.col, x.row), w: Z() });
    if (!W(t.col, t.row)) fail(who + ':tile-blocked', { w: Z() });
    const dc = w.col - t.col, dr = w.row - t.row;
    if (Math.abs(dc) >= 1 || Math.abs(dr) >= 1) stat(who + ':pos-off-tile-box(known rounding)');
    if (dc !== 0 && dr !== 0 && Math.abs(Math.abs(dc) - Math.abs(dr)) > 1e-9) fail(who + ':pos-off-diagonal', { dc, dr, w: Z() });
    if (!w.path.length && (w.col !== t.col || w.row !== t.row)) fail(who + ':stranded-fractional', { w: Z() });
    const N = segOther(w);
    if (N) {
      if (cheb(N, t) !== 1) fail(who + ':segment-not-adjacent', { w: Z() });
      else if (!w.canStep(t, N)) fail(who + ':current-step-illegal', { from: K(t), to: K(N), w: Z() });
      if (m.structureAt(N.col, N.row)) fail(who + ':stepping-into-structure', { to: K(N), w: Z() });
      if (N.col !== t.col && N.row !== t.row && (!W(N.col, t.row) || !W(t.col, N.row))) fail(who + ':diagonal-between-blocked', { w: Z() });
      if (!w.path.length) fail(who + ':mid-step-no-path', { w: Z() });
      else if (K(w.path[0]) !== K(N) && K(w.path[0]) !== K(t)) fail(who + ':path0-not-on-segment', { N: K(N), w: Z() });
    }
    let from = t;
    for (let k = 0; k < w.path.length; k++) {
      const q = w.path[k], d = cheb(from, q);
      if (k === 0 && d === 0) { from = q; continue; }
      if (d !== 1) { fail(who + ':path-non-adjacent', { k, from: K(from), to: K(q), w: Z() }); break; }
      if (!w.canStep(from, q)) { fail(who + ':path-step-illegal', { k, from: K(from), to: K(q), w: Z() }); break; }
      from = q;
    }
    const occ = new Set(w.occupiedTiles().map(K));
    for (const x of bodyTiles(w)) if (!occ.has(K(x))) fail(who + ':under-reserved-body', { tile: K(x), w: Z() });
    if (N) for (const x of [t, N, { col: N.col, row: t.row }, { col: t.col, row: N.row }]) if (!occ.has(K(x))) fail(who + ':under-reserved-step', { tile: K(x), w: Z() });
  }

  let pChaseStuck = 0, pNearNoSwing = 0;
  function gridCheck() {
    let n = 0;
    for (let i = 0; i < m.structGrid.length; i++) {
      const x = m.structGrid[i];
      if (!x) continue;
      n++;
      if (!m.structures.includes(x)) { fail('grid-has-unlisted-structure', { x: x.type + K(x) }); return; }
    }
    const want = m.structures.reduce((a, x) => a + x.tiles.length, 0);
    if (n !== want) fail('grid-count-mismatch', { n, want });
  }
  function check(dt, noticesThisFrame) {
    pf.maxDtSinceMorning = Math.max(pf.maxDtSinceMorning, dt);
    if (pf.frame % 5 === 0) gridCheck();
    checkPirates(dt, noticesThisFrame);
    if ((pf.repathsThisFrame || 0) > CFG.zombie.repathsPerFrame) fail('repath-budget-exceeded', { n: pf.repathsThisFrame });
    pf.repathsThisFrame = 0;
    checkWalker('player', p, false);
    if (s.rest.resting) {
      if (!m.structures.includes(s.rest.tent)) fail('resting-in-gone-tent', {});
      if (p.sprite.visible) fail('resting-player-visible', {});
      if (p.moving || p.action || p.swing) fail('resting-player-busy', { p: ps() });
    } else if (!p.sprite.visible) fail('outside-player-invisible', {});
    if (!s.rest.resting && !p.moving && !p.action && !p.swing && E.nextTo(p.tile)) fail('no-auto-attack', { z: zs(E.nextTo(p.tile)), p: ps() });
    const a = p.action;
    if (a && a.chase && !p.moving && !p.isNextTo(a.target.tiles)) { pChaseStuck += dt; if (pChaseStuck > 1.2) { fail('player-chase-stuck', { z: a.target.alive ? zs(a.target) : 'dead', p: ps() }); pChaseStuck = -1e9; } }
    else pChaseStuck = 0;
    if (a && a.chase && !a.isValid() && !p.moving) { if (pf.deadTarget === a.target) { fail('player-acting-on-dead-2frames', { p: ps() }); } pf.deadTarget = a.target; } else pf.deadTarget = null;
    if (a && a.chase && a.isValid()) {
      if (pf.chaseAct !== a) { pf.chaseAct = a; pf.chaseT = 0; pf.chaseNear = false; pf.chaseReported = false; }
      pf.chaseT += dt;
      if (p.isNextTo(a.target.tiles)) pf.chaseNear = true;
      if (!pf.chaseNear && pf.chaseT > 12 && !pf.chaseReported) { pf.chaseReported = true; fail('chase-never-arrives', { z: zs(a.target), p: ps(), t: pf.chaseT }); }
    }
    if (a && a.chase && a.isValid() && !p.moving && p.isNextTo(a.target.tiles) && !p.swing) { pNearNoSwing += dt; if (pNearNoSwing > 0.75) { fail('player-near-no-swing', { z: zs(a.target), p: ps() }); pNearNoSwing = -1e9; } }
    else pNearNoSwing = 0;

    const target = E.target();
    const midFrameSwitch = pf.restChanged; pf.restChanged = false;
    for (const e of E.list) {
      tag(e);
      const mt = meta.get(e);
      const atC = e.col === e.tile.col && e.row === e.tile.row;
      // the run is the game's own attackPlayer calls (counted from the frame where the tent broke too);
      // 'hit-not-standing-next-to' below checks separately that a hit comes from a legal place
      const adj = e.__ap === pf.frame && !target.structure;
      if (e.__ap === pf.frame && !(atC && e.nextTo(target)) && !midFrameSwitch) fail('attack-from-illegal-place', { z: zs(e), p: ps() });
      if (adj) { if (mt.run === null) { mt.run = 0; mt.hitsInRun = 0; } mt.run += dt; } else mt.run = null;
      if (e.smashing) { if (mt.smashObj !== e.smashing) { mt.smashObj = e.smashing; mt.smashAcc = 0; mt.smashHits = 0; } mt.smashAcc += dt; }
      else mt.smashObj = null;
    }
    for (const [e, x] of pf.pendingSmash) {
      const mt = meta.get(e);
      if (!mt || mt.smashObj !== x) { fail('smash-hit-untracked', { z: zs(e) }); continue; }
      const need = e.cfg.structureInterval * (mt.smashHits + 1);
      if (mt.smashAcc < need - 1e-6) fail(e.kind + ':smash-too-early', { z: zs(e), acc: mt.smashAcc, need });
      mt.smashHits++;
    }
    pf.pendingSmash.length = 0;
    for (const e of pf.pendingHits) {
      const mt = meta.get(e);
      if (midFrameSwitch) continue;
      if (!mt || mt.run === null || !(e.col === e.tile.col && e.row === e.tile.row && e.nextTo(E.target()))) { fail('hit-not-standing-next-to', { z: zs(e), p: ps() }); continue; }
      const need = e.cfg.firstHitDelay + e.cfg.hitInterval * mt.hitsInRun;
      if (mt.run < need - 1e-6) fail(e.kind + ':' + (mt.hitsInRun ? 'hit-interval-too-short' : 'first-hit-too-early'), { z: zs(e), run: mt.run, need });
      mt.hitsInRun++;
    }
    pf.pendingHits.length = 0;
    for (const e of E.list) {
      if (!e.alive) fail('dead-enemy-listed', { z: zs(e) });
      checkWalker(e.kind === 'zombie' ? 'zombie' : 'pirate', e, true);
      const mt = meta.get(e);
      const atC = e.col === e.tile.col && e.row === e.tile.row;
      const near = e.nextTo(target);
      if (e.smashing) {
        if (!atC) fail('smashing-not-at-centre', { z: zs(e) });
        const x = e.smashing;
        const onPath = e.path[0] && x.tiles.some((t) => K(t) === K(e.path[0]));
        const isTarget = target.structure === x && near;
        if (!onPath && !isTarget && m.structures.includes(x)) fail('smashing-not-blocker-nor-target', { z: zs(e) });
        if (!x.tiles.some((t) => cheb(t, e.tile) <= 1)) fail('smashing-far-structure', { z: zs(e) });
        if (m.structures.includes(x) && mt.smashAcc > e.cfg.structureInterval * (mt.smashHits + 1) + 1e-6) { fail(e.kind + ':smash-missing', { z: zs(e), acc: mt.smashAcc, hits: mt.smashHits, dt, speed: s.speed }); mt.smashObj = null; }
      }
      if (mt.run !== null && mt.run > e.cfg.firstHitDelay + e.cfg.hitInterval * mt.hitsInRun + 1e-6) { fail(e.kind + ':hit-missing', { z: zs(e), run: mt.run, hits: mt.hitsInRun, dt, speed: s.speed }); mt.run = null; }
      const here = p.here();
      if (!s.rest.resting && atC && e.tile.col === here.col && e.tile.row === here.row && !p.moving && !(e.path.length && !(e.path[0].col === e.tile.col && e.path[0].row === e.tile.row) && !m.structureAt(e.path[0].col, e.path[0].row))) {
        mt.onP = (mt.onP || 0) + dt;
        if (mt.onP > 1.0 && !mt.onPReported) { mt.onPReported = true; fail(e.kind[0] + ':stays-on-player-tile', { z: zs(e), p: ps(), onP: mt.onP,
          nb: [[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[-1,1],[0,1],[1,1]].map(([dc, dr]) => { const c = here.col + dc, r = here.row + dr; return K({ col: c, row: r }) + ':' + (!m.isOpen(c, r) ? 'X' : m.structureAt(c, r) ? m.structureAt(c, r).type[0] : E.takenTiles(e).has(c + ',' + r) ? 'taken' : 'free'); }).join(' ') }); }
      } else {
        if (mt.onP > 1.0) { pf.onPDur = pf.onPDur || []; pf.onPDur.push({ kind: e.kind, d: +mt.onP.toFixed(2), why: mt.onPWhy, f: pf.frame }); }
        mt.onP = 0; mt.onPReported = false;
      }
      if (mt.onP > 0) mt.onPWhy = e.path.length && m.structureAt(e.path[e.path[0] && e.path[0].col === e.tile.col && e.path[0].row === e.tile.row ? 1 : 0] ? (e.path[0].col === e.tile.col && e.path[0].row === e.tile.row ? e.path[1] || e.path[0] : e.path[0]).col : -1, (e.path[0].col === e.tile.col && e.path[0].row === e.tile.row ? e.path[1] || e.path[0] : e.path[0]).row) ? 'held-by-structure' : (e.path.length ? 'path' : 'no-path');
      const movedNow = e.col !== mt.lastPos[0] || e.row !== mt.lastPos[1];
      mt.lastPos = [e.col, e.row];
      if (!movedNow && !near && !e.smashing) {
        mt.still += dt;
        if (mt.still > 2.0 && !mt.reported) {
          mt.reported = true;
          const route = e.findRoute(e.goalsAround(target.tiles).all);
          fail(e.kind[0] + ':' + (route ? 'still-away-with-route' : 'still-away-no-route'),
            { z: zs(e), still: +mt.still.toFixed(2), routeLen: route ? route.length : 0, idx: E.list.indexOf(e), n: E.list.length, speed: s.speed, dt });
        }
      } else { mt.still = 0; mt.reported = false; }
      stat((e.kind === 'zombie' ? 'z:' : 'P:') + (e.smashing ? 'smashing' : !atC ? 'walking' : e.moving ? 'centre-with-path' : near ? 'adjacent' : 'idle'));
      const kind = target.structure ? 'tent' : 'player';
      if (e.goalKind !== null && e.goalKind !== kind) { mt.stale = (mt.stale || 0) + dt; if (mt.stale > 2.0 && !mt.staleReported) { mt.staleReported = true; fail('stale-goal-kind', { z: zs(e), kind, stale: mt.stale, idx: E.list.indexOf(e), n: E.list.length, speed: s.speed }); } }
      else { mt.stale = 0; mt.staleReported = false; }
    }
    if (p.action && p.action.chase) stat(p.moving ? 'p:chasing' : 'p:fighting');
    pf.lastHearts = s.hearts.value;
    if (pf.traceIds && pf.frame >= (pf.traceFrom || 0)) {
      for (const e of E.list) if (pf.traceIds.includes(e.__id)) {
        const mt = meta.get(e);
        pf.trace.push({ f: pf.frame, dt: +dt.toFixed(4), t: +s.clock.t.toFixed(3), e: zs(e), run: mt.run === null ? null : +mt.run.toFixed(4), hits: mt.hitsInRun,
          tgt: target.structure ? 'tent' : 'player@' + K(target.tiles[0]), P: ps(), mid: !!midFrameSwitch, rest: s.rest.resting, idx: E.list.indexOf(e), status: s.sys.settings.status });
      }
    }
  }

  // ── time director: nights and mornings at chosen moments (focus on the 35% / 45% moments) ──
  const dir = { endAt: undefined, nightAt: undefined };
  const pickEnd = () => {
    const r = pf.rnd(), sa = CFG.pirate.shipAt * CFG.time.nightLength, la = CFG.pirate.landAt * CFG.time.nightLength, ap = CFG.pirate.appearTime;
    if (r < pf.pNaturalNight) return Infinity;
    const q = pf.rnd();
    if (q < 0.15) return U(0, sa);
    if (q < 0.40) return U(sa - 0.1, sa + ap + 0.2);   // during the fade-in
    if (q < 0.55) return U(sa + ap, la);
    if (q < 0.75) return U(la - 0.15, la + 0.3);       // right around the landing
    return U(la, CFG.time.nightLength);
  };
  const pickNight = () => {
    const r = pf.rnd();
    if (r < pf.pNaturalDay) return Infinity;
    const q = pf.rnd();
    if (q < 0.45) return U(0, CFG.pirate.leaveTime + 0.3);   // during the morning fade-out
    if (q < 0.85) return U(CFG.pirate.leaveTime, 12);
    return U(12, CFG.time.dayLength);
  };
  function director() {
    const C = s.clock;
    if (C.isNight) {
      dir.nightAt = undefined;
      if (dir.endAt === undefined) { dir.endAt = pickEnd(); L('director: morning at t=' + dir.endAt.toFixed(3)); }
      if (C.t >= dir.endAt) { L('debugMorning (director) ' + shipS()); s.debugMorning(); dir.endAt = undefined; }
    } else {
      dir.endAt = undefined;
      if (dir.nightAt === undefined) { dir.nightAt = pickNight(); L('director: night at t=' + dir.nightAt.toFixed(3)); }
      if (C.t >= dir.nightAt) { const pend = s.resultPending; s.debugNight(); if (C.isNight) { L('debugNight (director) ' + shipS()); dir.nightAt = undefined; } else if (!pend) fail('debugNight-did-nothing', {}); }
    }
  }

  // ── random actions (between frames, like taps) ──
  const nearTile = (c0, r0, rad) => ({ col: c0 + ri(2 * rad + 1) - rad, row: r0 + ri(2 * rad + 1) - rad });
  function hotTiles() {
    const out = [];
    const add = (w) => {
      const t = w.tile, N = segOther(w);
      if (N) out.push(N, { col: N.col, row: t.row }, { col: t.col, row: N.row });
      let from = t;
      for (let k = 0; k < Math.min(4, w.path.length); k++) { const q = w.path[k]; out.push(q, { col: q.col, row: from.row }, { col: from.col, row: q.row }); from = q; }
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) out.push({ col: t.col + dc, row: t.row + dr });
    };
    add(p);
    for (const e of E.list) if (cheb(e.tile, p.tile) <= 8) add(e);
    return out;
  }
  function tryBuild(type) {
    const H = hotTiles();
    if (type === 'tent') {
      if (b.atMax('tent')) return false;
      for (let k = 0; k < 8; k++) {
        const base = pf.rnd() < 0.6 ? pick(H) : nearTile(p.tile.col, p.tile.row, 4);
        const c = base.col - ri(2), r = base.row - ri(2);
        const tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }];
        if (tiles.every((x) => b.canBuildAt(x.col, x.row))) { L(`place tent ${tiles.map(K).join('+')}`); b.place('tent', tiles); stat('build:tent'); return true; }
      }
      return false;
    }
    for (let k = 0; k < 8; k++) {
      const x = pf.rnd() < 0.8 ? pick(H) : nearTile(p.tile.col, p.tile.row, 5);
      if (b.canBuildAt(x.col, x.row)) { L(`place ${type} ${K(x)}`); b.place(type, [x]); stat('build:' + type); return true; }
    }
    return false;
  }
  // a structure built earlier on the landing area (reach is not checked: the player could have built it before)
  const freeForStructure = (x) => m.isOpen(x.col, x.row) && !m.structureAt(x.col, x.row) && !s.characterTiles().some((t) => t.col === x.col && t.row === x.row);
  function buildOnLanding() {
    const r = pf.rnd();
    if (r < 0.1 && !b.atMax('tent')) {
      const base = nearTile(LAND.col, LAND.row, 3);
      const tiles = [base, { col: base.col + 1, row: base.row }, { col: base.col, row: base.row + 1 }, { col: base.col + 1, row: base.row + 1 }];
      if (tiles.every(freeForStructure)) { L(`place tent (landing area) ${tiles.map(K).join('+')}`); b.place('tent', tiles); stat('build:tent-landing'); }
      return;
    }
    const x = pf.rnd() < 0.5 ? nearTile(LAND.col, LAND.row, 1) : nearTile(LAND.col, LAND.row, 3);
    const type = pf.rnd() < 0.85 ? 'fence' : 'campfire';
    if (freeForStructure(x)) { L(`place ${type} (landing area) ${K(x)}`); b.place(type, [x]); stat('build:landing-' + type); }
  }
  function ring() {
    const done = [];
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      if (!dc && !dr) continue;
      const x = { col: p.tile.col + dc, row: p.tile.row + dr };
      if (b.canBuildAt(x.col, x.row)) { b.place('fence', [x]); done.push(K(x)); }
    }
    L(`ring around ${K(p.tile)}: fences ${done.join(' ')}`); stat('ring');
  }
  function randomWalkable(c0, r0, rad) {
    for (let k = 0; k < 30; k++) { const x = nearTile(c0, r0, rad); if (W(x.col, x.row)) return x; }
    return null;
  }
  // a real tap through GameScene.onPress / onRelease (touch pointer)
  function tap(wx, wy, what) {
    const ptr = { wasTouch: true, button: 0, isDown: true, worldX: wx, worldY: wy };
    L(`tap ${what} @${wx.toFixed(1)},${wy.toFixed(1)}`); stat('tap:' + what);
    s.onPress(ptr); ptr.isDown = false; s.onRelease(ptr);
  }
  const inRect = (sp) => ({ x: sp.x - sp.displayWidth * sp.originX + pf.rnd() * sp.displayWidth, y: sp.y - sp.displayHeight * sp.originY + pf.rnd() * sp.displayHeight });
  function randomTap() {
    const q = pf.rnd();
    if (q < 0.30 && E.list.length) { const e = pick(E.list), sp = e.sprite; tap(sp.x + U(-14, 14), sp.y - sp.displayHeight * sp.originY * 0.5 + U(-20, 20), 'enemy-' + e.kind); return; }
    if (q < 0.45) { const list = m.objects.filter((o) => o.node && cheb(o, p.tile) <= 7); if (list.length) { const pt = inRect(pick(list).sprite); tap(pt.x, pt.y, 'node'); } return; }
    if (q < 0.60) { const t = m.structures.find((x) => x.type === 'tent'); if (t) { const pt = inRect(t.sprite); tap(pt.x, pt.y, 'tent'); } return; }
    if (q < 0.65) { const img = pf.rnd() < 0.5 ? P.ship : P.boat; const pt = inRect(img); tap(pt.x, pt.y, 'ship-or-boat'); return; }
    const base = pf.rnd() < 0.3 ? LAND : pf.rnd() < 0.4 && E.list.length ? pick(E.list).tile : p.tile;
    const x = nearTile(base.col, base.row, 6);
    tap((x.col - x.row) * 40 + U(-15, 15), (x.col + x.row) * 20 + U(-7, 7), 'ground');
  }
  let failedWalks = 0;
  function act() {
    pf.now = pf.gt;
    const r = pf.rnd();
    const C = s.clock;
    if (r < pf.pTime) {
      if (!C.isNight) {
        const pend = s.resultPending; L('debugNight (random)' + (pend ? ' (result pending)' : '')); s.debugNight();
        if (pend && s.clock.isNight) fail('night-while-result-pending', {});
      } else { L('debugMorning (random) ' + shipS()); s.debugMorning(); }
      return;
    }
    if (r < pf.pTime + pf.pSpawn) { if (E.list.length < pf.maxZ) { L('debugZombie'); s.debugZombie(); } return; }
    if (r < pf.pTime + pf.pSpawn + pf.pSpeed) { L('toggle speed'); s.debugToggleSpeed(); return; }
    if (r < pf.pTime + pf.pSpawn + pf.pSpeed + pf.pTap) { randomTap(); return; }
    if (r < pf.pTime + pf.pSpawn + pf.pSpeed + pf.pTap + pf.pLandBuild) { buildOnLanding(); return; }
    if (s.rest.resting) {
      const q = pf.rnd();
      if (q < 0.02) { L('rest.exit (button)'); s.rest.exit(); }
      else if (q < 0.08) tryBuild(pf.rnd() < 0.9 ? 'fence' : 'campfire');
      else if (q < 0.085) { L('destroy tent while resting'); b.destroy(s.rest.tent); }
      else if (q < 0.11) { const list = m.structures.filter((x) => x.type !== 'tent' && cheb(x.tiles[0], p.tile) <= 6); if (list.length) { const x = pick(list); L(`destroy ${x.type}@${K(x)}`); b.destroy(x); } }
      return;
    }
    const moving = p.moving;
    if (pf.campAtLanding && C.isNight && C.t >= 30 && C.t <= CFG.pirate.landAt * CFG.time.nightLength + 0.5) {
      // camp next to the landing tile so that the enemies crowd the landing tiles when the pirates land
      if (!moving && cheb(p.tile, LAND) > 2) { const x = randomWalkable(LAND.col, LAND.row, 1); if (x) { const ok = p.goTo(x.col, x.row); L(`camp goTo ${K(x)} ${ok}`); } }
      if (pf.rnd() < 0.05 && E.list.length) { const e = pick(E.list); L(`pressEnemy ${e.kind[0]}${e.__id}`); s.pressEnemy(e); }
      return;
    }
    const q = pf.rnd();
    let acc = 0;
    if (q < (acc += moving ? 0.02 : pf.pWalk)) {
      const base = pf.rnd() < pf.pNearLanding ? LAND : pf.rnd() < 0.4 && E.list.length ? pick(E.list).tile : p.tile;
      const x = randomWalkable(base.col, base.row, 6); if (!x) return;
      const ok = p.goTo(x.col, x.row); L(`goTo ${K(x)} ${ok}`); stat('goTo:' + ok);
      if (!ok) failedWalks++; else failedWalks = 0;
    } else if (q < (acc += pf.pPressEnemy)) {
      if (E.list.length) { const e = pick(E.list); L(`pressEnemy ${e.kind[0]}${e.__id}`); s.pressEnemy(e); stat('pressEnemy'); }
    } else if (q < (acc += moving ? 0.10 : 0.04)) {
      const t = pf.rnd();
      tryBuild(t < 0.85 ? 'fence' : t < 0.96 ? 'campfire' : 'tent');
    } else if (q < (acc += pf.pRing)) {
      ring();
    } else if (q < (acc += 0.025)) {
      const list = m.structures.filter((x) => cheb(x.tiles[0], p.tile) <= 7 || cheb(x.tiles[0], LAND) <= 3 || E.list.some((e) => e.smashing === x));
      if (list.length) {
        const sm = E.list.find((e) => e.smashing && m.structures.includes(e.smashing));
        const x = pf.rnd() < 0.4 && sm ? sm.smashing : pick(list);
        if (m.structures.includes(x)) { L(`destroy ${x.type}@${K(x)}`); b.destroy(x); }
      }
    } else if (q < (acc += 0.01)) {
      const list = m.objects.filter((o) => o.node && cheb(o, p.tile) <= 6);
      if (list.length) { const o = pick(list); L(`pressNode ${o.kind}@${o.col},${o.row}`); s.pressNode(o); }
    } else if (q < (acc += pf.pTent)) {
      const t = m.structures.find((x) => x.type === 'tent');
      if (t) { L('pressTent'); s.pressTent(t); }
    }
    if (m.structures.length > pf.maxS || failedWalks >= 3) {
      const list = failedWalks >= 3 ? m.structures.filter((x) => cheb(x.tiles[0], p.tile) <= 3) : [m.structures[0]];
      for (const x of list) { if (!m.structures.includes(x)) continue; L(`destroy-old ${x.type}@${K(x)}`); b.destroy(x); }
      failedWalks = 0;
    }
  }

  // one frame, the way SceneManager.update does it: queued scene ops first, then the scene's step
  function frame(delta) {
    g.scene.processQueue();
    if (s.sys.settings.status !== RUNNING) {
      if (pf.holdLeft === undefined) { pf.holdLeft = ri(4); pf.holdShip = [P.ship.alpha, P.boat.alpha, s.clock.t]; }
      if (pf.holdLeft-- > 0) {
        // window up: nothing in the world may move
        if (P.ship.alpha !== pf.holdShip[0] || P.boat.alpha !== pf.holdShip[1] || s.clock.t !== pf.holdShip[2]) fail('moved-while-paused', {});
        return;
      }
      pf.holdLeft = undefined;
      L('window up: ' + (pf.down ? 'down' : 'result'));
      if (pf.down) { s.hearts.value = s.hearts.max; s.events.emit('hearts-changed'); pf.down = false; pf.lastHearts = s.hearts.value; }
      ui.closeModal();
      s.resumeGame();
      g.scene.processQueue();
      if (s.sys.settings.status !== RUNNING) fail('could-not-resume', { st: s.sys.settings.status });
      return;
    }
    const sleeping = s.rest.resting && !s.enemyNear(s.rest.tent, CFG.build.tent.wakeRange);
    const dt = Math.min(delta / 1000, CFG.screen.maxFrameTime) * s.debugSpeed * (sleeping ? CFG.build.tent.sleepTimeScale : 1);
    pf.time += delta;
    pf.now = pf.gt + dt;
    pf.curDt = dt;
    pf.stepNo = pf.frame + 1;
    const n0 = notices.length;
    try {
      pf.inStep = true;
      s.sys.step(pf.time, delta);
      pf.inStep = false;
    } catch (err) {
      pf.inStep = false;
      fail('exception', { msg: String(err && err.message), stack: String(err && err.stack).slice(0, 1200) });
    }
    if (Math.abs(Math.min(delta / 1000, CFG.screen.maxFrameTime) * s.speed - dt) > 1e-12) stat('dt-mismatch');
    pf.gt = pf.now;
    pf.frame++;
    if (dt === 0) stat('dt0-frames');
    try { check(dt, notices.slice(n0)); } catch (err) { fail('check-exception', { msg: String(err && err.message), stack: String(err && err.stack).slice(0, 800) }); }
  }

  pf.init = (seed, opts = {}) => {
    pf.seed = seed; pf.rnd = mulberry32(seed);
    Math.random = mulberry32(seed ^ 0x9e3779b9);   // spawn points become reproducible
    pf.deltaMode = opts.delta === undefined ? 'random' : opts.delta;
    pf.maxZ = opts.maxZ || 10; pf.maxS = opts.maxS || 18;
    pf.pTime = opts.pTime === undefined ? 0.0002 : opts.pTime;
    pf.pSpawn = opts.pSpawn === undefined ? 0.004 : opts.pSpawn;
    pf.pSpeed = opts.pSpeed === undefined ? 0.002 : opts.pSpeed;
    pf.pTap = opts.pTap === undefined ? 0.03 : opts.pTap;
    pf.pLandBuild = opts.pLandBuild === undefined ? 0.006 : opts.pLandBuild;
    pf.pWalk = opts.pWalk === undefined ? 0.10 : opts.pWalk;
    pf.pNearLanding = opts.pNearLanding === undefined ? 0.35 : opts.pNearLanding;
    pf.pPressEnemy = opts.pPressEnemy === undefined ? 0.03 : opts.pPressEnemy;
    pf.pRing = opts.pRing === undefined ? 0.003 : opts.pRing;
    pf.pTent = opts.pTent === undefined ? 0.02 : opts.pTent;
    pf.pNaturalNight = opts.pNaturalNight === undefined ? 0.2 : opts.pNaturalNight;
    pf.pNaturalDay = opts.pNaturalDay === undefined ? 0.08 : opts.pNaturalDay;
    pf.p0 = opts.p0 === undefined ? 0.02 : opts.p0;           // share of 0 ms frames (random mode)
    pf.campAtLanding = !!opts.campAtLanding;
    pf.traceIds = opts.traceIds; pf.traceFrom = opts.traceFrom; pf.trace = []; pf.stopAtFrame = opts.stopAtFrame;
    if (opts.count !== undefined) CFG.pirate.count = opts.count;
    s.tools = ['dagger', 'axe', 'pickaxe'];
    if (!g.loop.sleeping) g.loop.sleep();
    s.clock.t = opts.clockT || 0; s.elapsed = 0; s.clock.dawn = 0;
    if (opts.speed3 && s.debugSpeed === 1) s.debugToggleSpeed();
    pf.time = 1000;
    for (const e of E.list) tag(e);
    L('init seed ' + seed + ' ' + JSON.stringify(opts));
  };
  pf.run = (n) => {
    for (let i = 0; i < n; i++) {
      director();
      const k = 1 + (pf.rnd() < 0.25 ? ri(3) : 0);
      for (let j = 0; j < k; j++) act();
      if (E.list[0]) pf.patchEnemyProto(Object.getPrototypeOf(E.list[0]));
      const delta = pf.deltaMode === 'random' ? (pf.rnd() < pf.p0 ? 0 : pf.rnd() < 0.1 ? 150 : 5 + pf.rnd() * 110) : pf.deltaMode;
      frame(delta);
      if (pf.stopAtFrame && pf.frame >= pf.stopAtFrame) break;
    }
    return { frame: pf.frame, fails: pf.fails.length, z: E.list.length, structures: m.structures.length, day: s.clock.day, kills: pf.kills,
             nights: pf.nights.length, landings: pf.nights.reduce((a, x) => a + x.landed, 0) };
  };
  pf.snap = snap; pf.zs = zs; pf.ps = ps; pf.frameOnce = frame; pf.check = check;
})();
