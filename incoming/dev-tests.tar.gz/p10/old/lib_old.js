// 시험 공통 도구
const { chromium } = require('playwright');
exports.open = async (opts = {}) => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: opts.w || 1920, height: opts.h || 1200 }, deviceScaleFactor: 1, hasTouch: !!opts.touch });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error' || (m.type() === 'warning' && !/GPU stall|ReadPixels/.test(m.text()))) errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  page.on('requestfailed', (r) => errors.push('requestfailed: ' + r.url()));
  page.on('response', (r) => { if (r.status() >= 400) errors.push('http ' + r.status() + ': ' + r.url()); });
  await page.goto('http://127.0.0.1:8001/' + (opts.query || ''));
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  await page.waitForTimeout(500);
  // Phase 6: 예전 시험(Phase 2~5)은 해적을 끄고 돌린다. 해적 시험은 { pirates: true }.
  if (!opts.pirates) await page.evaluate(async () => { const m = await import('/src/config.js'); m.CONFIG.pirate.enabled = false; });
  const G = (fn, arg) => page.evaluate(fn, arg);
  const W = (fn, arg, t = 60000) => page.waitForFunction(fn, arg, { timeout: t });
  // 칸 -> 브라우저 화면 좌표
  const tilePos = (col, row) => page.evaluate(([col, row]) => {
    const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main;
    const wx = (col - row) * 40, wy = (col + row) * 20;
    const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
    const r = g.canvas.getBoundingClientRect();
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, on: sx >= 0 && sy >= 0 && sx < cam.width && sy < cam.height };
  }, [col, row]);
  const tapTile = async (col, row, dx = 0, dy = 0) => {
    const p = await tilePos(col, row);
    if (!p.on) throw new Error(`tile ${col},${row} is off screen`);
    if (opts.touch) await page.touchscreen.tap(p.x + dx, p.y + dy); else await page.mouse.click(p.x + dx, p.y + dy);
    return p;
  };
  const state = () => G(() => {
    const s = window.__game.scene.getScene('game'), p = s.player;
    return { col: +p.col.toFixed(2), row: +p.row.toFixed(2), tile: [p.tile.col, p.tile.row], path: p.path.length, moving: p.moving,
             frame: p.sprite.frame.name, flip: p.sprite.flipX, anim: p.sprite.anims.isPlaying, cursor: s.cursor.visible, cursorAt: [s.cursor.x, s.cursor.y] };
  });
  const arrive = () => W(() => !window.__game.scene.getScene('game').player.moving);
  return { browser, page, errors, G, W, tilePos, tapTile, state, arrive };
};

// 화면(게임 1920×1200 좌표) (x, y) 둘레 r 픽셀의 평균 밝기. 빛 지도까지 그려진 마지막 화면을 읽는다.
exports.lum = (page, x, y, r = 16) => page.evaluate(([x, y, r]) => new Promise((res) => {
  window.__game.renderer.snapshotArea(Math.round(x - r), Math.round(y - r), r * 2, r * 2, (img) => {
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let s = 0; for (let i = 0; i < d.length; i += 4) s += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    res(+(s / (d.length / 4)).toFixed(1));
  });
}), [x, y, r]);
// 게임 시간 재기: 프레임마다 실제로 흐른 게임 시간(dt)을 더해 둔다
exports.trackTime = (G) => G(() => {
  const s = window.__game.scene.getScene('game'); window.__gt = 0;
  s.events.on('update', (t, d) => { window.__gt += Math.min(d / 1000, 0.1) * s.speed; });
});
