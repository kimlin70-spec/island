// Stress (v2): the craft window is opened before the walk, so the fence card is one click away.
// Fence LINES (straight on screen = diagonal in tile space, and straight in tile space) are clicked quickly across the path ahead.
const { open, report } = require('./lib.js');
const R = report('s2b');
const SEED = +(process.env.SEED || 11);
let rs = SEED;
const rnd = () => { rs = (rs * 1103515245 + 12345) & 0x7fffffff; return rs / 0x7fffffff; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const N = +(process.env.N || 12);
const TOUCH = !!process.env.TOUCH;

(async () => {
  const T = TOUCH ? await open({ w: 1024, h: 768, touch: true }) : await open({ w: 1920, h: 1200 });
  const st = () => T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return { col: p.col, row: p.row, tile: [p.tile.col, p.tile.row], path: p.path.map((t) => [t.col, t.row]), moving: p.moving,
             wood: s.inventory.count('wood'), mode: s.build.mode, open: window.__game.scene.getScene('ui').craftOpen }; });
  const screenOk = (sx, sy) => !(sx < 120 || sx > 1560 || sy < 230 || sy > 1060 || (sx < 720 && sy > 960) || (sx > 740 && sy > 700));
  let trials = 0, noMoveTaps = 0, oddRefusals = 0;
  for (let k = 0; k < N; k++) {
    let s0 = await st();
    if (s0.open) await T.closeCraft();
    if (s0.wood < 15) await T.materials();
    await T.craftBtn();                       // window open, no card: taps still walk
    const dest = await T.G(([seed]) => {
      const s = window.__game.scene.getScene('game'), p = s.player, m = s.map, cam = s.cameras.main;
      let r = seed; const rnd = () => { r = (r * 1103515245 + 12345) & 0x7fffffff; return r / 0x7fffffff; };
      for (let i = 0; i < 600; i++) {
        const c = p.tile.col + Math.round((rnd() * 2 - 1) * 11), rr = p.tile.row + Math.round((rnd() * 2 - 1) * 11);
        const d = Math.hypot(c - p.col, rr - p.row);
        if (d < 7 || d > 11.5 || !m.isWalkable(c, rr)) continue;
        const wx = (c - rr) * 40, wy = (c + rr) * 20;
        const sx = (wx - cam.midPoint.x) + cam.width / 2, sy = (wy - cam.midPoint.y) + cam.height / 2;
        if (sx < 150 || sx > 1500 || sy < 250 || sy > 690) continue;
        if (m.pickObject(wx, wy)) continue;
        return { c, r: rr };
      }
      return null; }, [Math.floor(rnd() * 1e9)]);
    if (!dest) { console.log('trial', k, 'no destination'); continue; }
    await T.tapTile(dest.c, dest.r);
    await T.sleep(60);
    let s1 = await st();
    if (!s1.moving) {
      const reach = await T.G(([c, r]) => { const s = window.__game.scene.getScene('game'), p = s.player;
        const save = p.path.slice(); const okk = p.routeTo([{ col: c, row: r }]); const len = p.path.length; p.path = save; return okk && len > 0; }, [dest.c, dest.r]);
      console.log('trial', k, 'tap did not walk', JSON.stringify(dest), 'reachable', reach, JSON.stringify(await T.presses().then((a) => a.slice(-1))));
      if (reach) noMoveTaps++;
      continue;
    }
    trials++;
    await T.card(2);
    const strategy = pick(['lineH', 'lineV', 'lineT', 'sides', 'ahead']);
    let tried = 0;
    s1 = await st();
    const steps = [s1.tile, ...s1.path];
    // pick the anchor tile 2..4 steps ahead
    const ai = Math.min(steps.length - 1, 2 + Math.floor(rnd() * 3));
    const b = steps[ai];
    let line = [];
    if (strategy === 'lineH') for (let q = -2; q <= 2; q++) line.push([b[0] + q, b[1] - q]);           // c+r const: horizontal on screen
    if (strategy === 'lineV') for (let q = -2; q <= 2; q++) line.push([b[0] + q, b[1] + q]);           // c-r const: vertical on screen
    if (strategy === 'lineT') { const hor = rnd() < 0.5; for (let q = -2; q <= 2; q++) line.push(hor ? [b[0] + q, b[1]] : [b[0], b[1] + q]); }
    if (strategy === 'sides') for (let i = 2; i < steps.length; i++) { const a = steps[i - 1], c = steps[i]; if (a[0] !== c[0] && a[1] !== c[1]) line.push([c[0], a[1]], [a[0], c[1]]); }
    if (strategy === 'ahead') line = steps.slice(2, 6);
    if (rnd() < 0.5) line.reverse();
    for (const c of line) {
      const pp = await T.w2p((c[0] - c[1]) * 40, (c[0] + c[1]) * 20);
      if (!screenOk(pp.sx, pp.sy)) continue;
      await T.tapPage(pp.x, pp.y);
      tried++;
    }
    try { await T.stopped(30000); } catch (e) { R.ok('trial ' + k + ' walk ends', false, 'still moving after 30 s'); }
    const s3 = await st();
    const M = await T.mon();
    const commits = await T.commits();
    const built = commits.filter((c) => c.built).length;
    const refused = commits.filter((c) => !c.built && c.open && !c.struct && c.dist <= 7);
    const body = refused.filter((c) => c.occ.includes(c.tile)), other = refused.filter((c) => !c.occ.includes(c.tile));
    for (const c of body) {
      const [tc, tr] = c.tile.split(',').map(Number);
      const to = c.path0 ? c.path0.split(',').map(Number) : c.at;
      const inBox = tc >= Math.floor(Math.min(c.at[0], to[0])) && tc <= Math.ceil(Math.max(c.at[0], to[0])) && tr >= Math.floor(Math.min(c.at[1], to[1])) && tr <= Math.ceil(Math.max(c.at[1], to[1]));
      if (!inBox) { oddRefusals++; console.log('   odd body refusal', JSON.stringify(c)); }
    }
    for (const c of other) { oddRefusals++; console.log('   refused for another reason', JSON.stringify(c)); }
    console.log(`trial ${k} ${strategy} dest ${dest.c},${dest.r} anchor ${b} tried ${tried} built ${built} refusedBody ${body.length} | end ${s3.tile} bad ${M.bad.length} frac ${M.frac.length} longest ${M.longest}`);
    if (M.bad.length || M.frac.length) { console.log('   BAD', JSON.stringify(M.bad.slice(0, 5)), JSON.stringify(M.frac.slice(0, 5))); break; }
  }
  const M = await T.mon();
  R.ok('trials run', trials >= Math.floor(N / 2), 'trials ' + trials);
  R.ok('taps on reachable ground always walk', noMoveTaps === 0, 'noMove ' + noMoveTaps);
  R.ok('no odd build refusals', oddRefusals === 0, 'odd ' + oddRefusals);
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no endless walk', M.longest < 20, 'longest ' + M.longest);
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  console.log('structures', (await T.structs()).length, 'frames', M.frames);
  await T.page.screenshot({ path: __dirname + '/s2b_end_' + SEED + (TOUCH ? 't' : '') + '.png' });
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
