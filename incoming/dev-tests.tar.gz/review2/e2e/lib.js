// e2e helpers: real mouse / touch input, plus in-page monitors that only READ game state
const { chromium } = require('playwright');

exports.open = async (opts = {}) => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: opts.w || 1920, height: opts.h || 1200 }, deviceScaleFactor: 1, hasTouch: !!opts.touch });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error' || (m.type() === 'warning' && !/GPU stall|ReadPixels/.test(m.text()))) errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  page.on('requestfailed', (r) => errors.push('requestfailed: ' + r.url()));
  page.on('response', (r) => { if (r.status() >= 400) errors.push('http ' + r.status() + ': ' + r.url()); });
  await page.goto('http://127.0.0.1:8000/' + (opts.query || ''));
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  await page.waitForTimeout(500);
  const T = { browser, page, errors, touch: !!opts.touch };
  T.G = (fn, arg) => page.evaluate(fn, arg);
  T.W = (fn, arg, t = 60000) => page.waitForFunction(fn, arg, { timeout: t });
  T.sleep = (ms) => page.waitForTimeout(ms);
  // game (1920x1200) coords -> page coords
  T.g2p = (x, y) => T.G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect();
    return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
  // world coords -> page coords (with the camera as it is now)
  T.w2p = (wx, wy) => T.G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, sx, sy,
             on: sx >= 0 && sy >= 0 && sx < cam.width && sy < cam.height }; }, [wx, wy]);
  T.tapPage = async (x, y) => {
    if (T.touch) await page.touchscreen.tap(x, y);
    else { await page.mouse.move(x, y); await page.mouse.click(x, y); }
  };
  T.ui = async (x, y, wait = 300) => { const p = await T.g2p(x, y); await T.tapPage(p.x, p.y); if (wait) await T.sleep(wait); };
  T.tapWorld = async (wx, wy, wait = 0) => {
    const p = await T.w2p(wx, wy);
    if (!p.on) throw new Error('off screen ' + wx + ',' + wy);
    await T.tapPage(p.x, p.y);
    if (wait) await T.sleep(wait);
    return p;
  };
  T.tapTile = (c, r, wait) => T.tapWorld((c - r) * 40, (c + r) * 20, wait);
  T.stopped = (t = 60000) => T.W(() => !window.__game.scene.getScene('game').player.moving, null, t);
  T.P = () => T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return { col: +p.col.toFixed(3), row: +p.row.toFixed(3), tile: [p.tile.col, p.tile.row], moving: p.moving,
             path: p.path.map((t) => t.col + ',' + t.row), action: !!p.action, resting: s.rest.resting,
             wood: s.inventory.count('wood'), stone: s.inventory.count('stone'), tools: s.tools.join(','), mode: s.build.mode }; });
  T.structs = () => T.G(() => window.__game.scene.getScene('game').map.structures.map((s) => s.type + '@' + s.tiles.map((t) => t.col + ',' + t.row).join('+')));

  // ---- UI buttons (1920x1200 game coords) ----
  T.craftBtn = () => T.ui(1824, 1104, 400);
  T.card = (i) => T.ui(776 + 20 + i * 182 + 85, 898, 300);
  T.debugBtn = () => T.ui(1852, 328, 300);
  T.debugItem = (i) => T.ui(1746, 402 + i * 66, 300);
  T.materials = async () => { await T.debugBtn(); await T.debugItem(0); await T.debugItem(4); };
  T.mode = async (cardIndex) => {   // open the craft window if closed, pick a card
    const open = await T.G(() => window.__game.scene.getScene('ui').craftOpen);
    if (!open) await T.craftBtn();
    await T.card(cardIndex);
  };
  T.closeCraft = async () => { const open = await T.G(() => window.__game.scene.getScene('ui').craftOpen); if (open) await T.craftBtn(); };

  // ---- monitors (read only) ----
  await T.G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    window.__mon = { bad: [], frac: [], longest: 0, cur: 0, presses: [], builds: [], frames: 0, overlap: [] };
    const M = window.__mon;
    const orig = s.onPress;
    s.onPress = function (p) {
      const o = this.map.pickObject(p.worldX, p.worldY);
      const pl = this.player;
      M.presses.push({ wx: +p.worldX.toFixed(1), wy: +p.worldY.toFixed(1), picked: o ? (o.type || o.kind) + '@' + o.col + ',' + o.row : null,
        mode: this.build.mode, at: [+pl.col.toFixed(2), +pl.row.toFixed(2)], resting: this.rest.resting });
      return orig.call(this, p);
    };
    const origPlace = s.build.place.bind(s.build);
    s.build.place = function (type, tiles) {
      const pl = s.player;
      const occ = pl.occupiedTiles().map((t) => t.col + ',' + t.row);
      const before = { at: [+pl.col.toFixed(3), +pl.row.toFixed(3)], tile: [pl.tile.col, pl.tile.row], path: pl.path.map((t) => t.col + ',' + t.row) };
      const r = origPlace(type, tiles);
      M.builds.push({ type, tiles: tiles.map((t) => t.col + ',' + t.row), occ, before, after: pl.path.map((t) => t.col + ',' + t.row) });
      return r;
    };
    s.events.on('postupdate', (t, d) => {
      M.frames++;
      const p = s.player;
      if (s.rest.resting) return;
      const c0 = Math.floor(p.col), c1 = Math.ceil(p.col), r0 = Math.floor(p.row), r1 = Math.ceil(p.row);
      for (let c = c0; c <= c1; c++) for (let r = r0; r <= r1; r++) if (!m.isWalkable(c, r)) {
        if (M.bad.length < 50) M.bad.push({ at: [+p.col.toFixed(3), +p.row.toFixed(3)], blocked: [c, r], s: m.structureAt(c, r) ? m.structureAt(c, r).type : 'obj' });
      }
      if (!p.moving && (p.col !== Math.round(p.col) || p.row !== Math.round(p.row))) { if (M.frac.length < 50) M.frac.push([p.col, p.row]); }
      if (!p.moving && (p.col !== p.tile.col || p.row !== p.tile.row)) { if (M.frac.length < 50) M.frac.push(['tile-mismatch', p.col, p.row, p.tile.col, p.tile.row]); }
      const dt = Math.min(d / 1000, 0.1) * s.speed;
      if (p.moving) { M.cur += dt; M.longest = Math.max(M.longest, M.cur); } else M.cur = 0;
    });
  });
  // record every commit (release in build mode) with why nothing was built
  await T.G(() => {
    const s = window.__game.scene.getScene('game'), b = s.build;
    window.__commits = [];
    const orig = b.commit.bind(b);
    b.commit = function (wx, wy) {
      const p = s.player, before = s.map.structures.length;
      const t = { col: Math.floor(((wx / 40 + wy / 20) / 2) + 0.5), row: Math.floor(((wy / 20 - wx / 40) / 2) + 0.5) };
      const occ = p.occupiedTiles().map((q) => q.col + ',' + q.row);
      const info = { mode: b.mode, tile: t.col + ',' + t.row, at: [+p.col.toFixed(3), +p.row.toFixed(3)], ptile: p.tile.col + ',' + p.tile.row,
        path0: p.path[0] ? p.path[0].col + ',' + p.path[0].row : null, occ,
        open: s.map.isOpen(t.col, t.row), struct: !!s.map.structureAt(t.col, t.row), dist: +Math.hypot(t.col - p.col, t.row - p.row).toFixed(2) };
      const r = orig(wx, wy);
      info.built = s.map.structures.length > before;
      info.spot = b.spot ? { ok: b.spot.ok, tiles: b.spot.tiles.map((q) => q.col + ',' + q.row) } : null;
      window.__commits.push(info);
      return r;
    };
  });
  T.commits = () => T.G(() => window.__commits.splice(0));
  T.mon = () => T.G(() => { const M = window.__mon; return { bad: M.bad, frac: M.frac, longest: +M.longest.toFixed(2), frames: M.frames, builds: M.builds.length }; });
  T.presses = () => T.G(() => window.__mon.presses);
  T.builds = () => T.G(() => window.__mon.builds);

  // an opaque pixel of an object/structure sprite that pickObject maps back to that object, near the sprite's visual centre
  T.pickPoint = (col, row, kindFilter) => T.G(([col, row]) => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    const o = m.objectAt(col, row) || m.structureAt(col, row);
    if (!o) return null;
    const sp = o.sprite;
    const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY;
    const cx = left + sp.displayWidth / 2, cy = top + sp.displayHeight * 0.45;
    let best = null;
    for (let y = Math.ceil(top) + 2; y < top + sp.displayHeight - 2; y += 2) for (let x = Math.ceil(left) + 2; x < left + sp.displayWidth - 2; x += 2) {
      let ok = true;
      for (let dy = -2; dy <= 2 && ok; dy += 2) for (let dx = -2; dx <= 2 && ok; dx += 2) if (m.pickObject(x + dx + 0.5, y + dy + 0.5) !== o) ok = false;
      if (!ok) continue;
      const d = Math.hypot(x - cx, y - cy);
      if (!best || d < best.d) best = { wx: x + 0.5, wy: y + 0.5, d };
    }
    return best;
  }, [col, row]);
  T.tapObject = async (col, row) => { const q = await T.pickPoint(col, row); if (!q) throw new Error('no pick point ' + col + ',' + row); return T.tapWorld(q.wx, q.wy); };
  return T;
};

exports.report = (name) => {
  let fails = 0;
  const ok = (n, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + n + (info ? '  ' + info : '')); if (!cond) fails++; };
  return { ok, done: () => { console.log(fails ? `\n${name}: ${fails} FAILED` : `\n${name}: ALL PASS`); return fails; } };
};
