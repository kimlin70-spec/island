// Campfire and tent beside a walk in progress, tent in/out, test window (night, morning, speed), building at x3 speed.
const { open, report } = require('./lib.js');
const R = report('s4');
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  await T.materials(); await T.materials();
  const st = () => T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return { col: p.col, row: p.row, tile: [p.tile.col, p.tile.row], path: p.path.map((t) => [t.col, t.row]), moving: p.moving, resting: s.rest.resting,
             speed: s.speed, night: s.clock.isNight, label: s.clock.label }; });
  const sideTiles = (s) => { const steps = [s.tile, ...s.path], out = [];
    for (let i = 2; i < steps.length; i++) { const a = steps[i - 1], b = steps[i]; if (a[0] !== b[0] && a[1] !== b[1]) out.push([b[0], a[1]], [a[0], b[1]]); }
    return out; };

  // 1. campfire beside a diagonal walk: destination diagonal from the start
  await T.craftBtn();            // open the window first (no card yet: taps still walk)
  await T.tapTile(43, 33);       // mostly diagonal walk up-right
  await T.card(3);               // campfire
  let s = await st();
  let built = 0;
  for (let i = 0; i < 4 && s.moving; i++) {
    const c = sideTiles(s)[0] || (s.path[1] || null);
    if (!c) break;
    await T.tapTile(c[0], c[1], 0);
    s = await st();
  }
  await T.stopped();
  let S = await T.structs();
  console.log('   campfires', S.join(' '), 'player', JSON.stringify((await st()).tile), JSON.stringify(await T.commits()));
  R.ok('campfire(s) built beside the walk', S.some((x) => x.startsWith('campfire')), S.join(' '));
  await T.closeCraft();

  // 2. tent beside a walk in progress: walk left-down, place the tent on/next to the path ahead
  await T.craftBtn();
  await T.tapTile(36, 44);
  await T.card(4);
  s = await st();
  let tentTry = 0;
  while (s.moving && tentTry < 4) {
    const steps = [s.tile, ...s.path];
    const tgt = steps[Math.min(2, steps.length - 1)];
    // the tent centre on the corner shared by tgt and its right neighbour
    const p = await T.w2p(((tgt[0] + 0.5) - (tgt[1] - 0.5)) * 40, ((tgt[0] + 0.5) + (tgt[1] - 0.5)) * 20);
    if (p.on && p.sy < 700) { await T.tapPage(p.x, p.y); tentTry++; }
    s = await st();
    if ((await T.structs()).some((x) => x.startsWith('tent'))) break;
  }
  await T.stopped();
  S = await T.structs();
  s = await st();
  console.log('   structures', S.join(' '), 'player', JSON.stringify(s.tile));
  const tent = S.find((x) => x.startsWith('tent'));
  if (!tent) {
    // place it with a click near the player while standing
    const t = s.tile;
    const p = await T.w2p(((t[0] + 2.5) - (t[1] - 2.5)) * 40, ((t[0] + 2.5) + (t[1] - 2.5)) * 20);
    await T.tapPage(p.x, p.y); await T.sleep(200);
    S = await T.structs();
  }
  R.ok('tent built', S.some((x) => x.startsWith('tent')), S.join(' '));
  const modeAfterTent = (await T.P()).mode;
  R.ok('tent: build mode ends after the only tent', modeAfterTent === null, 'mode ' + modeAfterTent);
  await T.closeCraft();
  const M1 = await T.mon();
  R.ok('so far never touching a blocked tile', M1.bad.length === 0, JSON.stringify(M1.bad.slice(0, 3)));

  // 3. enter the tent by tapping it
  const tentInfo = await T.G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
    return { col: t.col, row: t.row, x: t.sprite.x, y: t.sprite.y, h: t.sprite.displayHeight * t.sprite.originY }; });
  await T.tapWorld(tentInfo.x, tentInfo.y - tentInfo.h * 0.5);
  await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await T.sleep(300);
  s = await st();
  R.ok('tapping the tent: walks and goes in (x4)', s.resting && s.speed === 4, JSON.stringify(s));
  const entry = s.tile;
  // test window: night, speed, morning
  await T.debugBtn();
  await T.debugItem(1);
  s = await st();
  R.ok('test: night', s.night, s.label);
  await T.debugItem(3);
  s = await st();
  R.ok('test: speed x3 while resting -> x12', s.speed === 12, 'speed ' + s.speed);
  await T.debugItem(2);
  await T.sleep(300);
  s = await st();
  R.ok('test: morning', !s.night && /2일째/.test(s.label), s.label);
  await T.debugItem(3);       // back to x1
  await T.debugItem(4);       // close
  // while resting: build fences around (allowed), entry tile refused
  await T.mode(2);
  await T.tapTile(entry[0], entry[1], 150);
  S = await T.structs();
  R.ok('resting: entry tile cannot be built on', !S.includes(`fence@${entry[0]},${entry[1]}`), S.join(' '));
  await T.closeCraft();
  // rest button -> out
  await T.ui(960, 1132, 400);
  s = await st();
  R.ok('rest button: out on the entry tile', !s.resting && s.tile.join() === entry.join() && s.speed === 1, JSON.stringify(s));
  // tap the tent again -> in, then tap the tent -> out
  await T.tapWorld(tentInfo.x, tentInfo.y - tentInfo.h * 0.5);
  await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await T.sleep(300);
  await T.tapWorld(tentInfo.x, tentInfo.y - tentInfo.h * 0.5, 400);
  s = await st();
  R.ok('tap tent while resting: out', !s.resting, JSON.stringify(s));

  // 4. x3 speed: walk and build fences on the path ahead
  await T.debugBtn(); await T.debugItem(3); await T.debugItem(4);
  for (let k = 0; k < 3; k++) {
    const s0 = await st();
    const dest = await T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player, m = s.map, cam = s.cameras.main;
      for (let i = 0; i < 300; i++) { const c = p.tile.col + Math.round(Math.random() * 18 - 9), r = p.tile.row + Math.round(Math.random() * 18 - 9);
        if (Math.hypot(c - p.col, r - p.row) < 7 || !m.isWalkable(c, r)) continue;
        const wx = (c - r) * 40, wy = (c + r) * 20, sx = wx - cam.midPoint.x + cam.width / 2, sy = wy - cam.midPoint.y + cam.height / 2;
        if (sx < 150 || sx > 1500 || sy < 250 || sy > 700 || m.pickObject(wx, wy)) continue;
        return [c, r]; } return null; });
    if (!dest) continue;
    await T.tapTile(dest[0], dest[1]);
    await T.mode(2);
    for (let i = 0; i < 4; i++) {
      s = await st();
      if (!s.moving) break;
      const c = sideTiles(s)[0] || s.path[1];
      if (!c) break;
      const p = await T.w2p((c[0] - c[1]) * 40, (c[0] + c[1]) * 20);
      if (p.on && p.sy < 700) await T.tapPage(p.x, p.y);
    }
    await T.stopped();
    await T.closeCraft();
  }
  await T.debugBtn(); await T.debugItem(3); await T.debugItem(4);
  const M = await T.mon();
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no endless walk', M.longest < 20, 'longest ' + M.longest);
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  console.log('   structures', (await T.structs()).join(' '));
  await T.page.screenshot({ path: __dirname + '/s4_end.png' });
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
