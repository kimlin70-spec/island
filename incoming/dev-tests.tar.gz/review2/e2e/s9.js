// Tent beside a walk in progress, repeated: place the tent (real clicks) over/next to the path ahead and the step in progress.
// Then tap the tent to enter (walks around obstacles), exit, remove it with real clicks, repeat.
const { open, report } = require('./lib.js');
const R = report('s9');
const TOUCH = !!process.env.TOUCH;
(async () => {
  const T = TOUCH ? await open({ w: 1024, h: 768, touch: true }) : await open({ w: 1920, h: 1200 });
  await T.materials(); await T.materials(); await T.materials();
  const st = () => T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player, u = window.__game.scene.getScene('ui');
    return { col: p.col, row: p.row, tile: [p.tile.col, p.tile.row], path: p.path.map((t) => [t.col, t.row]), moving: p.moving, resting: s.rest.resting, mode: s.build.mode, open: u.craftOpen,
             tent: (s.map.structures.find((x) => x.type === 'tent') || {}).tiles }; });
  let seed = 17; const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  let placedWhileWalking = 0, entered = 0;
  for (let k = 0; k < 8; k++) {
    let s = await st();
    if (s.open) await T.closeCraft();
    await T.craftBtn();
    const dest = await T.G(([seed]) => {
      const s = window.__game.scene.getScene('game'), p = s.player, m = s.map, cam = s.cameras.main;
      let r = seed; const rnd = () => { r = (r * 1103515245 + 12345) & 0x7fffffff; return r / 0x7fffffff; };
      for (let i = 0; i < 600; i++) {
        const c = p.tile.col + Math.round((rnd() * 2 - 1) * 10), rr = p.tile.row + Math.round((rnd() * 2 - 1) * 10);
        if (Math.hypot(c - p.col, rr - p.row) < 7 || !m.isWalkable(c, rr)) continue;
        const wx = (c - rr) * 40, wy = (c + rr) * 20, sx = wx - cam.midPoint.x + cam.width / 2, sy = wy - cam.midPoint.y + cam.height / 2;
        if (sx < 150 || sx > 1500 || sy < 250 || sy > 690 || m.pickObject(wx, wy)) continue;
        return [c, rr];
      }
      return null; }, [Math.floor(rnd() * 1e9)]);
    if (!dest) continue;
    await T.tapTile(dest[0], dest[1]);
    await T.card(4);
    for (let j = 0; j < 5; j++) {
      s = await st();
      if (!s.moving || s.tent) break;
      const steps = [s.tile, ...s.path];
      const b = steps[Math.min(steps.length - 1, Math.floor(rnd() * 4))];
      const fc = b[0] + (rnd() < 0.5 ? 0.5 : -0.5), fr = b[1] + (rnd() < 0.5 ? 0.5 : -0.5);
      const pp = await T.w2p((fc - fr) * 40, (fc + fr) * 20);
      if (!pp.on || pp.sx < 130 || pp.sx > 1550 || pp.sy < 230 || pp.sy > 700) continue;
      await T.tapPage(pp.x, pp.y);
    }
    s = await st();
    if (s.tent && s.moving) placedWhileWalking++;
    await T.stopped(30000);
    s = await st();
    if (!s.tent) { console.log('   try', k, 'no tent placed'); continue; }
    const commits = await T.commits();
    const tentCommit = commits.find((c) => c.built);
    console.log(`   try ${k}: tent ${JSON.stringify(s.tent.map((t) => t.col + ',' + t.row))} player ${s.tile} | at build: ${JSON.stringify(tentCommit && { at: tentCommit.at, occ: tentCommit.occ })}`);
    // body tiles never under the tent
    if (tentCommit) {
      const clash = s.tent.filter((t) => tentCommit.occ.includes(t.col + ',' + t.row));
      R.ok('try ' + k + ': tent not on the body tiles', clash.length === 0, JSON.stringify(clash));
    }
    // refusals: every refused tent spot had a reason
    for (const c of commits.filter((c) => !c.built && c.spot)) {
      const reasons = await T.G((tiles) => { const s = window.__game.scene.getScene('game'); return tiles.map((t) => { const [c, r] = t.split(',').map(Number); return s.map.isOpen(c, r); }); }, c.spot.tiles);
      const bodyHit = c.spot.tiles.some((t) => c.occ.includes(t));
      if (!bodyHit && reasons.every(Boolean) && c.dist <= 6) console.log('   refused tent spot with no obvious reason', JSON.stringify(c));
    }
    // enter by tapping the tent
    await T.closeCraft();
    const ti = await T.G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
      return { x: t.sprite.x, y: t.sprite.y, h: t.sprite.displayHeight * t.sprite.originY }; });
    // wait for the camera to settle, then tap the tent picture
    await T.W(() => { const s = window.__game.scene.getScene('game'), c = s.cameras.main, p = s.player.sprite; return Math.abs(c.midPoint.x - p.x) < 2 && Math.abs(c.midPoint.y - p.y) < 2; }, null, 20000).catch(() => {});
    const pp = await T.w2p(ti.x, ti.y - ti.h * 0.5);
    if (pp.on && pp.sy < 980) {
      await T.tapPage(pp.x, pp.y);
      try { await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 20000); entered++; await T.sleep(200); await T.ui(960, 1132, 300); }
      catch (e) { console.log('   try', k, 'did not enter the tent', JSON.stringify(await st()), JSON.stringify((await T.presses()).slice(-1))); }
    }
    // remove the tent with real clicks
    await T.mode(5);
    const pp2 = await T.w2p(ti.x, ti.y - ti.h * 0.5);
    if (pp2.on && pp2.sy < 700) await T.tapPage(pp2.x, pp2.y);
    else await T.tapWorld(ti.x, ti.y);
    await T.sleep(200);
    s = await st();
    if (s.tent) console.log('   try', k, 'tent not removed');
    await T.closeCraft();
  }
  console.log('   placed while walking', placedWhileWalking, 'entered', entered);
  const M = await T.mon();
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
