// Tablet touch on a fence wall: where do taps inside the fence picture's box go?
// The wall is built with real taps; then taps land on random points inside one fence picture's rectangle.
const { open, report } = require('./lib.js');
const R = report('s7');
const TOUCH = !process.env.MOUSE;
(async () => {
  const T = TOUCH ? await open({ w: 1024, h: 768, touch: true }) : await open({ w: 1920, h: 1200 });
  await T.materials();
  let p = await T.P();
  const [c0, r0] = p.tile;
  // wall along row r0-2 (screen: a line going down-right), 7 fences, built with real taps
  await T.mode(2);
  for (let c = c0 - 3; c <= c0 + 3; c++) await T.tapTile(c, r0 - 2, 60);
  await T.closeCraft();
  const S = await T.structs();
  R.ok('wall built', S.length === 7, S.join(' '));
  // taps inside the middle fence picture (c0, r0-2)
  const box = await T.G(([c, r]) => { const s = window.__game.scene.getScene('game'), f = s.map.structureAt(c, r), sp = f.sprite;
    return { left: sp.x - sp.displayWidth * sp.originX, top: sp.y - sp.displayHeight * sp.originY, w: sp.displayWidth, h: sp.displayHeight, x: sp.x, y: sp.y }; }, [c0, r0 - 2]);
  console.log('   fence box', JSON.stringify(box));
  const res = { fence: 0, groundBehind: 0, groundOwn: 0, groundFront: 0, other: 0, walkedBehind: 0, n: 0 };
  let seed = 5; const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  for (let i = 0; i < 24; i++) {
    // a point in the upper 2/3 of the picture (the rails), like a finger aiming at the fence
    const wx = box.left + 8 + rnd() * (box.w - 16), wy = box.top + 6 + rnd() * (box.h * 0.6);
    await T.G(() => { window.__mon.presses.length = 0; });
    await T.tapWorld(wx, wy);
    await T.sleep(150);
    const pr = (await T.presses())[0];
    const s = await T.P();
    res.n++;
    if (!pr) { res.other++; continue; }
    const tc = Math.floor((pr.wx / 40 + pr.wy / 20) / 2 + 0.5), tr = Math.floor((pr.wy / 20 - pr.wx / 40) / 2 + 0.5);
    if (pr.picked && pr.picked.startsWith('fence')) res.fence++;
    else if (pr.picked) res.other++;
    else if (tr < r0 - 2) res.groundBehind++;
    else if (tr === r0 - 2) res.groundOwn++;
    else res.groundFront++;
    if (s.moving || s.tile.join() !== [c0, r0].join()) {
      const dest = s.path.length ? s.path[s.path.length - 1] : s.tile.join();
      if (tr < r0 - 2) res.walkedBehind++;
      console.log(`   tap ${i} at (${wx.toFixed(1)},${wy.toFixed(1)}) seen (${pr.wx},${pr.wy}) picked ${pr.picked} tile ${tc},${tr} -> walking to ${dest} (${s.path.length} steps)`);
      // come back
      await T.stopped(60000);
      await T.tapTile(c0, r0); await T.stopped(60000);
    }
  }
  console.log('   ', JSON.stringify(res));
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
