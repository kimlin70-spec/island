// Phase 2 flow with the real mouse: dagger chop, craft axe and pickaxe, mine a rock, dig rubble and stump
const { open, report } = require('./lib.js');
const R = report('s1');
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const kindAt = (c, r) => T.G(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return o ? o.kind + (o.node ? ':' + o.node.hp : ':-') : null; }, [c, r]);

  // 1. tree 37,35 with the dagger
  await T.tapObject(37, 35);
  await T.sleep(300);
  let p = await T.P();
  R.ok('tap tree: walking with an action', p.moving && p.action, JSON.stringify(p));
  await T.W(() => { const o = window.__game.scene.getScene('game').map.objectAt(37, 35); return o && o.kind === 'stump'; }, null, 60000);
  p = await T.P();
  R.ok('tree became a stump, wood 4', p.wood === 4, JSON.stringify(p));

  // 2. axe
  await T.mode(0);
  p = await T.P();
  R.ok('axe crafted', p.tools === 'dagger,axe' && p.wood === 1, JSON.stringify(p));
  await T.closeCraft();

  // 3. tree 35,35 with the axe
  await T.tapObject(35, 35);
  await T.W(() => { const o = window.__game.scene.getScene('game').map.objectAt(35, 35); return o && o.kind === 'stump'; }, null, 60000);
  p = await T.P();
  R.ok('second tree chopped with the axe, wood 5', p.wood === 5, JSON.stringify(p));

  // 4. rock without pickaxe -> notice, no walk
  await T.tapObject(33, 37);
  await T.sleep(300);
  p = await T.P();
  R.ok('rock without pickaxe: no walk', !p.moving && !p.action, JSON.stringify(p));
  // stump without pickaxe -> no walk
  await T.tapObject(37, 35);
  await T.sleep(300);
  p = await T.P();
  R.ok('stump without pickaxe: no walk', !p.moving && !p.action, JSON.stringify(p));

  // 5. pickaxe
  await T.mode(1);
  p = await T.P();
  R.ok('pickaxe crafted', p.tools === 'dagger,axe,pickaxe' && p.wood === 2, JSON.stringify(p));
  await T.closeCraft();

  // 6. rock
  await T.tapObject(33, 37);
  await T.W(() => { const o = window.__game.scene.getScene('game').map.objectAt(33, 37); return o && o.kind === 'rubble'; }, null, 60000);
  p = await T.P();
  R.ok('rock mined, stone 1', p.stone === 1, JSON.stringify(p));
  await T.sleep(800);
  // 7. dig the rubble
  await T.tapObject(33, 37);
  await T.W(() => !window.__game.scene.getScene('game').map.objectAt(33, 37), null, 30000);
  p = await T.P();
  R.ok('rubble dug out', (await kindAt(33, 37)) === null, JSON.stringify(p));
  // 8. dig the stump 37,35
  await T.tapObject(37, 35);
  await T.W(() => !window.__game.scene.getScene('game').map.objectAt(37, 35), null, 30000);
  R.ok('stump dug out', (await kindAt(37, 35)) === null);
  await T.stopped();
  // 9. stand on stump 35,35 and dig it (step off)
  await T.tapTile(35, 36);   // walk next to it first
  await T.stopped();
  // walk onto the stump tile: tap the ground part of the tile that is not covered by the stump picture
  const g = await T.G(() => { const s = window.__game.scene.getScene('game'), m = s.map;
    const c = 35, r = 35, cx = (c - r) * 40, cy = (c + r) * 20;
    for (let dy = -18; dy <= 18; dy += 2) for (let dx = -38; dx <= 38; dx += 2) {
      if (Math.abs(dx) / 40 + Math.abs(dy) / 20 > 0.8) continue;
      if (!m.pickObject(cx + dx, cy + dy)) return { wx: cx + dx, wy: cy + dy };
    }
    return null; });
  R.ok('found ground pixel of the stump tile', !!g, JSON.stringify(g));
  if (g) {
    await T.tapWorld(g.wx, g.wy);
    await T.stopped();
    p = await T.P();
    R.ok('standing on the stump tile', p.tile.join() === '35,35', JSON.stringify(p));
    await T.tapObject(35, 35);
    await T.sleep(200);
    p = await T.P();
    R.ok('tap stump while on it: steps off', p.moving || p.tile.join() !== '35,35', JSON.stringify(p));
    await T.W(() => !window.__game.scene.getScene('game').map.objectAt(35, 35), null, 30000);
    R.ok('stump dug out after stepping off', (await kindAt(35, 35)) === null);
  }
  await T.stopped();
  const M = await T.mon();
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no endless walk', M.longest < 15, 'longest ' + M.longest);
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  console.log('frames', M.frames);
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
