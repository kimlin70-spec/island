// Stress: build fences fast with the real mouse while the player is walking.
// Random destinations, fences on the path ahead, on the side tiles of diagonal steps, and screen-straight lines across the path.
const { open, report } = require('./lib.js');
const R = report('s2');
const SEED = +(process.env.SEED || 7);
let rs = SEED;
const rnd = () => { rs = (rs * 1103515245 + 12345) & 0x7fffffff; return rs / 0x7fffffff; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const N = +(process.env.N || 12);

(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const st = () => T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player, m = s.map;
    return { col: p.col, row: p.row, tile: [p.tile.col, p.tile.row], path: p.path.map((t) => [t.col, t.row]), moving: p.moving,
             wood: s.inventory.count('wood'), mode: s.build.mode, open: window.__game.scene.getScene('ui').craftOpen }; });
  const screenOk = (sx, sy, craftOpen) => {
    if (sx < 120 || sx > 1560 || sy < 230 || sy > 1060) return false;
    if (sx < 720 && sy > 960) return false;           // bag panel
    if (craftOpen && sx > 740 && sy > 700) return false;
    return true;
  };
  const reachable = (from, to) => T.G(([a, b]) => { const s = window.__game.scene.getScene('game');
    return !!s.player.map && !!(window.__find || null); }, [from, to]);

  let trials = 0, noMoveTaps = 0;
  for (let k = 0; k < N; k++) {
    let s0 = await st();
    if (s0.open) await T.closeCraft();
    if (s0.wood < 12) await T.materials();
    s0 = await st();
    // destination: walkable, 6..10 tiles, on screen, not covered by any picture at its centre, reachable
    const dest = await T.G(([seed]) => {
      const s = window.__game.scene.getScene('game'), p = s.player, m = s.map, cam = s.cameras.main;
      let r = seed; const rnd = () => { r = (r * 1103515245 + 12345) & 0x7fffffff; return r / 0x7fffffff; };
      for (let i = 0; i < 400; i++) {
        const c = p.tile.col + Math.round((rnd() * 2 - 1) * 10), rr = p.tile.row + Math.round((rnd() * 2 - 1) * 10);
        const d = Math.hypot(c - p.col, rr - p.row);
        if (d < 6 || d > 10.5 || !m.isWalkable(c, rr)) continue;
        const wx = (c - rr) * 40, wy = (c + rr) * 20;
        const sx = (wx - cam.midPoint.x) + cam.width / 2, sy = (wy - cam.midPoint.y) + cam.height / 2;
        if (sx < 150 || sx > 1500 || sy < 250 || sy > 700) continue;
        if (m.pickObject(wx, wy)) continue;
        p.routeTo; // no-op
        return { c, r: rr };
      }
      return null; }, [Math.floor(rnd() * 1e9)]);
    if (!dest) { console.log('trial', k, 'no destination'); continue; }
    await T.tapTile(dest.c, dest.r);
    await T.sleep(120);
    let s1 = await st();
    if (!s1.moving) {
      // is it reachable at all?
      const reach = await T.G(([c, r]) => { const s = window.__game.scene.getScene('game'), p = s.player;
        return p.routeTo ? (() => { const save = p.path.slice(); const okk = p.routeTo([{ col: c, row: r }]); const len = p.path.length; p.path = save; return okk && len > 0; })() : null; }, [dest.c, dest.r]);
      console.log('trial', k, 'tap did not walk', JSON.stringify(dest), 'reachable', reach);
      if (reach) noMoveTaps++;
      continue;
    }
    trials++;
    await T.craftBtn();
    await T.card(2);
    const K = 2 + Math.floor(rnd() * 4);
    const strategy = pick(['side', 'ahead', 'lineA', 'lineB', 'mixed']);
    let tried = 0;
    for (let j = 0; j < K; j++) {
      const s2 = await st();
      if (!s2.moving) break;
      // candidate tiles from the current path
      const steps = [[s2.tile[0], s2.tile[1]], ...s2.path];
      const cands = [];
      for (let i = 1; i < steps.length; i++) {
        const a = steps[i - 1], b = steps[i];
        const diag = a[0] !== b[0] && a[1] !== b[1];
        if ((strategy === 'side' || strategy === 'mixed') && diag && i >= 2) { cands.push([b[0], a[1]]); cands.push([a[0], b[1]]); }
        if ((strategy === 'ahead' || strategy === 'mixed') && i >= 2) cands.push(b);
        if (strategy === 'lineA' && i >= 2) for (let q = -2; q <= 2; q++) cands.push([b[0] + q, b[1] - q]);   // screen-horizontal line through b
        if (strategy === 'lineB' && i >= 2) for (let q = -2; q <= 2; q++) cands.push([b[0] + q, b[1] + q]);   // screen-vertical line through b
      }
      if (strategy === 'side' || strategy === 'mixed') {
        // also the side tiles of the step in progress (must be refused) once in a while
        if (s2.path.length) { const a = s2.tile, b = s2.path[0]; if (a[0] !== b[0] && a[1] !== b[1] && rnd() < 0.3) { cands.push([b[0], a[1]]); cands.push([a[0], b[1]]); } }
      }
      if (!cands.length) break;
      const c = pick(cands);
      const pp = await T.w2p((c[0] - c[1]) * 40, (c[0] + c[1]) * 20);
      if (!screenOk(pp.sx, pp.sy, true)) continue;
      await T.tapPage(pp.x, pp.y);
      tried++;
      if (rnd() < 0.5) await T.sleep(Math.floor(rnd() * 250));
    }
    try { await T.stopped(30000); } catch (e) { R.ok('trial ' + k + ' walk ends', false, 'still moving after 30 s'); }
    const s3 = await st();
    const M = await T.mon();
    const commits = await T.commits();
    const built = commits.filter((c) => c.built).length;
    // refused builds on tiles that are open, empty, in reach -> must be because of the body
    const refused = commits.filter((c) => !c.built && c.open && !c.struct && c.dist <= 7);
    const bodyRefusals = refused.filter((c) => c.occ.includes(c.tile));
    const otherRefusals = refused.filter((c) => !c.occ.includes(c.tile));
    console.log(`trial ${k} ${strategy} dest ${dest.c},${dest.r} K=${K} tried ${tried} built ${built} refusedBody ${bodyRefusals.length} refusedOther ${otherRefusals.length} | end ${s3.tile} (${s3.col.toFixed(2)},${s3.row.toFixed(2)}) bad ${M.bad.length} frac ${M.frac.length} longest ${M.longest}`);
    for (const c of bodyRefusals) {
      // check that the refused tile is inside the box of the step in progress
      const [tc, tr] = c.tile.split(',').map(Number);
      const to = c.path0 ? c.path0.split(',').map(Number) : c.at;
      const inBox = tc >= Math.floor(Math.min(c.at[0], to[0])) && tc <= Math.ceil(Math.max(c.at[0], to[0])) && tr >= Math.floor(Math.min(c.at[1], to[1])) && tr <= Math.ceil(Math.max(c.at[1], to[1]));
      if (!inBox) console.log('   odd body refusal', JSON.stringify(c));
    }
    for (const c of otherRefusals) console.log('   refused for another reason', JSON.stringify(c));
    if (M.bad.length || M.frac.length) { console.log('   BAD', JSON.stringify(M.bad.slice(0, 5)), JSON.stringify(M.frac.slice(0, 5))); break; }
  }
  const M = await T.mon();
  R.ok('trials run', trials >= Math.floor(N / 2), 'trials ' + trials);
  R.ok('taps on reachable ground always walk', noMoveTaps === 0, 'noMove ' + noMoveTaps);
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no endless walk', M.longest < 20, 'longest ' + M.longest);
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  console.log('structures', (await T.structs()).length, 'frames', M.frames);
  await T.page.screenshot({ path: __dirname + '/s2_end_' + SEED + '.png' });
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
