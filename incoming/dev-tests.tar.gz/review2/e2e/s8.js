// While walking (and while standing), taps that the GAME picked as a fence / campfire / bush must not change the walk.
// Uses the game's own press record (what pickObject returned) so camera lag in the test cannot fake a result.
const { open, report } = require('./lib.js');
const R = report('s8');
const TOUCH = !!process.env.TOUCH;
(async () => {
  const T = TOUCH ? await open({ w: 1024, h: 768, touch: true }) : await open({ w: 1920, h: 1200 });
  await T.G(() => {
    const s = window.__game.scene.getScene('game');
    window.__pp = [];
    const orig = s.onPress;
    s.onPress = function (p) {
      const pl = this.player, before = JSON.stringify(pl.path), act0 = pl.action;
      const o = this.map.pickObject(p.worldX, p.worldY);
      const r = orig.call(this, p);
      window.__pp.push({ picked: o ? (o.type || o.kind) : null, mode: this.build.mode, resting: this.rest.resting,
        changed: JSON.stringify(pl.path) !== before, actionChanged: pl.action !== act0, at: [pl.col, pl.row] });
      return r;
    };
  });
  await T.materials(); await T.materials();
  const p0 = await T.P();
  const [c0, r0] = p0.tile;
  await T.mode(2);
  for (const [c, r] of [[c0 - 2, r0 - 2], [c0 - 1, r0 - 2], [c0, r0 - 2], [c0 + 1, r0 - 2], [c0 + 2, r0 - 2], [c0 + 2, r0 - 1], [c0 + 2, r0]]) await T.tapTile(c, r, 60);
  await T.card(3);
  await T.tapTile(c0 - 2, r0 + 1, 100);
  await T.closeCraft();
  console.log('   built', (await T.structs()).join(' '));
  // targets: fence and campfire sprites + bushes
  const targets = await T.G(() => { const s = window.__game.scene.getScene('game'), m = s.map;
    return [...m.structures, ...m.objects.filter((o) => o.kind === 'bush')].map((o) => ({ x: o.sprite.x, y: o.sprite.y, w: o.sprite.displayWidth, h: o.sprite.displayHeight,
      ox: o.sprite.originX, oy: o.sprite.originY, what: o.type || o.kind, c: o.col, r: o.row })).filter((t) => Math.abs(t.c - 37) < 9 && Math.abs(t.r - 39) < 9); });
  let seed = 9; const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  const walkDests = [[c0 - 4, r0 + 3], [c0 + 4, r0 + 3], [c0 - 4, r0 - 4], [c0 + 5, r0 - 3], [c0, r0 + 4], [c0 - 5, r0]];
  for (const d of walkDests) {
    await T.tapTile(d[0], d[1]);
    for (let i = 0; i < 6; i++) {
      const t = targets[Math.floor(rnd() * targets.length)];
      const left = t.x - t.w * t.ox, top = t.y - t.h * t.oy;
      const wx = left + t.w * (0.3 + rnd() * 0.4), wy = top + t.h * (0.2 + rnd() * 0.5);
      const pp = await T.w2p(wx, wy);
      if (!pp.on || pp.sy > 1000 || pp.sy < 200 || pp.sx > 1550) continue;
      await T.tapPage(pp.x, pp.y);
    }
    await T.stopped(30000);
  }
  const pp = await T.G(() => window.__pp);
  const bad = pp.filter((q) => (q.picked === 'fence' || q.picked === 'campfire' || q.picked === 'bush') && (q.changed || q.actionChanged));
  const counts = {}; for (const q of pp) counts[q.picked] = (counts[q.picked] || 0) + 1;
  console.log('   presses by pick', JSON.stringify(counts));
  R.ok('taps on fences / campfire / bushes never change the walk', bad.length === 0, JSON.stringify(bad.slice(0, 3)));
  R.ok('some taps really hit fences', (counts.fence || 0) >= 5, 'fence ' + counts.fence);
  const M = await T.mon();
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
