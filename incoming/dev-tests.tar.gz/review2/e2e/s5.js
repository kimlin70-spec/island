// Tablet (1024x768) touch: chop, craft, fences around a walk, pen + remove, tent, test window, rest-button area when hidden
const { open, report } = require('./lib.js');
const R = report('s5');
(async () => {
  const T = await open({ w: 1024, h: 768, touch: true });
  // 1. tree 37,35 by touch
  await T.tapObject(37, 35);
  await T.sleep(200);
  let p = await T.P();
  R.ok('touch tree: walks to chop', p.moving && p.action, JSON.stringify(p));
  await T.W(() => { const o = window.__game.scene.getScene('game').map.objectAt(37, 35); return o && o.kind === 'stump'; }, null, 60000);
  await T.materials();
  await T.mode(0); await T.card(1);
  p = await T.P();
  R.ok('touch: axe and pickaxe crafted', p.tools === 'dagger,axe,pickaxe', JSON.stringify(p));
  await T.closeCraft();
  // 2. dig the stump by touch
  await T.tapObject(37, 35);
  await T.W(() => !window.__game.scene.getScene('game').map.objectAt(37, 35), null, 30000);
  R.ok('touch: stump dug', true);
  await T.stopped();
  // 3. world tap where the (hidden) rest button would be: walks
  const before = (await T.P()).tile;
  await T.ui(960, 1132, 300);
  p = await T.P();
  const pr = (await T.presses()).slice(-1)[0];
  R.ok('touch the hidden rest-button area: world receives it', pr && Math.abs(pr.wy - 0) >= 0, JSON.stringify(pr));
  console.log('   after tapping 960,1132:', JSON.stringify(p), 'from', before);
  await T.stopped();
  // 4. pen around the player by touch, then remove a side fence by touch and walk out
  p = await T.P();
  const [c0, r0] = p.tile;
  await T.mode(2);
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) await T.tapTile(c0 + dc, r0 + dr, 60);
  let S = await T.structs();
  const ringOk = S.filter((x) => x.startsWith('fence')).length;
  R.ok('touch: ring built', ringOk === 8, S.join(' '));
  await T.closeCraft();
  await T.tapTile(c0 + 3, r0 - 1, 300);
  p = await T.P();
  R.ok('touch: fenced in, tap outside does nothing', !p.moving && p.tile.join() === [c0, r0].join(), JSON.stringify(p));
  await T.mode(5);
  await T.tapTile(c0 + 1, r0, 200);       // side fence
  await T.closeCraft();
  await T.tapTile(c0 + 4, r0, 200);
  p = await T.P();
  R.ok('touch: after removing a side fence, walks out', p.moving, JSON.stringify(p));
  await T.stopped();
  // 5. tent next to the player by touch, enter, test window, rest button
  p = await T.P();
  await T.mode(4);
  const t = p.tile;
  let placed = false;
  for (const [dc, dr] of [[2, -2], [2, 1], [-3, 1], [1, -3], [-3, -3], [3, 3]]) {
    const pp = await T.w2p(((t[0] + dc + 0.5) - (t[1] + dr + 0.5)) * 40, ((t[0] + dc + 0.5) + (t[1] + dr + 0.5)) * 20);
    if (pp.sy > 700) continue;
    await T.tapPage(pp.x, pp.y); await T.sleep(200);
    if ((await T.structs()).some((x) => x.startsWith('tent'))) { placed = true; break; }
  }
  R.ok('touch: tent placed', placed, (await T.structs()).join(' '));
  await T.closeCraft();
  const ti = await T.G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent');
    return t ? { x: t.sprite.x, y: t.sprite.y, h: t.sprite.displayHeight * t.sprite.originY } : null; });
  if (ti) {
    await T.tapWorld(ti.x, ti.y - ti.h * 0.5);
    await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
    await T.sleep(300);
    await T.debugBtn(); await T.debugItem(1); await T.debugItem(3);
    let g = await T.G(() => { const s = window.__game.scene.getScene('game'); return { night: s.clock.isNight, speed: s.speed }; });
    R.ok('touch: night + x3 while resting', g.night && g.speed === 12, JSON.stringify(g));
    await T.debugItem(2); await T.debugItem(3); await T.debugItem(4);
    g = await T.G(() => { const s = window.__game.scene.getScene('game'); return { night: s.clock.isNight, speed: s.speed, label: s.clock.label }; });
    R.ok('touch: morning, x1, still resting (x4)', !g.night && g.speed === 4, JSON.stringify(g));
    await T.ui(960, 1132, 400);
    p = await T.P();
    R.ok('touch: rest button exits', !p.resting, JSON.stringify(p));
  }
  const M = await T.mon();
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.page.screenshot({ path: __dirname + '/s5_end.png' });
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
