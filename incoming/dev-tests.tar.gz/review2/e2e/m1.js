// Measurement only: how much of a tile next to fences can still be tapped as ground (pickObject null)?
const { open } = require('./lib.js');
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const r = await T.G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    const out = {};
    const tappable = (c, r) => {
      const cx = (c - r) * 40, cy = (c + r) * 20;
      let n = 0, tot = 0, fence = 0, other = 0;
      for (let dy = -20; dy < 20; dy++) for (let dx = -40; dx < 40; dx++) {
        const x = cx + dx + 0.5, y = cy + dy + 0.5;
        const tc = Math.floor((x / 40 + y / 20) / 2 + 0.5), tr = Math.floor((y / 20 - x / 40) / 2 + 0.5);
        if (tc !== c || tr !== r) continue;
        tot++;
        const o = m.pickObject(x, y);
        if (!o) n++; else if (o.type === 'fence') fence++; else other++;
      }
      return { ground: n, fence, other, tot };
    };
    const ring = (c0, r0, skip) => { for (let dc = -1; dc <= 1; dc++) for (let dr = -1; dr <= 1; dr++) { if (!dc && !dr) continue; if (skip && skip.some(([a, b]) => a === c0 + dc && b === r0 + dr)) continue; s.build.place('fence', [{ col: c0 + dc, row: r0 + dr }]); } };
    // A: pen around 40,39 open on the left side (39,39)
    ring(40, 39, [[39, 39]]);
    out.A_inner = tappable(40, 39);
    out.A_gap = tappable(39, 39);
    // B: a single fence wall row 44: tiles behind it (row 43) and in front (row 45)
    for (let c = 33; c <= 37; c++) s.build.place('fence', [{ col: c, row: 44 }]);
    out.B_behind = tappable(35, 43);
    out.B_front = tappable(35, 45);
    // C: screen-straight wall (c+r const) 30..34
    for (let i = 0; i < 5; i++) s.build.place('fence', [{ col: 42 + i, row: 34 - i }]);
    out.C_behind = tappable(43, 32);   // c+r = 75 (behind the wall c+r=76)
    out.C_front = tappable(44, 33);    // c+r = 77
    // D: 2-wide pen interior: ring around 2x1 interior
    return out;
  });
  console.log(JSON.stringify(r, null, 1));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
