// Chaos play with the real mouse (or touch): random taps on ground / trees / rocks / stumps / structures, crafting,
// building fences, campfires and the tent while walking, removing, tent in/out, speed, night/morning.
// In-page monitors (read only): body never on a blocked tile, never stopped between tiles, the planned path is always legal.
const { open, report } = require('./lib.js');
const R = report('s6');
const SEED = +(process.env.SEED || 3);
let rs = SEED;
const rnd = () => { rs = (rs * 1103515245 + 12345) & 0x7fffffff; return rs / 0x7fffffff; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const STEPS = +(process.env.STEPS || 60);
const TOUCH = !!process.env.TOUCH;

(async () => {
  const T = TOUCH ? await open({ w: 1024, h: 768, touch: true }) : await open({ w: 1920, h: 1200 });
  await T.G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    window.__pathBad = [];
    s.events.on('postupdate', () => {
      const p = s.player;
      let from = p.tile;
      for (let i = 0; i < p.path.length; i++) {
        const b = p.path[i];
        const adj = Math.max(Math.abs(b.col - from.col), Math.abs(b.row - from.row)) <= 1;
        if (!adj || !p.canStep(from, b)) { if (window.__pathBad.length < 30) window.__pathBad.push({ i, from: [from.col, from.row], to: [b.col, b.row], adj, at: [p.col, p.row] }); break; }
        from = b;
      }
    });
  });
  const st = () => T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player, u = window.__game.scene.getScene('ui');
    return { col: p.col, row: p.row, tile: [p.tile.col, p.tile.row], path: p.path.map((t) => [t.col, t.row]), moving: p.moving, resting: s.rest.resting,
             wood: s.inventory.count('wood'), stone: s.inventory.count('stone'), mode: s.build.mode, open: u.craftOpen, tools: s.tools.slice(), speed: s.debugSpeed,
             tent: !!s.map.structures.find((x) => x.type === 'tent') }; });
  // visible candidates, chosen in the page
  const candidates = (kind) => T.G(([kind]) => {
    const s = window.__game.scene.getScene('game'), p = s.player, m = s.map, cam = s.cameras.main;
    const scr = (wx, wy) => ({ sx: wx - cam.midPoint.x + cam.width / 2, sy: wy - cam.midPoint.y + cam.height / 2 });
    const okScr = (q) => q.sx > 150 && q.sx < 1500 && q.sy > 240 && q.sy < 700;
    const out = [];
    if (kind === 'ground') {
      for (let r = p.tile.row - 10; r <= p.tile.row + 10; r++) for (let c = p.tile.col - 10; c <= p.tile.col + 10; c++) {
        if (!m.isWalkable(c, r)) continue;
        const wx = (c - r) * 40, wy = (c + r) * 20;
        if (!okScr(scr(wx, wy)) || m.pickObject(wx, wy)) continue;
        out.push({ c, r, wx, wy });
      }
    } else {
      const list = kind === 'node' ? m.objects.filter((o) => o.node) : m.structures;
      for (const o of list) {
        const sp = o.sprite;
        const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY;
        // a few opaque pixels that pick this object
        for (let k = 0; k < 40; k++) {
          const wx = left + 3 + Math.random() * (sp.displayWidth - 6), wy = top + 3 + Math.random() * (sp.displayHeight - 6);
          if (!okScr(scr(wx, wy))) continue;
          if (m.pickObject(wx, wy) !== o) continue;
          out.push({ c: o.col, r: o.row, wx, wy, what: (o.type || o.kind) });
          break;
        }
      }
    }
    return out;
  }, [kind]);
  const reachableGround = (c, r) => T.G(([c, r]) => { const s = window.__game.scene.getScene('game'), p = s.player;
    const save = p.path.slice(); const okk = p.routeTo([{ col: c, row: r }]); p.path = save; return okk; }, [c, r]);
  if (process.env.FAST) { await T.debugBtn(); await T.debugItem(3); await T.debugItem(4); }
  const closeAll = async () => { const s = await st(); if (s.open) await T.closeCraft(); };
  const counts = {};
  let tapNoWalk = 0;

  for (let step = 0; step < STEPS; step++) {
    const s = await st();
    const act = s.resting ? pick(['exitButton', 'exitTent', 'night', 'morning', 'speed', 'buildWhileResting'])
      : pick(['ground', 'ground', 'ground', 'node', 'node', 'struct', 'buildWalk', 'buildWalk', 'buildWalk', 'buildWalk', 'campfireWalk', 'tentWalk', 'remove', 'speed', 'night', 'morning', 'craftTool', 'tapTent']);
    counts[act] = (counts[act] || 0) + 1;
    try {
      if (act === 'ground') {
        await closeAll();
        const c = await candidates('ground');
        if (!c.length) continue;
        const q = pick(c);
        const reach = await reachableGround(q.c, q.r);
        await T.tapWorld(q.wx, q.wy); await T.sleep(80);
        const s2 = await st();
        const there = s2.tile[0] === q.c && s2.tile[1] === q.r && !s2.moving;
        if (reach && !s2.moving && !there) { tapNoWalk++; console.log('   ground tap did not walk', JSON.stringify(q), JSON.stringify(s2), JSON.stringify((await T.presses()).slice(-1))); }
        if (rnd() < 0.5) await T.stopped(30000);
      } else if (act === 'node') {
        await closeAll();
        const c = await candidates('node');
        if (!c.length) continue;
        const q = pick(c);
        await T.tapWorld(q.wx, q.wy);
        await T.sleep(Math.floor(rnd() * 2500));
      } else if (act === 'struct') {
        await closeAll();
        const c = (await candidates('struct')).filter((q) => q.what !== 'tent');
        if (!c.length) continue;
        const q = pick(c);
        const before = await st();
        await T.tapWorld(q.wx, q.wy); await T.sleep(150);
        const after = await st();
        // tapping a fence or campfire never changes the walk (judged by what the GAME picked)
        const pr = (await T.presses()).slice(-1)[0];
        const pickedStruct = pr && pr.picked && /^(fence|campfire)@/.test(pr.picked);
        if (pickedStruct && JSON.stringify(before.path.slice(1)) !== JSON.stringify(after.path.slice(1)) && !(before.moving && !after.moving)) {
          console.log('   tapping', pr.picked, 'changed the path', JSON.stringify(before.path), '->', JSON.stringify(after.path));
          R.ok('tap on ' + pr.picked + ' does not re-route', false);
        }
      } else if (act === 'buildWalk' || act === 'campfireWalk') {
        await closeAll();
        if (s.wood < 12 || s.stone < 6) await T.materials();
        await T.craftBtn();
        const c = (await candidates('ground'));
        const far = [];
        for (const q of c) if (Math.hypot(q.c - s.tile[0], q.r - s.tile[1]) >= 6) far.push(q);
        if (!far.length) continue;
        const q = pick(far);
        await T.tapWorld(q.wx, q.wy);
        await T.card(act === 'campfireWalk' ? 3 : 2);
        const n = 1 + Math.floor(rnd() * 5);
        for (let j = 0; j < n; j++) {
          const s2 = await st();
          if (!s2.moving) break;
          const steps = [s2.tile, ...s2.path];
          const cand = [];
          for (let i = 1; i < steps.length; i++) {
            const a = steps[i - 1], b = steps[i];
            if (a[0] !== b[0] && a[1] !== b[1]) cand.push([b[0], a[1]], [a[0], b[1]]);
            cand.push(b);
            cand.push([b[0] + 1, b[1] - 1], [b[0] - 1, b[1] + 1], [b[0] + 1, b[1] + 1], [b[0] - 1, b[1] - 1]);
          }
          const t = pick(cand);
          const pp = await T.w2p((t[0] - t[1]) * 40, (t[0] + t[1]) * 20);
          if (pp.sx < 130 || pp.sx > 1550 || pp.sy < 230 || pp.sy > 700) continue;
          await T.tapPage(pp.x, pp.y);
        }
        await T.stopped(30000);
      } else if (act === 'tentWalk') {
        if (s.tent) continue;
        await closeAll();
        if (s.wood < 12 || s.stone < 6) await T.materials();
        await T.craftBtn();
        const c = (await candidates('ground')).filter((q) => Math.hypot(q.c - s.tile[0], q.r - s.tile[1]) >= 6);
        if (!c.length) continue;
        const q = pick(c);
        await T.tapWorld(q.wx, q.wy);
        await T.card(4);
        for (let j = 0; j < 4; j++) {
          const s2 = await st();
          if (!s2.moving || !s2.mode) break;
          const steps = [s2.tile, ...s2.path];
          const b = steps[Math.min(steps.length - 1, 1 + Math.floor(rnd() * 3))];
          const fc = b[0] + (rnd() < 0.5 ? 0.5 : -0.5), fr = b[1] + (rnd() < 0.5 ? 0.5 : -0.5);
          const pp = await T.w2p((fc - fr) * 40, (fc + fr) * 20);
          if (pp.sx < 130 || pp.sx > 1550 || pp.sy < 230 || pp.sy > 700) continue;
          await T.tapPage(pp.x, pp.y);
        }
        await T.stopped(30000);
      } else if (act === 'remove') {
        const c = await candidates('struct');
        if (!c.length) continue;
        await T.mode(5);
        const q = pick(c);
        await T.tapWorld(q.wx, q.wy, 100);
      } else if (act === 'speed') {
        await T.debugBtn(); await T.debugItem(3); await T.debugItem(4);
      } else if (act === 'night') {
        await T.debugBtn(); await T.debugItem(1); await T.debugItem(4);
      } else if (act === 'morning') {
        await T.debugBtn(); await T.debugItem(2); await T.debugItem(4);
      } else if (act === 'craftTool') {
        if (s.wood < 6) await T.materials();
        await T.mode(s.tools.includes('axe') ? 1 : 0);
      } else if (act === 'tapTent') {
        await closeAll();
        const c = (await candidates('struct')).filter((q) => q.what === 'tent');
        if (!c.length) continue;
        await T.tapWorld(c[0].wx, c[0].wy);
        await T.sleep(1500);
      } else if (act === 'exitButton') {
        await T.ui(960, 1132, 300);
      } else if (act === 'exitTent') {
        await closeAll();
        const c = (await candidates('struct')).filter((q) => q.what === 'tent');
        if (c.length) await T.tapWorld(c[0].wx, c[0].wy, 300);
      } else if (act === 'buildWhileResting') {
        await T.mode(2);
        const s2 = await st();
        for (let j = 0; j < 3; j++) {
          const t = [s2.tile[0] + Math.round(rnd() * 4 - 2), s2.tile[1] + Math.round(rnd() * 4 - 2)];
          const pp = await T.w2p((t[0] - t[1]) * 40, (t[0] + t[1]) * 20);
          if (pp.sx < 130 || pp.sx > 1550 || pp.sy < 230 || pp.sy > 700) continue;
          await T.tapPage(pp.x, pp.y);
        }
      }
    } catch (e) {
      console.log('   step', step, act, 'error', e.message.split('\n')[0]);
    }
    const M = await T.mon();
    const pb = await T.G(() => window.__pathBad);
    if (M.bad.length || M.frac.length || pb.length || T.errors.length) {
      console.log('STOP at step', step, act, JSON.stringify({ bad: M.bad.slice(0, 3), frac: M.frac.slice(0, 3), pathBad: pb.slice(0, 3), errors: T.errors.slice(0, 3) }));
      break;
    }
  }
  try { await T.stopped(30000); } catch (e) {}
  const M = await T.mon();
  const pb = await T.G(() => window.__pathBad);
  const commits = await T.commits();
  const odd = commits.filter((c) => !c.built && c.mode !== 'remove' && c.open && !c.struct && c.dist <= 7 && !c.occ.includes(c.tile) && c.spot && c.spot.tiles.length === 1);
  console.log('actions', JSON.stringify(counts), 'structures', (await T.structs()).length, 'frames', M.frames);
  for (const c of odd.slice(0, 5)) console.log('   refused for no visible reason', JSON.stringify(c));
  R.ok('taps on reachable ground always walk', tapNoWalk === 0, 'count ' + tapNoWalk);
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('planned path always legal', pb.length === 0, JSON.stringify(pb.slice(0, 3)));
  R.ok('no endless walk', M.longest < 25, 'longest ' + M.longest);
  R.ok('no refusals without a reason', odd.length === 0, 'odd ' + odd.length);
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors.slice(0, 5)));
  await T.page.screenshot({ path: __dirname + '/s6_end_' + SEED + (TOUCH ? 't' : '') + '.png' });
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
