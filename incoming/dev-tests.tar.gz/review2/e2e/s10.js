// Pens built quickly while walking (real clicks): a ring around the destination, and a ring around the tile being entered.
const { open, report } = require('./lib.js');
const R = report('s10');
const TOUCH = !!process.env.TOUCH;
(async () => {
  const T = TOUCH ? await open({ w: 1024, h: 768, touch: true }) : await open({ w: 1920, h: 1200 });
  await T.materials(); await T.materials();
  const st = () => T.G(() => { const s = window.__game.scene.getScene('game'), p = s.player, u = window.__game.scene.getScene('ui');
    return { col: p.col, row: p.row, tile: [p.tile.col, p.tile.row], path: p.path.map((t) => [t.col, t.row]), moving: p.moving, open: u.craftOpen }; });
  const ringTaps = async (c0, r0) => {
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      if (!dc && !dr) continue;
      const pp = await T.w2p(((c0 + dc) - (r0 + dr)) * 40, ((c0 + dc) + (r0 + dr)) * 20);
      if (!pp.on || pp.sy > 700 || pp.sy < 230 || pp.sx > 1550 || pp.sx < 130) continue;
      await T.tapPage(pp.x, pp.y);
    }
  };
  for (const variant of ['aroundDest', 'aroundNext', 'aroundDest', 'aroundNext']) {
    let s = await st();
    if (s.open) await T.closeCraft();
    await T.craftBtn();
    const dest = await T.G(() => {
      const s = window.__game.scene.getScene('game'), p = s.player, m = s.map, cam = s.cameras.main;
      for (let i = 0; i < 800; i++) {
        const c = p.tile.col + Math.round(Math.random() * 12 - 6), r = p.tile.row + Math.round(Math.random() * 12 - 6);
        if (Math.hypot(c - p.col, r - p.row) < 4 || Math.hypot(c - p.col, r - p.row) > 6 || !m.isWalkable(c, r)) continue;
        let free = true; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (!m.isWalkable(c + dc, r + dr)) free = false;
        if (!free) continue;
        const wx = (c - r) * 40, wy = (c + r) * 20, sx = wx - cam.midPoint.x + cam.width / 2, sy = wy - cam.midPoint.y + cam.height / 2;
        if (sx < 250 || sx > 1450 || sy < 300 || sy > 640 || m.pickObject(wx, wy)) continue;
        return [c, r];
      }
      return null; });
    if (!dest) { console.log('   no destination'); continue; }
    await T.tapTile(dest[0], dest[1]);
    await T.card(2);
    s = await st();
    if (variant === 'aroundDest') await ringTaps(dest[0], dest[1]);
    else if (s.path.length) await ringTaps(s.path[0][0], s.path[0][1]);
    await T.stopped(30000);
    const end = await st();
    const commits = await T.commits();
    const built = commits.filter((c) => c.built).map((c) => c.tile), body = commits.filter((c) => !c.built && c.occ.includes(c.tile)).map((c) => c.tile);
    console.log(`   ${variant} dest ${dest} built ${built.length} [${built.join(' ')}] refusedBody [${body.join(' ')}] end ${end.tile}`);
    // try to walk away: tap a far tile; if enclosed nothing happens
    await T.closeCraft();
  }
  const M = await T.mon();
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no endless walk', M.longest < 20, 'longest ' + M.longest);
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.page.screenshot({ path: __dirname + '/s10_end' + (TOUCH ? 't' : '') + '.png' });
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
