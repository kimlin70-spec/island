// Pen flow with the real mouse: fence yourself in, taps outside do nothing, remove a corner (still stuck),
// remove a side fence and walk out, walk back in, re-close the gap while walking out.
const { open, report } = require('./lib.js');
const R = report('s3');
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  await T.materials();
  let p = await T.P();
  const [c0, r0] = p.tile;
  await T.mode(2);
  const ring = [];
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) ring.push([c0 + dc, r0 + dr]);
  for (const [c, r] of ring) await T.tapTile(c, r, 80);
  let S = await T.structs();
  R.ok('8 fences around the player with real clicks', S.length === 8, S.join(' '));
  // the player's own tile cannot be built on
  await T.tapTile(c0, r0, 100);
  S = await T.structs();
  R.ok('own tile refused', S.length === 8);
  await T.closeCraft();
  // taps outside -> nothing
  let moved = 0;
  for (const [c, r] of [[c0 + 3, r0], [c0, r0 + 3], [c0 - 3, r0], [c0 + 2, r0 + 2], [c0 - 2, r0 - 2], [c0 + 3, r0 - 3]]) {
    await T.tapTile(c, r, 250);
    p = await T.P();
    if (p.moving || p.tile.join() !== [c0, r0].join()) { moved++; console.log('moved after tapping', c, r, JSON.stringify(p)); await T.stopped(); }
  }
  R.ok('fenced in: taps outside do nothing', moved === 0, 'moved ' + moved);
  // taps on every fence picture centre -> nothing
  moved = 0;
  for (const [c, r] of ring) {
    const q = await T.pickPoint(c, r);
    if (!q) continue;
    await T.tapWorld(q.wx, q.wy, 200);
    p = await T.P();
    if (p.moving || p.tile.join() !== [c0, r0].join()) { moved++; await T.stopped(); }
  }
  R.ok('fenced in: taps on the fences do nothing', moved === 0, 'moved ' + moved);
  // tap the tree 41,42 (outside) -> nothing
  await T.tapObject(41, 42);
  await T.sleep(300);
  p = await T.P();
  R.ok('fenced in: tapping a tree outside does nothing', !p.moving && !p.action, JSON.stringify(p));

  // remove the front corner fence (c0+1, r0+1)
  await T.mode(5);
  await T.tapTile(c0 + 1, r0 + 1, 200);
  S = await T.structs();
  R.ok('corner fence removed', S.length === 7 && !S.includes(`fence@${c0 + 1},${r0 + 1}`), S.join(' '));
  await T.closeCraft();
  await T.tapTile(c0 + 3, r0 + 3, 300);
  p = await T.P();
  R.ok('corner gap: cannot squeeze out diagonally (agreed)', !p.moving && p.tile.join() === [c0, r0].join(), JSON.stringify(p));

  // remove the side fence (c0, r0+1) and walk out
  await T.mode(5);
  await T.tapTile(c0, r0 + 1, 200);
  S = await T.structs();
  R.ok('side fence removed', S.length === 6, S.join(' '));
  await T.closeCraft();
  await T.tapTile(c0, r0 + 4, 150);
  p = await T.P();
  R.ok('side gap: walks out', p.moving, JSON.stringify(p));
  await T.stopped();
  p = await T.P();
  R.ok('arrived outside', p.tile.join() === [c0, r0 + 4].join(), JSON.stringify(p));
  // walk back in: tap the pen interior ground
  await T.tapTile(c0, r0, 150);
  p = await T.P();
  R.ok('walks back into the pen', p.moving, JSON.stringify(p));
  await T.stopped();
  p = await T.P();
  R.ok('back inside', p.tile.join() === [c0, r0].join(), JSON.stringify(p));

  // walk out again and close the gap behind / ahead while walking
  await T.tapTile(c0 + 1, r0 + 5, 0);
  await T.mode(2);
  // quickly try to build on the gap tile (c0, r0+1) and on the tile after it
  for (let i = 0; i < 6; i++) {
    const s = await T.P();
    if (!s.moving) break;
    await T.tapTile(c0, r0 + 1, 0);
    await T.tapTile(c0, r0 + 2, 0);
  }
  await T.stopped();
  p = await T.P();
  S = await T.structs();
  const b = await T.builds();
  console.log('   end', JSON.stringify(p), '| builds', JSON.stringify(b.slice(-3)));
  const M = await T.mon();
  R.ok('never touching a blocked tile', M.bad.length === 0, JSON.stringify(M.bad.slice(0, 3)));
  R.ok('never stopped between tiles', M.frac.length === 0, JSON.stringify(M.frac.slice(0, 3)));
  R.ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.page.screenshot({ path: __dirname + '/s3_end.png' });
  await T.browser.close();
  process.exit(R.done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
