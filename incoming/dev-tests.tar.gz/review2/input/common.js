// shared helpers for the fence-tap input review
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');

exports.setup = async (opts = {}) => {
  const T = await open(opts);
  const { page, G } = T;
  T.touch = !!opts.touch;
  // game (1920x1200) -> page px
  T.g2p = (x, y) => G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect();
    return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
  // world -> page px (uses the camera as last rendered)
  T.w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.worldView.x) * cam.zoom, sy = (wy - cam.worldView.y) * cam.zoom;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, on: sx >= 0 && sy >= 0 && sx < cam.width && sy < cam.height }; }, [wx, wy]);
  T.tapPage = async (x, y) => { if (T.touch) await page.touchscreen.tap(x, y); else { await page.mouse.move(x, y); await page.mouse.click(x, y); } };
  T.ui = async (x, y, wait = 300) => { const p = await T.g2p(x, y); await T.tapPage(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  T.tapWorld = async (wx, wy, wait = 0) => { const p = await T.w2p(wx, wy); if (!p.on) throw new Error('off ' + wx + ',' + wy); await T.tapPage(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  T.tapTile = (c, r, wait) => T.tapWorld((c - r) * 40, (c + r) * 20, wait);
  T.stopped = () => T.W(() => !window.__game.scene.getScene('game').player.moving, null, 60000);
  // camera settled: worldView unchanged across 3 frames
  T.settle = async () => {
    let last = null, same = 0;
    for (let i = 0; i < 80 && same < 3; i++) {
      const v = await G(() => { const c = window.__game.scene.getScene('game').cameras.main; return c.worldView.x.toFixed(2) + ',' + c.worldView.y.toFixed(2); });
      if (v === last) same++; else same = 0;
      last = v;
      await page.waitForTimeout(120);
    }
  };
  // in-page helpers + press recorder
  await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), m = s.map;
    const R = window.__rv = {};
    R.key = (o) => (o ? (o.type || o.kind) + '@' + o.col + ',' + o.row : null);
    R.mask = (f) => +f.sprite.texture.key.split('_').pop();
    R.rect = (sp) => ({ left: sp.x - sp.displayWidth * sp.originX, top: sp.y - sp.displayHeight * sp.originY });
    const cache = {};
    R.alphaMap = (key, frameName) => {
      const id = key + '#' + frameName;
      if (cache[id]) return cache[id];
      const fr = g.textures.getFrame(key, frameName), c = document.createElement('canvas');
      c.width = fr.cutWidth; c.height = fr.cutHeight;
      const ctx = c.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(fr.source.image, fr.cutX, fr.cutY, fr.cutWidth, fr.cutHeight, 0, 0, fr.cutWidth, fr.cutHeight);
      const d = ctx.getImageData(0, 0, fr.cutWidth, fr.cutHeight).data, a = new Uint8Array(fr.cutWidth * fr.cutHeight);
      for (let i = 0; i < a.length; i++) a[i] = d[i * 4 + 3];
      return (cache[id] = { w: fr.cutWidth, h: fr.cutHeight, a });
    };
    R.alphaAt = (o, x, y) => { const sp = o.sprite, r = R.rect(sp); const lx = Math.floor(x - r.left), ly = Math.floor(y - r.top);
      if (lx < 0 || ly < 0 || lx >= sp.width || ly >= sp.height) return 0;
      const M = R.alphaMap(sp.texture.key, sp.frame.name); return M.a[ly * M.w + lx]; };
    R.tileAt = (x, y) => ({ col: Math.floor((x / 40 + y / 20) / 2 + 0.5), row: Math.floor((y / 20 - x / 40) / 2 + 0.5) });
    R.snap = () => { const p = s.player; return { col: +p.col.toFixed(3), row: +p.row.toFixed(3), tile: p.tile.col + ',' + p.tile.row, path: p.path.map((t) => t.col + ',' + t.row).join(' '),
      action: p.action ? R.key(p.action.target) : null, cursor: s.cursor.visible, cursorAt: s.cursor.visible ? R.tileAt(s.cursor.x, s.cursor.y) : null, resting: s.rest.resting, mode: s.build.mode }; };
    R.fences = () => m.structures.filter((x) => x.type === 'fence');
    R.structs = () => m.structures.map((x) => R.key(x) + (x.type === 'fence' ? '#' + R.mask(x) : ''));
    window.__presses = [];
    const orig = s.onPress;
    s.onPress = function (p) {
      const o = this.map.pickObject(p.worldX, p.worldY);
      window.__presses.push({ wx: +p.worldX.toFixed(2), wy: +p.worldY.toFixed(2), touch: !!p.wasTouch, picked: R.key(o), tile: R.tileAt(p.worldX, p.worldY) });
      return orig.call(this, p);
    };
    // notices
    window.__notices = [];
    s.events.on('notice', (t) => window.__notices.push(t));
  });
  T.snap = () => G(() => window.__rv.snap());
  T.lastPress = () => G(() => window.__presses[window.__presses.length - 1] || null);
  return T;
};

// UI positions (1920x1200 game coords)
exports.UI = {
  craft: [1824, 1104],
  card: (i) => [776 + 20 + i * 182 + 85, 898],
  test: [1852, 328],
  testItem: (i) => [1746, 402 + i * 66],
  rest: [960, 1132],
};
