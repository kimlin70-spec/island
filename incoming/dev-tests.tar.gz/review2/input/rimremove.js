// Desktop: remove mode, click the rim (alpha 90..110) of fence F1's upper rail where it lies over the tile of fence F2 behind it
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G } = T;
  try {
    await T.settle();
    await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(2), 400);
    // two short walls, one behind the other (rows 36 and 37)
    for (const [c, r] of [[36, 36], [37, 36], [38, 36], [36, 37], [37, 37], [38, 37]]) await T.tapWorld((c - r) * 40, (c + r) * 20 - 10, 60);
    await T.ui(...UI.card(5), 400);    // remove mode
    console.log('built', (await G(() => window.__rv.structs())).join(' '));
    const rims = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, out = [];
      const f = m.structureAt(37, 37), sp = f.sprite, rc = R.rect(sp);
      for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
        const x = rc.left + i + 0.5, y = rc.top + j + 0.5, a = R.alphaAt(f, x, y), t = R.tileAt(x, y), st = m.structureAt(t.col, t.row);
        if (a < 90 || a > 110 || !st || st === f || m.pickObject(x, y, m.structures)) continue;
        out.push({ x, y, a, t: t.col + ',' + t.row, under: R.key(st) });
      }
      return out;
    });
    console.log('rim pixels of fence@37,37 over another fence tile with nothing picked there:', rims.length, J(rims.slice(0, 2)));
    await G(() => { const s = window.__game.scene.getScene('game'), R = window.__rv, b = s.build, inner = b.commit.bind(b); window.__dropped = 0;
      b.commit = (wx, wy) => { let best = 0; for (const f of R.fences()) best = Math.max(best, R.alphaAt(f, wx, wy));
        if (best < 90 || best > 110) { window.__dropped++; return; } window.__commitAt = { wx, wy, best }; return inner(wx, wy); }; });
    for (const q of rims) {
      const before = (await G(() => window.__rv.structs())).length;
      await T.tapWorld(q.x, q.y, 150);
      const after = await G(() => window.__rv.structs());
      if (after.length < before) {
        const at = await G(() => window.__commitAt);
        console.log('REMOVE click on the rim of fence@37,37 (alpha at press', at.best + ') removed:', ['fence@36,36#1', 'fence@37,36#3', 'fence@38,36#2', 'fence@36,37#1', 'fence@37,37#3', 'fence@38,37#2'].filter((k) => !after.includes(k)).join(' '), '| left:', after.join(' '));
        break;
      }
    }
    console.log('dropped', await G(() => window.__dropped), 'errors', J(T.errors));
  } catch (e) { console.error('CRASH', e); }
  finally { await T.browser.close(); }
})();
