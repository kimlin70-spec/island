// Desktop (1920x1200, mouse): fence taps for all 16 fence pictures, overlaps, remove/build/rest modes
const { setup, UI } = require('./common.js');
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
const J = JSON.stringify;

const FENCES = [
  [38, 41], [39, 41], [40, 41], [38, 42], [39, 42], [40, 42], [38, 43], [39, 43], [40, 43],   // A 3x3 grid
  [41, 38], [42, 38], [43, 38],                                                             // B line along col
  [34, 38], [34, 39], [34, 40],                                                             // C line along row
  [36, 44],                                                                                 // D isolated (bush 37,44 in front)
  [36, 34], [38, 34], [36, 36],                                                             // E around tree 37,35 (behind, tie, tie)
  [34, 42], [33, 43], [32, 41],                                                             // F around campfire 33,42
  [39, 35], [42, 36],                                                                       // H around tent 40..41,35..36
];

(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const t0 = Date.now();
  try {
    await T.settle();
    const start = await T.snap();
    console.log('start', J(start));
    // pre-check: all planned tiles buildable
    const pre = await G((F) => { const s = window.__game.scene.getScene('game');
      return F.filter(([c, r]) => !s.build.canBuildAt(c, r)).concat([[33, 42]].filter(([c, r]) => !s.build.canBuildAt(c, r))); }, FENCES);
    ok('planned tiles are buildable', pre.length === 0, J(pre));
    const objs = await G(() => { const m = window.__game.scene.getScene('game').map;
      return [[37, 35], [33, 37], [37, 44], [35, 35]].map(([c, r]) => { const o = m.objectAt(c, r); return o ? o.kind + ':' + o.key : null; }); });
    console.log('objects near:', J(objs));

    // materials x2
    await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    // fence mode
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(2), 400);
    ok('fence mode on', (await T.snap()).mode === 'fence');
    for (const [c, r] of FENCES) await T.tapWorld((c - r) * 40, (c + r) * 20 - 10, 60);   // a bit above the centre (window top is y=736)
    await T.ui(...UI.card(3), 300);
    await T.tapWorld((33 - 42) * 40, (33 + 42) * 20 - 8, 100);
    await T.ui(...UI.card(4), 300);
    await T.tapWorld((40.5 - 35.5) * 40, (40.5 + 35.5) * 20, 200);
    const modeAfterTent = (await T.snap()).mode;
    await T.ui(...UI.craft, 400);
    const structs = await G(() => window.__rv.structs());
    console.log('built:', structs.join(' '));
    const masks = new Set(structs.filter((x) => x.startsWith('fence')).map((x) => +x.split('#')[1]));
    ok('all 24 fences + campfire + tent built by real clicks', structs.length === 26 && structs.some((x) => x.startsWith('campfire@33,42')) && structs.some((x) => x.startsWith('tent@40,35')), structs.length + ' modeAfterTent=' + modeAfterTent);
    ok('all 16 fence pictures present', masks.size === 16, J([...masks].sort((a, b) => a - b)));
    const s1 = await T.snap();
    ok('player did not move while building', s1.tile === start.tile && !s1.path, J(s1));

    // ---------- 1. exhaustive in-page check of every pixel of every fence picture ----------
    const ex = await G(() => {
      const g = window.__game, s = g.scene.getScene('game'), m = s.map, R = window.__rv, p = s.player;
      const base = R.snap(), out = { fences: {}, fails: [], covered: {}, groundTaps: 0, groundMoves: 0, groundWrong: [] }, seenTile = {};
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp);
        const st = { mask: R.mask(f), opaque: 0, picked: 0, overOther: 0, overOtherWalk: 0, semiOverOtherWalk: 0, clearOverOtherWalk: 0, tiles: {} };
        for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5, a = R.alphaAt(f, x, y), t = R.tileAt(x, y);
          const own = t.col === f.col && t.row === f.row, walk = m.isWalkable(t.col, t.row);
          const o = m.pickObject(x, y);
          if (a > 110) {
            st.opaque++;
            if (o !== f) { const k = R.key(f) + ' under ' + R.key(o); out.covered[k] = (out.covered[k] || 0) + 1; continue; }
            st.picked++;
            if (!own) { st.overOther++; st.tiles[t.col + ',' + t.row] = 1; }
            if (!own && walk) st.overOtherWalk++;
            window.__presses.length = 0;
            s.onPress({ wasTouch: false, button: 0, worldX: x, worldY: y });
            const after = R.snap();
            if (after.path || after.cursor || after.action || after.resting || after.tile !== base.tile) {
              out.fails.push({ f: R.key(f), x, y, after });
              p.path = []; p.stopAction(); s.cursor.setVisible(false); s.cursorLeft = 0;
            }
          } else {
            if (!own && walk) { if (a > 0) st.semiOverOtherWalk++; else st.clearOverOtherWalk++; }
            if (!o) {      // ground tap: must be exactly walkTo(tile under the pointer). The result depends only on the tile.
              out.groundTaps++;
              const tk = t.col + ',' + t.row;
              if (seenTile[tk]) continue;
              seenTile[tk] = 1;
              s.onPress({ wasTouch: false, button: 0, worldX: x, worldY: y });
              const after = R.snap();
              if (after.path) {
                out.groundMoves++;
                const last = after.path.split(' ').pop();
                if (last !== t.col + ',' + t.row || !after.cursor || after.cursorAt.col !== t.col || after.cursorAt.row !== t.row) out.groundWrong.push({ x, y, t, after });
              }
              p.path = []; p.stopAction(); s.cursor.setVisible(false); s.cursorLeft = 0;
            }
          }
        }
        st.tiles = Object.keys(st.tiles).join(' ');
        out.fences[R.key(f)] = st;
      }
      window.__presses.length = 0;
      return out;
    });
    for (const [k, v] of Object.entries(ex.fences)) console.log('  ', k, J(v));
    console.log('   opaque fence pixels covered by a front picture:', J(ex.covered));
    console.log('   ground taps inside fence rects:', ex.groundTaps, 'of which walked:', ex.groundMoves);
    ok('exhaustive: no opaque fence pixel (front-most) moves the player / shows cursor', ex.fails.length === 0, J(ex.fails.slice(0, 5)));
    ok('exhaustive: transparent pixels in fence rects act exactly like ground taps', ex.groundWrong.length === 0, J(ex.groundWrong.slice(0, 3)));

    // ---------- 2. real clicks on opaque points of each of the 16 pictures ----------
    const targets = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, byMask = {};
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp), pts = [];
        for (let j = 1; j < sp.height - 1; j++) for (let i = 1; i < sp.width - 1; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5;
          if (R.alphaAt(f, x, y) <= 110) continue;
          let inner = true;
          for (let dy = -1.5; dy <= 1.5 && inner; dy += 1.5) for (let dx = -1.5; dx <= 1.5 && inner; dx += 1.5) if (m.pickObject(x + dx, y + dy) !== f) inner = false;
          if (!inner) continue;
          const t = R.tileAt(x, y), own = t.col === f.col && t.row === f.row, walk = m.isWalkable(t.col, t.row);
          pts.push({ x, y, t: t.col + ',' + t.row, cls: own ? 2 : walk ? 0 : 1 });
        }
        const mask = R.mask(f), score = pts.filter((q) => q.cls === 0).length;
        if (!byMask[mask] || score > byMask[mask].score) byMask[mask] = { f: R.key(f), score, pts };
      }
      const out = [];
      for (const [mask, v] of Object.entries(byMask)) {
        const pick = [];
        for (const cls of [0, 1, 2]) {
          const c = v.pts.filter((q) => q.cls === cls);
          const want = cls === 0 ? 3 : 1;
          for (let k = 0; k < want && c.length; k++) pick.push(c[Math.floor((k + 0.5) * c.length / want)]);
        }
        out.push({ mask: +mask, f: v.f, overWalk: v.score, pick });
      }
      return out;
    });
    let clicks = 0, moved = [], wrongPick = [], cursorShown = [];
    for (const tg of targets) {
      for (const q of tg.pick) {
        await G(() => { window.__presses.length = 0; });
        await T.tapWorld(q.x, q.y, 120);
        clicks++;
        const st = await T.snap(), pr = await T.lastPress();
        if (!pr || pr.picked !== tg.f) wrongPick.push({ mask: tg.mask, q, pr });
        if (st.path || st.tile !== start.tile || st.action) { moved.push({ mask: tg.mask, q, pr, st }); await T.stopped(); }
        if (st.cursor) cursorShown.push({ mask: tg.mask, q });
      }
      console.log(`   mask ${tg.mask} ${tg.f}: inner opaque points over other walkable tiles ${tg.overWalk}; clicked ${tg.pick.map((q) => q.t + '/' + ['walk', 'blocked', 'own'][q.cls]).join(' ')}`);
    }
    ok('real clicks: every click on an opaque fence point picked that fence', wrongPick.length === 0, `${wrongPick.length}/${clicks} ` + J(wrongPick.slice(0, 3)));
    ok('real clicks: no click on a fence moved the player', moved.length === 0, J(moved.slice(0, 3)));
    ok('real clicks: no move cursor shown', cursorShown.length === 0, J(cursorShown.slice(0, 3)));

    // ---------- 3. overlaps: front-most picture is picked ----------
    const pairs = await G(() => {
      const g = window.__game, s = g.scene.getScene('game'), m = s.map, R = window.__rv;
      const find = (c, r) => m.structureAt(c, r) || m.objectAt(c, r);
      const res = [];
      const check = (fc, fr, oc, or) => {
        const f = m.structureAt(fc, fr), o = find(oc, or);
        if (!f || !o) { res.push({ pair: [fc, fr, oc, or], missing: true }); return; }
        const sp = f.sprite, rc = R.rect(sp), both = [];
        let pickedFront = 0, pickedBack = 0;
        for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5;
          if (R.alphaAt(f, x, y) <= 110 || R.alphaAt(o, x, y) <= 110) continue;
          const front = f.sprite.depth > o.sprite.depth ? f : o.sprite.depth > f.sprite.depth ? o : null;
          const p = m.pickObject(x, y);
          if (p === front) pickedFront++; else pickedBack++;
          let inner = true;
          for (let dy = -1.5; dy <= 1.5 && inner; dy += 1.5) for (let dx = -1.5; dx <= 1.5 && inner; dx += 1.5) if (m.pickObject(x + dx, y + dy) !== p) inner = false;
          if (inner) both.push({ x, y, p: R.key(p) });
        }
        // display-list order (what is drawn later is on top)
        const list = s.children.list, fi = list.indexOf(f.sprite), oi = list.indexOf(o.sprite);
        res.push({ fence: R.key(f), other: R.key(o), fenceDepth: f.sprite.depth, otherDepth: o.sprite.depth, drawnOnTop: fi > oi ? 'fence' : 'other',
                   bothOpaque: pickedFront + pickedBack, pickedFront, pickedBack, sample: both.length ? both[Math.floor(both.length / 2)] : null });
      };
      check(34, 38, 33, 37);   // rock behind fence
      check(36, 44, 37, 44);   // bush in front of fence
      check(36, 34, 37, 35);   // tree in front of fence
      check(38, 34, 37, 35);   // same depth as tree
      check(36, 36, 37, 35);   // same depth as tree
      check(34, 42, 33, 42); check(33, 43, 33, 42); check(32, 41, 33, 42);   // campfire
      check(42, 36, 40, 35); check(39, 35, 40, 35);   // tent
      return res;
    });
    for (const pr of pairs) console.log('  ', J(pr));
    ok('overlaps: where both pictures are opaque, the one drawn on top is always picked', pairs.every((p) => p.pickedBack === 0 && (p.bothOpaque === 0 || (p.drawnOnTop === 'fence') === (p.fenceDepth > p.otherDepth) || p.fenceDepth === p.otherDepth)), '');
    // real clicks on overlap points where the result must be "nothing happens"
    for (const pr of pairs.filter((p) => p.sample && !/^(tree|tent)/.test(p.sample.p))) {
      await G(() => { window.__presses.length = 0; window.__notices.length = 0; });
      await T.tapWorld(pr.sample.x, pr.sample.y, 150);
      const st = await T.snap(), lp = await T.lastPress(), nt = await G(() => window.__notices.slice());
      ok(`overlap click ${pr.fence} vs ${pr.other}: picked ${lp && lp.picked}, nothing happens`, lp && lp.picked === pr.sample.p && !st.path && !st.action && !st.cursor && !st.resting, J({ st, nt }));
    }

    // ---------- 4. remove mode: tap the upper rail ----------
    const rm = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv;
      const pt = (c, r, wantTile) => { const f = m.structureAt(c, r), sp = f.sprite, rc = R.rect(sp), pts = [];
        for (let j = 1; j < sp.height - 1; j++) for (let i = 1; i < sp.width - 1; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5, t = R.tileAt(x, y);
          if (t.col === c && t.row === r) continue;
          if (wantTile && (t.col + ',' + t.row) !== wantTile) continue;
          let inner = true;
          for (let dy = -1.5; dy <= 1.5 && inner; dy += 1.5) for (let dx = -1.5; dx <= 1.5 && inner; dx += 1.5) if (m.pickObject(x + dx, y + dy, m.structures) !== f) inner = false;
          if (inner) pts.push({ x, y, t: t.col + ',' + t.row, walk: m.isWalkable(t.col, t.row) });
        }
        pts.sort((a, b) => a.y - b.y);   // highest point first (top of the post / upper rail)
        return pts[Math.floor(pts.length * 0.2)]; };
      return { b: pt(41, 38), centre: pt(39, 42), left: pt(38, 42) };
    });
    console.log('   remove targets', J(rm));
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(5), 400);
    const before = await G(() => window.__rv.structs());
    await T.tapWorld(rm.b.x, rm.b.y, 300);
    let after = await G(() => window.__rv.structs());
    ok('remove mode: tapping the upper part of fence 41,38 (over ' + rm.b.t + ') removes 41,38', !after.some((x) => x.startsWith('fence@41,38')) && after.length === before.length - 1 && after.includes('fence@42,38#1'), J(after.filter((x) => /@4[123],38/.test(x))));
    await T.tapWorld(rm.centre.x, rm.centre.y, 300);
    await T.tapWorld(rm.left.x, rm.left.y, 300);
    after = await G(() => window.__rv.structs());
    ok('remove mode: grid centre 39,42 and left edge 38,42 removed by their upper parts', !after.some((x) => x.startsWith('fence@39,42') || x.startsWith('fence@38,42')) && after.length === before.length - 3, J(after.filter((x) => /@(38|39|40),4[123]/.test(x))));
    const s4 = await T.snap();
    ok('remove mode: player did not move', s4.tile === start.tile && !s4.path, J(s4));
    await T.ui(...UI.craft, 400);

    // ---------- 5. U-shaped pen: rails over the pen inside ----------
    const pen = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, p = s.player;
      const reach = !!s.player.routeTo && (() => { const saved = p.path.slice(); const okk = p.routeTo([{ col: 39, row: 42 }]); const len = p.path.length; p.path = saved; return okk && len > 0; })();
      const pts = [];
      for (const [c, r] of [[39, 43], [40, 42], [40, 43]]) {
        const f = m.structureAt(c, r), sp = f.sprite, rc = R.rect(sp), cand = [];
        for (let j = 1; j < sp.height - 1; j++) for (let i = 1; i < sp.width - 1; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5, t = R.tileAt(x, y);
          if (t.col !== 39 || t.row !== 42) continue;
          let inner = true;
          for (let dy = -1.5; dy <= 1.5 && inner; dy += 1.5) for (let dx = -1.5; dx <= 1.5 && inner; dx += 1.5) if (m.pickObject(x + dx, y + dy) !== f) inner = false;
          if (inner) cand.push({ f: R.key(f), x, y });
        }
        if (cand.length) pts.push(cand[Math.floor(cand.length / 2)]);
      }
      return { reach, pts };
    });
    ok('pen inside 39,42 is reachable through the gap (so the old code would have walked in)', pen.reach);
    for (const q of pen.pts) {
      await T.tapWorld(q.x, q.y, 150);
      const st = await T.snap(), lp = await T.lastPress();
      ok(`pen: tapping ${q.f} where it covers the pen inside does nothing`, lp.picked === q.f && !st.path && !st.cursor, J({ lp, st }));
    }

    // ---------- 6. build mode: tapping a fence's upper rail builds on the tile under the pointer (as before) ----------
    const bpt = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv;
      const f = m.structureAt(42, 38), sp = f.sprite, rc = R.rect(sp);
      for (let j = 1; j < sp.height - 1; j++) for (let i = 1; i < sp.width - 1; i++) {
        const x = rc.left + i + 0.5, y = rc.top + j + 0.5, t = R.tileAt(x, y);
        if ((t.col === 42 && t.row === 38) || !s.build.canBuildAt(t.col, t.row) || m.pickObject(x, y) !== f) continue;
        const t2 = R.tileAt(x + 1.5, y + 1.5), t3 = R.tileAt(x - 1.5, y - 1.5);
        if (t2.col !== t.col || t2.row !== t.row || t3.col !== t.col || t3.row !== t.row) continue;
        return { x, y, t: t.col + ',' + t.row };
      }
      return null;
    });
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(2), 400);
    const nBefore = (await G(() => window.__rv.structs())).length;
    await T.tapWorld(bpt.x, bpt.y, 300);
    const builtNow = await G(() => window.__rv.structs());
    ok('build mode: tapping the rail of 42,38 builds on the tile under the pointer ' + bpt.t, builtNow.length === nBefore + 1 && builtNow.some((x) => x.startsWith('fence@' + bpt.t)), J(builtNow.slice(-2)));
    const s6 = await T.snap();
    ok('build mode: player did not move', s6.tile === start.tile && !s6.path, J(s6));
    await T.ui(...UI.craft, 400);

    // ---------- 7. campfire and bush taps do nothing ----------
    for (const [label, c, r, dy] of [['campfire', 33, 42, -20], ['bush', 37, 44, -20], ['bush2', 43, 40, -20]]) {
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld((c - r) * 40, (c + r) * 20 + dy, 150);
      const st = await T.snap(), lp = await T.lastPress();
      ok(`${label} tap does nothing (picked ${lp && lp.picked})`, lp && /^(campfire|bush)/.test(lp.picked) && !st.path && !st.cursor && !st.action, J(st));
    }

    // ---------- 8. transparent pixel next to a fence: ground tap ----------
    const gp = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv;
      const f = m.structureAt(36, 44), sp = f.sprite, rc = R.rect(sp), cand = [];
      for (let j = 2; j < sp.height - 2; j++) for (let i = 2; i < sp.width - 2; i++) {
        const x = rc.left + i + 0.5, y = rc.top + j + 0.5, t = R.tileAt(x, y);
        if ((t.col === 36 && t.row === 44) || !m.isWalkable(t.col, t.row)) continue;
        let clear = true;
        for (let dy = -2; dy <= 2 && clear; dy++) for (let dx = -2; dx <= 2 && clear; dx++) { if (m.pickObject(x + dx, y + dy)) clear = false; const tt = R.tileAt(x + dx, y + dy); if (tt.col !== t.col || tt.row !== t.row) clear = false; }
        if (clear) cand.push({ x, y, t: t.col + ',' + t.row });
      }
      return cand.find((q) => q.t === '35,43') || cand.find((q) => q.t === '36,43') || cand[0];
    });
    await G(() => { window.__presses.length = 0; });
    await T.tapWorld(gp.x, gp.y, 100);
    let st8 = await T.snap();
    const lp8 = await T.lastPress();
    ok('transparent point inside the fence picture rect over ' + gp.t + ' walks there with the cursor', lp8.picked === null && st8.path.split(' ').pop() === gp.t && st8.cursor, J({ lp8, st8 }));
    await T.stopped(); await T.settle();

    // ---------- 9. tree drawn in front of fence 36,34: tapping where both are opaque goes to the tree ----------
    const tr = pairs.find((p) => p.fence === 'fence@36,34');
    if (tr && tr.sample) {
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld(tr.sample.x, tr.sample.y, 150);
      const st = await T.snap(), lp = await T.lastPress();
      ok('tree in front of fence: picks the tree and goes to cut it', lp.picked === 'tree@37,35' && st.action === 'tree@37,35', J({ lp, st }));
      // stop by tapping the ground near the player
      await T.stopped();
      await T.tapTile(36, 40, 100); await T.stopped(); await T.settle();
    }

    // ---------- 10. tent drawn in front of fence 39,35: tapping where both are opaque enters the tent ----------
    const tp = pairs.find((p) => p.fence === 'fence@39,35');
    await G(() => { window.__presses.length = 0; });
    await T.tapWorld(tp.sample.x, tp.sample.y, 150);
    const lp10 = await T.lastPress();
    await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
    let s10 = await T.snap();
    ok('tent in front of fence: picks the tent and enters it', lp10.picked === 'tent@40,35' && s10.resting, J({ lp10, s10 }));
    await T.settle();
    // while resting: a fence elsewhere does nothing
    const restFence = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, out = {};
      for (const [c, r] of [[43, 38], [42, 36]]) {
        const f = m.structureAt(c, r), sp = f.sprite, rc = R.rect(sp), cand = [];
        for (let j = 1; j < sp.height - 1; j++) for (let i = 1; i < sp.width - 1; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5, t = R.tileAt(x, y);
          let inner = true;
          for (let dy = -1.5; dy <= 1.5 && inner; dy += 1.5) for (let dx = -1.5; dx <= 1.5 && inner; dx += 1.5) { if (m.pickObject(x + dx, y + dy) !== f) inner = false; const tt = R.tileAt(x + dx, y + dy); if (tt.col !== t.col || tt.row !== t.row) inner = false; }
          if (inner) cand.push({ x, y, t: t.col + ',' + t.row, tentTile: m.structureAt(t.col, t.row) === s.rest.tent });
        }
        out[c + ',' + r] = { own: cand.find((q) => !q.tentTile && q.t === c + ',' + r), overTent: cand.find((q) => q.tentTile) };
      }
      return out;
    });
    console.log('   rest-mode fence points', J(restFence));
    await T.tapWorld(restFence['43,38'].own.x, restFence['43,38'].own.y, 200);
    s10 = await T.snap();
    ok('resting: tapping a fence elsewhere does nothing', s10.resting && !s10.path, J(s10));
    if (restFence['42,36'].overTent) {
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld(restFence['42,36'].overTent.x, restFence['42,36'].overTent.y, 200);
      const lp = await T.lastPress();
      s10 = await T.snap();
      console.log('   INFO resting: tapped fence 42,36 where its upper rail lies over tent tile', restFence['42,36'].overTent.t, '-> picked', lp.picked, 'resting after =', s10.resting);
      if (!s10.resting) { await T.tapWorld(tp.sample.x, tp.sample.y, 150); await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 60000); }
    }
    // tent tap exits
    const tentPt = await G(() => { const s = window.__game.scene.getScene('game'), t = s.rest.tent; return { x: t.sprite.x, y: t.sprite.y - 50 }; });
    await T.tapWorld(tentPt.x, tentPt.y, 300);
    s10 = await T.snap();
    ok('resting: tapping the tent exits', !s10.resting, J(s10));

    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) {
    console.error('CRASH', e);
    fails++;
  } finally {
    console.log('elapsed', ((Date.now() - t0) / 1000).toFixed(0), 's');
    await T.browser.close();
  }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
  process.exit(fails ? 1 : 0);
})();
