// Desktop: a fence wall in front of the player; click the visible rim (alpha 90..110) of an upper rail over the tile behind the wall
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await T.settle();
    await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(2), 400);
    const wall = [[34, 37], [35, 37], [36, 37], [37, 37], [38, 37], [39, 37], [40, 37]];
    for (const [c, r] of wall) await T.tapWorld((c - r) * 40, (c + r) * 20 - 10, 60);
    await T.ui(...UI.craft, 400);
    console.log('built', (await G(() => window.__rv.structs())).join(' '));
    await T.settle();
    // rim pixels of 37,37 (alpha 90..110) over the walkable tile behind the wall, with no other picture there
    const rims = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, out = [];
      for (const [c, r] of [[37, 37], [38, 37], [36, 37]]) {
        const f = m.structureAt(c, r), sp = f.sprite, rc = R.rect(sp);
        for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5, a = R.alphaAt(f, x, y), t = R.tileAt(x, y);
          if (a < 90 || a > 110 || t.row !== 36 || !m.isWalkable(t.col, t.row) || m.pickObject(x, y)) continue;
          out.push({ f: R.key(f), x, y, a, t: t.col + ',' + t.row });
        }
      }
      return out;
    });
    console.log('rim pixels (alpha 90-110) over row 36:', rims.length);
    // only let presses through that really land on a rim pixel (alpha 90..110) of a wall fence; others are dropped
    await G(() => { const s = window.__game.scene.getScene('game'), R = window.__rv, inner = s.onPress;
      window.__dropped = 0;
      s.onPress = function (p) {
        let best = 0; for (const f of R.fences()) best = Math.max(best, R.alphaAt(f, p.worldX, p.worldY));
        if (best < 90 || best > 110) { window.__dropped++; return; }
        return inner.call(this, p);
      }; });
    const start = await T.snap();
    let hit = null;
    for (const q of rims) {
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld(q.x, q.y, 80);
      const pr = await T.lastPress();
      if (!pr) continue;
      const real = await G((pr) => { const s = window.__game.scene.getScene('game'), R = window.__rv; const f = s.map.structureAt(37, 37);
        const fences = R.fences(); let best = 0, who = null; for (const ff of fences) { const a = R.alphaAt(ff, pr.wx, pr.wy); if (a > best) { best = a; who = R.key(ff); } } return { alpha: best, fence: who }; }, pr);
      const st = await T.snap();
      if (st.path) { hit = { q, pr, real, st }; break; }
    }
    if (hit) {
      console.log('dropped presses (landed off the rim):', await G(() => window.__dropped));
      console.log('CLICK on the rim of', hit.real.fence, '(alpha at the pressed point:', hit.real.alpha + ') -> picked', hit.pr.picked, ', ground tile', J(hit.pr.tile));
      console.log('   player path:', hit.st.path, '| cursor at', J(hit.st.cursorAt));
      await page.screenshot({ path: __dirname + '/rim_click.png', clip: { x: 760, y: 380, width: 520, height: 300 } });
      await T.stopped();
      console.log('   ended at', (await T.snap()).tile, '(started at', start.tile + ')');
    } else console.log('no rim click moved the player');
    console.log('errors', J(T.errors));
  } catch (e) { console.error('CRASH', e); }
  finally { await T.browser.close(); }
})();
