// Tablet (1024x768, touch): all 16 fence pictures with open ground behind, stump/campfire/tent overlaps,
// remove by upper rail, tent/rest, fence taps while walking and while chopping, campfire/bush taps.
const { setup, UI } = require('./common.js');
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
const J = JSON.stringify;

(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G } = T;
  const t0 = Date.now();
  try {
    await T.settle();
    const start = await T.snap();
    // stump: chop tree 35,35 the game's own way (three axe strikes through NodeSystem.hit), without walking
    const stump = await G(() => { const s = window.__game.scene.getScene('game'), o = s.map.objectAt(35, 35);
      for (let i = 0; i < 5 && o.node && o.kind !== 'stump'; i++) s.nodes.hit(o, 'axe');
      return o.kind + ':' + o.key; });
    ok('tree 35,35 is now a stump', stump === 'stump:obj_stump', stump);

    // layout: shapes placed automatically (buildable, in reach, tap point not under the craft window, shapes not 4-adjacent)
    const plan = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, b = s.build, cam = s.cameras.main;
      const used = new Set(), out = { fences: [], campfire: null, tent: null, groups: {} };
      const k = (c, r) => c + ',' + r;
      const screenOk = (c, r) => { const x = (c - r) * 40 - cam.worldView.x, y = (c + r) * 20 - 10 - cam.worldView.y; return !(x >= 770 && y >= 730) && y > 120 && y < 1060; };
      const free = (c, r) => b.canBuildAt(c, r) && !used.has(k(c, r)) && screenOk(c, r) && Math.max(Math.abs(c - 37), Math.abs(r - 39)) >= 2;
      const near4 = (c, r) => [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dc, dr]) => used.has(k(c + dc, r + dr)));
      const place = (name, fences, extra = [], keep = []) => {
        const cands = [];
        for (let r = 30; r <= 48; r++) for (let c = 28; c <= 46; c++) cands.push([c, r]);
        cands.sort((a, b2) => Math.hypot(a[0] - 37, a[1] - 39) - Math.hypot(b2[0] - 37, b2[1] - 39));
        for (const [c0, r0] of cands) {
          const tiles = fences.map(([dc, dr]) => [c0 + dc, r0 + dr]), ex = extra.map(([dc, dr]) => [c0 + dc, r0 + dr]), kp = keep.map(([dc, dr]) => [c0 + dc, r0 + dr]);
          if (![...tiles, ...ex].every(([c, r]) => free(c, r) && !near4(c, r))) continue;
          if (!kp.every(([c, r]) => m.isWalkable(c, r) && !used.has(k(c, r)))) continue;
          for (const [c, r] of [...tiles, ...ex, ...kp]) used.add(k(c, r));
          out.fences.push(...tiles); out.groups[name] = { at: [c0, r0], tiles, extra: ex };
          return true;
        }
        out.groups[name] = null; return false;
      };
      // stump ring around 35,35 (fixed place)
      const sr = [[34, 34], [35, 34], [36, 34], [34, 35], [36, 35], [34, 36], [35, 36], [36, 36]];
      if (sr.every(([c, r]) => free(c, r) && !near4(c, r))) { for (const [c, r] of sr) used.add(k(c, r)); out.fences.push(...sr); out.groups.stumpRing = { tiles: sr }; }
      else out.groups.stumpRing = null;
      // keep the ring centre free (pen inside) and the spaces right behind each corner
      place('camp', [[-1, 1], [0, 1], [1, 1], [-1, -1], [0, -1], [1, -1]], [[0, 0]]);
      place('tent', [[-1, 2], [0, 2], [1, 2], [2, 2]], [[0, 0], [1, 0], [0, 1], [1, 1]], [[2, 0], [2, 1]]);
      place('ringSpurs', [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1], [0, -2], [0, 2], [-2, 0], [2, 0]], [], [[0, 0]]);
      place('cross', [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]], [], [[-1, -1]]);
      place('lineC', [[0, 0], [1, 0], [2, 0]], [], [[0, -1], [1, -1]]);
      place('lineR', [[0, 0], [0, 1], [0, 2]], [], [[-1, 0], [-1, 1]]);
      place('iso', [[0, 0]], [], [[-1, -1]]);
      if (out.groups.camp) out.campfire = out.groups.camp.extra[0];
      if (out.groups.tent) out.tent = out.groups.tent.extra[0];
      return out;
    });
    console.log('plan', J(plan.groups));
    ok('layout found for every shape', Object.values(plan.groups).every((x) => x), J(Object.keys(plan.groups).filter((n) => !plan.groups[n])));

    // materials x3, build everything by touch
    await T.ui(...UI.test); for (let i = 0; i < 3; i++) await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(2), 400);
    for (const [c, r] of plan.fences) await T.tapWorld((c - r) * 40, (c + r) * 20 - 10, 40);
    await T.ui(...UI.card(3), 300);
    await T.tapWorld((plan.campfire[0] - plan.campfire[1]) * 40, (plan.campfire[0] + plan.campfire[1]) * 20 - 10, 100);
    await T.ui(...UI.card(4), 300);
    await T.tapWorld((plan.tent[0] + 0.5 - plan.tent[1] - 0.5) * 40, (plan.tent[0] + plan.tent[1] + 1) * 20, 200);
    await T.ui(...UI.craft, 400);
    const structs = await G(() => window.__rv.structs());
    const masks = new Set(structs.filter((x) => x.startsWith('fence')).map((x) => +x.split('#')[1]));
    console.log('built', structs.length, structs.join(' '));
    ok('everything built by touch', structs.length === plan.fences.length + 2, `${structs.length} vs ${plan.fences.length + 2}`);
    ok('all 16 fence pictures present', masks.size === 16, J([...masks].sort((a, b) => a - b)));
    const s0 = await T.snap();
    ok('player did not move while building', s0.tile === start.tile && !s0.path, J(s0));

    // ---------- 1. exhaustive in-page check (all pixels, synthetic touch presses) ----------
    const ex = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, p = s.player;
      const out = { fails: [], perMask: {}, covered: {} };
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp), mk = R.mask(f);
        out.perMask[mk] = out.perMask[mk] || { fences: 0, picked: 0, overWalk: 0 };
        out.perMask[mk].fences++;
        for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5;
          if (R.alphaAt(f, x, y) <= 110) continue;
          const o = m.pickObject(x, y);
          if (o !== f) { const kk = R.key(o).split('@')[0]; out.covered[kk] = (out.covered[kk] || 0) + 1; continue; }
          const t = R.tileAt(x, y);
          out.perMask[mk].picked++;
          if (!(t.col === f.col && t.row === f.row) && m.isWalkable(t.col, t.row)) out.perMask[mk].overWalk++;
          s.onPress({ wasTouch: true, button: 0, worldX: x, worldY: y });
          const a = R.snap();
          if (a.path || a.cursor || a.action || a.resting) { out.fails.push({ f: R.key(f), x, y, a }); p.path = []; p.stopAction(); s.cursor.setVisible(false); }
        }
      }
      window.__presses.length = 0;
      return out;
    });
    console.log('   per picture:', J(ex.perMask));
    console.log('   opaque fence pixels covered by:', J(ex.covered));
    ok('exhaustive (touch presses): no opaque fence pixel moves the player or shows the cursor', ex.fails.length === 0, J(ex.fails.slice(0, 3)));
    ok('every picture has opaque pixels over open ground behind it', Object.values(ex.perMask).every((v) => v.overWalk > 0), J(Object.entries(ex.perMask).filter(([, v]) => !v.overWalk).map(([k2]) => k2)));

    // ---------- 2. real touch taps: 3 points over open ground + 1 on the own tile, for each picture ----------
    const targets = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, best = {};
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp), pts = [];
        for (let j = 1; j < sp.height - 1; j++) for (let i = 1; i < sp.width - 1; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5;
          if (R.alphaAt(f, x, y) <= 110) continue;
          let inner = true;
          for (let dy = -2; dy <= 2 && inner; dy += 1) for (let dx = -2; dx <= 2 && inner; dx += 1) if (m.pickObject(x + dx, y + dy) !== f) inner = false;
          if (!inner) continue;
          const t = R.tileAt(x, y), own = t.col === f.col && t.row === f.row;
          pts.push({ x, y, t: t.col + ',' + t.row, cls: own ? 2 : m.isWalkable(t.col, t.row) ? 0 : 1 });
        }
        const mk = R.mask(f), sc = pts.filter((q) => q.cls === 0).length;
        if (!best[mk] || sc > best[mk].sc) best[mk] = { f: R.key(f), sc, pts };
      }
      return Object.entries(best).map(([mk, v]) => {
        const w = v.pts.filter((q) => q.cls === 0), o = v.pts.filter((q) => q.cls === 2), pick = [];
        for (let i = 0; i < 3 && w.length; i++) pick.push(w[Math.floor((i + 0.5) * w.length / 3)]);
        if (o.length) pick.push(o[Math.floor(o.length / 2)]);
        return { mask: +mk, f: v.f, sc: v.sc, pick };
      });
    });
    let taps = 0; const moved = [], wrong = [], cur = [], landed = {};
    for (const tg of targets) {
      for (const q of tg.pick) {
        await G(() => { window.__presses.length = 0; });
        await T.tapWorld(q.x, q.y, 120);
        taps++;
        const st = await T.snap(), pr = await T.lastPress();
        if (!pr || pr.picked !== tg.f) wrong.push({ mask: tg.mask, q, pr });
        else landed[tg.mask] = (landed[tg.mask] || 0) + (q.cls === 0 && (pr.tile.col + ',' + pr.tile.row) !== tg.f.split('@')[1] ? 1 : 0);
        if (st.path || st.tile !== start.tile || st.action) { moved.push({ mask: tg.mask, q, pr, st }); await T.stopped(); }
        if (st.cursor) cur.push({ mask: tg.mask, q });
      }
    }
    console.log('   taps that landed on the fence over another (open) tile, per picture:', J(landed));
    const sample = await G(() => window.__presses.slice(-1));
    console.log('   last touch press as the game saw it:', J(sample));
    ok(`touch taps: all ${taps} taps picked the fence (${targets.length} pictures)`, wrong.length === 0 && targets.length === 16, J(wrong.slice(0, 3)));
    ok('touch taps: no tap on a fence moved the player', moved.length === 0, J(moved.slice(0, 3)));
    ok('touch taps: no move cursor', cur.length === 0, J(cur.slice(0, 3)));

    // ---------- 3. overlaps: stump ring, tree, campfire lines, tent line ----------
    const ov = await G(() => {
      const g = window.__game, s = g.scene.getScene('game'), m = s.map, R = window.__rv;
      const others = [...m.objects.filter((o) => o.kind === 'stump' || o.kind === 'tree' || o.kind === 'pine' || o.kind === 'palm' || o.kind === 'bush' || o.kind === 'rock'), ...m.structures.filter((x) => x.type !== 'fence')];
      const res = {}, samples = [];
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp);
        for (const o of others) {
          if (Math.abs(o.sprite.x - sp.x) > 200 || Math.abs(o.sprite.y - sp.y) > 200) continue;
          let both = 0, wrongPick = 0, pt = null;
          for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
            const x = rc.left + i + 0.5, y = rc.top + j + 0.5;
            if (R.alphaAt(f, x, y) <= 110 || R.alphaAt(o, x, y) <= 110) continue;
            both++;
            const front = f.sprite.depth > o.sprite.depth ? f : o;
            const p = m.pickObject(x, y);
            if (p !== front && !(p !== f && p !== o)) wrongPick++;
            if (!pt) { let inner = true; for (let dy = -2; dy <= 2 && inner; dy++) for (let dx = -2; dx <= 2 && inner; dx++) if (m.pickObject(x + dx, y + dy) !== p) inner = false; if (inner) pt = { x, y, p: R.key(p) }; }
          }
          const kind = (o.type || o.kind);
          const kk = kind + (f.sprite.depth > o.sprite.depth ? ' behind fence' : f.sprite.depth < o.sprite.depth ? ' in front of fence' : ' same depth');
          res[kk] = res[kk] || { pairs: 0, both: 0, wrongPick: 0 };
          if (both) { res[kk].pairs++; res[kk].both += both; res[kk].wrongPick += wrongPick; }
          if (pt && !samples.some((q) => q.kk === kk)) samples.push({ kk, f: R.key(f), o: R.key(o), ...pt });
        }
      }
      return { res, samples };
    });
    console.log('   overlap summary', J(ov.res));
    ok('overlaps: front-most picture always picked (stump, trees, campfire, tent, bushes, rocks)', Object.values(ov.res).every((v) => v.wrongPick === 0), J(ov.res));
    for (const q of ov.samples.filter((q) => !/^(tree|tent|pine|palm|rock|stump)/.test(q.p))) {
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld(q.x, q.y, 150);
      const st = await T.snap(), pr = await T.lastPress();
      ok(`overlap tap (${q.kk}) picked ${pr && pr.picked}, nothing happens`, pr && pr.picked === q.p && !st.path && !st.action && !st.cursor, J({ q, st }));
    }

    // ---------- 4. remove mode by touch: tap the upper rail of a fence over open ground ----------
    const rmT = targets.find((t) => t.mask === 3 && t.pick.some((q) => q.cls === 0)) || targets.find((t) => t.pick.some((q) => q.cls === 0));
    const rq = rmT.pick.find((q) => q.cls === 0);
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(5), 400);
    const nb = (await G(() => window.__rv.structs())).length;
    await T.tapWorld(rq.x, rq.y, 300);
    const afterRm = await G(() => window.__rv.structs());
    ok(`remove (touch): tapping ${rmT.f}'s rail over ${rq.t} removes ${rmT.f}`, afterRm.length === nb - 1 && !afterRm.some((x) => x.startsWith(rmT.f + '#')), '');
    await T.ui(...UI.craft, 400);
    const s4 = await T.snap();
    ok('remove (touch): player did not move', s4.tile === start.tile && !s4.path, J(s4));

    // ---------- 5. fence tap while walking: walk continues to the first destination ----------
    const far = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map;
      for (const [c, r] of [[37, 33], [38, 32], [36, 32], [39, 33], [40, 44], [30, 40]]) if (m.isWalkable(c, r) && !m.pickObject((c - r) * 40, (c + r) * 20)) return [c, r]; return null; });
    const walkFence = targets.find((t) => t.mask === 15) || targets[0];
    await G(() => { window.__presses.length = 0; });
    await T.tapTile(far[0], far[1], 50);
    const sw0 = await T.snap();
    await T.tapWorld(walkFence.pick[0].x, walkFence.pick[0].y, 50);
    const sw1 = await T.snap(), prs = await G(() => window.__presses.slice());
    ok('walking: a fence tap does not change the walk', sw0.path && sw1.path && sw1.path.split(' ').pop() === far.join(',') && (!sw1.cursor || (sw1.cursorAt.col === far[0] && sw1.cursorAt.row === far[1])), J({ sw0, sw1, prs }));
    await T.stopped(); await T.settle();

    // ---------- 6. tent: enter by touch, fence taps while resting, exit by tent and by button ----------
    const tentPt = await G(() => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent'); return { x: t.sprite.x, y: t.sprite.y - 60 }; });
    await T.tapWorld(tentPt.x, tentPt.y, 100);
    await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
    await T.settle();
    let sr = await T.snap();
    ok('touch the tent: walks there and goes in', sr.resting, J(sr));
    const restPts = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, tent = s.rest.tent, out = [];
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp);
        for (let j = 2; j < sp.height - 2 && out.length < 40; j += 2) for (let i = 2; i < sp.width - 2; i += 2) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5, t = R.tileAt(x, y);
          if (R.alphaAt(f, x, y) <= 110) continue;
          let inner = true;
          for (let dy = -2; dy <= 2 && inner; dy++) for (let dx = -2; dx <= 2 && inner; dx++) { if (m.pickObject(x + dx, y + dy) !== f) inner = false; const tt = R.tileAt(x + dx, y + dy); if (tt.col !== t.col || tt.row !== t.row) inner = false; }
          if (inner) out.push({ f: R.key(f), x, y, t: t.col + ',' + t.row, overTent: m.structureAt(t.col, t.row) === tent });
        }
      }
      return { notTent: out.find((q) => !q.overTent), overTent: out.find((q) => q.overTent) };
    });
    await T.tapWorld(restPts.notTent.x, restPts.notTent.y, 200);
    sr = await T.snap();
    ok('resting: touching a fence does nothing', sr.resting && !sr.path, J(sr));
    if (restPts.overTent) {
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld(restPts.overTent.x, restPts.overTent.y, 200);
      const pr = await T.lastPress();
      sr = await T.snap();
      console.log(`   INFO resting: touched ${restPts.overTent.f} where its rail lies over tent tile ${restPts.overTent.t} -> picked ${pr.picked}, resting after = ${sr.resting}`);
      if (!sr.resting) { await T.tapWorld(tentPt.x, tentPt.y, 100); await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 60000); }
    } else console.log('   INFO no fence rail over a tent tile in this layout');
    await T.tapWorld(tentPt.x, tentPt.y, 300);
    sr = await T.snap();
    ok('resting: touching the tent exits', !sr.resting, J(sr));
    await T.tapWorld(tentPt.x, tentPt.y, 100);
    await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
    await T.ui(...UI.rest, 300);
    sr = await T.snap();
    ok('resting: the rest button exits', !sr.resting, J(sr));
    await T.settle();

    // ---------- 7. fence tap while chopping: chopping continues ----------
    const treeT = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, p = s.player;
      let best = null;
      for (const o of m.objects) if (o.node && (o.kind === 'tree' || o.kind === 'pine')) { const d = Math.hypot(o.col - p.col, o.row - p.row); if (d > 1.5 && d < 5 && (!best || d < best.d)) best = { d, x: o.sprite.x, y: o.sprite.y - 70, key: window.__rv.key(o) }; }
      return best; });
    await T.tapWorld(treeT.x, treeT.y, 100);
    await T.W(() => { const p = window.__game.scene.getScene('game').player; return !p.moving && p.swing; }, null, 60000);
    await T.settle();
    const fenceNow = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv;
      for (const f of R.fences()) { const sp = f.sprite, rc = R.rect(sp);
        for (let j = 2; j < sp.height - 2; j++) for (let i = 2; i < sp.width - 2; i++) { const x = rc.left + i + 0.5, y = rc.top + j + 0.5, t = R.tileAt(x, y);
          if (R.alphaAt(f, x, y) <= 110 || (t.col === f.col && t.row === f.row) || !m.isWalkable(t.col, t.row)) continue;
          let inner = true; for (let dy = -2; dy <= 2 && inner; dy++) for (let dx = -2; dx <= 2 && inner; dx++) if (m.pickObject(x + dx, y + dy) !== f) inner = false;
          const cam = s.cameras.main, sx = x - cam.worldView.x, sy = y - cam.worldView.y;
          if (inner && sx > 100 && sy > 150 && sx < 1820 && sy < 1050 && !(sx > 770 && sy > 730)) return { f: R.key(f), x, y }; } }
      return null; });
    const c0 = await T.snap();
    await T.tapWorld(fenceNow.x, fenceNow.y, 300);
    const c1 = await T.snap(), lp7 = await T.lastPress();
    ok('chopping: a fence tap does not stop chopping', c0.action === treeT.key && c1.action === treeT.key && !c1.path && lp7.picked === fenceNow.f, J({ c0, c1, lp7 }));
    const [pc, pr] = c1.tile.split(',').map(Number);
    await T.tapTile(pc, pr, 100);                      // tap own tile: stops chopping
    await T.stopped(); await T.settle();
    const c2 = await T.snap();
    if (c2.action) console.log('   note: still chopping after own-tile tap', J(c2));

    // ---------- 8. campfire and bush taps do nothing ----------
    const cb = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, cam = s.cameras.main, out = [];
      const vis = (x, y) => { const sx = x - cam.worldView.x, sy = y - cam.worldView.y; return sx > 100 && sy > 150 && sx < 1820 && sy < 1050 && !(sx > 770 && sy > 730); };
      const cf = m.structures.find((x) => x.type === 'campfire'); if (cf && vis(cf.sprite.x, cf.sprite.y - 25)) out.push({ k: 'campfire', x: cf.sprite.x, y: cf.sprite.y - 25 });
      for (const o of m.objects) if (o.kind === 'bush' && out.length < 3 && vis(o.sprite.x, o.sprite.y - 15) && m.pickObject(o.sprite.x, o.sprite.y - 15) === o) out.push({ k: 'bush', x: o.sprite.x, y: o.sprite.y - 15 });
      return out; });
    for (const q of cb) {
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld(q.x, q.y, 150);
      const st = await T.snap(), pr = await T.lastPress();
      ok(`${q.k} touch does nothing (picked ${pr && pr.picked})`, pr && pr.picked && pr.picked.startsWith(q.k) && !st.path && !st.cursor && !st.action, J(st));
    }
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) {
    console.error('CRASH', e);
    fails++;
  } finally {
    console.log('elapsed', ((Date.now() - t0) / 1000).toFixed(0), 's');
    await T.browser.close();
  }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
  process.exit(fails ? 1 : 0);
})();
