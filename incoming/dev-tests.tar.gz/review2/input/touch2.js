// Tablet (1024x768, touch): ring with spurs -> pictures 5,6,7,9,10,11,13,14 (+1,2,4,8) with open ground behind
const { setup, UI } = require('./common.js');
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { G } = T;
  try {
    await T.settle();
    const start = await T.snap();
    const plan = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, b = s.build, cam = s.cameras.main;
      const shape = [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1], [0, -2], [0, 2], [-2, 0], [2, 0]];
      const screenOk = (c, r) => { const x = (c - r) * 40 - cam.worldView.x, y = (c + r) * 20 - 10 - cam.worldView.y; return !(x >= 770 && y >= 730) && y > 120 && y < 1060; };
      const cands = [];
      for (let r = 30; r <= 48; r++) for (let c = 28; c <= 46; c++) cands.push([c, r]);
      cands.sort((a, b2) => Math.hypot(a[0] - 37, a[1] - 39) - Math.hypot(b2[0] - 37, b2[1] - 39));
      const scored = [];
      for (const [c0, r0] of cands) {
        const tiles = shape.map(([dc, dr]) => [c0 + dc, r0 + dr]);
        if (!tiles.every(([c, r]) => b.canBuildAt(c, r) && screenOk(c, r) && Math.max(Math.abs(c - 37), Math.abs(r - 39)) >= 1)) continue;
        if (!m.isWalkable(c0, r0)) continue;
        // prefer places where nothing tall stands right in front of the ring
        let cover = 0;
        for (const [c, r] of tiles) for (const [dc, dr] of [[1, 0], [0, 1], [1, 1], [2, 1], [1, 2], [2, 2]]) { const o = m.objectAt(c + dc, r + dr); if (o && o.tall) cover++; }
        scored.push({ at: [c0, r0], tiles, cover });
      }
      scored.sort((a, b2) => a.cover - b2.cover);
      return scored[0] || null;
    });
    console.log('ring with spurs at', J(plan && plan.at), 'tall objects in front:', plan && plan.cover);
    ok('ring with spurs fits', !!plan);
    await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    await T.ui(...UI.craft, 400); await T.ui(...UI.card(2), 400);
    for (const [c, r] of plan.tiles) await T.tapWorld((c - r) * 40, (c + r) * 20 - 10, 40);
    await T.ui(...UI.craft, 400);
    const structs = await G(() => window.__rv.structs());
    console.log('built', structs.join(' '));
    const masks = new Set(structs.map((x) => +x.split('#')[1]));
    ok('pictures 5,6,7,9,10,11,13,14 present', [5, 6, 7, 9, 10, 11, 13, 14].every((x) => masks.has(x)), J([...masks]));
    const targets = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, out = [];
      let fails = 0, opaque = 0;
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp), pts = [];
        for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
          const x = rc.left + i + 0.5, y = rc.top + j + 0.5;
          if (R.alphaAt(f, x, y) <= 110 || m.pickObject(x, y) !== f) continue;
          opaque++;
          s.onPress({ wasTouch: true, button: 0, worldX: x, worldY: y });
          const a = R.snap();
          if (a.path || a.cursor || a.action) { fails++; s.player.path = []; s.player.stopAction(); s.cursor.setVisible(false); }
          if (i < 2 || j < 2 || i >= sp.width - 2 || j >= sp.height - 2) continue;
          let inner = true;
          for (let dy = -2; dy <= 2 && inner; dy++) for (let dx = -2; dx <= 2 && inner; dx++) if (m.pickObject(x + dx, y + dy) !== f) inner = false;
          const t = R.tileAt(x, y);
          if (inner && !(t.col === f.col && t.row === f.row) && m.isWalkable(t.col, t.row)) pts.push({ x, y, t: t.col + ',' + t.row });
        }
        out.push({ f: R.key(f), mask: R.mask(f), n: pts.length, pick: [0, 1, 2].map((k) => pts[Math.floor((k + 0.5) * pts.length / 3)]).filter(Boolean) });
      }
      window.__presses.length = 0;
      return { out, fails, opaque };
    });
    ok(`exhaustive: ${targets.opaque} opaque front-most fence pixels, none moves the player`, targets.fails === 0, String(targets.fails));
    const moved = [], wrong = [], cur = [];
    let taps = 0;
    for (const tg of targets.out) {
      console.log(`   ${tg.f} picture ${tg.mask}: inner opaque points over open ground ${tg.n}; tapping ${tg.pick.map((q) => q.t).join(' ')}`);
      for (const q of tg.pick) {
        await G(() => { window.__presses.length = 0; });
        await T.tapWorld(q.x, q.y, 120);
        taps++;
        const st = await T.snap(), pr = await T.lastPress();
        if (!pr || pr.picked !== tg.f || (pr.tile.col + ',' + pr.tile.row) === tg.f.split('@')[1]) wrong.push({ tg: tg.f, q, pr });
        if (st.path || st.tile !== start.tile || st.action) { moved.push({ tg: tg.f, q, st }); await T.stopped(); }
        if (st.cursor) cur.push({ tg: tg.f, q });
      }
    }
    ok(`touch: ${taps} taps on fence rails over open ground all picked the fence`, wrong.length === 0, J(wrong.slice(0, 3)));
    ok('touch: none moved the player', moved.length === 0, J(moved.slice(0, 3)));
    ok('touch: no move cursor', cur.length === 0, J(cur.slice(0, 3)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
  process.exit(fails ? 1 : 0);
})();
