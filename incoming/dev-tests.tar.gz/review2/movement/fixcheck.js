// Same fuzz, with a candidate fix patched in the page (not in the repo). node fixcheck.js <fix: eps|occ> <first> <count> <frames> <delta|random> <speed>
const fs = require('fs');
const { open } = require('../../p4/lib.js');
const src = fs.readFileSync(__dirname + '/fuzz_page.js', 'utf8');
const fix = process.argv[2], first = +process.argv[3], count = +process.argv[4], frames = +process.argv[5];
const deltaMode = process.argv[6] && process.argv[6] !== 'random' ? +process.argv[6] : 'random', speed3 = process.argv[7] === '3';
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  const all = {};
  for (let seed = first; seed < first + count; seed++) {
    if (seed !== first) { await page.reload(); await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 }); await page.waitForTimeout(300); }
    await G((fix) => {
      const p = window.__game.scene.getScene('game').player;
      if (fix === 'occ') {
        // box over this.tile, the position and path[0]
        p.occupiedTiles = function () {
          const pts = [this, this.tile, ...(this.path.length ? [this.path[0]] : [])];
          const c0 = Math.floor(Math.min(...pts.map((t) => t.col))), c1 = Math.ceil(Math.max(...pts.map((t) => t.col)));
          const r0 = Math.floor(Math.min(...pts.map((t) => t.row))), r1 = Math.ceil(Math.max(...pts.map((t) => t.row)));
          const out = []; for (let c = c0; c <= c1; c++) for (let r = r0; r <= r1; r++) out.push({ col: c, row: r }); return out;
        };
      } else {
        // arrival test with a small tolerance (copy of Player.update's movement loop)
        const orig = p.update.bind(p);
        p.update = function (dt) {
          let left = 3.5 * dt;
          while (left > 0 && this.path.length) {
            const t = this.path[0]; const dc = t.col - this.col, dr = t.row - this.row; const dist = Math.hypot(dc, dr);
            this.face(dc - dr);
            if (dist <= left + 1e-9) { this.col = t.col; this.row = t.row; this.tile = { col: t.col, row: t.row }; this.path.shift(); left -= dist; }
            else { this.col += dc / dist * left; this.row += dr / dist * left; left = 0; }
          }
          // run the rest of the original update with no movement
          const saved = this.path; this.path = []; const moving = saved.length > 0;
          orig(0);
          this.path = saved;
          if (moving) this.sprite.anims.play(this.key + '_walk', true);
        };
      }
    }, fix);
    await page.addScriptTag({ content: src });
    await G(([seed, dm, s3]) => window.__fz.init(seed, dm, s3), [seed, deltaMode, speed3]);
    for (let done = 0; done < frames; done += 2000) await G((n) => window.__fz.run(n), Math.min(2000, frames - done));
    const st = await G(() => window.__fz.stats);
    for (const [k, v] of Object.entries(st)) if (k.startsWith('FAIL') || k.startsWith('build-mid') || k.startsWith('rest') || k.startsWith('state:') || k === 'path-cut' || k === 'walked-steps') all[k] = (all[k] || 0) + v;
  }
  console.log(`fix=${fix} seeds ${first}..${first + count - 1} frames ${frames} delta ${deltaMode} speed x${speed3 ? 3 : 1}:`, JSON.stringify(all));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
