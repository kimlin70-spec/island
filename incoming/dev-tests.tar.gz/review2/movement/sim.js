// Pure re-implementation of Player.update's movement arithmetic (same expressions), to count
// frames that end exactly on path[0] without "arriving" (tile not updated).
function sim(path0, dtFn, frames) {
  const P = { col: path0[0].col, row: path0[0].row, tile: { ...path0[0] }, path: path0.slice(1).map((t) => ({ ...t })) };
  let exact = 0, offbox = 0, n = 0;
  for (let f = 0; f < frames && P.path.length; f++) {
    let left = 3.5 * dtFn(f);
    while (left > 0 && P.path.length) {
      const t = P.path[0];
      const dc = t.col - P.col, dr = t.row - P.row;
      const dist = Math.hypot(dc, dr);
      if (dist <= left) { P.col = t.col; P.row = t.row; P.tile = { col: t.col, row: t.row }; P.path.shift(); left -= dist; }
      else { P.col += dc / dist * left; P.row += dr / dist * left; left = 0; }
    }
    n++;
    if (P.path.length && P.col === P.path[0].col && P.row === P.path[0].row && (P.tile.col !== P.col || P.tile.row !== P.row)) exact++;
  }
  return { frames: n, exact };
}
const line = (n, dc, dr) => Array.from({ length: n + 1 }, (_, k) => ({ col: 10 + k * dc, row: 10 + k * dr }));
const capped = (speed) => () => Math.min(150 / 1000, 0.1) * speed;   // a slow device: every frame capped
const rnd60 = () => Math.min((16.67 + (Math.random() - 0.5) * 4) / 1000, 0.1);
console.log('straight x1, capped dt   ', sim(line(400, 1, 0), capped(1), 100000));
console.log('straight x3, capped dt   ', sim(line(400, 1, 0), capped(3), 100000));
console.log('diagonal x1, capped dt   ', sim(line(400, 1, 1), capped(1), 100000));
console.log('diagonal x3, capped dt   ', sim(line(400, 1, -1), capped(3), 100000));
console.log('straight x1, ~60fps      ', sim(line(4000, 1, 0), rnd60, 1000000));
const fixed = (ms) => () => Math.min(ms / 1000, 0.1);
for (const ms of [16, 16.666666666666668, 20, 25, 33.333333333333336, 50]) console.log('straight x1, fixed', ms, 'ms', sim(line(4000, 1, 0), fixed(ms), 1000000));
