// Real game loop (requestAnimationFrame, real frame times), ground taps through GameScene.walkTo at random moments.
// Counts frames that end exactly on path[0] without arriving. node realloop.js <seconds> <speed 1|3> <w> <h>
const { open } = require('../../p4/lib.js');
const secs = +(process.argv[2] || 40), speed = +(process.argv[3] || 1), w = +(process.argv[4] || 1920), h = +(process.argv[5] || 1200);
(async () => {
  const T = await open({ w, h });
  const { G, page } = T;
  await G((speed) => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, m = s.map;
    const K = (t) => t.col + ',' + t.row;
    if (speed === 3) s.debugToggleSpeed();
    let a = 12345; const R = () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
    window.__rl = { frames: 0, capped: 0, orth: 0, diag: 0, taps: 0, ex: [] };
    s.events.on('update', (t, d) => { window.__rl.frames++; if (d >= 100) window.__rl.capped++;
      if (!p.moving || R() < 0.06) { for (let k = 0; k < 10; k++) { const c = p.tile.col + Math.floor(R() * 11) - 5, r = p.tile.row + Math.floor(R() * 11) - 5;
        if (m.isWalkable(c, r) && Math.hypot(c - 37, r - 39) < 9) { s.walkTo(c, r); window.__rl.taps++; break; } } } });
    s.events.on('postupdate', () => {
      if (p.path.length && p.col === p.path[0].col && p.row === p.path[0].row && K(p.tile) !== K(p.path[0])) {
        const d = p.tile.col !== p.path[0].col && p.tile.row !== p.path[0].row;
        if (d) window.__rl.diag++; else window.__rl.orth++;
        if (window.__rl.ex.length < 5) window.__rl.ex.push({ d, pos: [p.col, p.row], tile: K(p.tile), path: p.path.map(K).join(' '), occ: p.occupiedTiles().map(K).join(' ') });
      } });
  }, speed);
  await page.waitForTimeout(secs * 1000);
  const r = await G(() => ({ ...window.__rl, fps: window.__game.loop.actualFps }));
  console.log(`speed x${speed} ${w}x${h}: frames ${r.frames} (capped dt ${r.capped}), fps ${r.fps.toFixed(1)}, taps ${r.taps}, exact landings: orth ${r.orth} diag ${r.diag}`);
  for (const e of r.ex) console.log('  ', JSON.stringify(e));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
