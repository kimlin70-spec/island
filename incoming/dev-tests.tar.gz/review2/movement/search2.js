const fs = require('fs');
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await G(() => window.__game.loop.sleep());
  await page.addScriptTag({ content: fs.readFileSync(__dirname + '/search2_page.js', 'utf8') });
  for (const [name, dt] of [['dt 0.1 (under 10 fps)', 0.1], ['dt 0.3 (under 10 fps, speed x3)', 0.30000000000000004], ['dt 1/60', 1 / 60], ['dt 1/30', 1 / 30], ['dt 0.05', 0.05]]) {
    const t0 = Date.now();
    const r = await G(([dt]) => window.__search2(7, 300, 400, dt, 0.03), [dt]);
    console.log(name.padEnd(32), 'frames', r.frames, 'orth', r.orth, 'diag', r.diag, ((Date.now() - t0) / 1000).toFixed(1) + 's');
    if (r.firstDiag) console.log('   first diag:', JSON.stringify(r.firstDiag));
  }
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
