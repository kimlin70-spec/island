// Find a deterministic tap sequence (from the start tile, every frame dt = 0.1 s, i.e. a device under 10 fps)
// after which a frame ends exactly on path[0] without "arriving" on a DIAGONAL step.
(() => {
  const g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player, b = s.build;
  const K = (t) => t.col + ',' + t.row;
  const reset = () => {
    for (const x of [...m.structures]) b.destroy(x);
    p.col = 37; p.row = 39; p.tile = { col: 37, row: 39 }; p.path = []; p.stopAction(); s.debugSpeed = 1;
  };
  const exactState = () => p.path.length && p.col === p.path[0].col && p.row === p.path[0].row && K(p.tile) !== K(p.path[0]);
  const diag = () => p.tile.col !== p.path[0].col && p.tile.row !== p.path[0].row;
  window.__search = (maxHits, dt) => {
    const hits = [];
    const cand = [];
    for (let r = 33; r <= 45; r++) for (let c = 31; c <= 43; c++) if (m.isWalkable(c, r) && (c !== 37 || r !== 39)) cand.push({ col: c, row: r });
    for (const X of cand) {
      for (let f1 = 1; f1 <= 9; f1++) {
        for (let yi = 0; yi < cand.length; yi += (window.__yStep || 3)) {
          const Y = cand[yi];
          reset();
          if (!p.goTo(X.col, X.row)) break;
          for (let f = 0; f < f1; f++) p.update(dt);
          if (!p.moving) break;
          const fracBefore = [p.col, p.row];
          if (!p.goTo(Y.col, Y.row)) continue;
          const backing = p.path.length && K(p.path[0]) === K(p.tile);
          for (let k = 1; k <= 40 && p.moving; k++) {
            p.update(dt);
            if (exactState()) {
              if (!window.__onlyDiag || diag()) hits.push({ X: K(X), f1, Y: K(Y), k, backing, diag: diag(), fracBefore, pos: [p.col, p.row], tile: K(p.tile), path: p.path.map(K).join(' ') });
              if (diag()) break;
            }
          }
          if (hits.filter((h) => h.diag).length >= maxHits) { reset(); return hits; }
        }
      }
    }
    reset();
    return hits;
  };
})();
