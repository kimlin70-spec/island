// Real loop + real mouse clicks on the ground for walking (GameScene.onPress -> walkTo), fences/campfires placed with
// BuildSystem.place on tiles canBuildAt allows (biased to the step in progress) at random moments mid-walk.
// Per-frame invariants in 'postupdate' (fuzz_page.js checker). node realinput.js <seed> <iterations> <speed 1|3>
const fs = require('fs');
const { open } = require('../../p4/lib.js');
const seed = +(process.argv[2] || 7), iters = +(process.argv[3] || 60), speed = +(process.argv[4] || 1);
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const { page, G } = T;
  await page.addScriptTag({ content: fs.readFileSync(__dirname + '/fuzz_page.js', 'utf8') });
  await G(([seed, speed]) => { window.__fz.seedOnly(seed); const s = window.__game.scene.getScene('game'); if (speed === 3) s.debugToggleSpeed(); }, [seed, speed]);
  let a = seed; const R = () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  let clicks = 0, walked = 0, builds = 0;
  for (let i = 0; i < iters; i++) {
    // pick a walkable tile with no object picture over its centre, compute its screen point right before clicking
    const tgt = await G(() => { const fz = window.__fz, s = window.__game.scene.getScene('game'), m = s.map;
      for (let k = 0; k < 30; k++) { const x = fz.randomWalkable(6); if (!x) continue; const wx = (x.col - x.row) * 40, wy = (x.col + x.row) * 20;
        if (!m.pickObject(wx, wy)) { const g = window.__game, cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
          const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
          if (sx > 60 && sy > 60 && sx < cam.width - 400 && sy < cam.height - 250) return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, t: x.col + ',' + x.row }; } }
      return null; });
    if (tgt) { await page.mouse.click(tgt.x, tgt.y); clicks++; }
    // during the walk: a few builds at random moments, sometimes a destroy
    const nb = 1 + Math.floor(R() * 3);
    for (let j = 0; j < nb; j++) {
      await page.waitForTimeout(40 + Math.floor(R() * 350));
      const r = await G((q) => { const fz = window.__fz, s = window.__game.scene.getScene('game'), m = s.map, p = s.player;
        if (q < 0.15 && m.structures.length) { const x = m.structures[Math.floor(q * 1000) % m.structures.length]; s.build.destroy(x); return 'destroy'; }
        if (!p.moving) return 'idle';
        return fz.tryBuild(q < 0.93 ? 'fence' : 'campfire') ? 'built' : 'refused'; }, R());
      if (r === 'built') builds++;
    }
    await G(() => { const s = window.__game.scene.getScene('game'), m = s.map; while (m.structures.length > 12) s.build.destroy(m.structures[0]); });
  }
  await page.waitForTimeout(800);
  const res = await G(() => ({ stats: window.__fz.stats, fails: window.__fz.fails.slice(0, 6), fps: window.__game.loop.actualFps }));
  const failKinds = Object.entries(res.stats).filter(([k]) => k.startsWith('FAIL'));
  console.log(`seed ${seed} speed x${speed}: clicks ${clicks}, builds ${builds}, fps ${res.fps.toFixed(1)}; mid-step builds diag ${res.stats['build-mid-step:diag'] || 0} orth ${res.stats['build-mid-step:orth'] || 0}, path cuts ${res.stats['path-cut'] || 0}, walked steps ${res.stats['walked-steps'] || 0}`);
  console.log('fails:', JSON.stringify(failKinds));
  for (const f of res.fails.slice(0, 3)) console.log('  ', f.kind, JSON.stringify(f.info), JSON.stringify(f.st));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
