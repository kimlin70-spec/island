// Random tap sequences, every frame the same dt; look for a frame that ends exactly on a DIAGONAL path[0] without arriving.
(() => {
  const g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player, b = s.build;
  const K = (t) => t.col + ',' + t.row;
  function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  const reset = () => { for (const x of [...m.structures]) b.destroy(x); p.col = 37; p.row = 39; p.tile = { col: 37, row: 39 }; p.path = []; p.stopAction(); };
  const exact = () => p.path.length && p.col === p.path[0].col && p.row === p.path[0].row && K(p.tile) !== K(p.path[0]);
  const diag = () => p.tile.col !== p.path[0].col && p.tile.row !== p.path[0].row;
  window.__search2 = (seed, trials, framesPerTrial, dt, tapProb) => {
    const R = mulberry32(seed);
    const out = { orth: 0, diag: 0, frames: 0, firstDiag: null };
    for (let tr = 0; tr < trials; tr++) {
      reset();
      const seq = [];
      for (let f = 0; f < framesPerTrial; f++) {
        if (!p.moving || R() < tapProb) {
          let x;
          for (let k = 0; k < 10; k++) { x = { col: p.tile.col + Math.floor(R() * 13) - 6, row: p.tile.row + Math.floor(R() * 13) - 6 }; if (m.isWalkable(x.col, x.row)) break; }
          if (p.goTo(x.col, x.row)) seq.push([f, K(x)]);
        }
        p.update(dt);
        out.frames++;
        if (exact()) {
          if (diag()) { out.diag++; if (!out.firstDiag) out.firstDiag = { trial: tr, frame: f, seq: seq.slice(), pos: [p.col, p.row], tile: K(p.tile), path: p.path.map(K).join(' ') }; }
          else out.orth++;
        }
      }
    }
    reset();
    return out;
  };
})();
