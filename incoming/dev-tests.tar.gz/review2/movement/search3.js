// shortest tap sequences (from the start, fixed dt) that end a frame exactly on a diagonal path[0] without arriving
const fs = require('fs');
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await G(() => window.__game.loop.sleep());
  await page.addScriptTag({ content: fs.readFileSync(__dirname + '/search2_page.js', 'utf8') });
  await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map, p = s.player, b = s.build;
    const K = (t) => t.col + ',' + t.row;
    function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
    const reset = () => { for (const x of [...m.structures]) b.destroy(x); p.col = 37; p.row = 39; p.tile = { col: 37, row: 39 }; p.path = []; p.stopAction(); };
    window.__short = (seed, trials, dt, maxTaps) => {
      const R = mulberry32(seed); const found = [];
      for (let tr = 0; tr < trials; tr++) {
        reset(); const seq = []; let f = 0;
        const nt = 2 + Math.floor(R() * (maxTaps - 1));
        for (let i = 0; i < nt; i++) {
          let x; for (let k = 0; k < 10; k++) { x = { col: p.tile.col + Math.floor(R() * 13) - 6, row: p.tile.row + Math.floor(R() * 13) - 6 }; if (m.isWalkable(x.col, x.row)) break; }
          if (p.goTo(x.col, x.row)) seq.push([f, K(x)]);
          const wait = i < nt - 1 ? 1 + Math.floor(R() * 12) : 60;
          for (let w = 0; w < wait && p.moving; w++, f++) {
            p.update(dt);
            if (p.path.length && p.col === p.path[0].col && p.row === p.path[0].row && K(p.tile) !== K(p.path[0]) && p.tile.col !== p.path[0].col && p.tile.row !== p.path[0].row) {
              found.push({ seq: seq.slice(), endFrame: f, pos: [p.col, p.row], tile: K(p.tile), path: p.path.map(K).join(' ') }); i = nt; break;
            }
          }
          if (!p.moving && i < nt - 1) { /* keep tapping from where we stopped */ }
        }
      }
      reset();
      found.sort((a, b) => a.seq.length - b.seq.length || a.endFrame - b.endFrame);
      return found.slice(0, 5);
    };
  });
  for (const [name, dt] of [['dt 0.1', 0.1], ['dt 0.3 (x3)', 0.30000000000000004]]) {
    const t0 = Date.now();
    const r = await G(([dt]) => window.__short(11, 60000, dt, 3), [dt]);
    console.log(name, ((Date.now() - t0) / 1000).toFixed(1) + 's', 'found', r.length);
    for (const h of r) console.log('  ', JSON.stringify(h));
  }
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
