// The same stranding, in the real requestAnimationFrame loop (headless Chromium runs this 1920x1200 game at ~5-8 fps,
// so every frame's dt is capped at 0.1 s). Taps are GameScene.walkTo calls made in the scene's 'update' event (before
// Player.update of that frame = a tap between two frames); the build is BuildSystem.commit on the tile's world point
// in 'postupdate' (= a release between two frames).
const { open } = require('../../p4/lib.js');
(async () => {
  for (let attempt = 1; attempt <= 3; attempt++) {
    const T = await open({ w: 1920, h: 1200 });
    const { G, W } = T;
    await G(() => {
      const g = window.__game, s = g.scene.getScene('game'), p = s.player, m = s.map, b = s.build;
      const K = (t) => t.col + ',' + t.row;
      s.debugGive(); s.debugToggleSpeed();     // 시험: 재료 +20, 속도 x3
      const R = window.__rs = { n: 0, deltas: [], log: [], done: false, bad: [] };
      const st = (w) => R.log.push(`#${R.n} ${w}: pos=(${p.col},${p.row}) tile=${K(p.tile)} path=[${p.path.map(K).join(' ')}] occ=[${p.occupiedTiles().map(K).join(' ')}]`);
      let n0 = -1, phase = 0;
      s.events.on('update', (t, d) => {
        R.n++;
        if (n0 < 0 && R.n >= 5) { n0 = R.n; s.walkTo(41, 35); st('tap 41,35'); }
        else if (n0 > 0 && R.n === n0 + 2) { s.walkTo(40, 40); st('tap 40,40'); }
        if (n0 > 0 && R.n >= n0 && R.n <= n0 + 3) R.deltas.push(d);
      });
      s.events.on('postupdate', () => {
        for (let c = Math.floor(p.col); c <= Math.ceil(p.col); c++) for (let r = Math.floor(p.row); r <= Math.ceil(p.row); r++)
          if (!m.isWalkable(c, r)) R.bad.push(`#${R.n} body (${p.col.toFixed(3)},${p.row.toFixed(3)}) over blocked ${c},${r}`);
        if (n0 > 0 && R.n === n0 + 3) {
          st('frame end');
          R.exact = p.path.length && p.col === p.path[0].col && p.row === p.path[0].row && K(p.tile) !== K(p.path[0]);
          b.setMode('fence'); b.commit((39 - 38) * 40, (39 + 38) * 20); b.setMode(null);
          R.fences = m.structures.map(K).join(' ');
          st('released on 39,38 in build mode');
        }
        if (n0 > 0 && R.n === n0 + 6) { st('3 frames later'); s.walkTo(40, 40); st('tap 40,40 again'); }
        if (n0 > 0 && R.n === n0 + 14) { st('8 frames later'); R.done = true; }
      });
    });
    await W(() => window.__rs.done, null, 120000);
    const r = await G(() => window.__rs);
    console.log(`attempt ${attempt}: deltas of the 4 frames (ms): ${r.deltas.map((d) => d.toFixed(1)).join(', ')}`);
    console.log(r.log.join('\n'));
    console.log('exact landing:', r.exact, '| fences:', r.fences, '| body over blocked:', JSON.stringify(r.bad));
    console.log('errors', JSON.stringify(T.errors));
    await T.browser.close();
    if (r.exact) break;
  }
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
