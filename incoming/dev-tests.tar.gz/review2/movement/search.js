const fs = require('fs');
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await G(() => window.__game.loop.sleep());
  await page.addScriptTag({ content: fs.readFileSync(__dirname + '/search_page.js', 'utf8') });
  const t0 = Date.now();
  await G(() => { window.__onlyDiag = true; window.__yStep = 1; }); const hits = await G(() => window.__search(5, 0.1));
  console.log('search took', (Date.now() - t0) / 1000, 's, hits', hits.length, 'diag', hits.filter((h) => h.diag).length);
  for (const h of hits.slice(0, 40)) console.log(JSON.stringify(h));
  fs.writeFileSync(__dirname + '/search_hits.json', JSON.stringify(hits, null, 1));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
