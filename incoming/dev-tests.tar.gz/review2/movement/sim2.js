// Same arithmetic as Player.update + routeTo's walk-back rule, on an open plane.
// Random re-routes (taps) while walking; count frames ending exactly on path[0] with tile not updated.
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function run(seed, dtFn, frames, tapProb) {
  const R = mulberry32(seed);
  const P = { col: 0, row: 0, tile: { col: 0, row: 0 }, path: [] };
  const straightPath = (from, goal) => {   // 8-dir greedy path (open plane): diagonal first, then straight
    const out = [{ ...from }]; let c = from.col, r = from.row;
    while (c !== goal.col || r !== goal.row) { c += Math.sign(goal.col - c); r += Math.sign(goal.row - r); out.push({ col: c, row: r }); }
    return out;
  };
  let exactOrth = 0, exactDiag = 0, taps = 0;
  for (let f = 0; f < frames; f++) {
    if (!P.path.length || R() < tapProb) {
      taps++;
      const goal = { col: P.tile.col + Math.floor(R() * 13) - 6, row: P.tile.row + Math.floor(R() * 13) - 6 };
      const best = straightPath(P.tile, goal);
      const next = P.path[0];
      if (next && best.length >= 2 && best[1].col === next.col && best[1].row === next.row) best.shift();
      P.path = (!next && best.length === 1) ? [] : best;
    }
    let left = 3.5 * dtFn(f, R);
    while (left > 0 && P.path.length) {
      const t = P.path[0];
      const dc = t.col - P.col, dr = t.row - P.row;
      const dist = Math.hypot(dc, dr);
      if (dist <= left) { P.col = t.col; P.row = t.row; P.tile = { col: t.col, row: t.row }; P.path.shift(); left -= dist; }
      else { P.col += dc / dist * left; P.row += dr / dist * left; left = 0; }
    }
    if (P.path.length && P.col === P.path[0].col && P.row === P.path[0].row && (P.tile.col !== P.col || P.tile.row !== P.row)) {
      if (P.tile.col !== P.col && P.tile.row !== P.row) exactDiag++; else exactOrth++;
    }
  }
  return { frames, taps, exactOrth, exactDiag };
}
const capped = (speed) => () => 0.1 * speed;   // Math.min(delta/1000, 0.1) * speed with delta >= 100 ms
const at60 = (f, R) => Math.min((16.67 + (R() - 0.5) * 4) / 1000, 0.1);
const fps = (n) => () => Math.min(1 / n, 0.1);
for (const [name, fn] of [['capped x1 (<=10 fps)', capped(1)], ['capped x3 (<=10 fps, speed x3)', capped(3)], ['8 fps uncapped? (0.125->0.1)', capped(1)],
                           ['~60 fps jitter', at60], ['exact 60 fps', fps(60)], ['exact 30 fps', fps(30)], ['exact 20 fps', fps(20)], ['exact 12 fps', fps(12)]]) {
  let tot = { frames: 0, taps: 0, exactOrth: 0, exactDiag: 0 };
  for (let seed = 1; seed <= 20; seed++) { const r = run(seed, fn, 50000, 0.02); for (const k in tot) tot[k] += r[k]; }
  console.log(name.padEnd(34), JSON.stringify(tot));
}
