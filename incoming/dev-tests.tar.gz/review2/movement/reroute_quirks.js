// (a) tapping a tree while 90% into a tile that is next to the tree: the player walks back to the tile it left
// (b) tap ahead, tap behind, tap ahead again within one step: the player keeps backing out to the tile centre before turning
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { G } = T;
  const out = await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player;
    const K = (t) => t.col + ',' + t.row;
    g.loop.sleep();
    let time = g.loop.time;
    const frame = (ms = 50) => { time += ms; s.sys.step(time, ms); };
    const res = {};
    // (a) find a tree T and two orthogonally adjacent walkable tiles A, B that are both next to T, plus a tile C beyond B
    let setup = null;
    for (const o of m.objects) {
      if (!o.node || o.node.group !== 'tree' || Math.hypot(o.col - 37, o.row - 39) > 8) continue;
      for (const [dc, dr] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        // A and B on the row/col next to T, side by side
        for (const [ac, ar] of [[o.col - 1, o.row + 1], [o.col + 1, o.row - 1], [o.col - 1, o.row - 1], [o.col + 1, o.row + 1]]) {
          const A = { col: ac, row: ar }, B = { col: ac + dc, row: ar + dr }, C = { col: ac + 3 * dc, row: ar + 3 * dr };
          const nextTo = (t) => Math.max(Math.abs(t.col - o.col), Math.abs(t.row - o.row)) === 1;
          if (nextTo(A) && nextTo(B) && m.isWalkable(A.col, A.row) && m.isWalkable(B.col, B.row) && m.isWalkable(ac + 2 * dc, ar + 2 * dr) && m.isWalkable(C.col, C.row)) { setup = { o, A, B, C }; break; }
        }
        if (setup) break;
      }
      if (setup) break;
    }
    const { o, A, B, C } = setup;
    p.col = A.col; p.row = A.row; p.tile = { ...A }; p.path = []; p.stopAction();
    s.walkTo(C.col, C.row);
    for (let i = 0; i < 40 && !(K(p.tile) === K(A) && p.path.length && K(p.path[0]) === K(B) && Math.hypot(p.col - A.col, p.row - A.row) >= 0.85); i++) frame(50);
    const at = [p.col, p.row];
    s.pressNode(o);
    res.a = { tree: K(o), A: K(A), B: K(B), posBefore: at, pathAfterTap: p.path.map(K).join(' '), distToA: Math.hypot(at[0] - A.col, at[1] - A.row), distToB: Math.hypot(at[0] - B.col, at[1] - B.row) };
    const trail = [];
    for (let i = 0; i < 30 && p.moving; i++) { frame(50); trail.push(`(${p.col.toFixed(2)},${p.row.toFixed(2)})`); }
    res.a.trail = trail.join(' '); res.a.endTile = K(p.tile);
    // (b) straight line: tap ahead, tap behind, tap ahead again
    let row = null;
    for (let r = 30; r <= 48 && row === null; r++) for (let c = 25; c <= 45; c++) { let ok = true; for (let k = -4; k <= 4; k++) if (!m.isWalkable(c + k, r)) ok = false; if (ok) { row = { c, r }; break; } }
    const S = { col: row.c, row: row.r };
    p.col = S.col; p.row = S.row; p.tile = { ...S }; p.path = []; p.stopAction();
    const log = [];
    s.walkTo(S.col + 4, S.row); frame(100); frame(100);   // 0.70 tiles into S -> S+1
    log.push(`ahead:  pos ${p.col.toFixed(3)} tile ${K(p.tile)} path ${p.path.map(K).join(' ')}`);
    s.walkTo(S.col - 4, S.row); frame(100);
    log.push(`behind: pos ${p.col.toFixed(3)} tile ${K(p.tile)} path ${p.path.map(K).join(' ')}`);
    s.walkTo(S.col + 4, S.row);
    log.push(`ahead again (tap): pos ${p.col.toFixed(3)} tile ${K(p.tile)} path ${p.path.map(K).join(' ')}`);
    const xs = [];
    for (let i = 0; i < 6; i++) { frame(100); xs.push(p.col.toFixed(3)); }
    log.push('col over the next frames (moving toward larger col is "ahead"): ' + xs.join(' '));
    res.b = log;
    return res;
  });
  console.log('(a)', JSON.stringify(out.a, null, 1));
  console.log('(b)\n' + out.b.join('\n'));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
