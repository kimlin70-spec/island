// Sanity check: does the harness catch the old (pre-fix) code? node mutant.js <seed> <frames>
const fs = require('fs');
const { open } = require('../../p4/lib.js');
const src = fs.readFileSync(__dirname + '/fuzz_page.js', 'utf8');
const seed = +(process.argv[2] || 1), frames = +(process.argv[3] || 6000);
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await G(() => {
    const p = window.__game.scene.getScene('game').player;
    // pre-fix versions from commit 1fbcf01
    p.occupiedTiles = function () { return this.path.length ? [this.tile, this.path[0]] : [this.tile]; };
    p.onMapChanged = function () { const i = this.path.findIndex((t) => !this.map.isWalkable(t.col, t.row)); if (i >= 0) this.path.length = i; };
  });
  await page.addScriptTag({ content: src });
  await G((seed) => window.__fz.init(seed), seed);
  const r = await G((n) => window.__fz.run(n), frames);
  const res = await G(() => ({ stats: window.__fz.stats, fails: window.__fz.fails }));
  console.log('frames', r.frame, 'fails', res.fails.length);
  const kinds = {}; for (const f of res.fails) kinds[f.kind] = (kinds[f.kind] || 0) + 1;
  console.log(JSON.stringify(kinds));
  console.log(JSON.stringify(res.fails[0], null, 1).slice(0, 2500));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
