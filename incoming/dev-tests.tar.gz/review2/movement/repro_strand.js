// Deterministic repro: a frame ends exactly on path[0] (diagonal) without arriving; a fence on a side tile
// of that step is accepted; the walk is cut to nothing while tile still points behind; the next tap walks
// the player diagonally back past the new fence corner (and into a fence on the old tile).
// Full GameScene steps (s.sys.step), each frame delta 150 ms (= any frame slower than 100 ms, dt capped at 0.1 s),
// test speed x3 (the 시험 window's 속도 button). Walk/build go through GameScene.walkTo and BuildSystem.commit.
const { open } = require('../../p4/lib.js');
const variant = process.argv[2] || 'side';     // 'side' | 'tile'
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { G } = T;
  const out = await G((variant) => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, m = s.map, b = s.build;
    const K = (t) => t.col + ',' + t.row;
    g.loop.sleep();
    let time = g.loop.time;
    const log = [];
    const st = (what) => log.push(`${what}: pos=(${p.col},${p.row}) tile=${K(p.tile)} path=[${p.path.map(K).join(' ')}] occupied=[${p.occupiedTiles().map(K).join(' ')}]`);
    const bad = [];
    s.events.on('postupdate', () => {
      for (let c = Math.floor(p.col); c <= Math.ceil(p.col); c++) for (let r = Math.floor(p.row); r <= Math.ceil(p.row); r++)
        if (!m.isWalkable(c, r)) bad.push(`body (${p.col.toFixed(3)},${p.row.toFixed(3)}) over blocked ${c},${r}`);
    });
    const frame = () => { time += 150; s.sys.step(time, 150); };
    s.debugGive();
    s.debugToggleSpeed();                       // 속도 x3
    st('start');
    s.walkTo(41, 35); st('tap 41,35');
    frame(); frame(); st('after 2 frames');
    s.walkTo(40, 40); st('tap 40,40');
    frame(); st('frame');
    frame(); st('frame');
    const exact = p.path.length && p.col === p.path[0].col && p.row === p.path[0].row && K(p.tile) !== K(p.path[0]);
    const side = { col: 39, row: 38 };
    const canSide = b.canBuildAt(side.col, side.row), canTile = b.canBuildAt(p.tile.col, p.tile.row), canOther = b.canBuildAt(38, 39);
    // build mode + commit at the tile's world point = what releasing a click/touch on that tile does
    b.setMode('fence');
    const commitAt = (c, r) => b.commit((c - r) * 40, (c + r) * 20);
    commitAt(side.col, side.row); st('commit fence at 39,38');
    if (variant === 'tile') { commitAt(38, 38); st('commit fence at 38,38 (the stale tile)'); }
    const fences = m.structures.map((x) => K(x)).join(' ');
    b.setMode(null);
    frame(); frame(); st('2 frames later');
    const stranded = !p.path.length && (p.col !== p.tile.col || p.row !== p.tile.row);
    s.walkTo(40, 40); st('tap 40,40 again');
    const trail = [];
    for (let i = 0; i < 12 && p.moving; i++) { frame(); trail.push(`(${p.col.toFixed(3)},${p.row.toFixed(3)}) tile ${K(p.tile)}`); }
    st('end');
    return { exact, canSide, canTile, canOther, fences, stranded, log, trail, bad: bad.slice(0, 6), nbad: bad.length };
  }, variant);
  console.log(out.log.join('\n'));
  console.log('exact landing without arrival:', out.exact, '| canBuildAt side 39,38:', out.canSide, 'side 38,39:', out.canOther, 'stale tile 38,38:', out.canTile);
  console.log('fences:', out.fences, '| stranded (empty path, pos != tile):', out.stranded);
  console.log('trail after the next tap:', out.trail.join(' -> '));
  console.log('body over blocked tiles:', out.nbad, JSON.stringify(out.bad));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
