// How often does a frame end with the step in progress only partly reserved (no builds, just walking with re-taps)?
const fs = require('fs');
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { G } = T;
  await G(() => window.__game.loop.sleep());
  const res = await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map, p = s.player;
    const K = (t) => t.col + ',' + t.row;
    function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
    const out = {};
    for (const [name, dt, tapProb] of [['dt0.1 tap2%', 0.1, 0.02], ['dt0.1 tap5%', 0.1, 0.05], ['dt0.3 tap5%', 0.30000000000000004, 0.05], ['dt1/60 tap1%', 1 / 60, 0.01], ['dt1/30 tap2%', 1 / 30, 0.02]]) {
      const R = mulberry32(99);
      p.col = 37; p.row = 39; p.tile = { col: 37, row: 39 }; p.path = []; p.stopAction();
      const o = { frames: 0, walking: 0, diagSteps: 0, orthMissTile: 0, diagMissSide: 0, diagMissTileOnly: 0 };
      for (let f = 0; f < 300000; f++) {
        if (!p.moving || R() < tapProb) {
          for (let k = 0; k < 10; k++) { const c = p.tile.col + Math.floor(R() * 13) - 6, r = p.tile.row + Math.floor(R() * 13) - 6;
            if (m.isWalkable(c, r) && Math.hypot(c - 37, r - 39) < 12) { p.goTo(c, r); break; } }
        }
        const before = K(p.tile);
        p.update(dt); o.frames++;
        if (!p.path.length) continue;
        o.walking++;
        const a = p.tile, b = p.path[0];
        if (K(a) === K(b)) continue;                      // backing out / start of a walk
        const occ = new Set(p.occupiedTiles().map(K));
        const diag = a.col !== b.col && a.row !== b.row;
        if (diag) {
          const sides = [{ col: b.col, row: a.row }, { col: a.col, row: b.row }];
          if (sides.some((t) => !occ.has(K(t)))) o.diagMissSide++;
          else if (!occ.has(K(a))) o.diagMissTileOnly++;
        } else if (!occ.has(K(a))) o.orthMissTile++;
      }
      out[name] = o;
    }
    return out;
  });
  for (const [k, v] of Object.entries(res)) console.log(k.padEnd(14), JSON.stringify(v));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
