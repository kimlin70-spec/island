// Re-tapping the same tree while the walk toward it has been cut by a new fence is ignored (act() early return).
// Real mouse clicks on the tree picture; the fence is placed with BuildSystem.place on a path tile ahead
// (the same thing a build-mode release does; canBuildAt is checked first).
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const { page, G, W } = T;
  const w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, on: sx >= 0 && sy >= 0 && sx < cam.width && sy < cam.height }; }, [wx, wy]);
  // a tree 7..10 tiles away, with a point on its picture that picks it
  const tree = await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map, p = s.player;
    const cands = m.objects.filter((o) => o.node && o.node.group === 'tree' && Math.hypot(o.col - p.tile.col, o.row - p.tile.row) >= 7 && Math.hypot(o.col - p.tile.col, o.row - p.tile.row) <= 10);
    for (const o of cands) {
      const sp = o.sprite;
      for (let fy = 0.5; fy <= 0.8; fy += 0.05) { const wx = sp.x, wy = sp.y - sp.displayHeight * sp.originY * fy;
        if (m.pickObject(wx, wy) === o) return { col: o.col, row: o.row, wx, wy, kind: o.kind }; }
    }
    return null; });
  console.log('tree', JSON.stringify(tree));
  const clickTree = async () => { const q = await w2p(tree.wx, tree.wy); await page.mouse.click(q.x, q.y); };
  const P = () => G(() => { const s = window.__game.scene.getScene('game'), p = s.player, K = (t) => t.col + ',' + t.row;
    return { tile: K(p.tile), path: p.path.map(K).join(' '), action: p.action ? K(p.action.target) : null }; });
  await clickTree();
  await page.waitForTimeout(150);
  const s1 = await P();
  console.log('after 1st click on the tree:', JSON.stringify(s1));
  // fence on a path tile 4 steps ahead (blocks the walk; the player will stop in front of it)
  const placed = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, b = s.build;
    for (let k = Math.min(5, p.path.length - 2); k >= 3; k--) { const t = p.path[k]; if (b.canBuildAt(t.col, t.row)) { b.place('fence', [{ col: t.col, row: t.row }]); return t.col + ',' + t.row; } }
    return null; });
  const s2 = await P();
  console.log('fence placed at', placed, '->', JSON.stringify(s2));
  // the user taps the tree again while the player is still walking toward the fence
  const before = await P();
  await clickTree();
  await page.waitForTimeout(100);
  const s3 = await P();
  const goalOf = (st) => st.path.split(' ').pop();
  const adj = (k) => { const [c, r] = k.split(',').map(Number); return Math.max(Math.abs(c - tree.col), Math.abs(r - tree.row)) <= 1; };
  console.log('2nd click on the tree while still walking: before', JSON.stringify(before), 'after', JSON.stringify(s3));
  console.log('   walk still ends at', goalOf(s3), '(the tile in front of the fence); is that next to the tree?', adj(goalOf(s3)));
  await W(() => !window.__game.scene.getScene('game').player.moving, null, 60000);
  await page.waitForTimeout(300);
  const s4 = await P();
  console.log('after stopping:', JSON.stringify(s4), '| next to the tree:', await G((t) => window.__game.scene.getScene('game').player.isNextTo([{ col: t.col, row: t.row }]), tree));
  await clickTree();
  await page.waitForTimeout(150);
  const s5 = await P();
  console.log('3rd click on the tree (after it stopped):', JSON.stringify(s5), '| walk ends next to the tree:', s5.path ? adj(s5.path.split(' ').pop()) : null);
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
