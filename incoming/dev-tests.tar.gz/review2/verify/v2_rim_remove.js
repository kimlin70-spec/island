// input-1 (remove mode): two short walls (rows 36 and 37, cols 36..38). In remove mode click a rim pixel (alpha 40..110) of fence 37,37
// that lies over the tile of a fence behind it, where no picture is picked. Which fence is removed? Control: a solid pixel of 37,37 there.
const { setup, UI } = require('./vlib.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await T.settle();
    await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    await T.ui(...UI.craft); await T.ui(...UI.card(2));
    for (const [c, r] of [[36, 36], [37, 36], [38, 36], [36, 37], [37, 37], [38, 37]]) await T.clickTile(c, r, 150);
    await T.ui(...UI.card(5));            // remove mode
    await T.settle();
    console.log('built', await G(() => window.__v.structs()), '| mode', (await T.snap()).mode);
    const cand = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, V = window.__v, f = m.structureAt(37, 37), sp = f.sprite;
      const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY, rim = [], solid = [];
      for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
        const x = left + i + 0.5, y = top + j + 0.5, a = V.px(f, x, y).a, t = V.tileAt(x, y), st = m.structureAt(t.col, t.row);
        if (!st || st === f) continue;
        const o = m.pickObject(x, y, m.structures);
        if (a >= 40 && a <= 110 && !o) rim.push({ x, y, a, t: t.col + ',' + t.row, under: V.key(st) });
        if (a > 110 && o === f) solid.push({ x, y, a, t: t.col + ',' + t.row, under: V.key(st) });
      }
      return { rim, solid };
    });
    console.log('rim pixels of 37,37 over another fence tile, nothing picked:', cand.rim.length, '| solid pixels of 37,37 over another fence tile:', cand.solid.length);
    // control: solid pixel
    const q0 = cand.solid[Math.floor(cand.solid.length / 2)];
    const h0 = await T.aim(q0.x, q0.y, (w) => G(([wx, wy]) => { const m = window.__game.scene.getScene('game').map, V = window.__v, t = V.tileAt(wx, wy), st = m.structureAt(t.col, t.row);
      return V.key(m.pickObject(wx, wy, m.structures)) === 'fence@37,37' && st && V.key(st) !== 'fence@37,37'; }, [w.wx, w.wy]));
    const before0 = await G(() => window.__v.structs());
    const tile0 = await G(([wx, wy]) => window.__v.tileAt(wx, wy), [h0.w.wx, h0.w.wy]);
    await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(500);
    const after0 = await G(() => window.__v.structs());
    console.log('(control) SOLID pixel of 37,37 over tile', J(tile0), '-> removed:', before0.split(' ').filter((k) => !after0.split(' ').includes(k)).join(' '));
    // put 37,37 back if it was removed (rebuild), then test the rim
    // simpler: test rim on the remaining layout only if 37,37 still stands; else rebuild it
    if (!after0.includes('fence@37,37')) {
      await T.ui(...UI.card(2)); await T.clickTile(37, 37, 300); await T.ui(...UI.card(5)); await T.settle();
      console.log('rebuilt 37,37:', await G(() => window.__v.structs()));
    }
    const cand2 = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, V = window.__v, f = m.structureAt(37, 37), sp = f.sprite;
      const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY, rim = [];
      for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
        const x = left + i + 0.5, y = top + j + 0.5, a = V.px(f, x, y).a, t = V.tileAt(x, y), st = m.structureAt(t.col, t.row);
        if (!st || st === f) continue;
        if (a >= 40 && a <= 110 && !m.pickObject(x, y, m.structures)) rim.push({ x, y, a, t: t.col + ',' + t.row, under: V.key(st) });
      }
      return rim;
    });
    for (const q of cand2) {
      const hit = await T.aim(q.x, q.y, (w) => G(([wx, wy]) => { const m = window.__game.scene.getScene('game').map, V = window.__v, f = m.structureAt(37, 37), t = V.tileAt(wx, wy), st = m.structureAt(t.col, t.row);
        const a = V.px(f, wx, wy).a; return a >= 40 && a <= 110 && !m.pickObject(wx, wy, m.structures) && st && st !== f; }, [w.wx, w.wy]));
      if (!hit) continue;
      const info = await G(([wx, wy]) => { const m = window.__game.scene.getScene('game').map, V = window.__v; const t = V.tileAt(wx, wy); return { a: V.px(m.structureAt(37, 37), wx, wy).a, tile: t, under: V.key(m.structureAt(t.col, t.row)) }; }, [hit.w.wx, hit.w.wy]);
      const before = await G(() => window.__v.structs());
      await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(500);
      const after = await G(() => window.__v.structs());
      console.log('(rim) RIM pixel of 37,37 (alpha', info.a + ') over tile', J(info.tile), 'of', info.under, '-> removed:', before.split(' ').filter((k) => !after.split(' ').includes(k)).join(' '), '| 37,37 still there:', after.includes('fence@37,37'));
      break;
    }
    console.log('player', J(await T.snap()), 'errors', J(T.errors));
  } catch (e) { console.error('CRASH', e); }
  finally { await T.browser.close(); }
})();
