// input-1 (normal mode): real mouse clicks, no handler wrapping.
// Wall of 7 fences at 34..40,37 in front of the player (37,39). Click (a) a solid pixel of fence 37,37's upper rail over row 36,
// (b) a rim pixel (alpha 40..110) of the same rail over row 36.
const { setup, UI } = require('./vlib.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await T.settle();
    console.log('start', J(await T.snap()));
    await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    await T.ui(...UI.craft); await T.ui(...UI.card(2));
    for (let c = 34; c <= 40; c++) await T.clickTile(c, 37, 150);
    await T.ui(...UI.craft);
    await T.settle();
    console.log('built', await G(() => window.__v.structs()), '| mode', (await T.snap()).mode);
    const cand = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, V = window.__v, f = m.structureAt(37, 37), sp = f.sprite;
      const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY, rim = [], solid = [];
      for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
        const x = left + i + 0.5, y = top + j + 0.5, a = V.px(f, x, y).a, t = V.tileAt(x, y);
        if (t.row !== 36 || !m.isWalkable(t.col, t.row)) continue;
        const o = m.pickObject(x, y);
        if (a >= 40 && a <= 110 && !o) rim.push({ x, y, a, i, j, t: t.col + ',' + t.row });
        if (a > 110 && o === f) { let inner = true; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (m.pickObject(x + dx, y + dy) !== f || V.tileAt(x + dx, y + dy).row !== 36) inner = false; if (inner) solid.push({ x, y, a, i, j, t: t.col + ',' + t.row }); }
      }
      return { mask: sp.texture.key, rim, solid, feet: [sp.x, sp.y] };
    });
    console.log('fence 37,37 picture', cand.mask, '| rim pixels (alpha 40..110, nothing picked) over walkable row-36 tiles:', cand.rim.length, '| inner solid pixels there:', cand.solid.length);
    // (a) control: solid pixel of the upper rail
    const sp0 = cand.solid[Math.floor(cand.solid.length / 2)];
    const a0 = await T.aim(sp0.x, sp0.y, (w) => G(([wx, wy]) => { const m = window.__game.scene.getScene('game').map; return window.__v.key(m.pickObject(wx, wy)) === 'fence@37,37'; }, [w.wx, w.wy]));
    await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(500);
    let pr = await G(() => window.__v.presses.slice(-1)[0]);
    console.log('(a) SOLID rail pixel click: press', J(pr), '-> after', J(await T.snap()));
    // (b) rim pixel: hover first, accept only if the game pointer is on a rim pixel of 37,37 with nothing picked, over a walkable row-36 tile
    let done = false;
    for (const q of cand.rim) {
      const hit = await T.aim(q.x, q.y, (w) => G(([wx, wy]) => { const s = window.__game.scene.getScene('game'), m = s.map, V = window.__v, f = m.structureAt(37, 37);
        const a = V.px(f, wx, wy).a, t = V.tileAt(wx, wy); return a >= 40 && a <= 110 && !m.pickObject(wx, wy) && t.row === 36 && m.isWalkable(t.col, t.row); }, [w.wx, w.wy]));
      if (!hit) continue;
      // what the screen shows there (rendered pixel) vs plain grass 6px further out is checked from a screenshot
      await page.screenshot({ path: __dirname + '/v1_rim_before.png', clip: { x: hit.x - 40, y: hit.y - 40, width: 80, height: 80 } });
      const info = await G(([wx, wy]) => { const s = window.__game.scene.getScene('game'), V = window.__v, f = s.map.structureAt(37, 37); return { alpha: V.px(f, wx, wy), tile: V.tileAt(wx, wy) }; }, [hit.w.wx, hit.w.wy]);
      await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(400);
      pr = await G(() => window.__v.presses.slice(-1)[0]);
      const after = await T.snap();
      console.log('(b) RIM pixel click at page', hit.x + ',' + hit.y, '| fence 37,37 pixel', J(info.alpha), 'tile', J(info.tile));
      console.log('    press', J(pr), '-> after', J(after));
      await T.stopped();
      console.log('    player ended at', (await T.snap()).tile);
      done = true; break;
    }
    if (!done) console.log('(b) could not place the pointer on a rim pixel');
    console.log('errors', J(T.errors));
  } catch (e) { console.error('CRASH', e); }
  finally { await T.browser.close(); }
})();
