// Verifier helpers: no wrapping of game handlers. Presses are logged by a passive listener added after the game's own.
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
exports.setup = async (opts = {}) => {
  const T = await open(opts);
  const { page, G } = T;
  T.g2p = (x, y) => G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect();
    return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
  T.ui = async (x, y, wait = 350) => { const p = await T.g2p(x, y); await page.mouse.move(p.x, p.y); await page.mouse.click(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  // world -> page (fractional), from the camera as it is now
  T.w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.worldView.x) * cam.zoom, sy = (wy - cam.worldView.y) * cam.zoom;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height }; }, [wx, wy]);
  T.clickWorld = async (wx, wy, wait = 0) => { const p = await T.w2p(wx, wy); await page.mouse.move(p.x, p.y); await page.mouse.click(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  T.clickTile = (c, r, wait) => T.clickWorld((c - r) * 40, (c + r) * 20, wait);
  T.stopped = () => T.W(() => !window.__game.scene.getScene('game').player.moving, null, 90000);
  T.settle = async () => { let last = null, same = 0;
    for (let i = 0; i < 80 && same < 3; i++) {
      const v = await G(() => { const c = window.__game.scene.getScene('game').cameras.main; return c.scrollX.toFixed(3) + ',' + c.scrollY.toFixed(3); });
      if (v === last) same++; else same = 0; last = v; await page.waitForTimeout(120); } };
  await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), m = s.map, V = window.__v = {};
    V.key = (o) => (o ? (o.type || o.kind) + '@' + o.col + ',' + o.row : null);
    V.tileAt = (x, y) => ({ col: Math.floor((x / 40 + y / 20) / 2 + 0.5), row: Math.floor((y / 20 - x / 40) / 2 + 0.5) });
    // the exact pixel and alpha pickObject would read for object o at world (x, y)
    V.px = (o, x, y) => { const sp = o.sprite; const lx = Math.floor(x - (sp.x - sp.displayWidth * sp.originX)), ly = Math.floor(y - (sp.y - sp.displayHeight * sp.originY));
      if (lx < 0 || ly < 0 || lx >= sp.width || ly >= sp.height) return { lx, ly, a: 0 };
      return { lx, ly, a: g.textures.getPixelAlpha(lx, ly, sp.texture.key, sp.frame.name) }; };
    V.snap = () => { const p = s.player; return { tile: p.tile.col + ',' + p.tile.row, pos: [+p.col.toFixed(2), +p.row.toFixed(2)], path: p.path.map((t) => t.col + ',' + t.row).join(' '),
      moving: p.moving, cursor: s.cursor.visible ? V.tileAt(s.cursor.x, s.cursor.y) : null, resting: s.rest.resting, mode: s.build.mode }; };
    V.structs = () => m.structures.map((x) => V.key(x)).sort().join(' ');
    V.presses = [];
    // passive: runs after GameScene.onPress (registered later); pickObject has no side effects
    s.input.on('pointerdown', (p) => { const o = m.pickObject(p.worldX, p.worldY); V.presses.push({ wx: +p.worldX.toFixed(3), wy: +p.worldY.toFixed(3), picked: V.key(o), tile: V.tileAt(p.worldX, p.worldY) }); });
    V.pointerWorld = () => { const p = s.input.activePointer; p.updateWorldPoint(s.cameras.main); return { wx: p.worldX, wy: p.worldY }; };
  });
  T.snap = () => G(() => window.__v.snap());
  // move the mouse (no press) onto integer page coords near the target and return where the game puts the pointer
  T.aim = async (wx, wy, accept) => {
    const p = await T.w2p(wx, wy);
    for (const [dx, dy] of [[0, 0], [0.5, 0], [-0.5, 0], [0, 0.5], [0, -0.5], [0.5, 0.5], [-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5]]) {
      const x = Math.round(p.x + dx), y = Math.round(p.y + dy);
      await page.mouse.move(x, y);
      const w = await G(() => window.__v.pointerWorld());
      if (await accept(w)) return { x, y, w };
    }
    return null;
  };
  return T;
};
exports.UI = { craft: [1824, 1104], card: (i) => [776 + 20 + i * 182 + 85, 898], test: [1852, 328], testItem: (i) => [1746, 402 + i * 66], rest: [960, 1132] };
