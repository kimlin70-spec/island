// input-2: tent at 40..41,35..36 and one fence at 42,36 in front of it. Enter the tent with a real click, then while resting click
// (a) the fence post over its own tile 42,36, (b) the fence post where it lies over tent tile 41,35, (c) the tent's tile 41,35 where no picture is picked.
const { setup, UI } = require('./vlib.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await T.settle();
    await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4));
    await T.ui(...UI.craft); await T.ui(...UI.card(4));            // tent
    await T.clickWorld(200, 1520, 400);                              // fc 40.5, fr 35.5 -> tiles 40..41,35..36
    await T.ui(...UI.card(2)); await T.clickTile(42, 36, 300);       // fence
    await T.ui(...UI.craft);                                         // close: build mode off
    await T.settle();
    console.log('built', await G(() => window.__v.structs()), '| mode', (await T.snap()).mode);
    // enter the tent: click a solid tent pixel high on the picture
    const tp = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, V = window.__v, t = m.structureAt(40, 35);
      for (let y = t.sprite.y - 80; y < t.sprite.y; y++) if (m.pickObject(t.sprite.x, y) === t) return { x: t.sprite.x, y }; return null; });
    await T.clickWorld(tp.x, tp.y + 10, 300);
    await T.W(() => window.__game.scene.getScene('game').rest.resting, null, 90000);
    await T.settle();
    console.log('resting', J(await T.snap()));
    const pts = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, V = window.__v, f = m.structureAt(42, 36), sp = f.sprite, tent = s.rest.tent;
      const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY, own = [], over = [];
      for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) {
        const x = left + i + 0.5, y = top + j + 0.5, t = V.tileAt(x, y);
        let inner = true;
        for (let dy = -1; dy <= 1 && inner; dy++) for (let dx = -1; dx <= 1 && inner; dx++) { if (m.pickObject(x + dx, y + dy) !== f) inner = false; const tt = V.tileAt(x + dx, y + dy); if (tt.col !== t.col || tt.row !== t.row) inner = false; }
        if (!inner) continue;
        const tentUnder = V.px(tent, x, y).a;
        if (t.col === 42 && t.row === 36) own.push({ x, y, tentUnder }); else if (m.structureAt(t.col, t.row) === tent) over.push({ x, y, t: t.col + ',' + t.row, tentUnder });
      }
      return { own: own[Math.floor(own.length / 2)], over: over[Math.floor(over.length / 2)], nOver: over.length, nOverTentOpaque: over.filter((q) => q.tentUnder > 110).length };
    });
    console.log('fence 42,36 inner pixels over a tent tile:', pts.nOver, '(tent picture also solid under', pts.nOverTentOpaque, 'of them)');
    const press = async (label, q, accept) => {
      const hit = await T.aim(q.x, q.y, accept);
      if (!hit) { console.log(label, 'could not aim'); return; }
      await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(400);
      const pr = await G(() => window.__v.presses.slice(-1)[0]);
      console.log(label, '| press', J(pr), '| resting after:', (await T.snap()).resting);
    };
    const onFence = (tileKey) => (w) => G(([wx, wy, tk]) => { const m = window.__game.scene.getScene('game').map, V = window.__v, t = V.tileAt(wx, wy);
      return V.key(m.pickObject(wx, wy)) === 'fence@42,36' && (t.col + ',' + t.row) === tk; }, [w.wx, w.wy, tileKey]);
    await press('(a) fence post over its own tile 42,36', pts.own, onFence('42,36'));
    await page.screenshot({ path: __dirname + '/v3_rest_over.png', clip: { x: (await T.w2p(pts.over.x, pts.over.y)).x - 60, y: (await T.w2p(pts.over.x, pts.over.y)).y - 60, width: 120, height: 120 } });
    await press('(b) fence post where it lies over tent tile ' + pts.over.t, pts.over, onFence(pts.over.t));
    console.log('errors', J(T.errors));
  } catch (e) { console.error('CRASH', e); }
  finally { await T.browser.close(); }
})();
