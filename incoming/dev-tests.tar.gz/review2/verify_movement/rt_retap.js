// movement-2 through the real UI: every input is a real mouse click (test window, craft button, fence card,
// build release, tree picture). No loop control; the game runs normally.
//  1. craft window open (no card), click a tree ~8 tiles away -> the player walks toward it
//  2. fence card, release on a path tile ahead -> path cut in front of the fence (agreed: stops, no re-route)
//  3. craft button (window closed, build mode off), click the same tree again while the player still walks
//  4. see whether the walk is re-planned (it should go around the fence to the tree)
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const { page, G, W, tilePos } = T;
  const w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height }; }, [wx, wy]);
  const P = () => G(() => { const s = window.__game.scene.getScene('game'), p = s.player, K = (t) => t.col + ',' + t.row;
    return { t: +(window.__gt || 0).toFixed(2), pos: [+p.col.toFixed(2), +p.row.toFixed(2)], tile: K(p.tile), path: p.path.map(K).join(' '), action: p.action ? K(p.action.target) : null, mode: s.build.mode,
             fences: s.map.structures.map(K).join(' ') }; });
  await G(() => { const s = window.__game.scene.getScene('game'); window.__gt = 0; s.events.on('update', (t, d) => { window.__gt += Math.min(d / 1000, 0.1) * s.speed; }); });
  // materials (시험 -> +20 -> 닫기)
  await page.mouse.click(1852, 328); await page.waitForTimeout(300);
  await page.mouse.click(1746, 402); await page.waitForTimeout(300);
  await page.mouse.click(1746, 402 + 4 * 66); await page.waitForTimeout(300);
  // a tree 7..10 tiles away and a point on its picture that picks it
  const tree = await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map, p = s.player;
    const cands = m.objects.filter((o) => o.node && o.node.group === 'tree' && Math.hypot(o.col - p.tile.col, o.row - p.tile.row) >= 7 && Math.hypot(o.col - p.tile.col, o.row - p.tile.row) <= 10);
    for (const o of cands) {
      const sp = o.sprite;
      for (let fy = 0.5; fy <= 0.8; fy += 0.05) { const wx = sp.x, wy = sp.y - sp.displayHeight * sp.originY * fy;
        if (m.pickObject(wx, wy) === o) return { col: o.col, row: o.row, wx, wy, hp: o.node.hp }; }
    }
    return null; });
  const hp = () => G((t) => { const o = window.__game.scene.getScene('game').map.objects.find((x) => x.col === t.col && x.row === t.row); return o && o.node ? o.node.hp : null; }, tree);
  console.log('tree', JSON.stringify(tree), 'hp', await hp());
  const clickTree = async () => { const q = await w2p(tree.wx, tree.wy); await page.mouse.click(q.x, q.y); };

  await page.mouse.click(1824, 1104);                         // craft window open, no card
  await clickTree();                                          // 1st click on the tree
  await page.waitForTimeout(100);
  console.log('1st click on the tree:', JSON.stringify(await P()));
  await page.mouse.click(776 + 20 + 2 * 182 + 85, 898);       // fence card
  // a path tile 3..5 steps ahead that can be built on now
  const target = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, b = s.build;
    for (let k = Math.min(5, p.path.length - 2); k >= 3; k--) { const t = p.path[k]; if (b.canBuildAt(t.col, t.row)) return { col: t.col, row: t.row }; }
    return null; });
  const tp = await tilePos(target.col, target.row);
  await page.mouse.click(tp.x, tp.y);                         // release on that tile in fence mode
  const s2 = await P();
  console.log('fence release on', target.col + ',' + target.row, '->', JSON.stringify(s2));
  await page.mouse.click(1824, 1104);                         // close the craft window (build mode off)
  await clickTree();                                          // 2nd click on the tree, player still walking
  await page.waitForTimeout(100);
  const s3 = await P();
  const adj = (k) => { if (!k) return null; const [c, r] = k.split(',').map(Number); return Math.max(Math.abs(c - tree.col), Math.abs(r - tree.row)) <= 1; };
  console.log('2nd click on the tree while walking:', JSON.stringify(s3), '| walk ends at', s3.path.split(' ').pop(), 'next to the tree?', adj(s3.path.split(' ').pop()));
  await W(() => !window.__game.scene.getScene('game').player.moving, null, 60000);
  await page.waitForTimeout(1500);
  const s4 = await P();
  console.log('after it stops (+1.5 s):', JSON.stringify(s4), '| tree hp', await hp());
  await clickTree();                                          // 3rd click
  await page.waitForTimeout(100);
  const s5 = await P();
  console.log('3rd click:', JSON.stringify(s5), '| walk ends next to the tree:', adj(s5.path.split(' ').pop()));
  await W((t) => { const o = window.__game.scene.getScene('game').map.objects.find((x) => x.col === t.col && x.row === t.row); return o && o.node && o.node.hp < t.hp; }, tree, 60000).catch(() => {});
  console.log('after the 3rd click: tree hp', await hp(), JSON.stringify(await P()));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
