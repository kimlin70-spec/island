// Pure arithmetic replica of Player.update (same expressions) to find where a reversal leads to an
// exact-landing-without-arrival on a diagonal step. Ignores the map (geometry only).
const speedMul = +(process.argv[2] || 1);
const dt = Math.min(150 / 1000, 0.1) * speedMul;
const LEFT = 3.5 * dt;
function frame(st) {
  let left = LEFT;
  while (left > 0 && st.path.length) {
    const t = st.path[0];
    const dc = t.col - st.col, dr = t.row - st.row;
    const dist = Math.hypot(dc, dr);
    if (dist <= left + 1e-9) { st.col = t.col; st.row = t.row; st.tile = { col: t.col, row: t.row }; st.path.shift(); left -= dist; }
    else { st.col += dc / dist * left; st.row += dr / dist * left; left = 0; }
  }
}
const D8 = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
const DG = D8.filter(([a,b]) => a && b);
let hits = [];
for (let c = 20; c <= 60; c++) for (let r = 20; r <= 60; r++) {
  for (const d1 of D8) for (const d2 of D8) {
    const S = { col: c, row: r }, N1 = { col: c + d1[0], row: r + d1[1] }, N2 = { col: N1.col + d2[0], row: N1.row + d2[1] };
    if (N2.col === c && N2.row === r) continue;
    for (const d3 of D8) {
      const N3 = { col: N1.col + d3[0], row: N1.row + d3[1] };
      if (N3.col === N2.col && N3.row === N2.row) continue;
      for (let k = 1; k <= 8; k++) {
        const st = { col: c, row: r, tile: { ...S }, path: [S, N1, N2, { col: N2.col + d2[0], row: N2.row + d2[1] }] };
        for (let i = 0; i < k; i++) frame(st);
        // must be mid-step N1 -> N2 (tile N1, path[0] N2) for the reversal to go back to N1
        if (!(st.tile.col === N1.col && st.tile.row === N1.row && st.path.length && st.path[0].col === N2.col && st.path[0].row === N2.row)) continue;
        if (st.col === N1.col && st.row === N1.row) continue;
        st.path = [N1, N3, { col: N3.col + d3[0], row: N3.row + d3[1] }];   // reversal: back to N1, then one step to N3, then on
        for (let i = 0; i < 12 && st.path.length; i++) {
          frame(st);
          const t = st.path[0];
          if (t && st.col === t.col && st.row === t.row && (st.tile.col !== t.col || st.tile.row !== t.row)) {
            const diag = st.tile.col !== t.col && st.tile.row !== t.row;
            hits.push({ S: c + ',' + r, d1, d2, d3, k, after: i + 1, tile: st.tile.col + ',' + st.tile.row, at: t.col + ',' + t.row, diag });
            break;
          }
        }
      }
    }
  }
}
const diag = hits.filter((h) => h.diag);
console.log('speed', speedMul, 'LEFT', LEFT, 'hits', hits.length, 'diag', diag.length);
const near = diag.filter((h) => { const [c, r] = h.S.split(',').map(Number); return Math.abs(c - 37) <= 4 && Math.abs(r - 39) <= 4; });
console.log('diag near start (within 4):', near.length);
for (const h of near.slice(0, 30)) console.log(JSON.stringify(h));
const byPattern = {};
for (const h of diag) { const k = `d1=${h.d1} d2=${h.d2} d3=${h.d3} k=${h.k} after=${h.after}`; byPattern[k] = (byPattern[k] || 0) + 1; }
console.log(Object.entries(byPattern).sort((a, b) => b[1] - a[1]).slice(0, 15));
