// Search (deterministic stepping, delta 150 ms = capped dt 0.1, speed x1) for two-tap sequences from the start tile
// that leave the player exactly on path[0] of a DIAGONAL step without arriving (the state movement-1 relies on).
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { G } = T;
  const out = await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, m = s.map;
    const K = (t) => t.col + ',' + t.row;
    g.loop.sleep();
    let time = g.loop.time;
    const frame = () => { time += 150; s.sys.step(time, 150); };
    const reset = () => { p.col = 37; p.row = 39; p.tile = { col: 37, row: 39 }; p.path = []; p.stopAction(); };
    const hits = [];
    let tries = 0;
    const targets = [];
    for (let c = 33; c <= 42; c++) for (let r = 34; r <= 43; r++) if (m.isWalkable(c, r)) targets.push({ col: c, row: r });
    for (const A of targets) for (const B of targets) {
      if (K(A) === K(B)) continue;
      for (let k = 1; k <= 7; k++) {
        reset(); tries++;
        if (!p.goTo(A.col, A.row)) break;
        for (let i = 0; i < k; i++) frame();
        if (!p.moving) break;
        if (!p.goTo(B.col, B.row)) continue;
        for (let i = 0; i < 25 && p.moving; i++) {
          frame();
          const t = p.path[0];
          if (t && p.col === t.col && p.row === t.row && (p.tile.col !== t.col || p.tile.row !== t.row) && p.tile.col !== t.col && p.tile.row !== t.row) {
            hits.push({ A: K(A), B: K(B), k, after: i + 1, tile: K(p.tile), next: K(t), occ: p.occupiedTiles().map(K).join(' ') });
            break;
          }
        }
        if (hits.length >= 12) return { tries, hits };
      }
    }
    return { tries, hits };
  });
  console.log('tries', out.tries, 'hits', out.hits.length);
  for (const h of out.hits) console.log(JSON.stringify(h));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
