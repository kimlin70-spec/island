const speedMul = 1, dt = Math.min(150 / 1000, 0.1) * speedMul, LEFT = 3.5 * dt;
function frame(st) { let left = LEFT; while (left > 0 && st.path.length) { const t = st.path[0]; const dc = t.col - st.col, dr = t.row - st.row; const dist = Math.hypot(dc, dr);
  if (dist <= left) { st.col = t.col; st.row = t.row; st.tile = { col: t.col, row: t.row }; st.path.shift(); left -= dist; } else { st.col += dc / dist * left; st.row += dr / dist * left; left = 0; } } }
const D8 = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
const cells = {};
for (let c = 15; c <= 65; c++) for (let r = 15; r <= 65; r++) for (const d1 of D8) for (const d2 of D8) {
  const S = { col: c, row: r }, N1 = { col: c + d1[0], row: r + d1[1] }, N2 = { col: N1.col + d2[0], row: N1.row + d2[1] };
  if (N2.col === c && N2.row === r) continue;
  for (const d3 of D8) { if (!(d3[0] && d3[1])) continue;
    const N3 = { col: N1.col + d3[0], row: N1.row + d3[1] }; if (N3.col === N2.col && N3.row === N2.row) continue;
    for (let k = 1; k <= 8; k++) {
      const st = { col: c, row: r, tile: { ...S }, path: [S, N1, N2, { col: N2.col + d2[0], row: N2.row + d2[1] }] };
      for (let i = 0; i < k; i++) frame(st);
      if (!(st.tile.col === N1.col && st.tile.row === N1.row && st.path.length && st.path[0].col === N2.col && st.path[0].row === N2.row)) continue;
      if (st.col === N1.col && st.row === N1.row) continue;
      st.path = [N1, N3, { col: N3.col + d3[0], row: N3.row + d3[1] }];
      for (let i = 0; i < 12 && st.path.length; i++) { frame(st); const t = st.path[0];
        if (t && st.col === t.col && st.row === t.row && st.tile.col !== t.col && st.tile.row !== t.row) {
          const key = `${c},${r}`; (cells[key] = cells[key] || []).push(`d1=${d1} d2=${d2} d3=${d3} k=${k} after=${i + 1}`); break; } }
    } }
}
const list = Object.keys(cells).map((k) => { const [c, r] = k.split(',').map(Number); return { k, d: Math.hypot(c - 37, r - 39), n: cells[k].length, ex: cells[k][0] }; }).sort((a, b) => a.d - b.d);
console.log('cells with diag hits:', list.length);
for (const x of list.slice(0, 25)) console.log(x.k, x.d.toFixed(1), x.n, x.ex);
