// movement-1, through the real UI at speed x1 (no speed tool): every input is a real Playwright mouse click
// (craft button, fence card, ground taps, build release). Only the TIMING is controlled: the page's game loop is
// put to sleep at a chosen frame boundary (postupdate) so the clicks land between two particular frames, which is
// what a user's click does on a slow device; then the loop is woken. CPU throttling keeps every frame >= 100 ms
// (dt capped at 0.1 s), like a device under 10 fps. All deltas are recorded to prove dt = 0.1 in every frame.
const { open } = require('../../p4/lib.js');
const S = { col: +(process.argv[2] || 22), row: +(process.argv[3] || 26) };
const A = { col: +(process.argv[4] || 24), row: +(process.argv[5] || 29) };
const B = { col: +(process.argv[6] || 22), row: +(process.argv[7] || 25) };
const K1 = +(process.argv[8] || 5);
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const { page, G, W, tilePos } = T;
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: 2 });
  const K = (t) => t.col + ',' + t.row;
  const st = () => G(() => {
    const s = window.__game.scene.getScene('game'), p = s.player, K = (t) => t.col + ',' + t.row;
    return { n: window.__R ? window.__R.n : -1, pos: [p.col, p.row], tile: K(p.tile), path: p.path.map(K).join(' '), occ: p.occupiedTiles().map(K).join(' '), mode: s.build.mode,
             fences: s.map.structures.map((x) => K(x)).join(' ') };
  });
  // a click point inside tile (col,row) that picks no object picture (so it is a ground tap)
  const groundPoint = (col, row) => G(([col, row]) => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    for (const [dx, dy] of [[0, 0], [0, 6], [0, -6], [10, 0], [-10, 0], [0, 12], [16, 4], [-16, 4]]) {
      const wx = (col - row) * 40 + dx, wy = (col + row) * 20 + dy;
      if (!m.pickObject(wx, wy)) return { dx, dy };
    }
    return null;
  }, [col, row]);
  const clickTile = async (col, row, needGround = true) => {
    const off = needGround ? await groundPoint(col, row) : { dx: 0, dy: 0 };
    if (!off) throw new Error('no ground point on ' + col + ',' + row);
    const p = await tilePos(col, row);
    if (!p.on) throw new Error(`tile ${col},${row} off screen`);
    await page.mouse.click(p.x + off.dx, p.y + off.dy);
  };
  const walkAndWait = async (col, row) => { await clickTile(col, row); await W(() => !window.__game.scene.getScene('game').player.moving, null, 120000); };

  // materials: 시험 -> 나무, 돌 +20 -> 닫기 (real clicks)
  await page.mouse.click(1852, 328); await page.waitForTimeout(400);
  await page.mouse.click(1746, 402); await page.waitForTimeout(400);
  await page.mouse.click(1746, 402 + 4 * 66); await page.waitForTimeout(400);
  console.log('wood', await G(() => window.__game.scene.getScene('game').inventory.count ? window.__game.scene.getScene('game').inventory.count('wood') : JSON.stringify(window.__game.scene.getScene('game').inventory)));

  // walk to S in hops with real clicks
  const walkable = await G((t) => t.map((x) => window.__game.scene.getScene('game').map.isWalkable(x.col, x.row)), [S, A, B, { col: 30, row: 33 }]);
  console.log('walkable S,A,B,hop', JSON.stringify(walkable));
  await walkAndWait(30, 33);
  await walkAndWait(S.col, S.row);
  await page.waitForTimeout(800);
  console.log('at S:', JSON.stringify(await st()));

  // frame hook: count frames, record deltas, sleep at R.stopAt
  await G(() => {
    const g = window.__game, s = g.scene.getScene('game');
    const R = window.__R = { n: 0, stopAt: 1, deltas: [] };
    s.events.on('update', (t, d) => R.deltas.push(+d.toFixed(1)));
    s.events.on('postupdate', () => { R.n++; if (R.n === R.stopAt) g.loop.sleep(); });
  });
  const asleep = () => W(() => !window.__game.loop.running, null, 60000);
  const runFrames = async (k) => { await G((k) => { window.__R.stopAt = window.__R.n + k; window.__game.loop.wake(); }, k); await asleep(); };
  await asleep();

  // craft window open (no card selected yet, so ground taps still walk)
  await page.mouse.click(1824, 1104);
  console.log('craft open, mode =', (await st()).mode);
  await clickTile(A.col, A.row);                          // tap A
  console.log('tap A', K(A), JSON.stringify(await st()));
  await runFrames(K1);
  console.log(`after ${K1} frames`, JSON.stringify(await st()));
  await clickTile(B.col, B.row);                          // tap B (turn back)
  console.log('tap B', K(B), JSON.stringify(await st()));
  await page.mouse.click(776 + 20 + 2 * 182 + 85, 898);   // fence card
  console.log('fence card, mode =', (await st()).mode);
  // run frame by frame until the exact-landing state shows up (or the walk ends)
  let ex = null;
  for (let i = 0; i < 12; i++) {
    await runFrames(1);
    const s1 = await st();
    const e = await G(() => { const p = window.__game.scene.getScene('game').player, t = p.path[0];
      return !!t && p.col === t.col && p.row === t.row && p.tile.col !== t.col && p.tile.row !== t.row; });
    console.log(`frame +${i + 1}`, JSON.stringify(s1), e ? '<== exactly on path[0], not arrived' : '');
    if (e) { ex = s1; break; }
    if (!s1.path) break;
  }
  if (!ex) { console.log('no exact landing this run'); console.log('deltas', JSON.stringify((await G(() => window.__R.deltas)))); await T.browser.close(); return; }
  const tile = ex.tile.split(',').map(Number), at = ex.path.split(' ')[0].split(',').map(Number);
  const side1 = { col: at[0], row: tile[1] }, side2 = { col: tile[0], row: at[1] };
  const can = await G(([a, b, c]) => { const bs = window.__game.scene.getScene('game').build; return [bs.canBuildAt(a.col, a.row), bs.canBuildAt(b.col, b.row), bs.canBuildAt(c.col, c.row)]; }, [side1, side2, { col: tile[0], row: tile[1] }]);
  console.log('canBuildAt side', K(side1), can[0], 'side', K(side2), can[1], 'stale tile', ex.tile, can[2]);
  await clickTile(side1.col, side1.row, false);           // release on a side tile of the step in progress, in fence mode
  console.log('released on side tile', K(side1), JSON.stringify(await st()));
  await runFrames(3);
  console.log('3 frames later', JSON.stringify(await st()));
  await clickTile(side2.col, side2.row, false);           // the other side tile is buildable too now
  console.log('released on side tile', K(side2), JSON.stringify(await st()));
  await page.mouse.click(1824, 1104);                     // close the craft window (build mode off)
  console.log('craft closed, mode =', (await st()).mode);
  // tap a tile beyond the stale tile: the route is planned from the stale tile
  const dest = process.argv[9] ? { col: +process.argv[9], row: +process.argv[10] } : { col: tile[0] + (tile[0] - at[0]), row: tile[1] + (tile[1] - at[1]) };
  const okDest = await G((d) => window.__game.scene.getScene('game').map.isWalkable(d.col, d.row), dest);
  console.log('dest', K(dest), 'walkable', okDest);
  await clickTile(dest.col, dest.row);
  console.log('tap dest', JSON.stringify(await st()));
  await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, m = s.map; window.__R.bad = []; window.__R.trail = [];
    s.events.on('postupdate', () => {
      window.__R.trail.push(`(${p.col.toFixed(3)},${p.row.toFixed(3)})`);
      for (let c = Math.floor(p.col); c <= Math.ceil(p.col); c++) for (let r = Math.floor(p.row); r <= Math.ceil(p.row); r++)
        if (!m.isWalkable(c, r)) window.__R.bad.push(`body (${p.col.toFixed(3)},${p.row.toFixed(3)}) over blocked ${c},${r}`);
    }); });
  for (let i = 0; i < 10; i++) { await runFrames(1); if (i === 1) await page.screenshot({ path: __dirname + '/rt_strand_between.png', clip: { x: 760, y: 400, width: 400, height: 400 } }); }
  const R = await G(() => window.__R);
  console.log('trail', R.trail.join(' '));
  console.log('body over blocked tiles:', JSON.stringify(R.bad));
  console.log('end', JSON.stringify(await st()));
  console.log('frame deltas passed to the scene (ms; >=100 means dt = 0.1):', JSON.stringify(R.deltas), 'min', Math.min(...R.deltas));
  console.log('errors', JSON.stringify(T.errors));
  await G(() => window.__game.loop.wake());
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
