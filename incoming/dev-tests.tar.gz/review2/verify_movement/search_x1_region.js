// In-page deterministic search (delta 150 ms -> capped dt 0.1, speed x1) over start tiles in the upper-left
// part of the island: stand on S, goTo(A), k frames, goTo(B), then look for an exact landing on a diagonal step
// without arrival. Uses the real map, A* and Player code.
const { open } = require('../../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { G } = T;
  const out = await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, m = s.map;
    const K = (t) => t.col + ',' + t.row;
    g.loop.sleep();
    let time = g.loop.time;
    const frame = () => { time += 150; s.sys.step(time, 150); };
    const place = (S) => { p.col = S.col; p.row = S.row; p.tile = { ...S }; p.path = []; p.stopAction(); };
    const hits = [];
    let tries = 0;
    for (let sc = 22; sc <= 33; sc++) for (let sr = 22; sr <= 33; sr++) {
      if (!m.isWalkable(sc, sr)) continue;
      const S = { col: sc, row: sr };
      for (let ac = sc - 3; ac <= sc + 3; ac++) for (let ar = sr - 3; ar <= sr + 3; ar++) {
        if (Math.max(Math.abs(ac - sc), Math.abs(ar - sr)) < 2 || !m.isWalkable(ac, ar)) continue;
        for (const k of [5, 6]) {
          place(S);
          if (!p.goTo(ac, ar)) continue;
          for (let i = 0; i < k; i++) frame();
          if (!p.moving) continue;
          const N1 = { ...p.tile };
          for (let bc = N1.col - 2; bc <= N1.col + 2; bc++) for (let br = N1.row - 2; br <= N1.row + 2; br++) {
            if (!m.isWalkable(bc, br)) continue;
            // replay to the same state
            place(S); p.goTo(ac, ar); for (let i = 0; i < k; i++) frame();
            tries++;
            if (!p.goTo(bc, br)) continue;
            for (let i = 0; i < 12 && p.moving; i++) {
              frame();
              const t = p.path[0];
              if (t && p.col === t.col && p.row === t.row && p.tile.col !== t.col && p.tile.row !== t.row) {
                hits.push({ S: K(S), A: ac + ',' + ar, k, B: bc + ',' + br, after: i + 1, tile: K(p.tile), at: K(t), path: p.path.map(K).join(' '), occ: p.occupiedTiles().map(K).join(' '),
                            sides: [t.col + ',' + p.tile.row, p.tile.col + ',' + t.row].map((x) => x + (m.isWalkable(...x.split(',').map(Number)) ? '' : '(blocked)')).join(' ') });
                break;
              }
            }
          }
        }
      }
      if (hits.length > 40) break;
    }
    return { tries, hits };
  });
  console.log('tries', out.tries, 'hits', out.hits.length);
  for (const h of out.hits.slice(0, 40)) console.log(JSON.stringify(h));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
