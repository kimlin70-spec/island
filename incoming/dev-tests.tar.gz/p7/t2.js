// Phase 7 확인 2: 철조망. 이어진 그림(울타리와는 안 이어짐), 할 일 5번, 주인공은 그냥 지나감,
// 적은 0.4배로 느려지고 1초마다 피해 1(철조망 체력도 1씩), 체력 0이면 사라짐, 길찾기 비용 3, 치우기
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 960, h: 600 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  // 주인공 아래쪽으로 6칸이 비어 있는 줄을 찾는다(같은 row, col+2..col+7)
  const L = await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.startStage2(); s.debugGive(); s.debugGive();
    const p = s.player.tile;
    for (const dr of [2, -2, 3, -3, 4]) { const r = p.row + dr, cs = [0, 1, 2, 3, 4, 5].map((k) => p.col - 2 + k);
      if (cs.every((c) => s.build.canBuildAt(c, r)) && s.build.canBuildAt(p.col - 2, r + 1)) return { r, cs }; }
    return null; });
  const built = await G((L) => { const s = window.__S; s.build.setMode('wire');
    for (const c of L.cs) { s.pressing = true; s.build.commit((c - L.r) * 40, (c + L.r) * 20); }
    s.build.setMode('fence'); s.pressing = true; s.build.commit((L.cs[0] - (L.r + 1)) * 40, (L.cs[0] + L.r + 1) * 20); s.build.setMode(null);
    const tex = L.cs.map((c) => s.map.wireAt(c, L.r) && s.map.wireAt(c, L.r).sprite.texture.key);
    const f = s.map.structureAt(L.cs[0], L.r + 1);
    return { tex, fence: f && f.sprite.texture.key, wires: s.build.count('wire'), todo: s.todo.isDone('wire'), iron: s.inventory.count('iron'), blocks: s.map.isWalkable(L.cs[2], L.r) }; }, L);
  ok('6 wires in a row link to each other (ends 1-sided, middle 2-sided), not to the fence next to one', L && J(built.tex) === J(['build_wire_1', 'build_wire_3', 'build_wire_3', 'build_wire_3', 'build_wire_3', 'build_wire_2']) && built.fence === 'build_fence_0', J({ L, built }));
  ok('wire costs 1 iron each; to-do 5 "철조망 6개 깔기" checked; wire tiles stay walkable', built.iron === 40 - 6 && built.wires === 6 && built.todo && built.blocks, J(built));
  const nob = await G((L) => { const s = window.__S; return { onWire: s.build.canBuildAt(L.cs[1], L.r) }; }, L);
  ok('nothing can be built on a wire tile', !nob.onWire, J(nob));
  // 주인공은 철조망 위를 그냥 지나간다(빠르기 그대로)
  const pw = await G((L) => { const s = window.__S, p = s.player; p.col = L.cs[2]; p.row = L.r - 1; p.tile = { col: L.cs[2], row: L.r - 1 }; p.path = [];
    window.__ps = []; s.events.on('postupdate', () => { if (p.moving) window.__ps.push([p.col, p.row]); }); return s.walkTo(L.cs[2], L.r + 2); }, L);
  await T.run(90);
  const pr = await G((L) => { const s = window.__S, p = s.player; const ps = window.__ps; let d = 0; for (let i = 1; i < ps.length; i++) d += Math.hypot(ps[i][0] - ps[i - 1][0], ps[i][1] - ps[i - 1][1]);
    return { tile: [p.tile.col, p.tile.row], crossed: ps.some((q) => Math.round(q[1]) === L.r), speed: +(d / ((ps.length - 1) / 60)).toFixed(2), hearts: s.hearts.value }; }, L);
  ok('the player walks across a wire at normal speed and is not hurt', J(pr.tile) === J([L.cs[2], L.r + 2]) && pr.crossed && Math.abs(pr.speed - 3.5) < 0.1 && pr.hearts === 5, J(pr));
  // 좀비를 철조망 위에 세운다: 0.4배, 1초마다 피해 1, 철조망 체력 1씩
  const z0 = await G((L) => { const s = window.__S, E = s.enemies; s.hurtPlayer = () => false; s.pressEnemy = () => {};
    const p = s.player; p.col = L.cs[0] - 6; p.row = L.r; p.tile = { col: p.col, row: p.row }; p.path = [];
    const z = window.__z = E.add('zombie', { col: L.cs[5], row: L.r }); z.hp = 99; window.__zl = [];
    z.path = L.cs.slice(0, 5).reverse().map((c) => ({ col: c, row: L.r })); z.wantPath = false; z.repathLeft = 99; z.goalKey = 'x';
    s.events.on('postupdate', () => { if (z.alive) window.__zl.push({ t: +s.elapsed.toFixed(3), c: +z.col.toFixed(4), hp: z.hp, wires: L.cs.map((c) => (s.map.wireAt(c, L.r) ? s.map.wireAt(c, L.r).hp : null)) }); });
    return { speed: z.speedNow() }; }, L);
  await T.run(60 * 3);
  const zl = await G(() => window.__zl.slice());
  const mv = zl.slice(10, 70); const sp = (mv[0].c - mv[mv.length - 1].c) / (mv[mv.length - 1].t - mv[0].t);
  const hpDrops = zl.filter((x, i) => i && x.hp < zl[i - 1].hp).map((x) => x.t - zl[0].t);
  const wireDrop = zl[zl.length - 1].wires.reduce((a, w) => a + (w === null ? 10 : 10 - w), 0);
  ok('a zombie on wire walks at 1.2 x 0.4 = 0.48 tiles/s', z0.speed === 1.2 * 0.4 && Math.abs(sp - 0.48) < 0.01, J({ z0, sp }));
  ok('it loses 1 hp every 1.0 s on wire, and the wire loses 1 hp each time', hpDrops.length >= 2 && Math.abs(hpDrops[1] - hpDrops[0] - 1) < 0.02 && wireDrop === 99 - zl[zl.length - 1].hp, J({ hpDrops, wireDrop, last: zl[zl.length - 1] }));
  // 체력 1 철조망: 피해를 주며 사라진다(먼지, poof 없음)
  const wr = await G((L) => { const s = window.__S, z = window.__z; const h = z.here(); const w = s.map.wireAt(h.col, h.row); w.hp = 1; z.wireLeft = 0.01; window.__poofs = 0;
    const op = s.effects.poof.bind(s.effects); s.effects.poof = (x, y) => { window.__poofs++; op(x, y); }; window.__w = w; return [h.col, h.row]; }, L);
  await T.run(3);
  const wg = await G((at) => { const s = window.__S; return { gone: !s.map.structures.includes(window.__w), at: s.map.wireAt(at[0], at[1]), poofs: window.__poofs, wires: s.build.count('wire') }; }, wr);
  ok('a wire at 1 hp wears out after its last hit (no poof: 12.7 chips + dust)', wg.gone && !wg.at && wg.poofs === 0 && wg.wires === 5, J(wg));
  // 길찾기: 곧은 길 위의 철조망 한 칸은 돌아서 피한다(비용 3 > 돌아가는 비용)
  const rt = await G((L) => { const s = window.__S, z = window.__z; const r = L.r - 3, c0 = L.cs[0];
    const free = [0, 1, 2, 3, 4].every((k) => s.map.isWalkable(c0 + k, r) && s.map.isWalkable(c0 + k, r - 1) && s.map.isWalkable(c0 + k, r + 1));
    if (!free) return { skip: true };
    s.build.place('wire', [{ col: c0 + 2, row: r }]);
    const route = z.findRoute([{ col: c0 + 4, row: r }], { col: c0, row: r });
    return { free, route: route.map((t) => t.col + ',' + t.row), through: route.some((t) => t.col === c0 + 2 && t.row === r) }; }, L);
  ok('enemy pathfinding avoids a single wire tile when going round is cheaper (cost 3)', rt.skip || (rt.route && !rt.through), J(rt));
  // 치우기: 철조망은 돌려받는 것이 없다
  const rm = await G((L) => { const s = window.__S; const n0 = s.inventory.count('iron'); const w = s.map.wireAt(L.cs[0], L.r);
    s.build.setMode('remove'); s.pressing = true; s.build.commit((L.cs[0] - L.r) * 40, (L.cs[0] + L.r) * 20); s.build.setMode(null);
    return { gone: !s.map.wireAt(L.cs[0], L.r), iron: s.inventory.count('iron') - n0, nextTex: s.map.wireAt(L.cs[1], L.r) && s.map.wireAt(L.cs[1], L.r).sprite.texture.key }; }, L);
  ok('치우기 removes a wire with no refund and the neighbour relinks', rm.gone && rm.iron === 0 && /build_wire_\d+/.test(rm.nextTex || 'build_wire_x'), J(rm));
  // 철조망에 쓰러지는 적
  const kd = await G((L) => { const s = window.__S, z = window.__z; z.hp = 1; z.wireLeft = 0.01; const h = z.here(); const w = s.map.wireAt(h.col, h.row) || s.build.place('wire', [h]); w.hp = 10; window.__d0 = s.enemies.defeated; return true; }, L);
  await T.run(5);
  const kr = await G(() => ({ alive: window.__z.alive, inList: window.__S.enemies.list.includes(window.__z), corpse: window.__z.sprite.active }));
  ok('an enemy killed by wire falls (corpse) and leaves the list', !kr.alive && !kr.inList && kr.corpse, J(kr));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
