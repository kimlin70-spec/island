// Phase 7 확인 1: 1단계에서는 철광석을 못 캔다 -> 첫 밤 결과 창 "계속하기" -> 2단계(할 일, 가방, 두 줄 만들기 창, 시험용 +20)
// -> 곡괭이로 철광석 캐기(2~3개, 캔 수 5 이상이면 할 일 1번), 곡괭이 없이 누르면 알림
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const ui = () => G(() => { const u = window.__game.scene.getScene('ui'), s = window.__game.scene.getScene('game');
    return { todo: u.todoLabels.map((l) => l.text), bag: Object.keys(u.bagCounts), bagN: Object.fromEntries(Object.entries(u.bagCounts).map(([k, v]) => [k, v.text])),
      cards: u.cards.map((c) => [c.card.id, Math.round(c.box.x), Math.round(c.box.y)]), win: [Math.round(u.craftWin.x), Math.round(u.craftWin.y)],
      give: u.debugLabels[0].label.text, stage: s.stage }; });
  // 1) 1단계
  let st = await ui();
  ok('stage 1: 6 to-do items, bag wood/stone, 6 cards in one row', st.stage === 1 && st.todo.length === 6 && st.todo[0] === '나무 도끼 만들기' && J(st.bag) === J(['wood', 'stone']) && st.cards.length === 6 && new Set(st.cards.map((c) => c[2])).size === 1 && st.give === '나무, 돌 +20', J(st));
  const ironTap = await G(() => { const s = window.__game.scene.getScene('game'); s.tools.push('pickaxe'); window.__n = []; s.events.on('notice', (t) => window.__n.push(t));
    const o = s.map.objects.find((x) => x.kind === 'iron'); window.__iron = o; const sp = o.sprite;
    s.onPress({ wasTouch: true, worldX: sp.x, worldY: sp.y - 10 }); return { notices: window.__n.slice(), action: !!s.player.action }; });
  ok('stage 1: tapping iron (even with a pickaxe) says "아직 캘 수 없습니다" and does nothing', J(ironTap.notices) === J(['아직 캘 수 없습니다']) && !ironTap.action, J(ironTap));
  // 2) 첫 밤 -> 아침 -> 결과 창 -> 계속하기(실제 클릭)
  await G(() => { const s = window.__game.scene.getScene('game'); s.debugNight(); s.enemies.schedule = []; s.pirates.landDue = false; s.pirates.shipDue = false; s.debugMorning(); });
  await T.until('return !g.scene.isActive("game")', 600);
  const texts = await T.modalTexts();
  await T.modalButton('계속하기'); await T.run(3);
  st = await ui();
  ok('result window "계속하기" starts stage 2', texts && texts[0] === '첫 밤을 넘겼습니다' && st.stage === 2, J({ texts, stage: st.stage }));
  ok('stage 2 to-do list (11.1)', J(st.todo) === J(['철광석 5개 모으기', '총 만들기', '망루 세우기', '총 타워 세우기', '철조망 6개 깔기', '밤을 넘기기']), J(st.todo));
  ok('stage 2 bag: wood, stone, iron', J(st.bag) === J(['wood', 'stone', 'iron']), J(st));
  const ids = st.cards.map((c) => c[0]);
  const rows = [...new Set(st.cards.map((c) => c[2]))];
  ok('stage 2 craft window: two rows; top axe, pickaxe, gun (Phase 9), fence, wire; bottom campfire, tent, watchtower, gun tower (Phase 8), remove',
    J(ids) === J(['axe', 'pickaxe', 'gun', 'fence', 'wire', 'campfire', 'tent', 'watchtower', 'guntower', 'remove']) && rows.length === 2 && st.cards[2][1] - st.cards[1][1] === 162 && st.cards[7][1] - st.cards[6][1] === 162 && st.win[0] === 1920 - 24 - 838 && st.win[1] === 580, J(st));
  ok('stage 2 test tool: "나무, 돌, 철광석 +20" gives iron too', st.give === '나무, 돌, 철광석 +20' && await G(() => { const s = window.__game.scene.getScene('game'); s.debugGive(); return s.inventory.count('iron') === 20; }), st.give);
  await G(() => { const s = window.__game.scene.getScene('game'); s.inventory.items.iron = 0; s.events.emit('inventory-changed'); });
  // 3) 곡괭이 없이 철광석 -> "곡괭이가 필요합니다"
  const np = await G(() => { const s = window.__game.scene.getScene('game'); s.tools = ['dagger', 'axe']; window.__n.length = 0;
    const sp = window.__iron.sprite; s.onPress({ wasTouch: true, worldX: sp.x, worldY: sp.y - 10 }); return { n: window.__n.slice(), action: !!s.player.action }; });
  ok('stage 2: tapping iron without a pickaxe says "곡괭이가 필요합니다"', J(np.n) === J(['곡괭이가 필요합니다']) && !np.action, J(np));
  // 4) 곡괭이로 캐기: 5번에 다 캔다(15 / 3), 2~3개, 돌 부스러기
  await G(() => { const s = window.__game.scene.getScene('game'); s.tools = ['dagger', 'axe', 'pickaxe']; s.events.emit('tools-changed');
    window.__hits = 0; const oh = s.nodes.hit.bind(s.nodes); s.nodes.hit = (o, t) => { if (o === window.__iron) window.__hits++; return oh(o, t); };
    window.__key = window.__iron.key; const sp = window.__iron.sprite; s.onPress({ wasTouch: true, worldX: sp.x, worldY: sp.y - 10 }); });
  const r = await T.until('return window.__iron.kind === "rubble"', 60 * 40);
  const mined = await G(() => { const s = window.__game.scene.getScene('game'); return { hits: window.__hits, iron: s.inventory.count('iron'), mined: s.ironMined, key: window.__key, kind: window.__iron.kind, bag: window.__game.scene.getScene('ui').bagCounts.iron.text, walk: s.map.isWalkable(window.__iron.col, window.__iron.row) }; });
  ok('stage 2: the pickaxe mines iron in 5 hits; obj_iron_1 gives 2, obj_iron_2 gives 3; it becomes rubble (walkable); bag shows it',
    r.ok && mined.hits === 5 && mined.iron === (mined.key === 'obj_iron_1' ? 2 : 3) && mined.mined === mined.iron && mined.bag === String(mined.iron) && mined.walk, J(mined));
  ok('to-do 1 not yet checked below 5', !(await G(() => window.__game.scene.getScene('game').todo.isDone('iron'))) || mined.mined >= 5, J(mined));
  // 다른 철광석을 하나 더(5개 넘게)
  for (let k = 0; k < 3 && !(await G(() => window.__game.scene.getScene('game').ironMined >= 5)); k++) {
    await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; const ores = s.map.objects.filter((x) => x.kind === 'iron' && x.node).sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row));
      window.__iron2 = ores[0]; s.pressNode(ores[0]); });
    await T.until('return window.__iron2.kind === "rubble"', 60 * 40);
    if (k === 0) ok('to-do 1 stays open while fewer than 5 are mined', await G(() => { const s = window.__game.scene.getScene('game'); return s.ironMined >= 5 || !s.todo.isDone('iron'); }));
  }
  const t1 = await G(() => { const s = window.__game.scene.getScene('game'); return { mined: s.ironMined, done: s.todo.isDone('iron'), label: window.__game.scene.getScene('ui').todoLabels[0].style.color }; });
  ok('to-do 1 "철광석 5개 모으기" is checked once 5 or more were mined', t1.mined >= 5 && t1.done, J(t1));
  await T.shot('p7_stage2');
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
