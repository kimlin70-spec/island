// Phase 7 확인 3(실제 클릭): 2단계 만들기 창 열기, 철조망 카드 -> 안내 글, 지을 칸 누르기로 짓기, 시험 창을 열면 만들기 창이 닫힌다
const { setup, checker, J, UI } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.startStage2(); s.debugGive(); });
  await page.waitForTimeout(300);
  await T.ui(...UI.craft);
  const win = await G(() => { const u = window.__game.scene.getScene('ui'); return { open: u.craftOpen, vis: u.craftWin.visible, wire: u.cards.find((c) => c.card.id === 'wire') }; });
  const wc = await G(() => { const u = window.__game.scene.getScene('ui'); const c = u.cards.find((c) => c.card.id === 'wire'); const K = u.craftK;
    return { x: u.craftWin.x + c.box.x + K.cardW / 2, y: u.craftWin.y + c.box.y + K.cardH / 2, alpha: c.box.alpha }; });
  ok('craft button opens the two-row window; wire card is bright (iron 20)', win.open && win.vis && wc.alpha === 1, J(wc));
  await T.ui(wc.x, wc.y);
  const hint = await G(() => { const u = window.__game.scene.getScene('ui'); return { mode: window.__game.scene.getScene('game').build.mode, text: u.noticeText.text, vis: u.noticeBox.visible }; });
  ok('wire card -> build mode with "철조망: 지을 칸을 누르세요"', hint.mode === 'wire' && hint.text === '철조망: 지을 칸을 누르세요' && hint.vis, J(hint));
  // 주인공 오른쪽 아래 두 칸을 누른다(만들기 창에 가리지 않는 곳)
  const spot = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile;
    for (const [dc, dr] of [[0, 2], [-2, 0], [-1, 2], [-2, 1], [1, 2]]) if (s.build.canBuildAt(p.col + dc, p.row + dr)) return { col: p.col + dc, row: p.row + dr }; return null; });
  await T.tapWorld((spot.col - spot.row) * 40, (spot.col + spot.row) * 20, 300);
  const b = await G((sp) => { const s = window.__game.scene.getScene('game'); const w = s.map.wireAt(sp.col, sp.row); return { built: !!w, iron: s.inventory.count('iron') }; }, spot);
  ok('tapping a free tile builds the wire there (iron 20 -> 19)', b.built && b.iron === 19, J(b));
  await page.screenshot({ path: __dirname + '/p7_craft.png' });
  await T.ui(...UI.test);
  const dbg = await G(() => { const u = window.__game.scene.getScene('ui'); return { debug: u.debugWin.visible, craft: u.craftOpen, mode: window.__game.scene.getScene('game').build.mode }; });
  ok('stage 2: opening the test window hides the craft window (they overlap); build mode stays', dbg.debug && !dbg.craft && dbg.mode === 'wire', J(dbg));
  await page.screenshot({ path: __dirname + '/p7_debug.png' });
  await T.ui(...UI.craft);
  const back = await G(() => { const u = window.__game.scene.getScene('ui'); return { debug: u.debugWin.visible, craft: u.craftOpen }; });
  ok('opening the craft window closes the test window', !back.debug && back.craft, J(back));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
