// Phase 7 검토 뒤: 1단계에서는 시험 창과 만들기 창이 서로 닫지 않는다(짓기 상태 유지), 2단계 텐트 안 버튼이 장비 칸과 겹치지 않는다,
// 철조망 체력 막대는 철조망 아래쪽(위에 선 적의 얼굴에 걸리지 않는다)
const { setup, checker, J, UI } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.debugGive(); });
  await page.waitForTimeout(300);
  await T.ui(...UI.craft);
  await T.ui(...UI.card(2));                                   // 울타리
  await T.ui(...UI.test);
  let st = await G(() => { const u = window.__game.scene.getScene('ui'); return { mode: window.__game.scene.getScene('game').build.mode, craft: u.craftOpen, dbg: u.debugWin.visible }; });
  ok('stage 1: opening 시험 keeps the craft window and fence build mode (no overlap in stage 1)', st.mode === 'fence' && st.craft && st.dbg, J(st));
  await T.ui(...UI.test);
  // 2단계 + 도구 넷 + 텐트 안: 쉬는 중 버튼이 장비 칸 오른쪽에
  const r = await G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui');
    s.build.setMode(null); s.startStage2(); s.tools.push('axe', 'pickaxe'); s.events.emit('tools-changed');
    const p = s.player.tile; let spot = null;
    for (let d = 2; d < 6 && !spot; d++) for (const [dc, dr] of [[d, 0], [0, d], [-d, 0], [0, -d]]) {
      const ts = [[0, 0], [1, 0], [0, 1], [1, 1]].map(([a, b]) => ({ col: p.col + dc + a, row: p.row + dr + b }));
      if (!spot && ts.every((t) => s.build.canBuildAt(t.col, t.row))) spot = ts; }
    const tent = s.build.place('tent', spot); s.rest.enter(tent);
    const E = u.equipBg.input ? u.equipBg : null;
    const eqRight = 24 + 438 + 20 + 20 + 4 * 76;
    const bg = u.restBox.list[0]; const b = bg.input.hitArea;
    return { vis: u.restBox.visible, restLeft: b.x, eqRight }; });
  ok('stage 2 with 4 tools: the rest button sits right of the equipment bar (no overlap)', r.vis && r.restLeft >= r.eqRight, J(r));
  await page.screenshot({ path: __dirname + '/p7_rest.png' });
  // 철조망 막대
  const wb = await G(() => { const s = window.__game.scene.getScene('game'); s.rest.exit(); const p = s.player.tile;
    let t = null; for (const [dc, dr] of [[3, 0], [0, 3], [-3, 0], [0, -3]]) if (!t && s.build.canBuildAt(p.col + dc, p.row + dr)) t = { col: p.col + dc, row: p.row + dr };
    const w = s.build.place('wire', [t]); s.build.wear(w); const z = s.enemies.add('zombie', t);
    return { barY: w.bar.g.y, wireY: w.sprite.y, zTop: z.sprite.y - z.sprite.displayHeight * z.sprite.originY, zFoot: z.sprite.y }; });
  ok('a worn wire shows its hp bar below its own picture, not across the enemy standing on it', wb.barY > wb.wireY && wb.barY > wb.zFoot, J(wb));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
