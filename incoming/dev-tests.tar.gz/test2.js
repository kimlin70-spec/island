const { chromium } = require('playwright');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.getScene('game').player);
  const put = (c, r) => page.evaluate(([c, r]) => {
    const g = window.__game.scene.getScene('game'); const p = g.player;
    p.col = c; p.row = r; p.tile = { col: c, row: r }; p.path = []; p.syncSprite();
    g.cameras.main.centerOn(p.sprite.x, p.sprite.y);
  }, [c, r]);
  const clip = { x: 312, y: 134, width: 400, height: 400 };
  // 야자수 (26,32): 뒤 (25,31), 앞 (27,33)
  await put(25, 31); await page.waitForTimeout(1500);
  await page.screenshot({ path: out + 't_behind.png', clip });
  await put(27, 33); await page.waitForTimeout(1500);
  await page.screenshot({ path: out + 't_front.png', clip });
  // 집 뒤 (24,24)
  await put(24, 24); await page.waitForTimeout(1500);
  await page.screenshot({ path: out + 't_house.png', clip });
  // 실제 터치로 걷기: 문 앞에서 왼쪽으로 3칸, 끝까지 기다림
  await put(26, 27); await page.waitForTimeout(500);
  await page.touchscreen?.tap; // noop
  await page.mouse.click(512 - 150, 384 + 75);
  await page.waitForFunction(() => { const p = window.__game.scene.getScene('game').player; return !p.moving && (p.col !== 26 || p.row !== 27); }, null, { timeout: 60000 });
  console.log(await page.evaluate(() => { const p = window.__game.scene.getScene('game').player; return [p.col, p.row, p.sprite.frame.name, p.sprite.flipX]; }));
  // 끌기는 이동이 아님
  await page.mouse.move(700, 300); await page.mouse.down(); await page.mouse.move(760, 340, { steps: 4 }); await page.mouse.up();
  console.log('after drag moving =', await page.evaluate(() => window.__game.scene.getScene('game').player.moving));
  await page.setViewportSize({ width: 768, height: 1024 });
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + 't_portrait.png' });
  console.log('errors', errors);
  await browser.close();
})();
