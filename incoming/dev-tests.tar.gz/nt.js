const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 } });
  page.on('pageerror', (e) => console.log('pageerror', e.message));
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui'));
  for (let i = 0; i < 12; i++) {
    await page.waitForTimeout(1000);
    console.log(i, await page.evaluate(() => { const u = window.__game.scene.getScene('ui'); const t = u.tweens.getTweens(); return [u.noticeBox.alpha.toFixed(2), u.noticeText.text, u.notices.length, window.__game.loop.actualFps.toFixed(1), u.tweens.tweens.length, JSON.stringify(u.tweens.tweens.map(t => [t.constructor.name, t.state, t.currentIndex, t.paused]))]; }));
  }
  await browser.close();
})();
