const { chromium } = require('playwright');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').zoneText, null, { timeout: 20000 }).catch(() => {});
  await page.waitForTimeout(800);
  console.log('errors@start', errors);
  await page.screenshot({ path: out + 'p2_start.png' });
  const G = (fn, arg) => page.evaluate(fn, arg);
  const st = () => G(() => {
    const g = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui');
    return { tile: g.player.tile, moving: g.player.moving, inv: { ...g.inventory.items }, v: [g.vitals.hearts, g.vitals.hunger], zone: u.zoneText.text, action: !!g.player.action };
  });
  // 화면 좌표 <- 월드
  const toScreen = (wx, wy) => G(([wx, wy]) => {
    const g = window.__game.scene.getScene('game'); const cam = g.cameras.main;
    const ds = window.__game.scale.displayScale; const b = window.__game.canvas.getBoundingClientRect();
    return { x: b.left + (wx - cam.worldView.x) * cam.zoom / ds.x, y: b.top + (wy - cam.worldView.y) * cam.zoom / ds.y };
  }, [wx, wy]);
  console.log('start', await st());
  await G(() => window.__game.scene.getScene('game').debugToggleSpeed());
  await G(() => { const g = window.__game.scene.getScene('game'); g.player.teleport(26, 29); g.cameras.main.centerOn(g.player.sprite.x, g.player.sprite.y); });
  await page.waitForTimeout(1500);

  // 가장 가까운 보이는 나무류의 "잎"(그림 위쪽)을 눌러 캐기
  const tree = await G(() => {
    const g = window.__game.scene.getScene('game'); const p = g.player;
    const c = g.mapSystem.objects.filter(o => o.sprite.visible && ['tree', 'palm', 'pine'].includes(o.type))
      .sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0];
    return { type: c.type, col: c.col, row: c.row, x: c.sprite.x, y: c.sprite.y, top: c.sprite.y - c.sprite.height * c.sprite.originY };
  });
  console.log('tree', tree);
  // 야자수 잎: 발에서 위로 170px 쯤
  const s = await toScreen(tree.x - 20, tree.top + 60);
  await page.mouse.click(s.x, s.y);
  await page.waitForTimeout(300);
  console.log('after tap leaf', await st());
  await page.waitForFunction(() => { const g = window.__game.scene.getScene('game'); return !g.player.action && !g.player.moving; }, null, { timeout: 90000 });
  console.log('after harvest', await st());
  await page.screenshot({ path: out + 'p2_stump.png' });

  // 덤불
  const bush = await G(() => {
    const g = window.__game.scene.getScene('game'); const p = g.player;
    const c = g.mapSystem.objects.filter(o => o.sprite.visible && o.type === 'bush')
      .sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0];
    return { col: c.col, row: c.row, x: c.sprite.x, y: c.sprite.y };
  });
  let b = await toScreen(bush.x, bush.y - 20);
  if (b.x < 0 || b.y < 0 || b.x > 1024 || b.y > 768) console.log('bush offscreen', b);
  await page.mouse.click(b.x, b.y);
  await page.waitForTimeout(400);
  await page.waitForFunction(() => { const g = window.__game.scene.getScene('game'); return !g.player.action && !g.player.moving; }, null, { timeout: 90000 });
  console.log('after bush', await st());
  await page.screenshot({ path: out + 'p2_bush.png' });

  // 먹기: 배부르면 안 먹힘
  const bag = { x: (26 + 10 + 2 * 196 + 98) / 2, y: (1536 - 26 - 70) / 2 };
  await page.mouse.click(bag.x, bag.y);
  await page.waitForTimeout(300);
  console.log('eat when full', await st());
  await G(() => { const g = window.__game.scene.getScene('game'); g.vitals.hunger = 2; g.vitals.changed(); });
  await page.mouse.click(bag.x, bag.y);
  await page.waitForTimeout(300);
  console.log('eat when hungry (expect hunger 3, berry-1, not moving)', await st());
  await page.screenshot({ path: out + 'p2_eat.png' });

  // 배고픔 타이머
  await G(() => { const g = window.__game.scene.getScene('game'); g.vitals.hungerTimer = 59.9; });
  await page.waitForTimeout(600);
  console.log('hunger tick', await st());
  // 쓰러짐
  await G(() => { const g = window.__game.scene.getScene('game'); g.inventory.add('wood', 4); g.inventory.add('stone', 5); g.vitals.hunger = 0; g.vitals.hearts = 1; g.vitals.starveTimer = 29.9; g.vitals.changed(); });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: out + 'p2_dark.png' });
  await page.waitForTimeout(6000);
  console.log('after collapse', await st());

  // 시험용 도구
  const gear = { x: (2048 - 26 - 52) / 2, y: (26 + 112 + 20 + 52) / 2 };
  await page.mouse.click(gear.x, gear.y);
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + 'p2_debug.png' });
  const d = { y0: (1536 - 620) / 2 + 150 + 75 };
  await page.mouse.click((1024 - 225) / 2, d.y0 / 2);            // 재료 +20
  await page.mouse.click((1024 + 225) / 2, d.y0 / 2);            // 안개 모두 걷기
  await page.mouse.click((1024 - 225) / 2, (d.y0 + 180) / 2);    // 속도
  await page.waitForTimeout(300);
  console.log('after debug', await st(), await G(() => window.__game.scene.getScene('game').speed));
  await page.mouse.click((1024 + 225) / 2, (d.y0 + 180) / 2);    // 닫기
  await page.waitForTimeout(1500);
  console.log('debug visible', await G(() => window.__game.scene.getScene('ui').debugBox.visible), await st());
  await page.screenshot({ path: out + 'p2_revealed.png' });
  console.log('errors', errors);
  await browser.close();
})();
