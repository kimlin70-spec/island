// Phase 2: 처음 화면(UI 포함), 콘솔 오류
const { open } = require('./lib.js');
const out = __dirname + '/';
(async () => {
  const T = await open();
  const { page, G, errors } = T;
  await page.waitForTimeout(600);
  await page.screenshot({ path: out + 'start.png' });
  console.log(JSON.stringify(await G(() => { const u = window.__game.scene.getScene('ui'); return { notice: u.noticeText.text, visible: u.noticeBox.visible, queue: u.noticeQueue, craft: u.craftWin.visible, children: u.children.list.length }; })));
  // 만들기 창 열기(실제 클릭)
  await page.mouse.click(1824, 1104);
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + 'craft_open.png' });
  console.log('craft open', await G(() => window.__game.scene.getScene('ui').craftWin.visible), 'player moving', await G(() => window.__game.scene.getScene('game').player.moving));
  console.log('errors', JSON.stringify(errors, null, 1));
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
