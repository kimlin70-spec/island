// Phase 2: 캐기, 도구 만들기, 가방, 할 일, 알림, 시험용 도구 (실제 클릭으로)
const { open } = require('./lib.js');
const out = __dirname + '/';
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 230) : '')); };
(async () => {
  const T = await open();
  const { page, G, W, state, arrive, errors } = T;
  // 게임 시간(초)을 따로 센다. 프레임마다 주인공의 그림 번호도 적어 둔다.
  await G(() => {
    const s = window.__game.scene.getScene('game'); window.__gt = 0; window.__frames = new Set(); window.__log = [];
    s.events.on('update', (t, d) => { window.__gt += Math.min(d / 1000, 0.1) * s.speed; window.__frames.add(s.player.sprite.frame.name); });
    s.events.on('notice', (text) => window.__log.push(text));
  });
  const S = () => G(() => {
    const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui');
    return { wood: s.inventory.count('wood'), stone: s.inventory.count('stone'), tools: s.tools.slice(), tile: [s.player.tile.col, s.player.tile.row], moving: s.player.moving,
             acting: !!s.player.action, notice: u.noticeBox.visible ? u.noticeText.text : null, gt: +window.__gt.toFixed(2), todo: [...s.todo.done],
             bag: [u.bagCounts.wood.text, u.bagCounts.stone.text], equip: u.equipIcons.map(i => i.texture.key), craft: u.craftWin.visible };
  });
  // 사물 그림 위의 한 점(화면 좌표). fy: 발에서 꼭대기까지의 비율
  const objPoint = (c, r, fy = 0.7, dx = 0) => G(([c, r, fy, dx]) => {
    const g = window.__game, s = g.scene.getScene('game'), o = s.map.objectAt(c, r), sp = o.sprite, cam = s.cameras.main;
    const wx = sp.x + dx, wy = sp.y - sp.displayHeight * sp.originY * fy;
    return { x: (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, y: (wy - cam.midPoint.y) * cam.zoom + cam.height / 2, key: sp.texture.key, kind: o.kind, hp: o.node && o.node.hp };
  }, [c, r, fy, dx]);
  const clickObj = async (c, r, fy, dx) => { const p = await objPoint(c, r, fy, dx); await page.mouse.click(p.x, p.y); return p; };
  const nearest = (kinds, n = 0) => G(([kinds, n]) => { const s = window.__game.scene.getScene('game'), p = s.player.tile; return s.map.objects.filter(o => kinds.includes(o.kind) && (kinds[0] !== 'rock' || true)).map(o => [o.col, o.row, Math.hypot(o.col - p.col, o.row - p.row), o.key]).sort((a, b) => a[2] - b[2])[n]; }, [kinds, n]);
  const node = (c, r) => G(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return { kind: o.kind, key: o.sprite.texture.key, hp: o.node ? o.node.hp : null, blocks: o.blocks, tall: o.tall, pickable: o.pickable, alpha: o.sprite.alpha, bar: !!(o.bar && o.bar.g.visible) }; }, [c, r]);

  // N) 처음 알림 세 개가 차례로
  await page.waitForTimeout(300);
  ok('N1 first intro notice', (await S()).notice === '땅을 누르면 이동합니다');

  // B) 곡괭이 없이 돌을 누르면 알림만 뜨고 움직이지 않는다
  const rock = await nearest(['rock']);
  await clickObj(rock[0], rock[1], 0.5);
  await page.waitForTimeout(150);
  let s = await S();
  ok('B rock without pickaxe: notice, no walking', s.notice === '곡괭이가 필요합니다' && !s.moving && !s.acting, JSON.stringify(s));

  // K) 덤불을 누르면 아무 일도 없다
  const bush = await nearest(['bush']);
  await clickObj(bush[0], bush[1], 0.5);
  await page.waitForTimeout(150);
  s = await S();
  ok('K bush tap does nothing', !s.moving && !s.acting, JSON.stringify(s.tile));

  // A) 나무를 누르면 다가가서 단검으로 벤다
  const tree = await nearest(['tree']);
  await G(() => { window.__frames.clear(); });
  const p0 = await clickObj(tree[0], tree[1], 0.7);
  await page.waitForTimeout(100);
  s = await S();
  ok('A1 tapping the canopy starts walking to the tree', s.moving && s.acting, JSON.stringify({ tree, p0, s }));
  await arrive();
  const tArrive = (await S()).gt;
  await W(() => window.__game.scene.getScene('game').inventory.count('wood') === 0 && window.__game.scene.getScene('game').player.swing !== null);
  await page.waitForTimeout(700);
  await page.screenshot({ path: out + 'chop.png' });
  let n = await node(tree[0], tree[1]);
  ok('A2 health bar shows while chopping, hp going down', n.bar && n.hp < 9 && n.hp > 0, JSON.stringify(n));
  await W(() => window.__game.scene.getScene('game').inventory.count('wood') > 0);
  const tDone = (await S()).gt;
  await page.screenshot({ path: out + 'chop_done.png' });
  s = await S(); n = await node(tree[0], tree[1]);
  ok('A3 wood +4 and bag shows it', s.wood === 4 && s.bag[0] === '4', JSON.stringify(s.bag));
  ok('A4 about 5 seconds with the dagger (game time from arrival)', tDone - tArrive > 4.2 && tDone - tArrive < 5.3, (tDone - tArrive).toFixed(2) + 's');
  ok('A5 tree became a stump: walkable, not tall, opaque, diggable later (hp 3)', n.key === 'obj_stump' && n.kind === 'stump' && !n.blocks && !n.tall && n.pickable && n.alpha === 1 && n.hp === 3, JSON.stringify(n));
  const fr = await G(() => [...window.__frames].map((i) => window.__game.scene.getScene('game').player.asset.frames[i]));
  // Phase 10: 단검은 dagger1~3(뒷모습이면 bdagger1~3)
  ok('A6 dagger pictures used (dagger1-3 or bdagger1-3), no axe/pick', fr.some((n) => /dagger1$/.test(n)) && fr.some((n) => /dagger2$/.test(n)) && fr.some((n) => /dagger3$/.test(n)) && !fr.some((n) => /axe|pick/.test(n)), fr.join());
  await page.waitForTimeout(600);
  s = await S();
  ok('A7 player stops after the tree is gone', !s.acting && !s.moving);

  // I) 그루터기는 땅과 같다: 눌러서 그 칸으로 걸어갈 수 있다
  const sp = await objPoint(tree[0], tree[1], 0, -30);        // 그루터기 그림 옆(같은 칸의 왼쪽 땅)
  await page.mouse.click(sp.x, sp.y + 2);
  await page.waitForTimeout(100);
  await arrive();
  s = await S();
  ok('I stump tile can be walked onto', s.tile.join() === [tree[0], tree[1]].join(), s.tile.join());

  // F) 재료가 모자란 카드를 누르면 "재료가 부족합니다"
  await page.mouse.click(1824, 1104);                         // 만들기 버튼
  await page.waitForTimeout(150);
  ok('C0 craft window opens, player does not move', (await S()).craft && !(await S()).moving);
  const cardX = (i) => 776 + 20 + i * 182 + 85, cardY = 800 + 98;
  await page.mouse.click(cardX(4), cardY);                    // 텐트 (나무 8, 돌 2)
  await page.waitForTimeout(150);
  ok('F lacking card: notice', (await S()).notice === '재료가 부족합니다');

  // C) 나무 3으로 나무 도끼를 만든다
  await page.mouse.click(cardX(0), cardY);
  await page.waitForTimeout(200);
  s = await S();
  ok('C1 axe crafted: wood 4 -> 1, tool owned', s.wood === 1 && s.tools.join() === 'dagger,axe', JSON.stringify(s));
  ok('C2 notice and equipment slot and to-do', s.notice === '나무 도끼를 만들었습니다' && s.equip.join() === 'icon_dagger,icon_tshirt,icon_axe' && s.todo.join() === 'axe', JSON.stringify([s.notice, s.equip, s.todo]));
  await page.screenshot({ path: out + 'crafted_axe.png' });
  await page.mouse.click(cardX(0), cardY);                    // 이미 가진 도구: 아무 일 없음
  await page.waitForTimeout(150);
  s = await S();
  ok('C3 owned card cannot be pressed again', s.wood === 1 && s.tools.length === 2);
  const cards = await G(() => window.__game.scene.getScene('ui').cards.map(c => [c.card.id, +c.box.alpha.toFixed(2), c.status.text, c.costParts.some(p => p.visible)]));
  ok('C4 cards: axe shows 보유 and is dim; fence (wood 1) is bright', cards[0][2] === '보유' && cards[0][1] === 0.45 && !cards[0][3] && cards[2][1] === 1 && cards[1][1] === 0.45, JSON.stringify(cards));
  // 시설 카드는 아직 눌러도 아무 일 없다
  await page.mouse.click(cardX(2), cardY);
  await page.waitForTimeout(150);
  ok('C5 fence card does nothing yet', (await S()).wood === 1);
  await page.mouse.click(1824, 1104);                         // 창 닫기
  await page.waitForTimeout(150);
  ok('C6 craft window closes', !(await S()).craft);

  // D) 도끼로 벤다: 훨씬 빠르고 도끼 그림
  const tree2 = await nearest(['tree', 'pine']);
  await G(() => { window.__frames.clear(); });
  await clickObj(tree2[0], tree2[1], 0.7);
  await page.waitForTimeout(100);
  await arrive();
  const t1 = (await S()).gt;
  await W(() => window.__game.scene.getScene('game').inventory.count('wood') === 5);
  const t2 = (await S()).gt;
  const fr2 = await G(() => [...window.__frames].map((i) => window.__game.scene.getScene('game').player.asset.frames[i]));
  ok('D1 axe: about 1.7 s or less, wood 1 -> 5', t2 - t1 > 1.0 && t2 - t1 < 2.0, (t2 - t1).toFixed(2) + 's');
  ok('D2 axe pictures used (axe1-3 or baxe1-3), not dagger', fr2.some((n) => /axe1$/.test(n)) && fr2.some((n) => /axe2$/.test(n)) && !fr2.some((n) => /dagger/.test(n)), fr2.join());

  // J) 캐다가 다른 곳을 누르면 멈추고, 깎인 체력은 남는다
  const tree3 = await nearest(['tree', 'pine']);
  await clickObj(tree3[0], tree3[1], 0.7);
  await page.waitForTimeout(100);
  await arrive();
  await W(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return o.node && o.node.hp < 9; }, [tree3[0], tree3[1]]);
  const hpMid = (await node(tree3[0], tree3[1])).hp;
  const away = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; for (const [dc, dr] of [[2, 2], [3, 0], [0, 3], [-2, 2], [2, -2], [-3, 0], [0, -3]]) if (s.map.isWalkable(p.col + dc, p.row + dr) && !s.map.objectAt(p.col + dc, p.row + dr)) return [p.col + dc, p.row + dr]; });
  await T.tapTile(away[0], away[1]);
  await page.waitForTimeout(100);
  await arrive();
  await page.waitForTimeout(1300);
  n = await node(tree3[0], tree3[1]);
  s = await S();
  ok('J1 walking away stops chopping, damage stays, bar hides', n.hp === hpMid && !s.acting && !n.bar && s.wood === 5, JSON.stringify({ hpMid, n }));
  await clickObj(tree3[0], tree3[1], 0.7);
  await W(() => window.__game.scene.getScene('game').inventory.count('wood') === 9);
  ok('J2 coming back finishes the same tree', (await node(tree3[0], tree3[1])).key === 'obj_stump');

  // E) 나무 곡괭이를 만들면 돌을 캘 수 있다
  await page.mouse.click(1824, 1104);
  await page.waitForTimeout(150);
  await page.mouse.click(cardX(1), cardY);
  await page.waitForTimeout(200);
  s = await S();
  ok('E1 pickaxe crafted', s.tools.join() === 'dagger,axe,pickaxe' && s.wood === 6 && s.notice === '나무 곡괭이를 만들었습니다' && s.todo.join() === 'axe,pickaxe' && s.equip.length === 4, JSON.stringify(s));
  await page.screenshot({ path: out + 'crafted_both.png' });
  await page.mouse.click(1824, 1104);
  await page.waitForTimeout(150);
  const rock2 = await nearest(['rock']);
  await G(() => { window.__frames.clear(); });
  const rp = await clickObj(rock2[0], rock2[1], 0.5);
  await page.waitForTimeout(100);
  s = await S();
  ok('E2 tapping a rock now walks to it', s.acting, JSON.stringify(rock2));
  await W(() => window.__game.scene.getScene('game').inventory.count('stone') > 0, null, 90000);
  s = await S(); n = await node(rock2[0], rock2[1]);
  const want = { obj_rock_s: 1, obj_rock_m: 2, obj_rock_l: 3 }[rock2[3]];
  const fr3 = await G(() => [...window.__frames].map((i) => window.__game.scene.getScene('game').player.asset.frames[i]));
  ok('E3 stone gained by rock size, rock became rubble (walkable)', s.stone === want && n.key === 'obj_rubble' && !n.blocks, JSON.stringify({ rock: rock2[3], stone: s.stone, n }));
  ok('E4 pickaxe pictures used (pick1-3 or bpick1-3)', fr3.some((n) => /pick1$/.test(n)) && fr3.some((n) => /pick2$/.test(n)), fr3.join());

  // L) 야자수는 나무 +3
  const palm = await nearest(['palm']);
  const before = (await S()).wood;
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); const o = s.map.objectAt(c, r); s.pressNode(o); }, [palm[0], palm[1]]);
  await W((b) => window.__game.scene.getScene('game').inventory.count('wood') > b, before, 120000);
  ok('L palm gives wood +3', (await S()).wood === before + 3);

  // G) 시험용 도구: 나무, 돌 +20
  s = await S();
  await page.mouse.click(1920 - 24 - 44, 24 + 274 + 10 + 20);    // "시험" 버튼
  await page.waitForTimeout(150);
  ok('G1 debug window opens', await G(() => window.__game.scene.getScene('ui').debugWin.visible));
  await page.screenshot({ path: out + 'debug.png' });
  await page.mouse.click(1920 - 24 - 150, 24 + 274 + 10 + 40 + 10 + 16 + 24);
  await page.waitForTimeout(150);
  const s2 = await S();
  ok('G2 +20 wood and stone', s2.wood === s.wood + 20 && s2.stone === s.stone + 20 && s2.bag[0] === String(s2.wood), JSON.stringify(s2.bag));
  await page.mouse.click(1920 - 24 - 150, 24 + 274 + 10 + 40 + 10 + 16 + 5 * (48 + 8) + 24);    // 닫기(여섯째 줄. Phase 5에서 좀비 부르기가 늘었다)
  await page.waitForTimeout(150);
  ok('G3 debug window closes', !(await G(() => window.__game.scene.getScene('ui').debugWin.visible)));

  // H) UI를 누른 것은 월드로 가지 않는다
  await page.waitForTimeout(300);
  const tile0 = (await S()).tile.join();
  for (const [x, y] of [[100, 1140], [430, 1140], [1700, 150], [1824, 1104], [1824, 1104]]) { await page.mouse.click(x, y); await page.waitForTimeout(120); }
  s = await S();
  ok('H taps on panels and buttons do not move the player', !s.moving && s.tile.join() === tile0 && !s.craft);

  // M) 나무의 그림자를 누르면 나무가 아니라 땅이다
  const tree4 = await nearest(['tree']);
  const shadow = await G(([c, r]) => {
    const g = window.__game, s = g.scene.getScene('game'), o = s.map.objectAt(c, r), sp = o.sprite, cam = s.cameras.main;
    // 그림자: 그림의 오른쪽 아래. 옅은(알파 20~100) 점을 찾는다
    const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY;
    for (let ly = sp.height - 4; ly > sp.height * 0.8; ly -= 2) for (let lx = sp.width - 6; lx > sp.width * 0.5; lx -= 2) {
      const a = g.textures.getPixelAlpha(lx, ly, sp.texture.key);
      if (a > 20 && a < 100) { const wx = left + lx, wy = top + ly; return { x: (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, y: (wy - cam.midPoint.y) * cam.zoom + cam.height / 2, a, picked: !!s.map.pickObject(wx, wy) }; }
    }
  }, [tree4[0], tree4[1]]);
  ok('M shadow pixel is not picked as the tree', shadow && shadow.picked === false, JSON.stringify(shadow));

  // 알림 기록
  const log = await G(() => window.__log);
  console.log('notices seen:', JSON.stringify(log));
  console.log('errors', JSON.stringify(errors, null, 1));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
