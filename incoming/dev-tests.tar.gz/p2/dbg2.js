const { open } = require('./lib.js');
(async () => {
  const T = await open();
  const { page, G } = T;
  for (let i = 0; i < 4; i++) {
    console.log(JSON.stringify(await G(() => { const g = window.__game, l = g.loop; return { inFocus: l.inFocus, coolDown: l._coolDown, hasFocus: document.hasFocus(), vis: document.visibilityState, delta: +l.delta.toFixed(1), raw: +l.rawDelta.toFixed(1), frame: l.frame, target: +l._target.toFixed(2), min: l._min, smooth: l.smoothStep }; })));
    await page.waitForTimeout(3000);
  }
  await T.browser.close();
})();
