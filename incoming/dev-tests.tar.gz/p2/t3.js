// Phase 2: 처음 알림 세 개의 순서와 시간, 터치 화면에서 UI 누르기, 다가갈 수 없는 나무·돌의 수, 도중에 도끼를 만들면 바로 도끼로
const { open } = require('./lib.js');
const out = __dirname + '/';
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 260) : '')); };
(async () => {
  // 1) 처음 알림: 차례로, 각각 2.5초
  let T = await open();
  let { page, G, W, errors } = T;
  const seen = [];
  const t0 = Date.now();
  let last = null;
  while (Date.now() - t0 < 9500) {
    const n = await G(() => { const u = window.__game.scene.getScene('ui'); return u.noticeBox.visible ? u.noticeText.text : null; });
    if (n !== last) { seen.push([n, +((Date.now() - t0) / 1000).toFixed(1)]); last = n; }
    await page.waitForTimeout(100);
  }
  ok('N intro notices in order, about 2.5 s each, then gone', seen.map(s => s[0]).join('|') === '땅을 누르면 이동합니다|나무를 누르면 다가가서 벱니다|만들기에서 도구와 캠프를 만들 수 있습니다|' && Math.abs(seen[1][1] - seen[0][1] - 2.5) < 0.6 && Math.abs(seen[3][1] - seen[2][1] - 2.5) < 0.6, JSON.stringify(seen));

  // 2) 다가갈 수 없는 나무·돌(둘레 8칸이 모두 막힌 것)의 수
  const stat = await G(async () => {
    const s = window.__game.scene.getScene('game'), m = s.map, p = s.player;
    const { findPath } = await import('/src/systems/Pathfinder.js');
    let nodes = 0, noNeighbor = 0, unreachable = 0; const list = [];
    for (const o of m.objects) {
      if (!o.node) continue; nodes++;
      const ns = p.neighborsOf(o.tiles);
      if (!ns.length) { noNeighbor++; list.push([o.kind, o.col, o.row]); continue; }
      if (!ns.some(t => findPath(m.cols, m.rows, p.tile, t, (c, r) => p.costAt(c, r)))) unreachable++;
    }
    return { nodes, noNeighbor, unreachable, list: list.slice(0, 12) };
  });
  console.log('nodes that cannot be approached at the start:', JSON.stringify(stat));

  // 3) 단검으로 베는 도중에 도끼를 만들면 다음 휘두르기부터 도끼
  await G(() => { const s = window.__game.scene.getScene('game'); window.__frames = []; s.events.on('update', () => window.__frames.push(s.player.sprite.frame.name)); s.inventory.add('wood', 3); const o = s.map.objects.filter(o => o.kind === 'tree').sort((a, b) => Math.hypot(a.col - 37, a.row - 39) - Math.hypot(b.col - 37, b.row - 39))[0]; window.__o = o; s.pressNode(o); });
  await W(() => window.__o.node && window.__o.node.hp <= 8);
  await G(() => { const s = window.__game.scene.getScene('game'); window.__frames.length = 0; s.pressCard({ id: 'axe', type: 'tool', icon: 'icon_axe' }); });
  await W(() => window.__o.kind === 'stump', null, 30000);
  const fr = await G(() => [...new Set(window.__frames)].map((i) => window.__game.scene.getScene('game').player.asset.frames[i]));
  ok('X crafting the axe mid-chop switches to the axe', fr.some((n) => /axe1$/.test(n)) && fr.some((n) => /axe2$/.test(n)), fr.join() + ' wood=' + await G(() => window.__game.scene.getScene('game').inventory.count('wood')));
  console.log('errors', JSON.stringify(errors));
  await T.browser.close();

  // 4) 태블릿 크기의 터치 화면: 만들기 버튼, 카드, 나무 누르기
  T = await open({ w: 1024, h: 768, touch: true });
  ({ page, G, W, errors } = T);
  const toPage = (x, y) => G(([x, y]) => { const r = window.__game.canvas.getBoundingClientRect(); return { x: r.left + x * r.width / 1920, y: r.top + y * r.height / 1200 }; }, [x, y]);
  const tap = async (x, y) => { const p = await toPage(x, y); await page.touchscreen.tap(p.x, p.y); await page.waitForTimeout(150); };
  await G(() => window.__game.scene.getScene('game').inventory.add('wood', 3));
  await tap(1824, 1104);
  ok('T1 touch: craft window opens', await G(() => window.__game.scene.getScene('ui').craftWin.visible));
  await tap(776 + 20 + 85, 898);
  let st = await G(() => { const s = window.__game.scene.getScene('game'); return { tools: s.tools, wood: s.inventory.count('wood'), moving: s.player.moving }; });
  ok('T2 touch: axe card crafts, world not tapped', st.tools.join() === 'dagger,axe' && st.wood === 0 && !st.moving, JSON.stringify(st));
  await page.screenshot({ path: out + 'tablet_ui.png' });
  await tap(1824, 1104);
  // 나무 누르기(터치)
  const tp = await G(() => { const s = window.__game.scene.getScene('game'), cam = s.cameras.main; const o = s.map.objects.filter(o => o.kind === 'tree').sort((a, b) => Math.hypot(a.col - 37, a.row - 39) - Math.hypot(b.col - 37, b.row - 39))[0]; const sp = o.sprite; return { x: sp.x - cam.scrollX, y: sp.y - sp.displayHeight * sp.originY * 0.7 - cam.scrollY }; });
  await tap(tp.x, tp.y);
  await W(() => window.__game.scene.getScene('game').inventory.count('wood') === 4, null, 60000);
  ok('T3 touch: tapping a tree chops it', true);
  console.log('errors', JSON.stringify(errors));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
