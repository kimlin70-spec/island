const { open } = require('./lib.js');
(async () => {
  const T = await open();
  const { page, G } = T;
  for (let i = 0; i < 6; i++) {
    console.log(JSON.stringify(await G(() => { const g = window.__game, u = g.scene.getScene('ui'); return { left: u.noticeLeft, text: u.noticeText.text, vis: u.noticeBox.visible, alpha: u.noticeBox.alpha, q: u.noticeQueue.length, status: u.sys.settings.status, active: g.scene.isActive('ui'), hasUpdate: typeof u.update, fps: Math.round(g.loop.actualFps) }; })));
    await page.waitForTimeout(700);
  }
  await T.browser.close();
})();
