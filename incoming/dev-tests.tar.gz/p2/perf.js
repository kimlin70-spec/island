// 화면 그리는 속도: UI를 보일 때와 숨길 때, 요소별로
const { open } = require('./lib.js');
(async () => {
  const T = await open();
  const { page, G } = T;
  const measure = async (label) => {
    await page.waitForTimeout(400);
    const r = await G(() => new Promise((res) => {
      const g = window.__game; let n = 0; const t0 = performance.now(); let cpu = 0;
      const pre = () => { g.__t = performance.now(); };
      const post = () => { cpu += performance.now() - g.__t; if (++n === 25) { g.events.off('prestep', pre); g.events.off('postrender', post); res({ ms: (performance.now() - t0) / n, cpu: cpu / n }); } };
      g.events.on('prestep', pre); g.events.on('postrender', post);
    }));
    console.log(label.padEnd(44), 'frame', r.ms.toFixed(1), 'ms   js(step+render calls)', r.cpu.toFixed(1), 'ms');
  };
  await measure('world + UI (as is)');
  await G(() => window.__game.scene.getScene('ui').sys.setVisible(false));
  await measure('UI hidden');
  await G(() => window.__game.scene.getScene('ui').sys.setVisible(true));
  await G(() => { const u = window.__game.scene.getScene('ui'); window.__texts = u.children.list.filter(c => c.type === 'Text'); window.__gfx = u.children.list.filter(c => c.type === 'Graphics'); window.__texts.forEach(t => t.setVisible(false)); });
  await measure('UI without texts');
  await G(() => { window.__texts.forEach(t => t.setVisible(true)); window.__gfx.forEach(t => t.setVisible(false)); });
  await measure('UI without graphics (panels)');
  await G(() => { window.__gfx.forEach(t => t.setVisible(true)); });
  await measure('world + UI again');
  console.log(JSON.stringify(await G(() => { const u = window.__game.scene.getScene('ui'); const c = {}; const walk = (l) => l.forEach(o => { c[o.type] = (c[o.type] || 0) + 1; if (o.list) walk(o.list); }); walk(u.children.list); return c; })));
  await T.browser.close();
})();
