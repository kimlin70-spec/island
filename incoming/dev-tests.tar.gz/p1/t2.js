// Phase 1: 눌러서 이동, 막힌 칸, 좌우 뒤집기, 가려지면 반투명, 카메라
const { open } = require('./lib.js');
const out = __dirname + '/';
const ok = (name, cond, extra = '') => console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : ''));
(async () => {
  const T = await open();
  const { page, G, W, tapTile, state, arrive, errors } = T;
  const st = await G(() => window.__game.scene.getScene('game').mapData.playerStart);

  // A) 땅 누르기 -> 그 칸으로 걸어간다
  await G(() => { const s = window.__game.scene.getScene('game'); window.__visited = []; s.events.on('update', () => { const p = s.player; window.__visited.push([p.tile.col, p.tile.row, p.sprite.anims.isPlaying, p.sprite.flipX, p.sprite.frame.name]); }); });
  await tapTile(st.col + 4, st.row + 1);
  await page.waitForTimeout(120);
  let s1 = await state();
  ok('A1 tap starts walking', s1.moving && s1.anim, JSON.stringify(s1));
  ok('A2 cursor shown on tapped tile', s1.cursor && s1.cursorAt[0] === (st.col + 4 - st.row - 1) * 40 && s1.cursorAt[1] === (st.col + 4 + st.row + 1) * 20, JSON.stringify(s1.cursorAt));
  await page.screenshot({ path: out + 'walk.png' });
  await arrive();
  s1 = await state();
  ok('A3 arrives at tapped tile', s1.tile[0] === st.col + 4 && s1.tile[1] === st.row + 1 && s1.col === st.col + 4 && s1.row === st.row + 1, JSON.stringify(s1));
  ok('A4 idle frame when standing', s1.frame === 0 && !s1.anim, JSON.stringify(s1));
  await page.waitForTimeout(600);
  ok('A5 cursor hidden after 0.4s', !(await state()).cursor);
  const vis = await G(() => window.__visited);
  const frames = new Set(vis.filter(v => v[2]).map(v => v[4]));
  ok('A6 walk frames used: walk1/walk2 only', [...frames].sort().join() === '1,2', [...frames].join());

  // B) 물을 누르면 아무 일도 없다
  const water = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; for (let d = 1; d < 30; d++) { const c = p.col + d, r = p.row + d; if (!s.map.isLand(c, r)) return [c, r]; } });
  let before = await state();
  await tapTile(water[0], water[1]);
  await page.waitForTimeout(150);
  let after = await state();
  ok('B water tap does nothing', !after.moving && !after.cursor && after.tile.join() === before.tile.join(), 'water tile ' + water + ' ' + JSON.stringify(after));

  // C) 나무가 있는 칸(밑동)을 누르면 아무 일도 없다
  const tree = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; return s.map.objects.filter(o => o.kind === 'tree').map(o => [o.col, o.row, Math.hypot(o.col - p.col, o.row - p.row)]).sort((a, b) => a[2] - b[2])[0]; });
  await tapTile(tree[0], tree[1], 0, 4);
  await page.waitForTimeout(150);
  after = await state();
  ok('C blocked tile tap does nothing', !after.moving && !after.cursor, 'tree tile ' + tree.slice(0, 2));

  // D) 먼 곳으로: 지나간 칸이 모두 걸을 수 있는 칸인가 + 가다가 다른 곳을 누르면 바로 바꾼다
  await G(() => { window.__visited = []; });
  const far = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; let best = null; for (let c = p.col - 11; c <= p.col + 11; c++) for (let r = p.row - 11; r <= p.row + 11; r++) { if (!s.map.isWalkable(c, r)) continue; const d = Math.hypot(c - p.col, r - p.row); const wx = (c - r) * 40, wy = (c + r) * 20; const cam = s.cameras.main; const on = Math.abs(wx - cam.midPoint.x) < 900 && Math.abs(wy - cam.midPoint.y) < 560; if (on && wx < cam.midPoint.x - 300 && (!best || d > best[2])) best = [c, r, d]; } return best; });
  await tapTile(far[0], far[1]);
  await page.waitForTimeout(700);
  const mid = await state();
  ok('D1 walking left flips the picture', mid.moving && mid.flip === true, JSON.stringify(mid));
  // 가는 도중에 오른쪽을 누른다
  const tgt2 = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; for (let d = 6; d > 1; d--) { const c = p.col + d, r = p.row - d; if (s.map.isWalkable(c, r)) return [c, r]; } });
  await tapTile(tgt2[0], tgt2[1]);
  await page.waitForTimeout(400);
  const mid2 = await state();
  ok('D2 re-tap while moving changes direction (faces right)', mid2.flip === false && mid2.moving, JSON.stringify(mid2));
  await arrive();
  const end = await state();
  ok('D3 arrives at the second target', end.tile.join() === tgt2.join(), JSON.stringify(end.tile) + ' want ' + tgt2);
  const bad = await G(() => { const s = window.__game.scene.getScene('game'); return window.__visited.filter(v => !s.map.isWalkable(v[0], v[1])).length; });
  ok('D4 every visited tile is walkable', bad === 0, 'visited ' + (await G(() => window.__visited.length)) + ' frames');

  // E) 길찾기 300번: 막힌 칸을 지나지 않고, 모서리를 끊고 지나가지 않는다
  const pf = await G(async () => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    const { findPath } = await import('/src/systems/Pathfinder.js');
    const free = []; for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) if (m.isWalkable(c, r)) free.push({ col: c, row: r });
    let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    const cost = (c, r) => (m.isWalkable(c, r) ? 1 : 0);
    let none = 0, blocked = 0, cut = 0, jump = 0, total = 0, maxMs = 0, sumMs = 0;
    for (let i = 0; i < 300; i++) {
      const a = free[Math.floor(rnd() * free.length)], b = free[Math.floor(rnd() * free.length)];
      const t0 = performance.now(); const p = findPath(m.cols, m.rows, a, b, cost); const ms = performance.now() - t0; maxMs = Math.max(maxMs, ms); sumMs += ms;
      if (!p) { none++; continue; }
      total += p.length;
      for (let k = 0; k < p.length; k++) {
        if (!m.isWalkable(p[k].col, p[k].row)) blocked++;
        if (k) { const dc = p[k].col - p[k - 1].col, dr = p[k].row - p[k - 1].row; if (Math.abs(dc) > 1 || Math.abs(dr) > 1) jump++; if (dc && dr && (!m.isWalkable(p[k - 1].col + dc, p[k - 1].row) || !m.isWalkable(p[k - 1].col, p[k - 1].row + dr))) cut++; }
      }
    }
    return { free: free.length, none, blocked, cut, jump, avgLen: Math.round(total / 300), maxMs: +maxMs.toFixed(2), avgMs: +(sumMs / 300).toFixed(2) };
  });
  ok('E 300 random paths: no missing path, blocked tile, corner cut or jump', pf.none === 0 && pf.blocked === 0 && pf.cut === 0 && pf.jump === 0, JSON.stringify(pf));

  // F) 카메라가 주인공을 따라온다(바닥 그림 안에서)
  await page.waitForTimeout(3000);
  await page.waitForTimeout(1500);
  const cam = await G(() => { const s = window.__game.scene.getScene('game'), c = s.cameras.main, G = s.map.ground; return { dx: c.midPoint.x - s.player.sprite.x, dy: c.midPoint.y - s.player.sprite.y, inBounds: c.scrollX >= G.x && c.scrollY >= G.y && c.scrollX + c.width <= G.x + G.width && c.scrollY + c.height <= G.y + G.height }; });
  ok('F camera settles on the player and stays inside the ground picture', Math.abs(cam.dx) < 2 && Math.abs(cam.dy) < 2 && cam.inBounds, JSON.stringify(cam));

  console.log('errors', JSON.stringify(errors, null, 1));
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
