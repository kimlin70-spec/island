// Phase 1: 바닥 조각 사이에 줄이 보이지 않는가. 사물을 숨기고 카메라를 소수 좌표에 놓은 화면을 저장한다.
const { open } = require('./lib.js');
const fs = require('fs');
const out = __dirname + '/seam/';
(async () => {
  fs.mkdirSync(out, { recursive: true });
  const T = await open({ query: process.argv[2] === 'nocrop' ? '?' : '' });
  const { page, G, errors } = T;
  const nocrop = process.argv[2] === 'nocrop';
  await G((nocrop) => {
    const s = window.__game.scene.getScene('game');
    s.cameras.main.stopFollow();
    for (const o of s.map.objects) o.sprite.setVisible(false);
    s.player.sprite.setVisible(false);
    if (nocrop) for (const c of s.children.list) if (c.texture && c.texture.key.startsWith('ground_')) c.setCrop();   // 비교용: 자르기를 뺀 경우
  }, nocrop);
  const list = [];
  const fr = [0, 0.25, 0.5, 0.75, 0.37, 0.61, 0.9, 0.13];
  let i = 0;
  // 세로 경계(월드 x = -515, 507)와 가로 경계(월드 y = 747, 1769)가 화면 안에 오도록
  for (const bx of [-515, 507]) for (const by of [747, 1769]) for (let k = 0; k < fr.length; k += 2) {
    const fx = fr[k], fy = fr[(k + 3) % fr.length];
    const want = { sx: bx - 700 - fx, sy: by - 500 - fy };
    const got = await G((w) => { const c = window.__game.scene.getScene('game').cameras.main; c.setScroll(w.sx, w.sy); return null; }, want);
    await page.waitForTimeout(250);
    const real = await G(() => { const c = window.__game.scene.getScene('game').cameras.main; return { sx: c.scrollX, sy: c.scrollY }; });
    const name = 'seam_' + (nocrop ? 'nocrop_' : '') + String(i++).padStart(2, '0') + '.png';
    await page.screenshot({ path: out + name });
    list.push({ name, ...real, vx: [-1537, -515, 507, 1529].map(x => x - real.sx), hy: [747, 1769].map(y => y - real.sy) });
  }
  fs.writeFileSync(out + (nocrop ? 'list_nocrop.json' : 'list.json'), JSON.stringify(list));
  console.log('shots', list.length, 'errors', JSON.stringify(errors));
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
