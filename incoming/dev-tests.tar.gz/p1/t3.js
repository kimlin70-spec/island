// Phase 1: 나무 뒤 반투명 / 나무 앞에서는 주인공이 나무를 가린다
const { open } = require('./lib.js');
const out = __dirname + '/';
const ok = (name, cond, extra = '') => console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : ''));
(async () => {
  const T = await open();
  const { page, G, W, tapTile, state, arrive, errors } = T;
  const shot = async (name) => {
    const p = await G(() => { const s = window.__game.scene.getScene('game'), c = s.cameras.main; return { x: s.player.sprite.x - c.scrollX, y: s.player.sprite.y - c.scrollY }; });
    await page.screenshot({ path: out + name, clip: { x: Math.max(0, p.x - 260), y: Math.max(0, p.y - 240), width: 520, height: 400 } });
  };
  const treeInfo = (c, r) => G(([c, r]) => { const s = window.__game.scene.getScene('game'), o = s.map.objectAt(c, r); return { alpha: +o.sprite.alpha.toFixed(2), depth: o.sprite.depth, pdepth: s.player.sprite.depth, sprite: o.sprite.texture.key }; }, [c, r]);
  const go = async (c, r) => { const moved = await G(([c, r]) => window.__game.scene.getScene('game').player.goTo(c, r), [c, r]); if (!moved) throw new Error('cannot go to ' + c + ',' + r); await arrive(); await page.waitForTimeout(500); };

  // 시작 지점 위의 나무 (37,35). 뒤 칸: (36,34), 옆 뒤: (36,35) (37,34). 앞 칸: (38,36)
  const tr = [37, 35];
  console.log('tree', JSON.stringify(await treeInfo(...tr)));
  const cand = await G(([c, r]) => { const m = window.__game.scene.getScene('game').map; return [[c - 1, r - 1], [c - 1, r], [c, r - 1], [c - 2, r - 2], [c - 2, r - 1], [c - 1, r - 2], [c + 1, r + 1], [c + 1, r], [c, r + 1], [c - 3, r - 3], [c + 2, r - 2], [c - 2, r + 2]].map(t => [...t, m.isWalkable(t[0], t[1])]); }, tr);
  console.log('neighbours walkable', JSON.stringify(cand));

  // 1) 바로 뒤 칸: 캐노피를 눌러서 간다(땅 누르기와 같은 판정이므로 그 뒤 칸으로 간다)
  await tapTile(tr[0] - 1, tr[1] - 1);
  await arrive(); await page.waitForTimeout(500);
  let s = await state(), t = await treeInfo(...tr);
  ok('G1 tapping the canopy walks to the tile behind the tree', s.tile.join() === [tr[0] - 1, tr[1] - 1].join(), JSON.stringify(s.tile));
  ok('G2 tree in front of the player turns half transparent', t.alpha === 0.5 && t.depth > t.pdepth, JSON.stringify(t));
  await shot('occ_behind.png');

  // 2) 두 칸 뒤
  await go(tr[0] - 2, tr[1] - 2);
  t = await treeInfo(...tr);
  console.log('two tiles behind:', JSON.stringify(t));
  await shot('occ_behind2.png');

  // 3) 세 칸 뒤 (머리 위쪽만 살짝 걸친다 -> 가려지지 않으면 불투명)
  const far3 = await G(([c, r]) => { const m = window.__game.scene.getScene('game').map; return [[c - 3, r - 3], [c - 3, r - 2], [c - 2, r - 3]].find(t => m.isWalkable(t[0], t[1])); }, tr);
  console.log('three-behind tile used', JSON.stringify(far3));
  await go(far3[0], far3[1]);
  t = await treeInfo(...tr);
  console.log('three tiles behind:', JSON.stringify(t));
  await shot('occ_behind3.png');

  // 4) 옆(같은 y): 가려지지 않는다
  await go(tr[0] + 2, tr[1] - 2);
  t = await treeInfo(...tr);
  ok('G3 beside the tree (same height on screen): tree stays opaque', t.alpha === 1, JSON.stringify(t));
  await shot('occ_side.png');

  // 5) 앞 칸: 주인공이 나무를 가린다
  await go(tr[0] + 1, tr[1] + 1);
  t = await treeInfo(...tr);
  ok('G4 in front: tree opaque and player drawn over it', t.alpha === 1 && t.pdepth > t.depth, JSON.stringify(t));
  await shot('occ_front.png');

  // 6) 걸어서 지나갈 때 되돌아오는지: 뒤로 갔다가 멀리 떠난다
  await go(tr[0] - 1, tr[1] - 1);
  t = await treeInfo(...tr);
  await go(tr[0] + 3, tr[1] + 3);
  const t2 = await treeInfo(...tr);
  ok('G5 leaving restores the tree', t.alpha === 0.5 && t2.alpha === 1, JSON.stringify([t.alpha, t2.alpha]));

  // 7) 지금 반투명인 사물 수(주인공 하나만 있으니 0이어야 한다)
  const n = await G(() => window.__game.scene.getScene('game').map.objects.filter(o => o.sprite.alpha < 1).length);
  ok('G6 nothing else left translucent', n === 0, 'count ' + n);

  // 8) 숲 속: 소나무·야자수도 된다
  const pine = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map; for (const o of m.objects) { if (o.kind !== 'palm') continue; if (m.isWalkable(o.col - 1, o.row - 1)) return [o.col, o.row]; } });
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.player.col = c - 1; s.player.row = r - 1; s.player.tile = { col: c - 1, row: r - 1 }; s.player.path = []; }, pine);
  await page.waitForTimeout(800);
  t = await treeInfo(...pine);
  ok('G7 palm in front turns half transparent', t.alpha === 0.5, JSON.stringify(t));
  await shot('occ_palm.png');

  console.log('errors', JSON.stringify(errors, null, 1));
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
