// Phase 1: 처음 화면, 섬 전체, 콘솔 오류
const { chromium } = require('playwright');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1920, height: 1200 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error' || (m.type() === 'warning' && !/GPU stall|ReadPixels/.test(m.text()))) errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  page.on('requestfailed', (r) => errors.push('requestfailed: ' + r.url()));
  page.on('response', (r) => { if (r.status() >= 400) errors.push('http ' + r.status() + ': ' + r.url()); });
  const t0 = Date.now();
  await page.goto('http://127.0.0.1:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  console.log('loaded in ms', Date.now() - t0);
  await page.waitForTimeout(1000);
  await page.screenshot({ path: out + 'start.png' });
  const info = await page.evaluate(() => {
    const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main;
    return {
      renderer: g.config.renderType === 2 ? 'webgl' : 'canvas', fps: Math.round(g.loop.actualFps),
      canvas: [g.canvas.width, g.canvas.height], zoom: cam.zoom, scroll: [cam.scrollX, cam.scrollY], mid: [cam.midPoint.x, cam.midPoint.y],
      player: { col: s.player.col, row: s.player.row, x: s.player.sprite.x, y: s.player.sprite.y, depth: s.player.sprite.depth, frame: s.player.sprite.frame.name, flip: s.player.sprite.flipX },
      objects: s.map.objects.length, tall: s.map.objects.filter(o => o.tall).length,
      children: s.children.list.length, textures: Object.keys(g.textures.list).length,
      anims: g.anims.anims.keys(),
    };
  });
  console.log(JSON.stringify(info));
  // 섬 전체 보기(시험용으로 카메라만 바꾼다)
  await page.evaluate(() => {
    const s = window.__game.scene.getScene('game'), cam = s.cameras.main, G = s.map.ground;
    cam.stopFollow(); cam.setZoom(cam.width / G.width); cam.centerOn(G.x + G.width / 2, G.y + G.height / 2);
  });
  await page.waitForTimeout(500);
  await page.screenshot({ path: out + 'full.png' });
  console.log('errors', JSON.stringify(errors, null, 1));
  await browser.close();
})();
