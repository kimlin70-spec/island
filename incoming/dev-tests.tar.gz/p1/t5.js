// Phase 1: 태블릿 크기의 터치 화면에서 누르기, 여러 화면 크기에서 누른 칸이 맞는가
const { open } = require('./lib.js');
const out = __dirname + '/';
const ok = (name, cond, extra = '') => console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : ''));
(async () => {
  for (const [w, h, touch] of [[1024, 768, true], [1366, 768, false], [2560, 1440, false], [820, 1180, true]]) {
    const T = await open({ w, h, touch });
    const { page, G, tapTile, state, arrive, errors } = T;
    const st = await G(() => window.__game.scene.getScene('game').mapData.playerStart);
    const rect = await G(() => { const r = window.__game.canvas.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]; });
    const tag = `${w}x${h}${touch ? ' touch' : ''}`;
    // 누른 칸 표시가 정확히 그 칸에 뜨는지: 칸의 중심에서 조금씩 벗어난 곳을 눌러 본다
    let good = 0, n = 0;
    for (const [dc, dr, ox, oy] of [[3, 0, 0, 0], [0, 3, 0.35, 0], [-2, 1, -0.35, 0], [2, 2, 0, 0.3], [1, -2, 0, -0.3]]) {
      const target = [st.col + dc, st.row + dr];
      const walk = await G(([c, r]) => window.__game.scene.getScene('game').map.isWalkable(c, r), target);
      if (!walk) continue;
      await G(([c, r]) => { const p = window.__game.scene.getScene('game').player; p.path = []; p.col = c; p.row = r; p.tile = { col: c, row: r }; }, [st.col, st.row]);
      await page.waitForTimeout(700);   // 카메라가 제자리로
      const scale = rect[2] / 1920;
      await tapTile(target[0], target[1], ox * 80 * scale, oy * 40 * scale);
      await page.waitForTimeout(80);
      const s = await state();
      n++;
      if (s.cursor && s.cursorAt[0] === (target[0] - target[1]) * 40 && s.cursorAt[1] === (target[0] + target[1]) * 20) good++; else console.log('   miss', tag, target, JSON.stringify(s));
      await arrive();
    }
    ok(`J ${tag}: canvas ${rect.join(',')}  taps landed on the right tile ${good}/${n}`, good === n && n >= 3 && errors.length === 0, errors.join(' | '));
    if (w === 1024) await page.screenshot({ path: out + 'tablet.png' });
    if (w === 820) await page.screenshot({ path: out + 'portrait.png' });
    await T.browser.close();
  }
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
