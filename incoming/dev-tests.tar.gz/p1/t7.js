// 숲 속을 걸을 때의 화면, 섬 끝에서 카메라가 멈추는지
const { open } = require('./lib.js');
const out = __dirname + '/';
(async () => {
  const T = await open();
  const { page, G, arrive, errors } = T;
  // 숲 속의 걸을 수 있는 칸(둘레에 나무가 많은 곳)으로 걸어간다
  const spot = await G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map; let best = null;
    for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
      if (!m.isWalkable(c, r)) continue;
      let n = 0; for (let dr = 0; dr <= 3; dr++) for (let dc = 0; dc <= 3; dc++) { const o = m.objectAt(c + dc, r + dr); if (o && o.tall) n++; }
      if (!best || n > best[2]) best = [c, r, n];
    }
    return best;
  });
  console.log('forest spot', JSON.stringify(spot));
  await G(([c, r]) => window.__game.scene.getScene('game').player.goTo(c, r), spot);
  await page.waitForTimeout(2500);
  await page.screenshot({ path: out + 'forest_walk.png' });
  await arrive(); await page.waitForTimeout(1500);
  await page.screenshot({ path: out + 'forest.png' });
  const info = await G(() => { const s = window.__game.scene.getScene('game'); return { translucent: s.map.objects.filter(o => o.sprite.alpha < 1).length, fps: Math.round(window.__game.loop.actualFps) }; });
  console.log('at forest spot', JSON.stringify(info));
  // 섬의 맨 아래(가장 가까운 쪽) 걸을 수 있는 칸으로: 카메라가 바닥 그림 밖으로 나가지 않는다
  const south = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map; let best = null; for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) if (m.isWalkable(c, r) && (!best || c - r < best[0] - best[1])) best = [c, r]; return best; });
  await G(([c, r]) => window.__game.scene.getScene('game').player.goTo(c, r), south);
  await arrive(); await page.waitForTimeout(2500);
  const cam = await G(() => { const s = window.__game.scene.getScene('game'), c = s.cameras.main, G = s.map.ground; return { tile: [s.player.tile.col, s.player.tile.row], left: c.scrollX - G.x, top: c.scrollY - G.y, right: G.x + G.width - (c.scrollX + c.width), bottom: G.y + G.height - (c.scrollY + c.height), playerOnScreen: [Math.round(s.player.sprite.x - c.scrollX), Math.round(s.player.sprite.y - c.scrollY)] }; });
  console.log('west end', JSON.stringify(cam));
  await page.screenshot({ path: out + 'west.png' });
  console.log('errors', JSON.stringify(errors));
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
