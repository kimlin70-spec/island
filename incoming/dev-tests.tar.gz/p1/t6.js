// 파일을 바로 열었을 때(file://) 안내가 보이는가 / 서버로 열었을 때는 안 보이는가
const { chromium } = require('playwright');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  for (const url of ['file:///home/user/island/index.html', 'http://127.0.0.1:8000/']) {
    const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
    await page.goto(url);
    await page.waitForTimeout(3000);
    const r = await page.evaluate(() => ({ hint: getComputedStyle(document.getElementById('howto')).display, game: !!window.__game, text: document.getElementById('howto').innerText.replace(/\s+/g, ' ').trim() }));
    console.log(url, JSON.stringify(r));
    if (url.startsWith('file')) await page.screenshot({ path: out + 'fileopen.png' });
    await page.close();
  }
  await browser.close();
})();
