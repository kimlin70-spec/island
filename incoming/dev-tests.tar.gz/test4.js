const { chromium } = require('playwright');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').zoneText);
  const G = (fn, arg) => page.evaluate(fn, arg);
  await page.waitForTimeout(500);
  await G(() => { const g = window.__game.scene.getScene('game'); g.vitals.hungerTimer = 59.9; });
  await page.waitForTimeout(1500);
  console.log('hunger (expect 4)', await G(() => window.__game.scene.getScene('game').vitals.hunger));
  await G(() => { const g = window.__game.scene.getScene('game'); g.vitals.hunger = 0; g.vitals.hearts = 1; g.vitals.starveTimer = 29.9; g.vitals.changed(); });
  for (let i = 0; i < 8; i++) {
    await page.waitForTimeout(500);
    console.log(i, await G(() => { const g = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'); return [u.fadeRect.alpha.toFixed(2), g.vitals.hearts, g.collapsing]; }));
  }
  // 멀리 간 뒤 알림 3개 확인
  await page.waitForTimeout(9000);
  console.log('notice alpha', await G(() => { const u = window.__game.scene.getScene('ui'); return [u.noticeBox.alpha, u.noticeText.text, u.notices.length, u.noticeBusy]; }));
  // 안개 걷고 풀밭 쪽으로 걷기 + 팝업 확인
  await G(() => { const g = window.__game.scene.getScene('game'); g.debugToggleSpeed(); g.player.goTo(27, 22); });
  await page.waitForFunction(() => !window.__game.scene.getScene('game').player.moving, null, { timeout: 60000 });
  await G(() => { const g = window.__game.scene.getScene('game'); if (g.speed !== 1) g.debugToggleSpeed(); });
  // 가장 가까운 나무 캐기 (API) 후 팝업 스크린샷
  await G(() => {
    const g = window.__game.scene.getScene('game'); const p = g.player;
    const c = g.mapSystem.objects.filter(o => o.sprite.visible && o.type === 'tree')
      .sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0];
    window.__t = c;
    const cam = g.cameras.main;
    const s = c.sprite; // 잎 한가운데
    const w = { x: s.x, y: s.y - 140 };
    g.onTap(w.x, w.y);
  });
  await page.waitForFunction(() => { const g = window.__game.scene.getScene('game'); return g.inventory.count('wood') >= 1; }, null, { timeout: 60000 });
  await page.waitForTimeout(150);
  await page.screenshot({ path: out + 'p2_popup.png' });
  await page.waitForFunction(() => { const g = window.__game.scene.getScene('game'); return !g.player.action; }, null, { timeout: 60000 });
  await page.waitForTimeout(400);
  console.log('wood', await G(() => window.__game.scene.getScene('game').inventory.count('wood')), await G(() => window.__t.sprite.texture.key));
  await page.screenshot({ path: out + 'p2_after.png' });
  console.log('errors', errors);
  await browser.close();
})();
