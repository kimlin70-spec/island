const { chromium } = require('playwright');
const fs = require('fs');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  // 시험 환경이 느려서 해상도를 절반으로 (config.js 의 view 값만 바꿈)
  await page.route('**/src/config.js', async (route) => {
    let body = fs.readFileSync('/home/user/island/src/config.js', 'utf8');
    body = body.replace('width: 2048, height: 1536, dayZoom: 1.6, nightZoom: 1.0', 'width: 1024, height: 768, dayZoom: 0.8, nightZoom: 0.5');
    route.fulfill({ body, contentType: 'application/javascript' });
  });
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').zoneText);
  const G = (fn, arg) => page.evaluate(fn, arg);
  await page.waitForTimeout(3000);
  console.log('fps', await G(() => window.__game.loop.actualFps));
  await page.screenshot({ path: out + 'p5_lowres.png' });
  await G(() => { const g = window.__game.scene.getScene('game'); g.vitals.hungerTimer = 59.5; });
  await page.waitForFunction(() => window.__game.scene.getScene('game').vitals.hunger === 4, null, { timeout: 30000 });
  console.log('hunger ticked to 4');
  await G(() => { const g = window.__game.scene.getScene('game'); g.player.goTo(25, 30); });
  await page.waitForFunction(() => !window.__game.scene.getScene('game').player.moving, null, { timeout: 60000 });
  console.log('at', await G(() => window.__game.scene.getScene('game').player.tile));
  await G(() => {
    const g = window.__game.scene.getScene('game'); const p = g.player;
    const c = g.mapSystem.objects.filter(o => o.sprite.visible && o.node && o.node.kind === 'tree')
      .sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0];
    window.__t = c;
    g.onTap(c.sprite.x + (c.type === 'palm' ? 40 : 0), c.sprite.y - (c.type === 'palm' ? 170 : 140));   // 잎
  });
  await page.waitForFunction(() => window.__game.scene.getScene('game').inventory.count('wood') >= 1, null, { timeout: 60000 });
  await page.waitForTimeout(120);
  await page.screenshot({ path: out + 'p5_popup.png' });
  const t0 = Date.now();
  await page.waitForFunction(() => !window.__game.scene.getScene('game').player.action, null, { timeout: 60000 });
  console.log('2 more hits took ms', Date.now() - t0);
  await page.waitForTimeout(1200);
  console.log('wood', await G(() => window.__game.scene.getScene('game').inventory.count('wood')), await G(() => [window.__t.type, window.__t.sprite.texture.key, window.__t.tall]));
  // 그루터기를 다시 누르면 옆에 있으니 아무 일 없음, 캐는 중 다른 곳 누르면 멈춤
  await G(() => {
    const g = window.__game.scene.getScene('game'); const p = g.player;
    const c = g.mapSystem.objects.filter(o => o.sprite.visible && o.node && !o.node.depleted && o.node.kind !== 'bush')
      .sort((a, b) => Math.hypot(a.col - p.col, a.row - p.row) - Math.hypot(b.col - p.col, b.row - p.row))[0];
    window.__t2 = c; g.onTap(c.sprite.x, c.sprite.y - 30);
  });
  await page.waitForFunction(() => window.__t2.node.hitsLeft === 2, null, { timeout: 60000 });
  await G(() => { const g = window.__game.scene.getScene('game'); const p = g.player; g.onTap(p.sprite.x + 128, p.sprite.y); });
  await page.waitForTimeout(2000);
  console.log('interrupted: hitsLeft (expect 2)', await G(() => [window.__t2.type, window.__t2.node.hitsLeft, !!window.__game.scene.getScene('game').player.action]));
  // 쓰러짐
  await G(() => { const g = window.__game.scene.getScene('game'); g.vitals.hunger = 0; g.vitals.hearts = 1; g.vitals.starveTimer = 29.8; g.vitals.changed(); });
  await page.waitForFunction(() => window.__game.scene.getScene('ui').fadeRect.alpha > 0.6, null, { timeout: 30000 });
  await page.screenshot({ path: out + 'p5_dark.png' });
  await page.waitForFunction(() => { const g = window.__game.scene.getScene('game'); return g.vitals.hearts === 5 && window.__game.scene.getScene('ui').fadeRect.alpha === 0; }, null, { timeout: 30000 });
  console.log('after collapse', await G(() => { const g = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'); return [g.player.tile, g.vitals.hearts, g.inventory.items, u.fadeRect.alpha, g.collapsing]; }));
  await page.screenshot({ path: out + 'p5_after.png' });
  console.log('errors', errors);
  await browser.close();
})();
