export const meta = {
  name: 'review-fix-86c7629',
  description: 'Independent review of the fence-tap and diagonal-step fix (commit 86c7629), with adversarial verification',
  phases: [
    { title: 'Review', detail: 'three reviewers: movement logic + fuzz, fence taps + input, end-to-end regression' },
    { title: 'Verify', detail: 'one skeptic per reviewer tries to refute each finding by reproducing it' },
  ],
}

const SCRATCH = args.scratch
const CONTEXT = `
PROJECT: /home/user/island, a Phaser 3.90 browser game prototype (no build tools; ES modules in src/). The spec is DEMO_SPEC.md (Korean). CLAUDE.md has the project rules. PROGRESS.md has the history and the agreed decisions.

WHAT CHANGED (commit 86c7629, see \`git -C /home/user/island show 86c7629\`): a fix for two problems an earlier review confirmed.
 (A) Tapping a fence. Fences block the player (a user-requested change; spec 5.1 originally let the player pass their own fences). A fence picture (62x59) reaches about 41 px above its tile centre, so its upper rails lie over the tiles behind it. GameScene.onPress used to walk to the tile under the pointer when the picked object was a fence, so tapping the upper rail walked the player behind the fence (sometimes around a whole wall or into a pen). Now a picked fence calls walkTo(o.col, o.row), the fence's own tile, which is blocked, so nothing happens. Tapping a transparent pixel next to a fence is still a ground tap.
 (B) Diagonal steps past new structures. Path finding (src/systems/Pathfinder.js) is 8-directional and never cuts corners: a diagonal step needs both side tiles walkable. Player.onMapChanged (called by BuildSystem.place after a structure is added) used to cut the planned path only at a tile that became unwalkable, so a walk already under way could pass diagonally between two fences built beside a later step, or clip a fence corner. Now:
   - Player.canStep(a, b) applies the same rule as the path finder;
   - Player.onMapChanged walks the path from this.tile and cuts it before the first step that canStep refuses;
   - Player.occupiedTiles() (used by GameScene.characterTiles -> BuildSystem.canBuildAt, so you cannot build there) is now every tile in the box between the player's fractional position (col,row) and path[0]. Standing: 1 tile. Mid orthogonal step: 2 tiles. Mid diagonal step: 4 tiles (both ends and both side tiles). This also covers backing out of a step (path[0] is the tile just left). So the step in progress can never become illegal.
 Movement model (Player.update): this.tile is the tile stood on or just left; path[0] is the tile being entered; the position moves toward path[0] at CONFIG.player.speed tiles/s; on arrival tile=path.shift(). routeTo re-plans from this.tile; if the new route's second tile equals the current path[0] it continues, otherwise it walks back to this.tile first.

AGREED DECISIONS (do NOT report these): all structures (fence, campfire, tent) block the player; corner fences cannot be passed diagonally; when a new structure blocks the path, the player stops in front of it and does not re-route (the user taps again); building is not allowed on the tiles the player's body is on (now up to 4 during a diagonal step), so the build overlay shows red there for the ~0.4 s of that step; remove mode works at any distance; while resting in the tent, taps only exit via the tent; stumps/rubble are dug with the pickaxe; Phase 5 items (zombies, hearts dropping, structure damage, result window) are not built yet.

HOW TO RUN IT: a static server is ALREADY running at http://127.0.0.1:8000. Do not start or kill anything on port 8000. Node + Playwright + headless Chromium work (require('playwright')). The machine has only 4 CPUs and other reviewers run browsers at the same time, so use one browser at a time and keep runs short. Helper module: ${SCRATCH}/p4/lib.js exports open({w,h,touch,query}) -> {browser, page, errors, G(fn,arg) (=page.evaluate), W(fn,arg,timeoutMs) (=waitForFunction), tilePos(col,row), tapTile(col,row), state(), arrive()}. Working examples of real-click tests for this fix: ${SCRATCH}/p4/t6.js (fence taps, building beside a walk, occupied tiles) and ${SCRATCH}/p4/t7.js (tablet touch, tent). In the page, window.__game is the Phaser game; getScene('game') is GameScene (player, map, build, rest, ...), getScene('ui') is UIScene. Headless rendering is slow (~8 fps at 1920x1200); game logic uses per-frame dt capped at 0.1 s. The camera follows the player, so while the player walks, screen positions of tiles shift between computing a click position and the click landing; recompute right before each click and verify what was actually built. Key screen positions (1920x1200 game coords): craft button (1824,1104) toggles the craft window and build mode off; craft cards centre y=898, x = 776+20+i*182+85 (i: 0 axe, 1 pickaxe, 2 fence, 3 campfire, 4 tent, 5 remove); "시험" button (1852,328); test window items x=1746, y = 402+i*66 (0 +20 materials, 1 night, 2 morning, 3 speed, 4 close); rest button (960,1132).

RULES: do NOT modify anything under /home/user/island. Write scratch files only under ${SCRATCH}/review2/<your-lens>/. Report only real problems with a concrete failure scenario (inputs/sequence -> wrong result) and file:line. No style nits.`

const FINDINGS = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          title: { type: 'string' },
          file: { type: 'string' },
          line: { type: 'integer' },
          severity: { type: 'string', enum: ['high', 'medium', 'low'] },
          scenario: { type: 'string', description: 'concrete inputs/sequence and the wrong outcome' },
          evidence: { type: 'string', description: 'code, spec text, or reproduction output' },
          fix: { type: 'string' },
        },
        required: ['id', 'title', 'file', 'severity', 'scenario', 'evidence'],
      },
    },
    checked: { type: 'string', description: 'what you checked and found fine (brief)' },
  },
  required: ['findings', 'checked'],
}

const VERDICTS = {
  type: 'object',
  properties: {
    verdicts: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          real: { type: 'boolean' },
          reason: { type: 'string' },
          reproduction: { type: 'string' },
        },
        required: ['id', 'real', 'reason'],
      },
    },
  },
  required: ['verdicts'],
}

const LENSES = [
  { key: 'movement', prompt: `You are the MOVEMENT-LOGIC reviewer. Read src/systems/Player.js in full, src/systems/Pathfinder.js, BuildSystem.canBuildAt/place, GameScene.characterTiles/walkTo/onPress, and RestSystem. Enumerate every movement state (standing; start of a walk; mid orthogonal step; mid diagonal step; arriving exactly on a tile with path left; re-route mid-step that continues; re-route mid-step that walks back; walking back then re-routing again; act() towards a node or tent; resting) and check, for each: (1) can the player's body ever overlap a blocked tile (the box floor..ceil of its position, or the segment to path[0]); (2) can the remaining path contain a step that canStep/the path finder would refuse; (3) can the player be left with an empty path at a fractional position; (4) are tiles reserved that the body does not touch (over-reservation that wrongly refuses a build), or are tiles not reserved that the body touches; (5) floating-point edge cases in occupiedTiles (positions like 37.000000001). Then confirm with a seeded randomized fuzz in the browser: repeatedly start walks (ground taps through the real input or player.goTo) and place structures with s.build.place on random tiles that canBuildAt allows (call canBuildAt first, ignoring only the reach limit if you must), at random moments mid-walk, with per-frame invariants checked in a 'postupdate' listener. Report violations with the seed and the exact sequence.` },
  { key: 'input', prompt: `You are the INPUT/SPEC reviewer for the fence-tap part. Read DEMO_SPEC.md 3.5 and 5.1, PROGRESS.md (sections "사용자 요청으로 바꾼 것" and the Phase 4 parts), GameScene.onPress, MapSystem.pickObject. Then verify in the browser with real mouse clicks, and with 1024x768 touch: for each fence picture variant (build_fence_0..15, produced by building lines, corners, crosses and pens), tapping any opaque pixel never moves the player and never shows the move cursor; tapping transparent pixels near a fence behaves like a ground tap; fences overlapping a tree, stump, campfire or tent picture pick the front-most picture as before; build mode, remove mode (removing a fence by tapping its upper rail) and resting are unaffected; tapping a campfire or bush still does nothing; tapping a tent still enters it. Also check that every statement PROGRESS.md makes about these fixes matches the code's behaviour.` },
  { key: 'e2e', prompt: `You are the END-TO-END REGRESSION explorer. Using only the real UI (mouse at 1920x1200 and touch at 1024x768), play the Phase 2-4 flows with the fix in place and try to break it: chop trees with the dagger, craft the axe and pickaxe, mine rocks, dig out stumps and rubble, build fence lines and pens quickly while the player is walking (including lines that are straight on screen, which are diagonal in tile space), build campfires and the tent beside a walk in progress, fence yourself in and remove a side fence to get out, walk into and out of the tent, use the test window (night, morning, speed). Watch for console/page errors, the player stuck between tiles, the player standing on or inside a structure, a build refused on a tile the player is clearly not touching, a walk that never ends, or a tap that does nothing when it should walk. Report reproducible problems only, with exact steps and observed vs expected.` },
]

const results = await pipeline(
  LENSES,
  (lens) => agent(`${CONTEXT}\n\nYOUR TASK:\n${lens.prompt}\n\nReturn findings via the structured output. Use ids like ${lens.key}-1, ${lens.key}-2 ...`, { label: `review:${lens.key}`, phase: 'Review', schema: FINDINGS }),
  (review, lens) => {
    if (!review || !review.findings || review.findings.length === 0) return { lens: lens.key, review, verdicts: [] }
    return agent(`${CONTEXT}\n\nYOUR TASK: You are a SKEPTICAL VERIFIER. Another reviewer (lens: ${lens.key}) reported the findings below. For EACH finding, try hard to refute it: re-read the exact code, check whether it is one of the agreed decisions above, check whether the scenario can actually happen through the real UI, and reproduce it in the browser. Mark real=true only if you confirmed the wrong behaviour concretely. When uncertain, real=false and say why. Include your reproduction output when you ran something.\n\nFINDINGS:\n${JSON.stringify(review.findings, null, 1)}`, { label: `verify:${lens.key}`, phase: 'Verify', schema: VERDICTS })
      .then((v) => ({ lens: lens.key, review, verdicts: v ? v.verdicts : null }))
  },
)

const confirmed = []
const rejected = []
for (const r of results.filter(Boolean)) {
  const byId = Object.fromEntries((r.verdicts || []).map((v) => [v.id, v]))
  for (const f of (r.review && r.review.findings) || []) {
    const v = byId[f.id]
    if (v && v.real) confirmed.push({ ...f, lens: r.lens, verify: v.reason, reproduction: v.reproduction || '' })
    else rejected.push({ id: f.id, title: f.title, lens: r.lens, why: v ? v.reason : 'no verdict' })
  }
}
const missing = LENSES.filter((l) => !results.some((r) => r && r.lens === l.key)).map((l) => l.key)
if (missing.length) log(`reviewers that returned nothing: ${missing.join(', ')}`)
log(`confirmed ${confirmed.length}, rejected ${rejected.length}`)
return { confirmed, rejected, missing, checked: results.filter(Boolean).map((r) => ({ lens: r.lens, checked: r.review && r.review.checked })) }
