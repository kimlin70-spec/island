const { chromium } = require('playwright');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('requestfailed', (r) => errors.push('failed: ' + r.url()));
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.getScene('game').player);
  await page.waitForTimeout(500);
  await page.screenshot({ path: out + 's1_start.png' });

  const state = () => page.evaluate(() => {
    const g = window.__game.scene.getScene('game'); const p = g.player;
    return { col: p.col, row: p.row, moving: p.moving, flip: p.sprite.flipX, frame: p.sprite.frame.name };
  });
  // 화면 좌표 <- 칸
  const tileScreen = (col, row) => page.evaluate(([c, r]) => {
    const g = window.__game.scene.getScene('game'); const cam = g.cameras.main;
    const wx = (c - r) * 64, wy = (c + r) * 32;
    const sx = (wx - cam.worldView.x) * cam.zoom, sy = (wy - cam.worldView.y) * cam.zoom;
    const ds = window.__game.scale.displayScale; const b = window.__game.canvas.getBoundingClientRect();
    return { x: b.left + sx / ds.x, y: b.top + sy / ds.y };
  }, [col, row]);
  const tap = async (col, row) => { const s = await tileScreen(col, row); await page.mouse.click(s.x, s.y); };

  console.log('start', await state());
  // 1) 왼쪽 땅으로 이동
  await tap(22, 29);
  await page.waitForTimeout(300);
  console.log('mid', await state());
  await page.screenshot({ path: out + 's2_walk.png' });
  await page.waitForTimeout(2500);
  console.log('after move to 22,29', await state());

  // 2) 물 누르기 -> 물로는 가지 않음
  const info = await page.evaluate(() => {
    const m = window.__game.scene.getScene('game').mapSystem;
    const objs = m.objects.map(o => [o.type, o.col, o.row]);
    return { objs };
  });
  // 3) 가까운 나무 뒤로 가 보기
  const p0 = await state();
  const trees = info.objs.filter(o => ['tree', 'palm', 'pine'].includes(o[0]))
    .sort((a, b) => Math.hypot(a[1] - p0.col, a[2] - p0.row) - Math.hypot(b[1] - p0.col, b[2] - p0.row));
  const t = trees[0];
  console.log('nearest tree', t);
  // 나무 바로 뒤(화면 위쪽) 칸: col-1,row-1
  const r1 = await page.evaluate(([c, r]) => {
    const g = window.__game.scene.getScene('game');
    return g.player.goTo(c, r);
  }, [t[1] - 1, t[2] - 1]);
  console.log('goTo behind', r1);
  await page.waitForTimeout(4000);
  console.log('behind tree', await state(), await page.evaluate(([c, r]) => {
    const m = window.__game.scene.getScene('game').mapSystem;
    return m.objects.filter(o => o.sprite.alpha < 1).map(o => [o.type, o.col, o.row, o.sprite.alpha]);
  }, []));
  await page.screenshot({ path: out + 's3_behind.png' });
  await page.evaluate(([c, r]) => window.__game.scene.getScene('game').player.goTo(c, r), [t[1] + 1, t[2] + 1]);
  await page.waitForTimeout(3000);
  console.log('front of tree', await state(), await page.evaluate(() => {
    const m = window.__game.scene.getScene('game').mapSystem;
    return m.objects.filter(o => o.sprite.alpha < 1).length;
  }));
  await page.screenshot({ path: out + 's4_front.png' });

  // 4) 물 탭
  const before = await state();
  await page.evaluate(() => { const g = window.__game.scene.getScene('game'); window.__r = g.player.goTo(0, 0); });
  console.log('water far goTo', await page.evaluate(() => window.__r), before.col, before.row);

  // 5) 경로 검증: 섬 여러 곳으로 이동시키며 막힌 칸을 밟는지
  const bad = await page.evaluate(() => {
    const g = window.__game.scene.getScene('game'); const m = g.mapSystem; const p = g.player;
    let bad = 0, n = 0, none = 0;
    for (let i = 0; i < 300; i++) {
      const c = Math.floor(Math.random() * 40), r = Math.floor(Math.random() * 40);
      if (!p.goTo(c, r)) { none++; continue; }
      n++;
      let prev = p.tile;
      for (const s of p.path) {
        if (!m.isWalkable(s.col, s.row)) bad++;
        const dc = s.col - prev.col, dr = s.row - prev.row;
        if (Math.abs(dc) > 1 || Math.abs(dr) > 1) bad++;
        if (dc && dr && (!m.isWalkable(prev.col + dc, prev.row) || !m.isWalkable(prev.col, prev.row + dr))) bad++;
        prev = s;
      }
      const e = p.path[p.path.length - 1] || p.tile;
      p.col = e.col; p.row = e.row; p.tile = { col: e.col, row: e.row }; p.path = [];
    }
    return { bad, n, none };
  });
  console.log('path check', bad);

  // 6) 섬 전체 보기
  await page.evaluate(() => {
    const g = window.__game.scene.getScene('game'); const cam = g.cameras.main;
    cam.stopFollow(); cam.setZoom(0.62); cam.centerOn(0, 39 * 32);
  });
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + 's5_full.png' });
  // 이음매 확인용 확대
  await page.evaluate(() => {
    const g = window.__game.scene.getScene('game'); const cam = g.cameras.main;
    cam.setZoom(1.6); cam.centerOn((22 - 20) * 64 + 13.3, (22 + 20) * 32 + 7.7);
  });
  await page.waitForTimeout(300);
  await page.setViewportSize({ width: 2048, height: 1536 });
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + 's6_seams.png', clip: { x: 600, y: 400, width: 900, height: 700 } });
  console.log('fps', await page.evaluate(() => window.__game.loop.actualFps));
  console.log('errors', errors);
  // 세로 화면
  await page.setViewportSize({ width: 768, height: 1024 });
  await page.waitForTimeout(200);
  await page.screenshot({ path: out + 's7_portrait.png' });
  await browser.close();
})();
