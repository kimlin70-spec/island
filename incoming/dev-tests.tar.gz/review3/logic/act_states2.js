// act() states, part 2: stepOff, fenced in on a stump, tent arrive, rock -> rubble, dug out, other object, no route.
const fs = require('fs');
const { open } = require('../../p4/lib.js');
const lib = fs.readFileSync(__dirname + '/plib.js', 'utf8');
let fails = 0;
const ok = (name, cond, info) => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info !== undefined ? '  ' + (typeof info === 'string' ? info : JSON.stringify(info)) : '')); if (!cond) fails++; };

(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await page.addScriptTag({ content: lib });

  // B1 standing on a stump, press it: step off to a neighbour and dig; re-taps keep it
  let r = await G(() => {
    const L = window.__L, { s, p, m } = L;
    const tree = L.obj(32, 40);
    L.tp(33, 40);
    s.pressNode(tree);
    L.until(() => tree.kind === 'stump', 4000);
    L.step(2);
    s.walkTo(32, 40);                            // walk onto the stump
    L.until(() => !p.moving);
    const e0 = L.snap();
    s.pressNode(tree);
    const e1 = L.snap();
    s.pressNode(tree);                           // same frame
    const e2 = L.snap();
    L.step(1);
    const e3 = L.snap();                         // mid step-off
    s.pressNode(tree);
    const e4 = L.snap();
    L.until(() => !p.moving);
    L.step(1);
    const e5 = L.snap();                         // digging from the neighbour
    s.pressNode(tree);
    const e6 = L.snap();
    L.until(() => !m.objects.includes(tree), 4000);
    const e7 = L.snap();                         // the frame the stump is dug out (action still set until next update?)
    L.step(1);
    const e8 = L.snap();
    return { e0, e1, e2, e3, e4, e5, e6, e7, e8, gone: !m.objects.includes(tree) };
  });
  ok('B1 standing on the stump', r.e0.tile === '32,40', r.e0);
  ok('B1 press on the stump steps off (path to a neighbour)', r.e1.act && r.e1.path.split(' ').length >= 1 && r.e1.path !== '' && r.e1.path.split(' ').pop() !== '32,40', r.e1);
  ok('B1 second press in the same frame kept', r.e2.act === r.e1.act && r.e2.pathId === r.e1.pathId, r.e2);
  ok('B1 re-tap mid step-off kept', r.e4.act === r.e3.act && r.e4.pathId === r.e3.pathId, [r.e3, r.e4]);
  ok('B1 digging from the neighbour, re-tap keeps swing', r.e6.act === r.e5.act && r.e6.swing === r.e5.swing && r.e6.cd === r.e5.cd && r.e5.tile !== '32,40', [r.e5, r.e6]);
  ok('B1 stump dug out, action cleared next frame', r.gone && r.e8.act === null, [r.e7, r.e8]);

  // B2 fenced in on a stump: digs in place; re-tap kept
  r = await G(() => {
    const L = window.__L, { s, p, m } = L;
    L.clear();
    const tree = L.obj(44, 34);                   // partly cut in part 1? fresh page: intact
    L.tp(45, 34);
    s.pressNode(tree);
    L.until(() => tree.kind === 'stump', 4000);
    L.step(2);
    s.walkTo(44, 34);
    L.until(() => !p.moving);
    const built = [[45, 34], [43, 34], [44, 35], [44, 33]].map(([c, r]) => L.fence(c, r));
    const f0 = L.snap();
    const ret = s.pressNode(tree);
    const f1 = L.snap();
    L.step(1);
    const f2 = L.snap();
    s.pressNode(tree);
    const f3 = L.snap();
    L.until(() => !m.objects.includes(tree), 4000);
    L.step(1);
    return { built, f0, f1, f2, f3, gone: !m.objects.includes(tree), f4: L.snap() };
  });
  ok('B2 four fences around the stump', r.built.every(Boolean), r.built);
  ok('B2 fenced in: press digs in place', r.f1.act && r.f1.path === '' && r.f1.tile === '44,34', r.f1);
  ok('B2 re-tap while digging in place kept', r.f3.act === r.f2.act && r.f3.swing === r.f2.swing && r.f3.cd === r.f2.cd && r.f2.swing, [r.f2, r.f3]);
  ok('B2 dug out in place', r.gone && r.f4.act === null, r.f4);

  // B3 tent: walk to it, re-tap kept, arrive -> resting; cut path -> re-tap re-plans -> resting
  r = await G(() => {
    const L = window.__L, { s, p, m, b } = L;
    L.clear();
    L.tp(37, 39);
    const tiles = [{ col: 40, row: 44 }, { col: 41, row: 44 }, { col: 40, row: 45 }, { col: 41, row: 45 }];
    const okTiles = tiles.every((t) => b.canBuildAt(t.col, t.row));
    const tent = b.place('tent', tiles);
    s.pressTent(tent);
    L.step(2);
    const g0 = L.snap();
    s.pressTent(tent);
    const g1 = L.snap();
    L.until(() => s.rest.resting || !p.moving);
    L.step(1);
    const g2 = L.snap();
    s.rest.exit();
    // second: walk away, press the tent, cut the path short, re-tap
    s.walkTo(33, 39);
    L.until(() => !p.moving);
    s.pressTent(tent);
    L.step(2);
    const h0 = L.snap();
    let placed = null;
    for (let k = 2; k < p.path.length; k++) { const t = p.path[k]; if (L.fence(t.col, t.row)) { placed = L.K(t); break; } }
    const h1 = L.snap();
    const endNext = L.nextTo(tent.tiles, L.end());
    s.pressTent(tent);
    const h2 = L.snap();
    const endNext2 = L.nextTo(tent.tiles, L.end());
    L.until(() => s.rest.resting || !p.moving);
    L.step(1);
    return { okTiles, g0, g1, g2, h0, placed, h1, endNext, h2, endNext2, h3: L.snap() };
  });
  ok('B3 tent built', r.okTiles);
  ok('B3 re-tap while walking to the tent kept', r.g1.act === r.g0.act && r.g1.pathId === r.g0.pathId, [r.g0, r.g1]);
  ok('B3 arrives and rests', r.g2.resting, r.g2);
  ok('B3 cut path short then re-tap re-plans and rests', r.placed && !r.endNext && r.h2.act !== r.h1.act && r.endNext2 && r.h3.resting, r);

  // B4 rock -> rubble: press the rubble in the frame right after; then dug out; press the ground there
  r = await G(() => {
    const L = window.__L, { s, p, m } = L;
    L.clear();
    if (s.rest.resting) s.rest.exit();
    const rock = L.obj(33, 37);
    L.tp(34, 37);
    s.pressNode(rock);
    L.until(() => rock.kind === 'rubble', 4000);
    const k0 = L.snap();
    s.pressNode(rock);                            // right after it became rubble
    const k1 = L.snap();
    const tool = p.action && p.action.tool();
    L.until(() => !m.objects.includes(rock), 4000);
    const k2 = L.snap();                          // the frame it was dug out
    const picked = m.pickObject(rock.sprite.x, rock.sprite.y);
    s.walkTo(33, 37);                             // ground tap on that tile in the same frame
    const k3 = L.snap();
    L.until(() => !p.moving);
    return { k0, k1, tool, k2, picked: picked ? L.K(picked) : null, k3, k4: L.snap() };
  });
  ok('B4 frame after rock -> rubble: old action invalid', r.k0.act && r.k0.valid === false, r.k0);
  ok('B4 press rubble then starts digging with the pickaxe', r.k1.act !== r.k0.act && r.k1.valid && r.tool === 'pickaxe', r.k1);
  ok('B4 frame after dug out: ground tap walks there', r.k3.act === null && r.k4.tile === '33,37', [r.k2, r.k3, r.k4]);

  // B5 press on a different object while chopping: new action, swing dropped, cooldown kept
  r = await G(() => {
    const L = window.__L, { s, p, m } = L;
    L.clear();
    // two trees both next to one tile: 30,17 / 30,16? search
    let spot = null;
    for (const o of m.objects) {
      if (!o.node || o.node.group !== 'tree') continue;
      for (const o2 of m.objects) {
        if (o2 === o || !o2.node || o2.node.group !== 'tree') continue;
        if (L.cheb(o, o2) > 2) continue;
        for (let dc = -1; dc <= 1 && !spot; dc++) for (let dr = -1; dr <= 1 && !spot; dr++) {
          const t = { col: o.col + dc, row: o.row + dr };
          if (m.isWalkable(t.col, t.row) && L.cheb(t, o2) <= 1) spot = { t, o, o2 };
        }
        if (spot) break;
      }
      if (spot) break;
    }
    if (!spot) return null;
    L.tp(spot.t.col, spot.t.row);
    s.tools = ['dagger'];
    s.pressNode(spot.o);
    L.step(1);
    const m0 = L.snap();
    s.pressNode(spot.o2);
    const m1 = L.snap();
    L.step(1);
    const m2 = L.snap();
    s.tools = ['dagger', 'axe', 'pickaxe'];
    return { at: L.K(spot.t), o: L.K(spot.o), o2: L.K(spot.o2), m0, m1, m2 };
  });
  ok('B5 different object: new action, swing dropped, cooldown kept', r && r.m1.act !== r.m0.act && r.m1.swing === null && r.m1.cd === r.m0.cd && r.m1.actT.startsWith(r.o2), r);

  // B6 no route: tree fenced in on all 8 sides; press returns nothing, state unchanged.
  // B7 same target, path cut, no route any more: press does nothing (old action/path stay), then cleared on arrival
  r = await G(() => {
    const L = window.__L, { s, p, m } = L;
    L.clear();
    const tree = m.objects.find((o) => o.node && o.node.group === 'tree' && o.col === 41 && o.row === 42) ||
                 m.objects.find((o) => o.node && o.node.group === 'tree' && L.cheb(o, { col: 37, row: 39 }) <= 8 && o.kind !== 'stump');
    L.tp(37, 39);
    s.pressNode(tree);
    L.step(1);
    const n0 = L.snap();
    // ring of fences around the tree
    const ring = [];
    for (let dc = -1; dc <= 1; dc++) for (let dr = -1; dr <= 1; dr++) if (dc || dr) ring.push(L.fence(tree.col + dc, tree.row + dr) ? 1 : 0);
    const n1 = L.snap();
    const ret = s.pressNode(tree);
    const n2 = L.snap();
    L.until(() => !p.moving);
    L.step(1);
    const n3 = L.snap();
    const ret2 = s.pressNode(tree);
    const n4 = L.snap();
    return { tree: L.K(tree), ring, n0, n1, n2, n3, n4 };
  });
  ok('B7 path cut with no route: re-tap leaves state unchanged', r.n2.act === r.n1.act && r.n2.pathId === r.n1.pathId, r);
  ok('B7 action cleared when it stops (not next to the tree)', r.n3.act === null, r.n3);
  ok('B6 press with no route does nothing', r.n4.act === null && r.n4.path === '', r.n4);

  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
