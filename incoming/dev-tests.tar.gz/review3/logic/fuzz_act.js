// Driver: node fuzz.js <firstSeed> <seedCount> <framesPerSeed>
const fs = require('fs');
const { open } = require('../../p4/lib.js');
const src = fs.readFileSync(__dirname + '/fuzz_page_act.js', 'utf8');
const first = +(process.argv[2] || 1), count = +(process.argv[3] || 3), frames = +(process.argv[4] || 20000);
const deltaMode = process.argv[5] && process.argv[5] !== 'random' ? +process.argv[5] : 'random', speed3 = process.argv[6] === '3';

(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  const all = { stats: {}, fails: [] };
  for (let seed = first; seed < first + count; seed++) {
    if (seed !== first) {
      await page.reload();
      await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
      await page.waitForTimeout(300);
    }
    await G(() => import('/src/systems/Pathfinder.js').then((mod) => { window.__findPath = mod.findPath; }));
    await page.addScriptTag({ content: src });
    await G(([seed, dm, s3]) => window.__fz.init(seed, dm, s3), [seed, deltaMode, speed3]);
    const t0 = Date.now();
    let r;
    for (let done = 0; done < frames; done += 2000) {
      r = await G((n) => window.__fz.run(n), Math.min(2000, frames - done));
    }
    const res = await G(() => ({ stats: window.__fz.stats, fails: window.__fz.fails }));
    for (const [k, v] of Object.entries(res.stats)) all.stats[k] = (all.stats[k] || 0) + v;
    all.fails.push(...res.fails);
    console.log(`seed ${seed}: frames ${r.frame} fails ${res.fails.length} structures ${r.structures} (${((Date.now() - t0) / 1000).toFixed(1)}s)`);
    
  }
  console.log(JSON.stringify(all.stats, null, 1));
  fs.writeFileSync(__dirname + `/fuzzact_${first}_${count}_${deltaMode}_${speed3 ? 3 : 1}.json`, JSON.stringify(all, null, 1));
  console.log('page errors:', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
