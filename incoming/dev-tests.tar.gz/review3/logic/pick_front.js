// pickObject front-most rule with fences: for every pixel where a fence and a tent / rock overlap, the picked
// object must be the one drawn on top (higher depth) unless that one's pixel is below its threshold.
// Also remove mode (structures only). Uses the game's own pickObject and textures.
const fs = require('fs');
const { open } = require('../../p4/lib.js');
const lib = fs.readFileSync(__dirname + '/plib.js', 'utf8');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await page.addScriptTag({ content: lib });
  const r = await G(() => {
    const L = window.__L, { s, m, b } = L;
    L.clear();
    L.tp(37, 39);
    const tex = s.textures;
    const alphaOf = (o, x, y) => {
      const sp = o.sprite;
      const lx = Math.floor(x - (sp.x - sp.displayWidth * sp.originX)), ly = Math.floor(y - (sp.y - sp.displayHeight * sp.originY));
      if (lx < 0 || ly < 0 || lx >= sp.width || ly >= sp.height) return null;
      return tex.getPixelAlpha(lx, ly, sp.texture.key, sp.frame.name);
    };
    const thr = (o) => (o.type === 'fence' ? 30 : 110);
    const out = [];
    const audit = (label, objs, list) => {
      // every pixel in the union of the boxes: expected = first in depth order (desc, render order for ties) whose alpha > its threshold
      const xs = [], ys = [];
      for (const o of objs) { const sp = o.sprite; xs.push(sp.x - sp.displayWidth * sp.originX, sp.x + sp.displayWidth * (1 - sp.originX)); ys.push(sp.y - sp.displayHeight * sp.originY, sp.y + sp.displayHeight * (1 - sp.originY)); }
      const dl = s.children.list;
      const order = [...objs].sort((a, z) => (z.sprite.depth - a.sprite.depth) || (dl.indexOf(z.sprite) - dl.indexOf(a.sprite)));
      let n = 0, bad = 0, sample = [];
      for (let y = Math.floor(Math.min(...ys)); y < Math.max(...ys); y++) for (let x = Math.floor(Math.min(...xs)); x < Math.max(...xs); x++) {
        const px = x + 0.5, py = y + 0.5;
        let exp = null;
        for (const o of order) { const a = alphaOf(o, px, py); if (a !== null && a > thr(o)) { exp = o; break; } }
        const got = m.pickObject(px, py, list);
        if (!objs.includes(got) && got !== null) continue;            // something else of the map
        n++;
        if (got !== exp) { bad++; if (sample.length < 5) sample.push({ x: px, y: py, got: got && (got.type || got.kind), exp: exp && (exp.type || exp.kind) }); }
      }
      out.push({ label, pixels: n, mismatches: bad, sample });
    };
    // tent at 40..41,44..45 ; fences around its right side and front
    const tent = b.place('tent', [{ col: 40, row: 44 }, { col: 41, row: 44 }, { col: 40, row: 45 }, { col: 41, row: 45 }]);
    const f1 = b.place('fence', [{ col: 42, row: 44 }]), f2 = b.place('fence', [{ col: 42, row: 45 }]), f3 = b.place('fence', [{ col: 42, row: 43 }]);
    const f4 = b.place('fence', [{ col: 40, row: 46 }]), f5 = b.place('fence', [{ col: 41, row: 46 }]);
    // fence behind the tent
    const f6 = b.place('fence', [{ col: 40, row: 43 }]), f7 = b.place('fence', [{ col: 39, row: 44 }]);
    const objs = [tent, f1, f2, f3, f4, f5, f6, f7];
    audit('tent + fences (world pick)', objs, undefined);
    audit('tent + fences (remove mode)', objs, m.structures);
    // a rock with fences in front and behind
    const rock = m.objectAt(51, 38);
    const g1 = b.place('fence', [{ col: 52, row: 38 }]), g2 = b.place('fence', [{ col: 51, row: 39 }]), g3 = b.place('fence', [{ col: 51, row: 37 }]), g4 = b.place('fence', [{ col: 50, row: 38 }]);
    audit('rock + fences', [rock, g1, g2, g3, g4], undefined);
    return out;
  });
  for (const x of r) console.log(JSON.stringify(x));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
