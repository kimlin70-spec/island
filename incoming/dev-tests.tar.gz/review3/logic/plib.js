// Page-side helpers (installed with addScriptTag). Steps GameScene by hand with the game loop asleep.
(() => {
  const g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player, b = s.build;
  const L = window.__L = { s, m, p, b };
  let time = g.loop.time || 0;
  L.sleep = () => { if (!g.loop.sleeping) g.loop.sleep(); time = Math.max(time, g.loop.time || 0); };
  L.step = (n = 1, ms = 50) => { for (let i = 0; i < n; i++) { time += ms; s.sys.step(time, ms); } };
  L.K = (t) => t.col + ',' + t.row;
  const ids = new WeakMap(); let nid = 0;
  L.id = (o) => { if (!o) return null; if (!ids.has(o)) ids.set(o, ++nid); return ids.get(o); };
  L.snap = () => ({
    pos: [p.col, p.row], tile: L.K(p.tile), path: p.path.map(L.K).join(' '), pathId: L.id(p.path),
    act: p.action ? L.id(p.action) : null,
    actT: p.action ? L.K(p.action.target) + ':' + (p.action.target.kind || p.action.target.type) : null,
    valid: p.action ? p.action.isValid() : null,
    swing: p.swing ? L.id(p.swing) : null, swingT: p.swing ? +p.swing.t.toFixed(3) : null, struck: p.swing ? p.swing.struck : null,
    cd: +p.cooldown.toFixed(4), resting: s.rest.resting,
  });
  L.tp = (c, r) => { p.stopAction(); p.path = []; p.col = c; p.row = r; p.tile = { col: c, row: r }; p.cooldown = 0; p.syncSprite(); };
  L.clear = () => { if (s.rest.resting) s.rest.exit(); for (const x of [...m.structures]) b.destroy(x); };
  L.fence = (c, r) => { if (!b.canBuildAt(c, r)) return false; b.place('fence', [{ col: c, row: r }]); return true; };
  L.obj = (c, r) => m.objectAt(c, r);
  L.cheb = (a, z) => Math.max(Math.abs(a.col - z.col), Math.abs(a.row - z.row));
  L.nextTo = (tiles, at) => tiles.some((t) => L.cheb(t, at) <= 1);
  L.end = () => p.path[p.path.length - 1] || p.tile;
  L.until = (cond, max = 2000, ms = 50) => { let n = 0; while (!cond() && n < max) { L.step(1, ms); n++; } return n; };
  L.hp = (o) => (o.node ? o.node.hp : null);
  // legality of the remaining path (same rule as Player.canStep)
  L.pathLegal = () => {
    let from = p.tile;
    for (let k = 0; k < p.path.length; k++) {
      const q = p.path[k];
      if (k === 0 && L.cheb(from, q) === 0) continue;
      if (L.cheb(from, q) !== 1 || !p.canStep(from, q)) return false;
      from = q;
    }
    return true;
  };
  s.tools = ['dagger', 'axe', 'pickaxe'];
  L.sleep();
})();
