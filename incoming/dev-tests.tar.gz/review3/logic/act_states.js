// Deterministic act() states. Game loop asleep, frames stepped by hand (50 ms). Entry points are the ones
// onPress uses: GameScene.pressNode / pressTent / walkTo. Fences via BuildSystem.place after canBuildAt.
const fs = require('fs');
const { open } = require('../../p4/lib.js');
const lib = fs.readFileSync(__dirname + '/plib.js', 'utf8');
let fails = 0;
const ok = (name, cond, info) => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info !== undefined ? '  ' + (typeof info === 'string' ? info : JSON.stringify(info)) : '')); if (!cond) fails++; };

(async () => {
  const T = await open({ w: 960, h: 600 });
  const { page, G } = T;
  await page.addScriptTag({ content: lib });

  // A1 chopping next to a tree: re-tap keeps the action, the swing and the cooldown
  let r = await G(() => {
    const L = window.__L, { s, p } = L;
    const tree = L.obj(32, 40);
    L.tp(33, 40);
    s.tools = ['dagger'];                       // dagger: 9 hits, plenty of states
    s.pressNode(tree);
    const a0 = L.snap();
    L.step(1);
    const a1 = L.snap();                         // swing raised
    s.pressNode(tree);
    const a1b = L.snap();
    L.step(3);                                   // past toolRaise (0.2) -> struck
    const a2 = L.snap();
    s.pressNode(tree);
    const a2b = L.snap();
    L.until(() => !p.swing);
    const a3 = L.snap();                         // between swings, cooldown > 0
    s.pressNode(tree);
    const a3b = L.snap();
    const hpBefore = L.hp(tree);
    L.until(() => tree.kind === 'stump', 4000);
    return { a0, a1, a1b, a2, a2b, a3, a3b, hpBefore, kind: tree.kind };
  });
  ok('A1 press next to the tree starts the action without walking', r.a0.act && r.a0.path === '', r.a0);
  ok('A1 re-tap while the tool is raised keeps action/swing/cooldown', r.a1b.act === r.a1.act && r.a1b.swing === r.a1.swing && r.a1b.swingT === r.a1.swingT && r.a1b.cd === r.a1.cd, [r.a1, r.a1b]);
  ok('A1 re-tap right after the strike keeps action/swing/cooldown', r.a2b.act === r.a2.act && r.a2b.swing === r.a2.swing && r.a2b.cd === r.a2.cd && r.a2.struck, [r.a2, r.a2b]);
  ok('A1 re-tap between swings keeps the cooldown', r.a3b.act === r.a3.act && r.a3b.cd === r.a3.cd && r.a3.cd > 0, [r.a3, r.a3b]);
  ok('A1 tree is cut', r.kind === 'stump');

  // A2 walking to a tree, path intact: re-tap keeps the same action and the same path array
  r = await G(() => {
    const L = window.__L, { s } = L;
    s.tools = ['dagger', 'axe', 'pickaxe'];
    const tree = L.obj(41, 42);
    L.tp(37, 39);
    s.pressNode(tree);
    L.step(3);
    const b0 = L.snap();
    s.pressNode(tree);
    const b1 = L.snap();
    L.until(() => !L.p.moving);
    const b2 = L.snap();
    L.until(() => tree.kind === 'stump', 4000);
    return { b0, b1, b2, kind: tree.kind };
  });
  ok('A2 walking: re-tap keeps action and path', r.b1.act === r.b0.act && r.b1.pathId === r.b0.pathId && r.b1.path === r.b0.path, [r.b0, r.b1]);
  ok('A2 arrives and chops', r.b2.act === r.b0.act && r.kind === 'stump', r.b2);

  // A3 path cut by a fence so it ends short: re-tap re-plans around the fence
  r = await G(() => {
    const L = window.__L, { s, p } = L;
    L.clear();
    const tree = L.obj(44, 34);               // tree at 44,34
    L.tp(40, 39);
    s.pressNode(tree);
    L.step(2);
    const c0 = L.snap();
    // a fence on a path tile ahead that is not reserved
    let placed = null;
    for (let k = 2; k < p.path.length; k++) { const t = p.path[k]; if (L.fence(t.col, t.row)) { placed = L.K(t); break; } }
    const c1 = L.snap();
    const endNext = L.nextTo(tree.tiles, L.end());
    s.pressNode(tree);
    const c2 = L.snap();
    const legal = L.pathLegal();
    const endNext2 = L.nextTo(tree.tiles, L.end());
    L.until(() => !p.moving);
    const hp0 = L.hp(tree);
    L.step(20);
    return { c0, placed, c1, endNext, c2, legal, endNext2, hp0, hp1: L.hp(tree), c3: L.snap() };
  });
  ok('A3 fence placed on the path ahead, path cut short', r.placed && !r.endNext, r);
  ok('A3 re-tap re-plans (new action, path ends next to the tree, legal)', r.c2.act !== r.c1.act && r.endNext2 && r.legal, [r.c1, r.c2]);
  ok('A3 then chops', r.hp1 < r.hp0, { hp0: r.hp0, hp1: r.hp1, st: r.c3 });

  // A5 mid-step and backing out: walking to tree X, press tree Y behind -> backing out with action Y; re-tap Y keeps it
  r = await G(() => {
    const L = window.__L, { s, p } = L;
    L.clear();
    const X = L.obj(44, 34), Y = L.obj(32, 40);
    L.tp(37, 39);
    const tx = m => m;
    // X is a stump now (A3 may have cut it partly) - use any node; prefer trees
    const tX = L.obj(41, 42);                  // stump from A2 (dug with pickaxe as a node)
    s.pressNode(X);
    L.step(2);
    const d0 = L.snap();
    s.pressNode(Y);
    const d1 = L.snap();
    const backing = p.path.length && L.K(p.path[0]) === L.K(p.tile);
    s.pressNode(Y);
    const d2 = L.snap();
    L.until(() => !p.moving);
    const d3 = L.snap();
    return { d0, d1, backing, d2, d3, nextY: L.nextTo(Y.tiles, p.tile) };
  });
  ok('A5 switching to the tree behind walks back first (backing out)', r.backing, r.d1);
  ok('A5 re-tap while backing out keeps action and path', r.d2.act === r.d1.act && r.d2.pathId === r.d1.pathId, [r.d1, r.d2]);
  ok('A5 arrives next to Y with the action', r.nextY && r.d3.act === r.d1.act, r.d3);

  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
