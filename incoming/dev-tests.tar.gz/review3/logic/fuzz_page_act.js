// Page-side fuzz harness for player movement + building mid-walk.
// Installed as window.__fz. Drives GameScene by stepping its Systems manually (game loop asleep),
// so the same update()/postupdate code runs, just without rendering.
(() => {
  const g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player, b = s.build;
  const K = (t) => t.col + ',' + t.row;
  const W = (c, r) => m.isWalkable(c, r);
  const cheb = (a, z) => Math.max(Math.abs(a.col - z.col), Math.abs(a.row - z.row));

  const fz = {
    seed: 0, rnd: null, frame: 0, time: 0, log: [], fails: [], stats: {}, prevTile: null, prevPath: null,
    lastSeg: null,
  };
  window.__fz = fz;
  const stat = (k, n = 1) => { fz.stats[k] = (fz.stats[k] || 0) + n; };

  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  const ri = (n) => Math.floor(fz.rnd() * n);
  const pick = (arr) => arr[ri(arr.length)];

  const snap = () => ({ pos: [p.col, p.row], tile: K(p.tile), path: p.path.map(K).join(' '), occ: p.occupiedTiles().map(K).join(' '),
                        resting: s.rest.resting, action: p.action ? (p.action.target.type || p.action.target.kind) + '@' + p.action.target.col + ',' + p.action.target.row : null });
  const L = (what) => { fz.log.push({ f: fz.frame, what, st: snap() }); if (fz.log.length > 60) fz.log.shift(); };
  const perKind = {};
  const fail = (kind, info) => {
    perKind[kind] = (perKind[kind] || 0) + 1;
    if (perKind[kind] <= 3) fz.fails.push({ kind, info, frame: fz.frame, seed: fz.seed, st: snap(), recent: fz.log.slice(-25) });
    stat('FAIL:' + kind);
  };

  // The tile at the other end of the segment the body is on (null when standing on a tile centre)
  const segOther = () => {
    let dc = p.col - p.tile.col, dr = p.row - p.tile.row;
    if (Math.abs(dc) < 1e-9) dc = 0;
    if (Math.abs(dr) < 1e-9) dr = 0;
    if (dc === 0 && dr === 0) return null;
    return { col: p.tile.col + Math.sign(dc), row: p.tile.row + Math.sign(dr) };
  };

  // Invariants
  function check(where) {
    const t = p.tile;
    // tile must be a whole tile
    if (!Number.isInteger(t.col) || !Number.isInteger(t.row)) fail('tile-not-integer', { where });
    // I0 standing/just-left tile walkable
    if (!W(t.col, t.row)) fail('tile-blocked', { where });
    // I1 body tiles (floor..ceil of position) walkable
    const body = [];
    for (let c = Math.floor(p.col); c <= Math.ceil(p.col); c++) for (let r = Math.floor(p.row); r <= Math.ceil(p.row); r++) {
      body.push({ col: c, row: r });
      if (!W(c, r)) fail('body-on-blocked', { where, blocked: [c, r] });
    }
    if (p.path.length && p.col === p.path[0].col && p.row === p.path[0].row && K(p.tile) !== K(p.path[0]))
      fail('exact-landing-no-arrival:' + (p.tile.col !== p.path[0].col && p.tile.row !== p.path[0].row ? 'diag' : 'orth'), { where });
    // I3 empty path -> exactly on this.tile
    if (!p.path.length && (p.col !== t.col || p.row !== t.row)) fail('stranded-fractional', { where });
    // I4 position on a segment between this.tile and an adjacent tile, never outside it
    const dc = p.col - t.col, dr = p.row - t.row;
    if (Math.abs(dc) >= 1 || Math.abs(dr) >= 1) {
      const q = p.path[0];
      if (q && (p.col === q.col || p.row === q.row) && Math.abs(dc) <= 1 && Math.abs(dr) <= 1) stat('note:pos-off-box-landing');
      else fail('pos-off-tile-box:other', { where, dc, dr });
    }
    if (dc !== 0 && dr !== 0 && Math.abs(Math.abs(dc) - Math.abs(dr)) > 1e-9) fail('pos-off-diagonal', { where, dc, dr });
    const N = segOther();
    if (N) {
      // the step in progress must stay legal (forward or backing out)
      if (!p.canStep(t, N)) fail('current-step-illegal', { where, from: K(t), to: K(N) });
      // forward: path[0] must be N; backing out: path[0] must be this.tile
      if (!p.path.length) fail('mid-step-no-path', { where });
      else if (K(p.path[0]) !== K(N) && K(p.path[0]) !== K(t)) fail('path0-not-on-segment', { where, N: K(N) });
      if (p.path.length && K(p.path[0]) === K(t)) stat('state:backing-out');
      else if (p.path.length) stat(dc && dr ? 'state:mid-diagonal' : 'state:mid-orthogonal');
    } else if (p.path.length) {
      stat(K(p.path[0]) === K(t) ? 'state:start-of-walk' : 'state:on-tile-with-path');
    } else stat('state:standing');
    // I2 every remaining step legal
    let from = t;
    for (let k = 0; k < p.path.length; k++) {
      const q = p.path[k];
      const d = cheb(from, q);
      if (k === 0 && d === 0) { from = q; continue; }
      if (d !== 1) { fail('path-non-adjacent', { where, k, from: K(from), to: K(q) }); break; }
      if (!p.canStep(from, q)) { fail('path-step-illegal', { where, k, from: K(from), to: K(q) }); break; }
      from = q;
    }
    // I5 reservation: covers the body, the segment, nothing far away
    const occ = p.occupiedTiles();
    const occK = new Set(occ.map(K));
    for (const x of body) if (!occK.has(K(x))) fail('under-reserved-body', { where, tile: K(x) });
    if (N) {
      // both ends and (diagonal) both side tiles of the step in progress
      for (const x of [t, N, { col: N.col, row: t.row }, { col: t.col, row: N.row }]) if (!occK.has(K(x))) fail('under-reserved-step', { where, tile: K(x) });
    }
    // allowed: bbox of this.tile, the segment end, and path[0]
    const pts = [t, ...(N ? [N] : []), ...(p.path.length ? [p.path[0]] : [])];
    const c0 = Math.min(...pts.map((x) => x.col)), c1 = Math.max(...pts.map((x) => x.col));
    const r0 = Math.min(...pts.map((x) => x.row)), r1 = Math.max(...pts.map((x) => x.row));
    const sliver = Math.abs(p.col - Math.round(p.col)) < 1e-12 && Math.abs(p.row - Math.round(p.row)) < 1e-12;
    for (const x of occ) if (x.col < c0 || x.col > c1 || x.row < r0 || x.row > r1) { if (sliver) stat('note:over-reserved-sliver'); else fail('over-reserved-outside-step:not-sliver', { where, tile: K(x) }); }
    if (occ.length > 4) fail('occupied>4', { where, n: occ.length });
    // over-reservation vs the body (expected only when standing on a tile centre at the start of a diagonal step)
    const extra = occ.filter((x) => !body.some((y) => K(y) === K(x)));
    if (extra.length) stat('note:occ-beyond-body:' + (N ? 'mid-step' : (p.path.length && K(p.path[0]) !== K(t) ? 'on-tile-next-step' : 'other')));
    for (const x of occ) if (!W(x.col, x.row)) fail('occupied-blocked', { where, tile: K(x) });
  }
  fz.check = check;
  s.events.on('postupdate', () => { if (s.rest.resting) stat('state:resting'); if (p.action) stat(p.moving ? 'state:walking-to-act' : 'state:acting'); });

  // ── act() invariants ──
  const exists = (o) => m.objects.includes(o) || m.structures.includes(o);
  const nextTo = (tiles, at) => tiles.some((t) => cheb(t, at) <= 1);
  const onT = (tiles, at) => tiles.some((t) => t.col === at.col && t.row === at.row);
  const reachableNeighbour = (target) => {
    for (const n of p.neighborsOf(target.tiles)) {
      if (n.col === p.tile.col && n.row === p.tile.row) return true;
      if (window.__findPath(m.cols, m.rows, p.tile, n, p.costAt)) return true;
    }
    return false;
  };
  const origAct = p.act.bind(p);
  p.act = function (action) {
    const before = { action: p.action, path: p.path, pathK: p.path.map(K).join(' '), swing: p.swing, cd: p.cooldown, moving: p.moving, tile: { ...p.tile } };
    const sameValid = before.action && before.action.target === action.target && before.action.isValid();
    const endBefore = p.path[p.path.length - 1] || p.tile;
    fz.lastTarget = action.target;
    const ret = origAct(action);
    const kept = ret && p.action === before.action && before.action;
    const tgt = action.target;
    const end = p.path[p.path.length - 1] || p.tile;
    if (kept) {
      stat('act:kept' + (before.moving ? ':moving' : ':standing'));
      if (p.path !== before.path || p.swing !== before.swing || p.cooldown !== before.cd) fail('act-kept-changed-state', {});
      if (!nextTo(tgt.tiles, end)) fail('act-kept-end-not-next', {});
    } else if (ret) {
      stat('act:new' + (sameValid ? ':same-target-replanned' : before.action && before.action.target === tgt ? ':same-target-ended' : ''));
      if (p.action !== action) fail('act-true-but-not-set', {});
      if (p.swing) fail('act-new-kept-swing', {});
      if (p.cooldown !== before.cd) fail('act-new-changed-cooldown', {});
      const inPlace = !p.moving && onT(tgt.tiles, p.tile);
      if (!nextTo(tgt.tiles, end)) fail('act-new-end-not-next', { end: K(end) });
      if (inPlace && action.stepOff) {
        stat('act:in-place-on-target');
        if (reachableNeighbour(tgt)) fail('act-in-place-although-step-off-possible', {});
      }
      if (sameValid && nextTo(tgt.tiles, endBefore)) fail('act-replanned-although-end-was-next', {});
    } else {
      stat('act:false' + (sameValid ? ':same-target' : ''));
      if (p.action !== before.action || p.path !== before.path || p.path.map(K).join(' ') !== before.pathK) fail('act-false-changed-state', {});
      if (reachableNeighbour(tgt)) fail('act-false-but-route-exists', {});
      if (!p.moving && nextTo(tgt.tiles, p.tile) && !(action.stepOff && onT(tgt.tiles, p.tile))) fail('act-false-but-here', {});
    }
    return ret;
  };
  s.events.on('preupdate', () => { fz.preAction = p.action; fz.preValid = !!(p.action && p.action.isValid()); });
  s.events.on('postupdate', () => {
    const a = p.action;
    if (a && !p.moving) {
      const fresh = fz.preAction === a && fz.preValid;   // valid when the frame began: made invalid by this frame's strike
      if (!a.isValid()) { if (fresh) stat('note:invalidated-by-this-frame'); else fail('acting-on-invalid', {}); }
      if (!exists(a.target)) { if (fresh) stat('note:gone-this-frame'); else fail('acting-on-gone', {}); }
      if (!nextTo(a.target.tiles, p.tile)) fail('acting-not-next', {});
      if (a.arrive) fail('arrive-not-fired', {});
    }
    if (a && p.moving && !a.isValid()) stat('note:walking-with-invalid-action');
  });

  s.events.on('rest-changed', () => stat(s.rest.resting ? 'rest:enter' : 'rest:exit'));
  // per-frame: what was walked during the frame
  s.events.on('preupdate', () => { fz.prevTile = { ...p.tile }; fz.prevPath = p.path.map((x) => ({ ...x })); fz.prevPos = [p.col, p.row]; });
  s.events.on('postupdate', () => {
    // tiles passed this frame must be a prefix of the old path, each step legal now (map cannot change during update)
    if (K(p.tile) !== K(fz.prevTile)) {
      const seq = [fz.prevTile, ...fz.prevPath];
      const i = seq.findIndex((x, k) => k > 0 && K(x) === K(p.tile));
      if (i < 0) fail('tile-not-from-path', { prev: K(fz.prevTile), now: K(p.tile) });
      else {
        for (let k = 1; k <= i; k++) {
          if (K(seq[k]) === K(seq[k - 1])) continue;
          if (cheb(seq[k - 1], seq[k]) !== 1) fail('walked-non-adjacent', { from: K(seq[k - 1]), to: K(seq[k]) });
          else if (!p.canStep(seq[k - 1], seq[k])) fail('walked-illegal-step', { from: K(seq[k - 1]), to: K(seq[k]) });
          stat('walked-steps');
        }
      }
    }
    check('postupdate');
    const q = p.path[0];
    const landing = q && p.col === q.col && p.row === q.row && K(p.tile) !== K(q);
    const sl = (p.col !== Math.round(p.col) || p.row !== Math.round(p.row)) && Math.abs(p.col - Math.round(p.col)) < 1e-12 && Math.abs(p.row - Math.round(p.row)) < 1e-12;
    if (landing && fz.prevLanding) fail('exact-landing-two-frames', {});
    if (sl && fz.prevSliver) fail('sliver-two-frames', {});
    fz.prevLanding = landing; fz.prevSliver = sl;
  });

  // wrap place() so every build is checked right after onMapChanged
  const origPlace = b.place.bind(b);
  b.place = function (type, tiles) {
    const before = snap();
    const N = segOther();
    const r = origPlace(type, tiles);
    const cut = before.path !== p.path.map(K).join(' ');
    L(`place ${type} ${tiles.map(K).join('+')}${cut ? ' CUT ' + before.path + ' -> ' + p.path.map(K).join(' ') : ''}`);
    if (N) stat('build-mid-step:' + ((N.col !== p.tile.col && N.row !== p.tile.row) ? 'diag' : 'orth'));
    if (cut) stat('path-cut');
    check('after-place');
    return r;
  };

  // candidate tiles to build on: around the step in progress and along the path, plus random nearby
  function hotTiles() {
    const t = p.tile, out = [];
    const N = segOther();
    if (N) out.push(N, { col: N.col, row: t.row }, { col: t.col, row: N.row });
    let from = t;
    for (let k = 0; k < Math.min(4, p.path.length); k++) {
      const q = p.path[k];
      out.push(q, { col: q.col, row: from.row }, { col: from.col, row: q.row });
      from = q;
    }
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) out.push({ col: t.col + dc, row: t.row + dr });
    out.push({ col: Math.round(p.col), row: Math.round(p.row) });
    return out;
  }
  const near = (rad) => ({ col: p.tile.col + ri(2 * rad + 1) - rad, row: p.tile.row + ri(2 * rad + 1) - rad });

  function tryBuild(type) {
    if (type === 'tent') {
      if (b.atMax('tent')) return false;
      for (let k = 0; k < 6; k++) {
        const base = fz.rnd() < 0.6 ? pick(hotTiles()) : near(3);
        const c = base.col - ri(2), r = base.row - ri(2);
        const tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }];
        if (tiles.every((x) => b.canBuildAt(x.col, x.row))) { b.place('tent', tiles); return true; }
      }
      return false;
    }
    for (let k = 0; k < 6; k++) {
      const x = fz.rnd() < 0.75 ? pick(hotTiles()) : near(3);
      if (b.canBuildAt(x.col, x.row)) { b.place(type, [x]); return true; }
      stat('build-refused');
    }
    return false;
  }

  function randomWalkable(rad) {
    for (let k = 0; k < 20; k++) { const x = near(rad); if (W(x.col, x.row)) return x; }
    return null;
  }

  let failedWalks = 0;
  function act() {
    const r = fz.rnd();
    if (s.rest.resting) {
      if (r < 0.08) { s.rest.exit(); L('rest.exit'); check('after-exit'); }
      else if (r < 0.25) tryBuild(fz.rnd() < 0.9 ? 'fence' : 'campfire');
      else if (r < 0.27) { const t = s.rest.tent; L('destroy tent while resting'); b.destroy(t); check('after-destroy'); }
      return;
    }
    const moving = p.moving;
    const pw = moving ? 0.04 : 0.30;       // ground tap, random tile
    const pr = moving ? 0.04 : 0.0;        // tap the tile just left / being entered / the goal again
    const pb = moving ? 0.16 : 0.02;       // build
    let acc = 0;
    if (r < (acc += pw)) {
      const x = randomWalkable(6); if (!x) return;
      const ok = p.goTo(x.col, x.row); L(`goTo ${K(x)} ${ok}`); check('after-goto'); stat('goTo:' + ok);
      if (!ok) failedWalks++; else failedWalks = 0;
    } else if (r < (acc += pr)) {
      const opts = [p.tile, ...(p.path.length ? [p.path[0], p.path[p.path.length - 1]] : [])];
      const x = pick(opts); const ok = p.goTo(x.col, x.row); L(`goTo* ${K(x)} ${ok}`); check('after-goto'); stat('goToStar:' + ok);
    } else if (r < (acc += pb)) {
      const q = fz.rnd();
      tryBuild(q < 0.85 ? 'fence' : q < 0.97 ? 'campfire' : 'tent');
    } else if (r < (acc += 0.04)) {        // remove a nearby structure
      const list = m.structures.filter((x) => cheb(x.tiles[0], p.tile) <= 6);
      if (list.length) { const x = pick(list); L(`destroy ${x.type}@${x.col},${x.row}`); b.destroy(x); check('after-destroy'); }
    } else if (r < (acc += 0.02)) {        // press a node (tree, rock, stump, rubble)
      const list = m.objects.filter((o) => o.node && cheb(o, p.tile) <= 6);
      if (list.length) { const o = pick(list); L(`pressNode ${o.kind}@${o.col},${o.row}`); s.pressNode(o); check('after-act'); }
    } else if (r < (acc += 0.06)) {        // press the current target again (or the object it turned into)
      const a = p.action, o = a && a.target;
      if (o && m.objects.includes(o) && o.node) { L(`re-pressNode ${o.kind}@${o.col},${o.row}`); s.pressNode(o); check('after-act'); }
      else if (o && o.type === 'tent' && m.structures.includes(o)) { L('re-pressTent'); s.pressTent(o); check('after-act'); }
      else if (fz.lastTarget && m.objects.includes(fz.lastTarget) && fz.lastTarget.node) { L(`re-pressNode(last) ${fz.lastTarget.kind}`); s.pressNode(fz.lastTarget); check('after-act'); }
    } else if (r < (acc += 0.01)) {        // press the tent
      const t = m.structures.find((x) => x.type === 'tent');
      if (t) { L('pressTent'); s.pressTent(t); check('after-act'); }
    } else if (r < (acc += 0.002)) {
      if (fz.deltaMode === 'random') { s.debugToggleSpeed(); L('speed x' + s.debugSpeed); }
    }
    // keep the area from clogging up
    if (m.structures.length > 14 || failedWalks >= 3) {
      const list = failedWalks >= 3 ? m.structures.filter((x) => cheb(x.tiles[0], p.tile) <= 3) : [m.structures[0]];
      for (const x of list) { L(`destroy-old ${x.type}@${x.col},${x.row}`); b.destroy(x); check('after-destroy'); }
      failedWalks = 0;
    }
  }

  fz.deltaMode = 'random';
  fz.tryBuild = (type) => tryBuild(type);
  fz.randomWalkable = (rad) => randomWalkable(rad);
  fz.seedOnly = (seed) => { fz.seed = seed; fz.rnd = mulberry32(seed); s.tools = ['dagger', 'axe', 'pickaxe']; };
  fz.init = (seed, deltaMode, speed3) => {
    fz.seed = seed; fz.rnd = mulberry32(seed);
    if (deltaMode !== undefined) fz.deltaMode = deltaMode;
    if (speed3 && s.debugSpeed === 1) s.debugToggleSpeed();
    s.tools = ['dagger', 'axe', 'pickaxe'];
    if (!g.loop.sleeping) g.loop.sleep();
    fz.time = g.loop.time || 0;
  };

  // run n frames, each with a random delta; between frames do random things
  fz.run = (n) => {
    for (let i = 0; i < n; i++) {
      const k = 1 + (fz.rnd() < 0.3 ? ri(3) : 0);       // sometimes several actions between two frames
      for (let j = 0; j < k; j++) act();
      const delta = fz.deltaMode === 'random' ? (fz.rnd() < 0.1 ? 150 : 5 + fz.rnd() * 110) : fz.deltaMode;
      fz.time += delta;
      fz.frame++;
      s.sys.step(fz.time, delta);

    }
    return { frame: fz.frame, fails: fz.fails.length, structures: m.structures.length, st: snap() };
  };
})();
