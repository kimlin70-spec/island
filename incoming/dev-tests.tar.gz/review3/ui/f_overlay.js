// (f) fence mode next to the walking player: the overlay must be red only on the tiles the body is on (and other
// unbuildable tiles), green elsewhere; building on green tiles next to the walking body (incl. during diagonal steps)
// must never strand the player, put it on a structure, or let it pass between two fences.
// usage: node f_overlay.js <destCol> <destRow> <laps> [speed3]
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
const DEST = [+(process.argv[2] || 43), +(process.argv[3] || 33)];
const LAPS = +(process.argv[4] || 2);
const FAST = process.argv[5] === 'speed3';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await T.settle();
    await T.materials(); await T.materials();
    if (FAST) { await T.ui(...UI.test); await T.ui(...UI.testItem(3)); await T.ui(...UI.testItem(4)); }
    console.log('speed', await G(() => window.__game.scene.getScene('game').debugSpeed));
    await page.evaluate(async () => { const mod = await import('/src/systems/Pathfinder.js'); window.__findPath = mod.findPath; });
    // per-frame record of the overlay under the pointer vs the body
    await G(() => { const s = window.__game.scene.getScene('game'), b = s.build, m = s.map, p = s.player; window.__ov = [];
      s.events.on('postupdate', () => {
        if (!b.building || !s.hovering) return;
        const mk = b.marks[0]; if (!mk.visible) return;
        const t = { col: Math.round((mk.x / 40 + mk.y / 20) / 2), row: Math.round((mk.y / 20 - mk.x / 40) / 2) };
        const from = p.tile, to = p.path[0];
        // documented model: standing -> its tile; walking -> box of the tile just left and the tile being entered
        const box = []; const a = to || from;
        for (let c = Math.min(from.col, a.col); c <= Math.max(from.col, a.col); c++) for (let r = Math.min(from.row, a.row); r <= Math.max(from.row, a.row); r++) box.push(c + ',' + r);
        const inBody = box.includes(t.col + ',' + t.row);
        const other = !m.isOpen(t.col, t.row) || !!m.structureAt(t.col, t.row) || Math.hypot(t.col - p.col, t.row - p.row) > 7;
        const red = mk.texture.key === 'overlay_no';
        const nearCentre = Math.abs(p.col - Math.round(p.col)) < 1e-9 && Math.abs(p.row - Math.round(p.row)) < 1e-9;
        window.__ov.push({ f: window.__frames, t: t.col + ',' + t.row, red, inBody, other, pos: [p.col, p.row], from: from.col + ',' + from.row, to: to ? to.col + ',' + to.row : null, nearCentre, occ: p.occupiedTiles().map((q) => q.col + ',' + q.row).join(' ') });
      }); });
    let built = [];
    for (let lap = 0; lap < LAPS; lap++) {
      // a far tile with nothing drawn over its centre, whose path has many diagonal steps
      const dest = await G((lap) => { const s = window.__game.scene.getScene('game'), m = s.map, p = s.player; let best = null;
        for (let r = p.tile.row - 9; r <= p.tile.row + 9; r++) for (let c = p.tile.col - 9; c <= p.tile.col + 9; c++) {
          if (!m.isWalkable(c, r) || m.pickObject((c - r) * 40, (c + r) * 20)) continue;
          const sx = (c - r) * 40 - s.cameras.main.worldView.x, sy = (c + r) * 20 - s.cameras.main.worldView.y; if (sx < 100 || sy < 150 || sx > 1700 || sy > 700) continue;
          const path = window.__findPath(m.cols, m.rows, p.tile, { col: c, row: r }, p.costAt); if (!path || path.length < 7) continue;
          let diag = 0; for (let i = 1; i < path.length; i++) if (path[i].col !== path[i - 1].col && path[i].row !== path[i - 1].row) diag++;
          const score = diag * 2 + path.length + (lap % 2 ? Math.random() * 4 : 0); if (!best || score > best.score) best = { c, r, score, len: path.length, diag }; }
        return best; }, lap);
      console.log('lap', lap, 'dest', J(dest));
      await T.closeCraft();
      await T.settle();
      await T.tapTile(dest.c, dest.r, 0);
      await T.openCraft(); await T.card(2);
      // hover around the body while walking; now and then click a green tile next to the body
      let n = 0;
      while (n < 400) {
        const st = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, b = s.build;
          return { moving: p.moving, col: p.col, row: p.row, tile: [p.tile.col, p.tile.row], to: p.path[0] ? [p.path[0].col, p.path[0].row] : null, next: p.path[1] ? [p.path[1].col, p.path[1].row] : null }; });
        if (!st.moving) break;
        // candidate tiles: the box and its 8-neighbourhood
        const c0 = Math.min(st.tile[0], (st.to || st.tile)[0]) - 1, c1 = Math.max(st.tile[0], (st.to || st.tile)[0]) + 1;
        const r0 = Math.min(st.tile[1], (st.to || st.tile)[1]) - 1, r1 = Math.max(st.tile[1], (st.to || st.tile)[1]) + 1;
        const c = c0 + Math.floor(Math.random() * (c1 - c0 + 1)), r = r0 + Math.floor(Math.random() * (r1 - r0 + 1));
        const p = await T.w2p((c - r) * 40, (c + r) * 20);
        await page.mouse.move(p.x, p.y);
        n++;
        // every 7th hover: click if the overlay shows green there (a real build next to the walking body)
        if (n % 5 === 0) {
          const green = await G(() => { const b = window.__game.scene.getScene('game').build; return b.marks[0].visible && b.marks[0].texture.key === 'overlay_ok'; });
          if (green) { await page.mouse.down(); await page.mouse.up(); }
        }
        await page.waitForTimeout(20);
      }
      await T.stopped();
      built = await G(() => window.__rv.structs());
      console.log(`lap ${lap}: stopped at`, (await T.snap()).tile, '| fences', built.length);
    }
    await T.closeCraft();
    const ov = await G(() => window.__ov);
    const mism = ov.filter((o) => o.red !== (o.inBody || o.other));
    const real = mism.filter((o) => !o.nearCentre);
    console.log('overlay samples', ov.length, '| red on body tiles', ov.filter((o) => o.inBody && o.red).length, '| green next to body', ov.filter((o) => !o.inBody && !o.other && !o.red).length, '| mismatches', mism.length, '(not at a tile centre:', real.length + ')');
    for (const o of real.slice(0, 6)) console.log('   mismatch', J(o));
    ok('overlay red exactly on the body tiles (and unbuildable tiles), green elsewhere', real.length === 0);
    const bad = await T.bad();
    ok('per-frame invariants (never on a structure, never stranded, body box walkable)', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
    await page.screenshot({ path: __dirname + '/f_overlay.png' });
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
