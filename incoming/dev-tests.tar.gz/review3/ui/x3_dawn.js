const { setup, UI } = require('./common.js');
const { lum } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.settle();
  const day = await lum(page, 300, 900, 30);
  await T.ui(...UI.test); await T.ui(...UI.testItem(1), 1500); await T.ui(...UI.testItem(2), 100);
  for (let k = 0; k < 8; k++) {
    const r = await G(() => { const c = window.__game.scene.getScene('game').clock; return { dawn: +c.dawn.toFixed(2), night: c.isNight, amb: c.ambient ? JSON.stringify(c.ambient()) : null }; });
    console.log('t', k, 'lum', await lum(page, 300, 900, 30), 'day lum', day, JSON.stringify(r));
    await page.waitForTimeout(1000);
  }
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})();
