// (b) trees, a palm/pine and rocks behind a fence wall and in front of one.
// Clicking visible parts of the object chops/mines it from a reachable side; clicking the fence drawn over it does nothing.
// usage: node b_trees.js <set>   set 1: tree A behind wall, tree B in front of wall, rock behind wall (near the start)
//                                 set 2: palm in front of wall, pine behind wall, rock in front of wall (walks first)
const { setup } = require('./common.js');
const J = JSON.stringify;
const SET = +(process.argv[2] || 1);
const TOUCH = process.argv[3] === 'touch';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };

const SETS = {
  1: [
    { name: 'tree a2 (37,35) behind wall', o: [37, 35], wall: [[35, 36], [36, 36], [37, 36], [38, 36], [39, 36], [38, 35]], stand: [37, 39] },
    { name: 'tree a1 (35,35) in front of wall', o: [35, 35], wall: [[33, 34], [34, 34], [35, 34], [36, 34]], stand: [37, 39] },
    { name: 'rock (33,37) behind wall', o: [33, 37], wall: [[32, 38], [33, 38], [34, 38]], stand: [37, 39] },
  ],
  2: [
    { name: 'palm (43,44) in front of wall', o: [43, 44], wall: [[42, 41], [42, 42], [42, 43], [42, 44]], stand: [39, 41] },
    { name: 'pine (28,42) behind wall', o: [28, 42], wall: [[27, 43], [28, 43], [29, 43], [30, 43], [29, 42]], stand: [32, 42] },
    { name: 'rock_l (25,40) behind one fence, in front of another', o: [25, 40], wall: [[26, 40], [27, 40], [24, 40]], stand: [28, 41] },
    { name: 'rock (38,47) in front of wall', o: [38, 47], wall: [[36, 46], [37, 46], [38, 46], [39, 46]], stand: [38, 43] },
  ],
};

(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G } = T;
  const walkTo = async (c, r) => { await T.settle(); await T.tapTile(c, r, 150); await T.stopped(); await T.settle(); };
  try {
    await T.settle();
    await T.materials(); await T.materials();
    await T.openCraft(); await T.card(1);       // pickaxe (needed for rocks); no axe, so trees take 9 dagger strikes
    await T.closeCraft();
    console.log('tools', J(await G(() => window.__game.scene.getScene('game').tools)));
    for (const tc of SETS[SET]) {
      console.log('\n==', tc.name);
      await walkTo(...tc.stand);
      await T.openCraft(); await T.card(2);
      for (const [c, r] of tc.wall) { await T.tapTile(c, r, 80); }
      await T.closeCraft();
      await T.settle();
      const built = await G((wall) => wall.filter(([c, r]) => { const s = window.__game.scene.getScene('game').map.structureAt(c, r); return s && s.type === 'fence'; }).length, tc.wall);
      ok(tc.name + ': wall built', built === tc.wall.length, built + '/' + tc.wall.length);
      // points: object visible (drawn on top), fence drawn over the object, object drawn over the fence
      const P = await G(([oc, orow]) => {
        const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, cam = s.cameras.main;
        const o = m.objectAt(oc, orow); R.freeze();
        const sp = o.sprite, rc = R.rect(sp), M = R.alphaMap(sp.texture.key, sp.frame.name);
        const vis = [], fenceOver = [], overFence = [];
        for (let j = 0; j < M.h; j++) for (let i = 0; i < M.w; i++) {
          const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
          if (Math.floor(wx - rc.left) !== i || Math.floor(wy - rc.top) !== j) continue;
          const a = M.a[j * M.w + i]; if (a <= 110) continue;
          const sx = wx - cam.worldView.x, sy = wy - cam.worldView.y; if (sx < 0 || sy < 0 || sx >= 1920 || sy >= 1200) continue;
          const top = R.topAt(wx, wy, 0);
          const fa = Math.max(0, ...R.fences().map((f) => R.alphaAt(f, wx, wy)));
          const q = { wx, wy, a, fa, top: R.key(top), pick: R.key(m.pickObject(wx, wy)) };
          if (top === o) { vis.push(q); if (fa > 30) overFence.push(q); }
          else if (top && top.type === 'fence' && fa > 30) fenceOver.push(q);
        }
        R.unfreeze();
        return { kind: o.kind, key: o.key, hp: o.node.hp, vis, fenceOver, overFence };
      }, tc.o);
      console.log(`   ${P.kind} ${P.key}: visible solid px ${P.vis.length}, of them over a fence ${P.overFence.length}; fence drawn over solid object px ${P.fenceOver.length}`);
      // direct check of every point (same function the press uses)
      const wrongVis = P.vis.filter((q) => q.pick !== tc.name && q.pick !== `${P.kind}@${tc.o[0]},${tc.o[1]}`);
      const wrongFence = P.fenceOver.filter((q) => !q.pick || !q.pick.startsWith('fence'));
      ok(tc.name + ': every visible object pixel picks the object (pickObject)', wrongVis.length === 0, wrongVis.length + ' wrong, e.g. ' + J(wrongVis.slice(0, 2)));
      ok(tc.name + ': every fence pixel drawn over the object picks the fence (pickObject)', wrongFence.length === 0, wrongFence.length + ' wrong, e.g. ' + J(wrongFence.slice(0, 2)));
      // real clicks on the fence drawn over the object: nothing happens
      const start = await T.snap();
      const fsample = P.fenceOver.filter((_, k) => k % Math.max(1, Math.floor(P.fenceOver.length / 10)) === 0).slice(0, 10);
      await G(() => { window.__presses.length = 0; });
      for (const q of fsample) await T.tapWorld(q.wx + (TOUCH ? 0.5 : 0), q.wy + (TOUCH ? 0.5 : 0), 40);
      await page.waitForTimeout(300);
      const fp = await G(() => window.__presses.splice(0));
      const st1 = await T.snap();
      ok(tc.name + ': clicks on the fence over it do nothing', fp.length === fsample.length && fp.every((p) => p.picked && p.picked.startsWith('fence') && !p.after.path && !p.after.cursor && !p.after.action) && st1.tile === start.tile && !st1.path,
        `${fp.length} presses, picked ${[...new Set(fp.map((p) => p.picked))].join(' ')}; state ${J(st1)}`);
      // click a visible part of the object: walks to a reachable side and starts working on it
      const vsample = P.vis.filter((_, k) => k % Math.max(1, Math.floor(P.vis.length / 12)) === 0);
      const first = (P.overFence.length ? P.overFence : P.vis)[Math.floor((P.overFence.length ? P.overFence : P.vis).length / 2)];
      await T.tapWorld(first.wx + (TOUCH ? 0.5 : 0), first.wy + (TOUCH ? 0.5 : 0), 200);
      const p1 = await T.lastPress();
      console.log('   first click', J({ picked: p1.picked, top: p1.top, path: p1.after.path, action: p1.after.action }));
      ok(tc.name + ': click on the visible object picks it', p1.picked === `${P.kind}@${tc.o[0]},${tc.o[1]}`, p1.picked);
      await T.W((o) => { const s = window.__game.scene.getScene('game'), x = s.map.objectAt(o[0], o[1]); return !s.player.moving && (!x || !x.node || x.node.hp < 9 || !s.player.action); }, tc.o, 60000);
      await T.W((o) => { const s = window.__game.scene.getScene('game'), x = s.map.objectAt(o[0], o[1]); return !x || !x.node || x.node.hp < 9 || !s.player.action; }, tc.o, 60000);
      const st2 = await T.snap();
      const hp = await G((o) => { const x = window.__game.scene.getScene('game').map.objectAt(o[0], o[1]); return x && x.node ? x.node.hp : null; }, tc.o);
      const [pc, pr] = st2.tile.split(',').map(Number);
      ok(tc.name + ': reached a side of it and struck it', Math.max(Math.abs(pc - tc.o[0]), Math.abs(pr - tc.o[1])) <= 1 && hp !== null && hp < 9, `at ${st2.tile}, hp ${hp}, action ${st2.action}`);
      // while working on it: clicks on visible parts keep it going (no restart), clicks on the fence change nothing
      const P2 = await G(([oc, orow]) => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, cam = s.cameras.main, o = m.objectAt(oc, orow);
        R.freeze(); const sp = o.sprite, rc = R.rect(sp), M = R.alphaMap(sp.texture.key, sp.frame.name), vis = [], fence = [];
        const inner = (wx, wy, k) => { for (let dy = -k; dy <= k; dy += 3) for (let dx = -k; dx <= k; dx += 3) if (R.alphaAt(o, wx + dx, wy + dy) <= 110 || R.topAt(wx + dx, wy + dy, 0) !== o) return false; return true; };
        for (let j = 0; j < M.h; j += 3) for (let i = 0; i < M.w; i += 3) { const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
          if (M.a[j * M.w + i] <= 110) continue; const top = R.topAt(wx, wy, 0);
          if (top === o) { if (inner(wx, wy, 9)) vis.push({ wx, wy }); } else if (top && top.type === 'fence' && Math.max(...R.fences().map((f) => R.alphaAt(f, wx, wy))) > 30) fence.push({ wx, wy }); }
        R.unfreeze(); return { vis, fence }; }, tc.o);
      const clicks = [...P2.vis.filter((_, k) => k % Math.max(1, Math.floor(P2.vis.length / 6)) === 0).slice(0, 6), ...P2.fence.slice(0, 3)];
      const before = await G(() => { const p = window.__game.scene.getScene('game').player; window.__swings = 0; window.__restarts = 0; return { action: p.action }; });
      await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; window.__act0 = p.action; window.__presses.length = 0; });
      let clicked = 0;
      for (const q of clicks) {
        const alive = await G(([o, kind]) => { const x = window.__game.scene.getScene('game').map.objectAt(o[0], o[1]); return !!x && x.kind === kind && !!x.node && x.node.hp > (kind === 'rock' ? 3 : 1); }, [tc.o, P.kind]);
        if (!alive) break;
        await T.tapWorld(q.wx + (TOUCH ? 0.5 : 0), q.wy + (TOUCH ? 0.5 : 0), 60); clicked++;
      }
      await page.waitForTimeout(200);
      const same = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; return { sameAction: p.action === window.__act0 || !p.action, moving: p.moving, presses: window.__presses.map((x) => x.picked + (x.newPath || x.newAction ? ' NEW ' + x.after.path : '')) }; });
      console.log('   re-clicked', clicked, 'of', clicks.length);
      ok(tc.name + ': re-clicks while working keep the same action, no walk', same.sameAction && !same.moving && same.presses.length === clicked && clicked > 0 && same.presses.every((x) => !x.includes('NEW')), J(same));
      // let it finish and go back
      await T.W((o) => { const s = window.__game.scene.getScene('game'), x = s.map.objectAt(o[0], o[1]); return !s.player.action || !x || x.kind === 'stump' || x.kind === 'rubble'; }, tc.o, 60000);
      const end = await G((o) => { const x = window.__game.scene.getScene('game').map.objectAt(o[0], o[1]); return x ? x.kind : null; }, tc.o);
      console.log('   object is now', end);
    }
    const bad = await T.bad();
    ok('per-frame invariants', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
    await page.screenshot({ path: __dirname + `/b_trees_${SET}${TOUCH ? '_touch' : ''}.png` });
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
