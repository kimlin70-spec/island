const { setup, UI } = require('./common.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.settle(); await T.materials(); await T.openCraft(); await T.card(2);
  const mk = () => G(() => { const s = window.__game.scene.getScene('game'), b = s.build, m = b.marks[0], ptr = s.input.activePointer;
    return { vis: m.visible, tex: m.texture.key, at: m.visible ? [Math.round((m.x / 40 + m.y / 20) / 2), Math.round((m.y / 20 - m.x / 40) / 2)] : null, hovering: s.hovering, ptr: [ptr.x, ptr.y, +ptr.worldX.toFixed(1), +ptr.worldY.toFixed(1)] }; });
  for (const [c, r] of [[35, 39], [36, 41]]) {
    await T.freeze();
    const p = await T.w2p((c - r) * 40, (c + r) * 20);
    await page.mouse.move(p.x, p.y);
    console.log('frozen, moved to', c, r, '->', JSON.stringify(await mk()));
    await T.thaw();
    await page.waitForTimeout(300);
    console.log('   after thaw ->', JSON.stringify(await mk()));
  }
  await T.browser.close();
})();
