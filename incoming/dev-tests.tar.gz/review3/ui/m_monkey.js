// random real-UI play: taps on trees/rocks/stumps/tent/fences/ground (aimed with the loop frozen), fence building next to the
// walking player, remove mode, speed x3. Per-frame invariants; at the end the player must still walk.
// usage: node m_monkey.js <seed> <steps> [touch]
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
const SEED = +(process.argv[2] || 1), STEPS = +(process.argv[3] || 120);
const TOUCH = process.argv[4] === 'touch';
let rs = SEED >>> 0;
const rnd = () => { rs = (rs * 1664525 + 1013904223) >>> 0; return rs / 4294967296; };
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G } = T;
  const log = [];
  try {
    await page.evaluate(async () => { const mod = await import('/src/systems/Pathfinder.js'); window.__findPath = mod.findPath; });
    await T.settle();
    await T.materials(); await T.materials(); await T.materials();
    await T.openCraft(); await T.card(0); await T.card(1); await T.closeCraft();
    // a random point on a random visible object of a kind (drawn on top, picks it)
    const objPoint = (kinds, r) => G(([kinds, r]) => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, cam = s.cameras.main;
      const vis = R.all().filter((o) => kinds.includes(o.type || o.kind) && o.pickable && o.sprite.x > cam.worldView.x + 60 && o.sprite.x < cam.worldView.x + 1860 && o.sprite.y > cam.worldView.y + 120 && o.sprite.y < cam.worldView.y + 720);
      if (!vis.length) return null;
      const o = vis[Math.floor(r[0] * vis.length)], sp = o.sprite, rc = R.rect(sp);
      for (let k = 0; k < 60; k++) { const i = Math.floor((r[1] * 7 + k * 0.6180339) % 1 * sp.width), j = Math.floor((r[2] * 5 + k * 0.4142) % 1 * sp.height);
        const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j); if (m.pickObject(wx, wy) === o && R.topAt(wx, wy, 0) === o) return { wx, wy, what: R.key(o) }; }
      return null; }, [kinds, r]);
    const groundPoint = (r) => G((r) => { const s = window.__game.scene.getScene('game'), m = s.map, p = s.player;
      for (let k = 0; k < 40; k++) { const c = p.tile.col - 8 + Math.floor(((r[0] + k * 0.37) % 1) * 17), rr = p.tile.row - 8 + Math.floor(((r[1] + k * 0.73) % 1) * 17);
        if (m.isWalkable(c, rr) && !m.pickObject((c - rr) * 40, (c + rr) * 20)) return { wx: (c - rr) * 40, wy: (c + rr) * 20, what: 'ground@' + c + ',' + rr }; }
      return null; }, r);
    const nearTile = (r) => G((r) => { const s = window.__game.scene.getScene('game'), p = s.player;
      const c = Math.round(p.col) - 2 + Math.floor(r[0] * 5), rr = Math.round(p.row) - 2 + Math.floor(r[1] * 5); return { wx: (c - rr) * 40, wy: (c + rr) * 20, what: 'tile@' + c + ',' + rr }; }, r);
    const R3 = () => [rnd(), rnd(), rnd()];
    for (let step = 0; step < STEPS; step++) {
      const a = rnd();
      let what = null;
      if (a < 0.30) what = await T.frozenTapWorld(() => objPoint(['tree', 'pine', 'palm', 'rock', 'stump', 'rubble'], R3()));
      else if (a < 0.40) what = await T.frozenTapWorld(() => objPoint(['tent'], R3()));
      else if (a < 0.52) what = await T.frozenTapWorld(() => objPoint(['fence', 'campfire'], R3()));
      else if (a < 0.72) what = await T.frozenTapWorld(() => groundPoint(R3()));
      else if (a < 0.86) {             // fence (or campfire/tent) next to the player, 1-3 taps, then close
        const card = rnd() < 0.8 ? 2 : (rnd() < 0.5 ? 3 : 4);
        await T.ui(...UI.craft, 50); await T.ui(...UI.card(card), 50);
        const n = 1 + Math.floor(rnd() * 3); const got = [];
        for (let k = 0; k < n; k++) { const q = await T.frozenTapWorld(() => nearTile(R3())); got.push(q && q.what); await page.waitForTimeout(Math.floor(rnd() * 200)); }
        await T.closeCraft();
        what = { what: 'build' + card + ' ' + got.join(' ') };
      } else if (a < 0.93) {
        await T.ui(...UI.craft, 50); await T.ui(...UI.card(5), 50);
        const q = await T.frozenTapWorld(() => objPoint(['fence', 'campfire', 'tent'], R3()));
        await T.closeCraft();
        what = { what: 'remove ' + (q && q.what) };
      } else if (a < 0.96) { await T.ui(...UI.test, 50); await T.ui(...UI.testItem(3), 50); await T.ui(...UI.testItem(4), 50); what = { what: 'speed' }; }
      else { if (await G(() => window.__game.scene.getScene('game').rest.resting)) await T.ui(...UI.rest, 50); what = { what: 'rest-button' }; }
      log.push(step + ' ' + (what ? what.what : '-'));
      await page.waitForTimeout(Math.floor(rnd() * 700));
      const bad = await T.bad();
      if (bad.length) { console.log('INVARIANT at step', step, J(bad.slice(0, 3)), '\n   last steps', log.slice(-6).join(' | ')); break; }
    }
    // end: let it finish, leave the tent, then it must still walk to a reachable tile
    if (await G(() => window.__game.scene.getScene('game').rest.resting)) await T.ui(...UI.rest, 200);
    await T.closeCraft();
    await T.stopped(120000);
    await T.settle();
    const target = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, p = s.player, cam = s.cameras.main;
      for (let d = 2; d < 8; d++) for (const [dc, dr] of [[d, 0], [-d, 0], [0, d], [0, -d], [d, d], [-d, -d]]) { const c = p.tile.col + dc, r = p.tile.row + dr;
        if (!m.isWalkable(c, r) || m.pickObject((c - r) * 40, (c + r) * 20)) continue; if (window.__findPath(m.cols, m.rows, p.tile, { col: c, row: r }, p.costAt)) return [c, r]; }
      return null; });
    console.log('end target', J(target), 'state', J(await T.snap()));
    if (target) {
      await T.tapTile(target[0], target[1], 200);
      console.log('after end tap', J(await T.lastPress().then((p) => p && { picked: p.picked, tile: p.tile, path: p.after.path })));
      try { await T.stopped(30000); } catch (e) {
        console.log('NOT STOPPING', J(await G(() => { const g = window.__game, s = g.scene.getScene('game'), p = s.player;
          return { col: p.col, row: p.row, tile: p.tile, path: p.path, speed: s.speed, running: g.loop.running, frames: window.__frames, fps: g.loop.actualFps, delta: g.loop.delta, resting: s.rest.resting }; })));
        await page.waitForTimeout(2000);
        console.log('   2 s later', J(await G(() => { const g = window.__game, s = g.scene.getScene('game'), p = s.player; return { col: p.col, row: p.row, path: p.path.length, frames: window.__frames, running: g.loop.running }; })));
        throw e;
      }
    }
    const st = await T.snap();
    ok('still walks at the end', !target || st.tile === target.join(','), J(target) + ' -> ' + st.tile);
    const bad = await T.bad();
    ok('per-frame invariants', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
    console.log('structures', (await G(() => window.__rv.structs())).length, '| steps', log.length);
  } catch (e) { console.error('CRASH', e, '\n   last steps', log.slice(-6).join(' | ')); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
