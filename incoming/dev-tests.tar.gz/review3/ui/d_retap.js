// (d) walk toward a far tree, build a fence on the path ahead (path cut), click the same tree again while still walking:
// the player must go around and chop it. Re-clicking while chopping keeps chopping (no restart). When it becomes a stump,
// click the stump right away with the pickaxe: it is dug out.
// usage: node d_retap.js <treeCol> <treeRow> [touch]
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
const TREE = [+(process.argv[2] || 42), +(process.argv[3] || 30)];
const TOUCH = process.argv[4] === 'touch';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G, W } = T;
  const off = TOUCH ? 0.5 : 0;
  // a point on the tree picture that picks it and is drawn on top, nearest to its middle
  const treePoint = () => G(([c, r]) => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, o = m.objectAt(c, r);
    const sp = o.sprite, rc = R.rect(sp);
    for (const rad of [24, 18, 12, 6, 0]) { let best = null;
      for (let j = 4; j < sp.height - 4; j += 3) for (let i = 4; i < sp.width - 4; i += 3) { const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
        if (m.pickObject(wx, wy) !== o || R.topAt(wx, wy, 0) !== o) continue;
        let inner = true; for (let dy = -rad; dy <= rad && inner; dy += 6) for (let dx = -rad; dx <= rad && inner; dx += 6) if (m.pickObject(wx + dx, wy + dy) !== o) inner = false;
        if (!inner) continue;
        const d = Math.hypot(wx - sp.x, wy - (rc.top + sp.height * 0.45)); if (!best || d < best.d) best = { wx, wy, d, rad }; }
      if (best) return best; }
    return null; }, TREE);
  const clickTree = async () => T.frozenTapWorld(treePoint);
  try {
    await T.settle();
    // swing log: every swing start, strike and cancel
    await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; window.__sw = []; let last = null;
      s.events.on('postupdate', () => { const w = p.swing;
        if (w && w !== last) window.__sw.push({ f: window.__frames, ev: 'start', tool: w.tool });
        if (last && !last.struck && w !== last) window.__sw.push({ f: window.__frames, ev: 'CANCEL' });
        if (w && w.struck && !w.__logged) { w.__logged = true; window.__sw.push({ f: window.__frames, ev: 'strike' }); }
        last = w; }); });
    await T.materials();
    await T.openCraft(); await T.card(1);                 // pickaxe (dagger stays the tree tool)
    await T.closeCraft();
    const info = await G(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return o ? { kind: o.kind, key: o.key } : null; }, TREE);
    console.log('tree', J(TREE), J(info));
    // 1st click on the tree
    await clickTree();
    await page.waitForTimeout(100);
    const s1 = await T.snap();
    console.log('after 1st click', J(s1));
    ok('1st click starts a walk to the tree', !!s1.path && s1.action === `${info.kind}@${TREE[0]},${TREE[1]}`);
    // build a fence on the path a few steps ahead
    await T.ui(...UI.craft, 120); await T.ui(...UI.card(2), 120);
    let fence = null;
    for (let tries = 0; tries < 6 && !fence; tries++) {
      const tgt = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, b = s.build;
        for (let k = Math.min(p.path.length - 2, 5); k >= 3; k--) { const t = p.path[k]; if (b.canBuildAt(t.col, t.row)) return { col: t.col, row: t.row, k }; } return null; });
      if (!tgt) break;
      await T.frozenTapWorld(async () => ({ wx: (tgt.col - tgt.row) * 40, wy: (tgt.col + tgt.row) * 20 }));
      await page.waitForTimeout(60);
      fence = await G(() => { const s = window.__game.scene.getScene('game'); const f = s.map.structures.find((x) => x.type === 'fence'); return f ? f.col + ',' + f.row : null; });
    }
    await T.ui(...UI.craft, 60);
    const s2 = await T.snap();
    const adj = (k) => { if (!k) return false; const [c, r] = k.split(',').map(Number); return Math.max(Math.abs(c - TREE[0]), Math.abs(r - TREE[1])) <= 1; };
    const endOf = (st) => st.path ? st.path.split(' ').pop() : st.tile;
    console.log('fence at', fence, '-> state', J(s2));
    ok('fence built on the path; the walk now ends before the tree', !!fence && !adj(endOf(s2)), 'end ' + endOf(s2));
    ok('still walking when the tree is clicked again', !!s2.path, J(s2));
    // 2nd click on the same tree while still walking
    await clickTree();
    await page.waitForTimeout(80);
    const s3 = await T.snap();
    const p3 = await T.lastPress();
    console.log('after 2nd click', J(s3), 'picked', p3 && p3.picked);
    ok('2nd click on the same tree re-plans a walk that ends next to it', adj(endOf(s3)), 'end ' + endOf(s3));
    // arrive and chop
    await W(() => { const p = window.__game.scene.getScene('game').player; return !p.moving; }, null, 60000);
    await W(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return o.node && o.node.hp < 9 || !window.__game.scene.getScene('game').player.action; }, TREE, 60000);
    const s4 = await T.snap();
    const hp4 = await G(([c, r]) => window.__game.scene.getScene('game').map.objectAt(c, r).node.hp, TREE);
    ok('arrived next to the tree and chopping', adj(s4.tile) && s4.action && hp4 < 9, J(s4) + ' hp ' + hp4);
    // re-click while chopping
    const sw0 = await G(() => window.__sw.length);
    const act0 = await G(() => { window.__act0 = window.__game.scene.getScene('game').player.action; return true; });
    let reclicks = 0;
    for (let k = 0; k < 6; k++) {
      const hp = await G(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return o.kind !== 'stump' && o.node ? o.node.hp : 0; }, TREE);
      if (hp <= 2) break;
      await clickTree(); reclicks++;
      await page.waitForTimeout(100);
    }
    const same = await G(() => window.__game.scene.getScene('game').player.action === window.__act0);
    const swLog = await G((n) => window.__sw.slice(n), sw0);
    ok('re-clicks while chopping keep the same action', reclicks > 0 && same, `reclicks ${reclicks}`);
    ok('no swing was cancelled by the re-clicks', !swLog.some((e) => e.ev === 'CANCEL'), J(swLog));
    // when it becomes a stump, click the stump right away
    await W(([c, r]) => window.__game.scene.getScene('game').map.objectAt(c, r).kind === 'stump', TREE, 60000);
    const stumpPt = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, o = m.objectAt(c, r), sp = o.sprite, rc = R.rect(sp);
      for (let j = Math.floor(sp.height * 0.3); j < sp.height; j++) for (let i = Math.floor(sp.width * 0.3); i < sp.width; i++) { const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
        if (m.pickObject(wx, wy) === o && R.topAt(wx, wy, 0) === o) return { wx, wy, frames: window.__frames, old: s.player.action ? { valid: s.player.action.isValid() } : null }; }
      return null; }, TREE);
    await T.tapWorld(stumpPt.wx + off, stumpPt.wy + off, 0);
    const pr = await T.lastPress();
    const fr = await G(() => window.__frames);
    console.log('stump clicked', fr - stumpPt.frames, 'frames after it appeared; old action then', J(stumpPt.old), '| press', J({ picked: pr.picked, action: pr.after.action, path: pr.after.path }));
    ok('the stump click starts digging', pr.picked === `stump@${TREE[0]},${TREE[1]}` && pr.after.action === `stump@${TREE[0]},${TREE[1]}`, J(pr.after));
    await W(([c, r]) => { const s = window.__game.scene.getScene('game'), o = s.map.objectAt(c, r); return !o || !s.player.action; }, TREE, 60000);
    const gone = await G(([c, r]) => !window.__game.scene.getScene('game').map.objectAt(c, r), TREE);
    ok('the stump is dug out', gone);
    const bad = await T.bad();
    ok('per-frame invariants', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
