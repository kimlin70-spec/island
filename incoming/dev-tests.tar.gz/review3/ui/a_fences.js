// (a) build all 16 fence pictures with real clicks, then click all over the fence pictures (rail edges, rails, posts):
// the player must never move and no move cursor may appear. Clicking clearly beside a fence must still walk.
// usage: node a_fences.js [touch]
const { setup } = require('./common.js');
const J = JSON.stringify;
const TOUCH = process.argv[2] === 'touch';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };

const ring = (c0, r0, c1, r1) => { const out = []; for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) if (r === r0 || r === r1 || c === c0 || c === c1) out.push([c, r]); return out; };
const LAYOUTS = {
  pen: [...ring(38, 35, 41, 38), ...ring(33, 41, 36, 44)],          // two 4x4 pens with 2x2 insides, player outside
  inside: ring(35, 37, 39, 41),                                      // 5x5 pen around the player (inside 3x3)
};
const LAYOUT_NAME = process.argv.find((a) => LAYOUTS[a]);
const LAYOUT_MIX = [
  [39, 37], [40, 37], [41, 37], [39, 38], [40, 38], [41, 38], [39, 39], [40, 39], [41, 39],   // 3x3 block: 5 7 6 / 13 15 14 / 9 11 10
  [34, 42], [35, 42], [36, 42],                                                             // row wall: 1 3 2
  [33, 38], [33, 39], [33, 40],                                                             // column wall: 4 12 8
  [35, 40],                                                                                 // alone: 0
];
const LAYOUT = LAYOUT_NAME ? LAYOUTS[LAYOUT_NAME] : LAYOUT_MIX;

(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await page.evaluate(async () => { const mod = await import('/src/systems/Pathfinder.js'); window.__findPath = mod.findPath; });
    await T.settle();
    const start = (await T.snap()).tile;
    await T.materials(); await T.materials();
    await T.openCraft(); await T.card(2);
    for (const [c, r] of LAYOUT) await T.tapTile(c, r, 80);
    await T.closeCraft();
    await page.waitForTimeout(300);
    const structs = await G(() => window.__rv.structs());
    const masks = new Set(structs.map((k) => +k.split('#')[1]));
    console.log('built', structs.length, structs.join(' '));
    ok(LAYOUT.length + ' fences built with real ' + (TOUCH ? 'touches' : 'clicks'), structs.length === LAYOUT.length);
    if (!LAYOUT_NAME) ok('all 16 fence pictures appear', masks.size === 16, [...masks].sort((a, b) => a - b).join(','));
    else console.log('masks', [...masks].sort((a, b) => a - b).join(','));
    const s0 = await T.snap();
    ok('player did not move while building', s0.tile === start && !s0.path, J(s0));

    // candidate points on the fence pictures, in game-canvas pixels (camera is still; 1 world px = scale game px)
    const cands = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, cam = s.cameras.main;
      const out = { edge: [], solid: [], post: [], beside: [] };
      const fences = R.fences();
      R.freeze();
      const t0 = performance.now();
      for (const f of fences) {
        const sp = f.sprite, rc = R.rect(sp), M = R.alphaMap(sp.texture.key, sp.frame.name);
        for (let j = 0; j < M.h; j++) for (let i = 0; i < M.w; i++) {
          const a = M.a[j * M.w + i];
          // integer world point inside texture pixel (i, j)
          const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
          const gx = wx - cam.worldView.x, gy = wy - cam.worldView.y;
          const cx = rc.left + i + 0.5 - cam.worldView.x, cy = rc.top + j + 0.5 - cam.worldView.y;   // exact pixel centre (for touch)
          if (Math.floor(wx - rc.left) !== i || Math.floor(wy - rc.top) !== j) continue;
          const t = R.tileAt(wx, wy), own = t.col === f.col && t.row === f.row;
          const top = R.topAt(wx, wy, 0);
          if (a > 30) {
            if (!top || top.type !== 'fence') continue;           // something else is drawn over it
            const q = { f: R.key(f), mask: R.mask(f), i, j, a, wx, wy, gx, gy, cx, cy, tile: t.col + ',' + t.row, walk: m.isWalkable(t.col, t.row) };
            if (!own && q.walk) (a <= 110 ? out.edge : out.solid).push(q);
            else if (own) out.post.push(q);
          } else if (a === 0 && !own && m.isWalkable(t.col, t.row) && !top) {
            // clearly beside: no picture pixel of any fence within 4 px
            let near = false;
            const close = fences.filter((g) => Math.abs(g.sprite.x - wx) < 40 && Math.abs(g.sprite.y - wy) < 70);
            for (let dy = -4; dy <= 4 && !near; dy++) for (let dx = -4; dx <= 4 && !near; dx++) for (const g of close) if (R.alphaAt(g, wx + dx, wy + dy) > 0) { near = true; break; }
            if (!near && window.__findPath(m.cols, m.rows, s.player.tile, t, s.player.costAt)) out.beside.push({ f: R.key(f), i, j, wx, wy, gx, gy, tile: t.col + ',' + t.row });
          }
        }
      }
      R.unfreeze();
      out.ms = Math.round(performance.now() - t0);
      return out;
    });
    console.log('candidates computed in', cands.ms, 'ms');
    console.log('candidates: edge(31-110, over other walkable tiles)', cands.edge.length, '| solid over other walkable', cands.solid.length, '| own-tile (posts)', cands.post.length, '| beside', cands.beside.length);
    // all edge pixels, every 3rd solid pixel, every 6th own-tile pixel
    const pick = (arr, step) => arr.filter((_, k) => k % step === 0);
    const QUICK = process.argv.includes('quick');
    const list = QUICK ? [...pick(cands.edge, 3), ...pick(cands.solid, 12), ...pick(cands.post, 40)] : [...cands.edge, ...pick(cands.solid, 3), ...pick(cands.post, 6)];
    console.log('clicking', list.length, 'points'); const tc0 = Date.now();
    const scale = await G(() => { const g = window.__game, r = g.canvas.getBoundingClientRect(); return { sx: r.width / g.canvas.width, sy: r.height / g.canvas.height, left: r.left, top: r.top }; });
    let moved = 0, cursor = 0, notFence = 0, missed = 0, n = 0;
    const examples = [];
    await G(() => { window.__presses.length = 0; });
    for (let k = 0; k < list.length; k++) {
      const q = list[k];
      const px = scale.left + (TOUCH ? q.cx : q.gx) * scale.sx, py = scale.top + (TOUCH ? q.cy : q.gy) * scale.sy;
      if (TOUCH) await page.touchscreen.tap(px, py); else await page.mouse.click(px, py);
      n++;
      if (process.argv.includes('stopfirst')) {
        const pr = await G(() => window.__presses[window.__presses.length - 1]);
        if (pr && (pr.after.path || pr.after.tile !== start || pr.after.cursor)) {
          const real = await G((p) => { const R = window.__rv; let best = 0, who = null; for (const f of R.fences()) { const a = R.alphaAt(f, p.wx, p.wy); if (a > best) { best = a; who = R.key(f); } } return { alpha: best, fence: who }; }, pr);
          console.log('FIRST WALK at tap', n, 'target', J(q), 'page', px.toFixed(2), py.toFixed(2), '\n   press', J(pr), '\n   real', J(real));
          console.log('   all presses so far', await G(() => window.__presses.length), 'taps', n);
          break;
        }
      }
      if (n % 40 === 0 || k === list.length - 1) {
        const pr = await G(() => window.__presses.splice(0));
        for (const p of pr) {
          // what the press really landed on
          const real = await G((p) => { const R = window.__rv, m = window.__game.scene.getScene('game').map; let best = 0, who = null;
            for (const f of R.fences()) { const a = R.alphaAt(f, p.wx, p.wy); if (a > best) { best = a; who = R.key(f); } } return { alpha: best, fence: who }; }, p);
          if (real.alpha <= 30) { missed++; continue; }
          if (!p.picked || !p.picked.startsWith('fence')) { notFence++; if (examples.length < 6) examples.push({ why: 'not fence', p, real }); }
          if (p.after.path || p.after.tile !== start) { moved++; if (examples.length < 6) examples.push({ why: 'moved', p, real }); }
          if (p.after.cursor) { cursor++; if (examples.length < 6) examples.push({ why: 'cursor', p, real }); }
        }
        const st = await T.snap();
        if (st.path || st.tile !== start) { console.log('   player moved, settling; state', J(st)); await T.stopped(); await T.tapTile(...start.split(',').map(Number)); await T.stopped(); await T.settle(); }
      }
    }
    console.log('clicks', n, 'in', Date.now() - tc0, 'ms | landed on alpha<=30 (ignored)', missed);
    for (const e of examples) console.log('   example', J(e));
    ok('every click on a fence picture picked a fence', notFence === 0, 'not fence: ' + notFence);
    ok('clicking fence pictures never moves the player', moved === 0, 'moved ' + moved);
    ok('no move cursor appeared', cursor === 0, 'cursor ' + cursor);

    // control: clicking clearly beside a fence walks
    const besides = cands.beside.filter((_, k) => k % Math.max(1, Math.floor(cands.beside.length / 8)) === 0).slice(0, 8);
    let walked = 0, tried = 0;
    for (const q of besides) {
      await T.settle();
      await G(() => { window.__presses.length = 0; });
      await T.tapWorld(q.wx, q.wy, 150);
      const p = await T.lastPress();
      if (!p) { console.log('   no press for', J(q)); continue; }
      tried++;
      const good = !p.picked && (p.after.path || p.after.cursor);
      if (good) walked++; else console.log('   beside click did not walk', J(q), J(p));
      await T.stopped();
      await T.tapTile(...start.split(',').map(Number), 0); await T.stopped();
    }
    ok('clicking clearly beside a fence still walks', tried > 0 && walked === tried, `${walked}/${tried}`);
    const bad = await T.bad();
    ok('per-frame invariants', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
    await page.screenshot({ path: __dirname + '/a_fences' + (TOUCH ? '_touch' : '') + '.png' });
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
