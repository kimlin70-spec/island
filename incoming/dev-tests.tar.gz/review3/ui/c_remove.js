// (c) remove mode: clicking a front fence's rail (including its faint edge) removes that fence, not the one behind.
// Two short walls, one behind the other; also an L corner and a pen corner. Real clicks in remove mode; the removed fence is put back with place().
// usage: node c_remove.js [touch]
const { setup } = require('./common.js');
const J = JSON.stringify;
const TOUCH = process.argv[2] === 'touch';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
const WALLS = [[36, 36], [37, 36], [38, 36], [36, 37], [37, 37], [38, 37],      // two walls (rows 36 and 37)
               [40, 40], [41, 40], [42, 40], [40, 41], [40, 42],                 // L corner
               [33, 41], [34, 41], [35, 41], [33, 42], [35, 42], [33, 43], [34, 43], [35, 43]];   // 3x3 pen
(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await T.settle();
    await T.materials();
    await T.openCraft(); await T.card(2);
    for (const [c, r] of WALLS) await T.tapTile(c, r, 60);
    await T.card(5);                                                     // remove mode
    const built = await G(() => window.__rv.structs());
    ok('fences built with real clicks', built.length === WALLS.length, built.length + ' ' + built.join(' '));
    ok('remove mode on', (await T.snap()).mode === 'remove');
    // candidate points: pixels of a fence F with alpha > 30 that are drawn on top (no other fence drawn over them with alpha>0)
    // and lie over another fence's tile or over another fence's picture
    const cands = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, cam = s.cameras.main;
      R.freeze();
      const out = [];
      for (const f of R.fences()) {
        const sp = f.sprite, rc = R.rect(sp), M = R.alphaMap(sp.texture.key, sp.frame.name);
        for (let j = 0; j < M.h; j++) for (let i = 0; i < M.w; i++) {
          const a = M.a[j * M.w + i]; if (a === 0) continue;
          const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
          if (Math.floor(wx - rc.left) !== i || Math.floor(wy - rc.top) !== j) continue;
          const top = R.topAt(wx, wy, 0); if (top !== f) continue;
          const t = R.tileAt(wx, wy), under = m.structureAt(t.col, t.row);
          const behind = R.fences().filter((g) => g !== f && R.alphaAt(g, wx, wy) > 0);
          if ((under && under !== f) || behind.length) out.push({ f: R.key(f), a, wx, wy, under: R.key(under), behind: behind.map(R.key), band: a > 110 ? 'solid' : a > 30 ? 'edge' : 'faint' });
        }
      }
      R.unfreeze();
      return out;
    });
    const by = (b) => cands.filter((q) => q.band === b);
    console.log('candidates: edge', by('edge').length, 'solid', by('solid').length, 'faint(<=30)', by('faint').length);
    const pickN = (arr, n) => arr.filter((_, k) => k % Math.max(1, Math.floor(arr.length / n)) === 0).slice(0, n);
    const list = [...pickN(by('edge'), 60), ...pickN(by('solid'), 20), ...pickN(by('faint'), 20)];
    const res = { edge: { right: 0, wrong: 0 }, solid: { right: 0, wrong: 0 }, faint: { right: 0, wrong: 0, none: 0 } };
    const wrongEx = [];
    for (const q of list) {
      const before = await G(() => window.__rv.structs().map((k) => k.split('#')[0]));
      await T.tapWorld(q.wx + (TOUCH ? 0.5 : 0), q.wy + (TOUCH ? 0.5 : 0), 0);
      await page.waitForTimeout(40);
      const after = await G(() => window.__rv.structs().map((k) => k.split('#')[0]));
      const gone = before.filter((k) => !after.includes(k));
      if (gone.length === 1 && gone[0] === q.f) res[q.band].right++;
      else if (gone.length === 0) { res[q.band].none = (res[q.band].none || 0) + 1; if (q.band !== 'faint' && wrongEx.length < 8) wrongEx.push({ q, gone }); }
      else { res[q.band].wrong++; if (wrongEx.length < 8) wrongEx.push({ q, gone }); }
      // put the removed fences back
      if (gone.length) await G((gone) => { const s = window.__game.scene.getScene('game'); for (const k of gone) { const [c, r] = k.split('@')[1].split(',').map(Number); s.build.place('fence', [{ col: c, row: r }]); } }, gone);
    }
    console.log('results', J(res));
    for (const e of wrongEx) console.log('   example', J(e));
    ok('remove: clicking a fence rail edge (alpha 31-110) removes that fence', res.edge.wrong === 0 && !res.edge.none, J(res.edge));
    ok('remove: clicking a solid fence pixel removes that fence', res.solid.wrong === 0 && !res.solid.none, J(res.solid));
    console.log('INFO faint fringe (alpha<=30) clicks: removed the fence clicked', res.faint.right, '| removed another fence', res.faint.wrong, '| nothing', res.faint.none || 0);
    const st = await T.snap();
    ok('player never moved in remove mode', st.tile === '37,39' && !st.path, J(st));
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
