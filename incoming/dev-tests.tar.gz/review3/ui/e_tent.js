// (e) tent: build it with real clicks, click it -> walk there (re-click while walking), enter; exit by the button;
// enter again; exit by clicking the tent. Then: walk to it from far away with a fence built on the path, re-click -> goes around and enters.
// usage: node e_tent.js [touch]
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
const TOUCH = process.argv[2] === 'touch';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G, W } = T;
  const off = TOUCH ? 0.5 : 0;
  const st = () => G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'), p = s.player, t = s.map.structures.find((x) => x.type === 'tent');
    return { resting: s.rest.resting, hidden: !p.sprite.visible, tex: t ? t.sprite.texture.key : null, button: u.restBox.visible, tile: p.tile.col + ',' + p.tile.row, path: p.path.map((q) => q.col + ',' + q.row).join(' '), moving: p.moving, speed: s.speed, action: p.action ? 'tent' : null }; });
  // a point on the tent picture (drawn on top, picks the tent)
  const tentPoint = (fy = 0.45) => G((fy) => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, t = m.structures.find((x) => x.type === 'tent'), sp = t.sprite, rc = R.rect(sp);
    const cands = [];
    for (let j = 0; j < sp.height; j += 2) for (let i = 0; i < sp.width; i += 2) { const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
      if (m.pickObject(wx, wy) !== t || R.topAt(wx, wy, 0) !== t) continue;
      let inner = true; for (let dy = -24; dy <= 24 && inner; dy += 6) for (let dx = -24; dx <= 24 && inner; dx += 6) if (m.pickObject(wx + dx, wy + dy) !== t) inner = false;
      if (inner) cands.push({ wx, wy, d: Math.abs(j / sp.height - fy) + Math.abs(i / sp.width - 0.5) }); }
    cands.sort((a, b) => a.d - b.d); return cands[0]; }, fy);
  const clickTent = async (fy) => { await T.frozenTapWorld(() => tentPoint(fy)); };
  try {
    await T.settle();
    await T.materials();
    // build the tent 4 tiles away with a real click
    await T.openCraft(); await T.card(4);
    const spot = await G(() => { const s = window.__game.scene.getScene('game'), b = s.build, p = s.player;
      for (const [dc, dr] of [[-6, -1], [-6, 0], [-5, -2], [3, -6], [-4, -4], [2, 3]]) { const c = p.tile.col + dc, r = p.tile.row + dr;
        const tiles = [[c, r], [c + 1, r], [c, r + 1], [c + 1, r + 1]]; if (tiles.every(([x, y]) => b.canBuildAt(x, y))) return { c, r }; }
      return null; });
    // pointer at the shared corner of the four tiles (fc = c + 0.5, fr = r + 0.5)
    await T.tapWorld((spot.c - spot.r) * 40, (spot.c + spot.r + 1) * 20, 300);
    const tent = await G(() => { const t = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent'); return t ? t.tiles.map((q) => q.col + ',' + q.row).join(' ') : null; });
    ok('tent built with a real ' + (TOUCH ? 'touch' : 'click'), !!tent, tent);
    ok('tent card done: build mode off', (await T.snap()).mode === null);
    await T.closeCraft();
    await T.settle();
    // 1. click the tent: walk there; re-click twice while walking; it goes in
    await clickTent();
    await page.waitForTimeout(150);
    let s = await st();
    const path1 = s.path;
    ok('click on the tent starts a walk to it', !!path1 && s.action === 'tent', J(s));
    await clickTent(0.3); await page.waitForTimeout(30);
    const s1b = await st();
    await clickTent(0.6); await page.waitForTimeout(30);
    const s1c = await st();
    console.log('   re-clicks while walking:', J(s1b), J(s1c));
    console.log('   presses:', J((await G(() => window.__presses.slice(-3))).map((p) => ({ picked: p.picked, before: { tile: p.before.tile, path: p.before.path, resting: p.before.resting }, after: { tile: p.after.tile, path: p.after.path, resting: p.after.resting } }))));
    ok('re-clicking the tent while walking keeps the walk', (s1b.resting || s1b.path === '' || path1.endsWith(s1b.path.split(' ').pop())) && (s1c.resting || s1c.path === '' || path1.endsWith(s1c.path.split(' ').pop())));
    await W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
    await page.waitForTimeout(300);
    s = await st();
    const entry = s.tile;
    ok('entered the tent', s.resting && s.hidden && s.tex === 'build_tent_lit' && s.button && s.speed === 4, J(s));
    // 2. exit by the button
    await T.ui(...UI.rest, 400);
    s = await st();
    ok('rest button: comes out on the entry tile', !s.resting && !s.hidden && s.tex === 'build_tent' && !s.button && s.tile === entry && !s.moving && s.speed === 1, J(s));
    // 3. enter again by clicking the tent (already next to it)
    await T.settle();
    await clickTent();
    await W(() => window.__game.scene.getScene('game').rest.resting, null, 20000);
    await page.waitForTimeout(300);
    s = await st();
    ok('click on the tent from next to it: enters', s.resting && s.tile === entry, J(s));
    // 4. exit by clicking the tent
    await clickTent(0.4);
    await page.waitForTimeout(300);
    s = await st();
    ok('click on the tent while resting: comes out', !s.resting && !s.hidden && s.tile === entry, J(s));
    // 5. far away; click the tent; a fence cuts the path; re-click the tent while walking -> goes around and enters
    const far = await G(([e]) => { const s = window.__game.scene.getScene('game'), m = s.map, p = s.player, t = s.map.structures.find((x) => x.type === 'tent');
      const tc = t.tiles[0].col + 0.5, tr = t.tiles[0].row + 0.5; let best = null;
      for (let r = p.tile.row - 12; r <= p.tile.row + 12; r++) for (let c = p.tile.col - 12; c <= p.tile.col + 12; c++) { const d = Math.hypot(c - tc, r - tr);
        if (d < 9 || d > 11 || !m.isWalkable(c, r) || m.pickObject((c - r) * 40, (c + r) * 20)) continue; if (!best || d > best.d) best = { c, r, d }; }
      return best; }, [entry]);
    await T.tapTile(far.c, far.r, 0); await T.stopped(); await T.settle();
    console.log('   walked away to', (await st()).tile);
    await clickTent();
    await page.waitForTimeout(60);
    console.log('   tent click from far:', J(await T.lastPress().then((p) => p && { picked: p.picked, path: p.after.path })));
    await T.ui(...UI.craft, 100); await T.ui(...UI.card(2), 100);
    let fence = null;
    for (let tries = 0; tries < 6 && !fence; tries++) {
      const tgt = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, b = s.build;
        for (let k = Math.min(p.path.length - 2, 5); k >= 3; k--) { const t = p.path[k]; if (b.canBuildAt(t.col, t.row)) return { col: t.col, row: t.row }; } return null; });
      if (!tgt) break;
      await T.frozenTapWorld(async () => ({ wx: (tgt.col - tgt.row) * 40, wy: (tgt.col + tgt.row) * 20 })); await page.waitForTimeout(50);
      fence = await G(() => { const f = window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'fence'); return f ? f.col + ',' + f.row : null; });
    }
    await T.ui(...UI.craft, 50);
    const s5 = await st();
    const adjTent = (k) => G((k) => { const s = window.__game.scene.getScene('game'), t = s.map.structures.find((x) => x.type === 'tent'); const [c, r] = k.split(',').map(Number);
      return t.tiles.some((q) => Math.max(Math.abs(q.col - c), Math.abs(q.row - r)) <= 1); }, k);
    const end5 = s5.path ? s5.path.split(' ').pop() : s5.tile;
    console.log('   fence', fence, 'state', J(s5));
    ok('fence cut the walk to the tent', !!fence && !(await adjTent(end5)), 'end ' + end5);
    if (s5.moving) {
      await clickTent();
      await page.waitForTimeout(100);
      const s6 = await st();
      console.log('   re-click press:', J(await T.lastPress().then((p) => p && { picked: p.picked, before: p.before.path, after: p.after.path, action: p.after.action })));
      const end6 = s6.path ? s6.path.split(' ').pop() : s6.tile;
      ok('re-click on the tent re-plans a walk to it', await adjTent(end6), J(s6));
    } else console.log('   (already stopped before the re-click; clicking the tent again)'), await clickTent();
    await W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
    s = await st();
    ok('goes around and enters', s.resting, J(s));
    await T.ui(...UI.rest, 300);
    const bad = await T.bad();
    ok('per-frame invariants', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
