// real click on the stump in the very frame after the tree became a stump (game loop stepped by hand)
const { setup } = require('./common.js');
const J = JSON.stringify;
const TOUCH = process.argv[2] === 'touch';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { G, page } = T;
  try {
    await T.settle();
    await T.materials(); await T.openCraft(); await T.card(0); await T.card(1); await T.closeCraft();   // axe + pickaxe
    console.log('tools', J(await G(() => window.__game.scene.getScene('game').tools)));
    // tree 41,42: walk next to it first, then click it
    const TR = [+(process.argv[3] || 32), +(process.argv[4] || 40)];
    const nb = await G((TR) => { const s = window.__game.scene.getScene('game'), m = s.map;
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { const c = TR[0] + dc, r = TR[1] + dr; if ((dc || dr) && m.isWalkable(c, r) && !m.pickObject((c - r) * 40, (c + r) * 20)) return [c, r]; } return null; }, TR);
    console.log('stand at', J(nb));
    await T.tapTile(nb[0], nb[1], 0); await T.stopped(); await T.settle();
    console.log('tree now', await G((TR) => window.__game.scene.getScene('game').map.objectAt(TR[0], TR[1]).kind, TR));
    const pick = (c, r) => G(([c, r]) => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, o = m.objectAt(c, r), sp = o.sprite, rc = R.rect(sp);
      let best = null; for (let j = 0; j < sp.height; j++) for (let i = 0; i < sp.width; i++) { const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j);
        if (m.pickObject(wx, wy) !== o || R.topAt(wx, wy, 0) !== o) continue;
        let inner = 0; for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) if (m.pickObject(wx + dx, wy + dy) === o) inner++;
        const d = -inner * 100 + Math.hypot(wx - sp.x, wy - (rc.top + sp.height / 2)); if (!best || d < best.d) best = { wx, wy, d }; }
      return best; }, [c, r]);
    const tp = await pick(...TR);
    await T.tapWorld(tp.wx + (TOUCH ? 0.5 : 0), tp.wy + (TOUCH ? 0.5 : 0), 0);
    // step the loop by hand until the tree is a stump
    const r = await G((TR) => { const g = window.__game, s = g.scene.getScene('game'), o = s.map.objectAt(TR[0], TR[1]);
      g.loop.sleep(); window.__time = g.loop.time || performance.now(); let n = 0;
      while (o.kind !== 'stump' && n < 3000) { window.__time += 50; s.sys.step(window.__time, 50); n++; }
      return { n, kind: o.kind, action: !!s.player.action, valid: s.player.action ? s.player.action.isValid() : null, moving: s.player.moving }; }, TR);
    console.log('stepped', J(r));
    ok('tree became a stump while chopping; old action still set but no longer valid', r.kind === 'stump' && r.action && r.valid === false, J(r));
    // the very next thing: a real click on the stump (Phaser handles it immediately)
    const sp = await pick(...TR);
    await T.tapWorld(sp.wx + (TOUCH ? 0.5 : 0), sp.wy + (TOUCH ? 0.5 : 0), 0);
    const pr = await T.lastPress();
    console.log('press', J({ picked: pr.picked, action: pr.after.action, newAction: pr.newAction, at: [pr.wx, pr.wy], wanted: [sp.wx, sp.wy], presses: await G(() => window.__presses.length) }));
    ok('the click in that frame picks the stump and starts digging', pr.picked === `stump@${TR[0]},${TR[1]}` && pr.after.action === `stump@${TR[0]},${TR[1]}` && pr.newAction);
    const r2 = await G((TR) => { const g = window.__game, s = g.scene.getScene('game'); let n = 0;
      while (s.map.objectAt(TR[0], TR[1]) && n < 3000) { window.__time += 50; s.sys.step(window.__time, 50); n++; }
      g.loop.wake(); return { n, gone: !s.map.objectAt(TR[0], TR[1]) }; }, TR);
    ok('the stump is dug out', r2.gone, J(r2));
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
