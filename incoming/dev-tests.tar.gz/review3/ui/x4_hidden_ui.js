// world clicks where hidden UI sits (closed craft window cards, hidden rest button, closed test window) must reach the world
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
(async () => {
  for (const touch of [false, true]) {
    const T = await setup(touch ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
    const { G, page } = T;
    await T.settle();
    // open + close the craft window and the test window first, so their objects exist and are hidden
    await T.openCraft(); await T.closeCraft(); await T.ui(...UI.test); await T.ui(...UI.testItem(4));
    for (const [name, gx, gy] of [['card 0 area', UI.card(0)[0], UI.card(0)[1]], ['card 5 area', UI.card(5)[0], UI.card(5)[1] - 40], ['rest button area', UI.rest[0], UI.rest[1] - 20], ['test window item 2 area', UI.testItem(2)[0], UI.testItem(2)[1]]]) {
      await T.settle();
      await G(() => { window.__presses.length = 0; });
      const p = await T.g2p(gx, gy);
      // move a bit first (mouse), then click
      if (!touch) { await page.mouse.move(p.x - 30, p.y - 30); await page.mouse.move(p.x, p.y); }
      await T.tapPage(p.x, p.y);
      await page.waitForTimeout(200);
      const pr = await G(() => window.__presses.map((x) => ({ tile: x.tile, picked: x.picked, path: x.after.path, cursor: x.after.cursor })));
      console.log(touch ? 'touch' : 'mouse', name, J(pr));
      await T.stopped();
    }
    console.log('errors', J(T.errors));
    await T.browser.close();
  }
})();
