// probe: click coordinate mapping, equal-depth draw order vs pick order
const { setup } = require('./common.js');
const J = JSON.stringify;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await T.settle();
    const cam = await G(() => { const c = window.__game.scene.getScene('game').cameras.main; return { x: c.worldView.x, y: c.worldView.y, rp: c.roundPixels }; });
    console.log('camera', J(cam));
    // fractional click mapping
    for (const [x, y] of [[500.3, 600.7], [500.5, 600.5], [500.9, 600.2]]) {
      await page.mouse.click(x, y);
      await page.waitForTimeout(150);
      const pr = await T.lastPress();
      console.log('click page', x, y, '-> world', pr.wx, pr.wy, ' (world - scroll =', (pr.wx - cam.x).toFixed(3), (pr.wy - cam.y).toFixed(3) + ')');
      await T.stopped();
    }
    // equal depth: tree vs fence placed later
    const r = await G(() => {
      const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv;
      const tree = m.objectAt(35, 35);
      s.build.place('fence', [{ col: 36, row: 34 }]);
      const f = m.structureAt(36, 34);
      const idx = R.drawIndex();
      // overlapping pixels with both alpha>0
      let both = 0, treeTopPick = 0, fenceSolidTreeSolid = 0; const ex = [];
      const rf = R.rect(f.sprite);
      for (let j = 0; j < 59; j++) for (let i = 0; i < 62; i++) {
        const x = rf.left + i + 0.5, y = rf.top + j + 0.5;
        const af = R.alphaAt(f, x, y), at = R.alphaAt(tree, x, y);
        if (af > 30 && at > 0) { both++;
          const pk = m.pickObject(x, y);
          if (pk === tree) { treeTopPick++; if (ex.length < 3) ex.push({ x, y, af, at }); }
          if (af > 110 && at > 110) fenceSolidTreeSolid++; }
      }
      return { treeDepth: tree.sprite.depth, fenceDepth: f.sprite.depth, treeIdx: idx.get(tree.sprite), fenceIdx: idx.get(f.sprite), both, treeTopPick, fenceSolidTreeSolid, ex, mask: R.mask(f) };
    });
    console.log('equal depth tree(35,35) vs fence(36,34):', J(r));
    console.log('errors', J(T.errors));
  } catch (e) { console.error('CRASH', e); }
  finally { await T.browser.close(); }
})();
