// (g) the test window: night, morning, speed x3 (with walking, chopping, building and the tent at x3).
// usage: node g_testwin.js [touch]
const { setup, UI } = require('./common.js');
const { lum } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const J = JSON.stringify;
const TOUCH = process.argv[2] === 'touch';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await setup(TOUCH ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
  const { page, G, W } = T;
  const clock = () => G(() => { const s = window.__game.scene.getScene('game'), c = s.clock, u = window.__game.scene.getScene('ui');
    return { day: c.day, night: c.isNight, label: c.label, speed: s.speed, debugSpeed: s.debugSpeed, notices: window.__notices.slice(-3), hearts: s.hearts.value !== undefined ? s.hearts.value : s.hearts.hearts }; });
  try {
    await T.settle();
    const start = await T.snap();
    await T.ui(...UI.test);
    const lumDay = await lum(page, 300, 900, 30);
    await T.ui(...UI.testItem(1), 1200);                 // night
    let c = await clock();
    const lumNight = await lum(page, 300, 900, 30);
    const lumPlayer = await lum(page, 960, 580, 20);
    console.log('after night:', J(c), 'lum far day/night', lumDay, lumNight, 'near player', lumPlayer);
    ok('night button: it is night', c.night && c.notices.includes('밤이 되었습니다') && c.label === '1일째 밤');
    ok('night: the screen is dark away from the player', lumNight < lumDay * 0.7, `${lumDay} -> ${lumNight}`);
    await T.ui(...UI.testItem(1), 300);                  // night again: nothing
    ok('night button again at night: nothing', (await clock()).day === 1 && (await clock()).night);
    await T.ui(...UI.testItem(2), 4000);                 // morning
    c = await clock();
    const lumMorning = await lum(page, 300, 900, 30);
    console.log('after morning:', J(c), 'lum', lumMorning);
    ok('morning button: day 2 morning', !c.night && c.day === 2 && c.notices.includes('2일째 아침입니다') && c.label === '2일째 낮');
    ok('morning: the screen is bright again', lumMorning > lumDay * 0.9, `${lumMorning} vs ${lumDay}`);
    await T.ui(...UI.testItem(2), 300);                  // morning again in the day: nothing
    ok('morning button again in the day: nothing', (await clock()).day === 2);
    await T.ui(...UI.testItem(0), 300);                  // +20
    await T.ui(...UI.testItem(3), 300);                  // speed x3
    c = await clock();
    const label = await G(() => window.__game.scene.getScene('ui').debugLabels[3].label.text);
    ok('speed button: x3', c.debugSpeed === 3 && c.speed === 3 && label === '속도 ×3', label);
    await T.ui(...UI.testItem(4), 300);                  // close
    const s1 = await T.snap();
    ok('test window clicks did not reach the world', s1.tile === start.tile && !s1.path && !s1.cursor, J(s1));
    // walk at x3: game time and distance
    await G(() => { const s = window.__game.scene.getScene('game'); window.__gt = 0; window.__rt0 = performance.now(); s.events.on('update', (t, d) => { window.__gt += Math.min(d / 1000, 0.1) * s.speed; }); });
    await T.tapTile(37, 33, 0);
    await T.stopped();
    const sp = await G(() => ({ gt: window.__gt, rt: (performance.now() - window.__rt0) / 1000, tile: window.__rv.snap().tile }));
    console.log('walk 6 tiles at x3:', J(sp));
    ok('walked at x3 and arrived', sp.tile === '37,33', J(sp));
    // chop a tree at x3 (tree 37,35 is next to 37,34)
    await T.settle();
    const tp = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, o = m.objectAt(37, 35), sp = o.sprite, rc = R.rect(sp);
      for (let j = 10; j < sp.height; j += 2) for (let i = 10; i < sp.width; i += 2) { const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j); if (m.pickObject(wx, wy) === o && R.topAt(wx, wy, 0) === o) return { wx, wy }; } return null; });
    await T.tapWorld(tp.wx, tp.wy, 0);
    await W(() => window.__game.scene.getScene('game').map.objectAt(37, 35).kind === 'stump', null, 60000);
    ok('chopped a tree at x3', true);
    // build a few fences next to the walking player at x3
    await T.tapTile(41, 37, 0);
    await T.openCraft(); await T.card(2);
    for (let k = 0; k < 6; k++) {
      const tgt = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player, b = s.build;
        const from = p.tile; for (const [dc, dr] of [[1, 1], [-1, -1], [1, -1], [-1, 1], [0, 2], [2, 0]]) { const c = from.col + dc, r = from.row + dr; if (b.canBuildAt(c, r)) return { c, r }; } return null; });
      if (!tgt) break;
      await T.tapTile(tgt.c, tgt.r, 0);
      await page.waitForTimeout(30);
    }
    await T.closeCraft();
    await T.stopped();
    console.log('fences', (await G(() => window.__rv.structs())).join(' '), 'stopped at', (await T.snap()).tile);
    // tent at x3: x12 inside
    await T.openCraft(); await T.card(4);
    const spot = await G(() => { const s = window.__game.scene.getScene('game'), b = s.build, p = s.player;
      for (let dr = -5; dr <= 5; dr++) for (let dc = -5; dc <= 5; dc++) { const c = p.tile.col + dc, r = p.tile.row + dr; if (Math.max(Math.abs(dc), Math.abs(dr)) < 3) continue;
        if ([[c, r], [c + 1, r], [c, r + 1], [c + 1, r + 1]].every(([x, y]) => b.canBuildAt(x, y))) return { c, r }; } return null; });
    await T.settle();
    await T.tapWorld((spot.c - spot.r) * 40, (spot.c + spot.r + 1) * 20, 300);
    await T.closeCraft();
    await T.settle();
    const tentPt = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, R = window.__rv, t = m.structures.find((x) => x.type === 'tent'); if (!t) return null; const sp = t.sprite, rc = R.rect(sp);
      for (let j = Math.floor(sp.height * 0.4); j < sp.height; j += 2) for (let i = Math.floor(sp.width * 0.4); i < sp.width; i += 2) { const wx = Math.ceil(rc.left + i), wy = Math.ceil(rc.top + j); if (m.pickObject(wx, wy) === t) return { wx, wy }; } return null; });
    ok('tent built at x3', !!tentPt);
    await T.tapWorld(tentPt.wx, tentPt.wy, 0);
    await W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
    await page.waitForTimeout(500);
    c = await clock();
    ok('in the tent at x3: game speed x12', c.speed === 12, J(c));
    await T.ui(...UI.rest, 300);
    c = await clock();
    ok('out of the tent: back to x3', c.speed === 3, J(c));
    await T.ui(...UI.test); await T.ui(...UI.testItem(3)); await T.ui(...UI.testItem(4));
    c = await clock();
    ok('speed back to x1', c.speed === 1 && c.debugSpeed === 1, J(c));
    const bad = await T.bad();
    ok('per-frame invariants', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
