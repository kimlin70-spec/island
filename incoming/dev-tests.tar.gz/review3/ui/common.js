// shared helpers for the real-UI review (review3/ui)
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');

const UI = {
  craft: [1824, 1104],
  card: (i) => [776 + 20 + i * 182 + 85, 898],   // 0 axe, 1 pickaxe, 2 fence, 3 campfire, 4 tent, 5 remove
  test: [1852, 328],
  testItem: (i) => [1746, 402 + i * 66],          // 0 +20, 1 night, 2 morning, 3 speed, 4 close
  rest: [960, 1132],
};
exports.UI = UI;

exports.setup = async (opts = {}) => {
  const T = await open(opts);
  const { page, G } = T;
  T.touch = !!opts.touch;
  T.g2p = (x, y) => G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect();
    return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
  T.w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.worldView.x) * cam.zoom, sy = (wy - cam.worldView.y) * cam.zoom;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, on: sx >= 0 && sy >= 0 && sx < cam.width && sy < cam.height }; }, [wx, wy]);
  T.tapPage = async (x, y) => { if (T.touch) await page.touchscreen.tap(x, y); else { await page.mouse.move(x, y); await page.mouse.click(x, y); } };
  T.ui = async (x, y, wait = 300) => { const p = await T.g2p(x, y); await T.tapPage(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  T.tapWorld = async (wx, wy, wait = 0) => { const p = await T.w2p(wx, wy); if (!p.on) throw new Error('off ' + wx + ',' + wy); await T.tapPage(p.x, p.y); if (wait) await page.waitForTimeout(wait); return p; };
  T.tapTile = (c, r, wait) => T.tapWorld((c - r) * 40, (c + r) * 20, wait);
  T.stopped = (t = 60000) => T.W(() => !window.__game.scene.getScene('game').player.moving, null, t);
  T.settle = async () => {
    let last = null, same = 0;
    for (let i = 0; i < 120 && same < 3; i++) {
      const v = await G(() => { const c = window.__game.scene.getScene('game').cameras.main; return c.worldView.x.toFixed(3) + ',' + c.worldView.y.toFixed(3); });
      if (v === last) same++; else same = 0;
      last = v;
      await page.waitForTimeout(100);
    }
  };
  await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), m = s.map;
    const R = window.__rv = {};
    R.key = (o) => (o ? (o.type || o.kind) + '@' + o.col + ',' + o.row : null);
    R.mask = (f) => +f.sprite.texture.key.split('_').pop();
    R.rect = (sp) => ({ left: sp.x - sp.displayWidth * sp.originX, top: sp.y - sp.displayHeight * sp.originY, w: sp.displayWidth, h: sp.displayHeight });
    const cache = {};
    R.alphaMap = (key, frameName) => {
      const id = key + '#' + frameName;
      if (cache[id]) return cache[id];
      const fr = g.textures.getFrame(key, frameName), c = document.createElement('canvas');
      c.width = fr.cutWidth; c.height = fr.cutHeight;
      const ctx = c.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(fr.source.image, fr.cutX, fr.cutY, fr.cutWidth, fr.cutHeight, 0, 0, fr.cutWidth, fr.cutHeight);
      const d = ctx.getImageData(0, 0, fr.cutWidth, fr.cutHeight).data, a = new Uint8Array(fr.cutWidth * fr.cutHeight);
      for (let i = 0; i < a.length; i++) a[i] = d[i * 4 + 3];
      return (cache[id] = { w: fr.cutWidth, h: fr.cutHeight, a });
    };
    R.alphaAt = (o, x, y) => { const sp = o.sprite, r = R.rect(sp); const lx = Math.floor(x - r.left), ly = Math.floor(y - r.top);
      if (lx < 0 || ly < 0 || lx >= sp.width || ly >= sp.height) return 0;
      const M = R.alphaMap(sp.texture.key, sp.frame.name); return M.a[ly * M.w + lx]; };
    R.tileAt = (x, y) => ({ col: Math.floor((x / 40 + y / 20) / 2 + 0.5), row: Math.floor((y / 20 - x / 40) / 2 + 0.5) });
    R.all = () => [...m.objects, ...m.structures];
    // draw order: the display list after the depth sort (later = drawn on top)
    R.drawIndex = () => { s.children.depthSort(); const idx = new Map(); s.children.list.forEach((go, i) => idx.set(go, i)); return idx; };
    // the topmost pickable object whose picture has alpha > minA at (x, y), by real draw order
    // R.freeze() caches the draw order and the picture rectangles (call again after the scene changes)
    R.freeze = () => { R._idx = R.drawIndex(); R._objs = R.all().filter((o) => o.pickable).map((o) => ({ o, r: R.rect(o.sprite) })); };
    R.unfreeze = () => { R._idx = null; R._objs = null; };
    R.topAt = (x, y, minA = 0) => { const idx = R._idx || R.drawIndex(); const objs = R._objs || R.all().filter((o) => o.pickable).map((o) => ({ o, r: R.rect(o.sprite) }));
      let best = null, bi = -1;
      for (const { o, r } of objs) { if (x < r.left || y < r.top || x >= r.left + r.w || y >= r.top + r.h) continue;
        const a = R.alphaAt(o, x, y); if (a > minA && idx.get(o.sprite) > bi) { bi = idx.get(o.sprite); best = o; } }
      return best; };
    R.snap = () => { const p = s.player; return { col: +p.col.toFixed(3), row: +p.row.toFixed(3), tile: p.tile.col + ',' + p.tile.row, path: p.path.map((t) => t.col + ',' + t.row).join(' '),
      action: p.action ? R.key(p.action.target) : null, swing: p.swing ? +p.swing.t.toFixed(2) : null, cooldown: +p.cooldown.toFixed(2),
      cursor: s.cursor.visible, cursorAt: s.cursor.visible ? R.tileAt(s.cursor.x, s.cursor.y) : null, resting: s.rest.resting, mode: s.build.mode, visible: p.sprite.visible }; };
    R.fences = () => m.structures.filter((x) => x.type === 'fence');
    R.structs = () => m.structures.map((x) => R.key(x) + (x.type === 'fence' ? '#' + R.mask(x) : ''));
    window.__presses = [];
    const orig = s.onPress;
    s.onPress = function (p) {
      const o = this.map.pickObject(p.worldX, p.worldY);
      const before = R.snap(), pl = this.player, act0 = pl.action, path0 = pl.path;
      const rec = { wx: +p.worldX.toFixed(3), wy: +p.worldY.toFixed(3), touch: !!p.wasTouch, picked: R.key(o), top: R.key(R.topAt(p.worldX, p.worldY)), tile: R.tileAt(p.worldX, p.worldY), before };
      const ret = orig.call(this, p);
      rec.after = R.snap();
      rec.newAction = pl.action !== act0; rec.newPath = pl.path !== path0;
      window.__presses.push(rec);
      return ret;
    };
    window.__notices = [];
    s.events.on('notice', (t) => window.__notices.push(t));
    // per-frame invariants
    window.__bad = [];
    window.__frames = 0;
    s.events.on('postupdate', () => {
      window.__frames++;
      const p = s.player;
      const onStruct = (t) => t && m.structureAt(t.col, t.row);
      if (onStruct(p.tile)) window.__bad.push({ f: window.__frames, kind: 'tile-on-structure', at: [p.col, p.row], tile: [p.tile.col, p.tile.row] });
      if (p.path.length && onStruct(p.path[0])) window.__bad.push({ f: window.__frames, kind: 'next-on-structure', at: [p.col, p.row], next: [p.path[0].col, p.path[0].row] });
      // body box (floor/ceil of the position) must be walkable
      const e = 1e-9, c0 = Math.floor(p.col + e), c1 = Math.ceil(p.col - e), r0 = Math.floor(p.row + e), r1 = Math.ceil(p.row - e);   // ignore rounding slivers
      for (let c = c0; c <= c1; c++) for (let r = r0; r <= r1; r++) if (!m.isWalkable(c, r)) window.__bad.push({ f: window.__frames, kind: 'body-on-blocked', at: [p.col, p.row], blocked: [c, r] });
      // stranded: not moving but not on a tile centre
      if (!p.moving && (Math.abs(p.col - p.tile.col) > 1e-9 || Math.abs(p.row - p.tile.row) > 1e-9)) window.__bad.push({ f: window.__frames, kind: 'stranded', at: [p.col, p.row], tile: [p.tile.col, p.tile.row] });
    });
  });
  // freeze the game loop while computing a target and clicking it (Phaser handles real input immediately, also while asleep)
  T.freeze = () => G(() => window.__game.loop.sleep());
  T.thaw = () => G(() => window.__game.loop.wake());
  T.frozenTapWorld = async (getPoint) => { await T.freeze(); try { const q = await getPoint(); if (q) await T.tapWorld(q.wx + (T.touch ? 0.5 : 0), q.wy + (T.touch ? 0.5 : 0), 0); return q; } finally { await T.thaw(); } };
  T.snap = () => G(() => window.__rv.snap());
  T.lastPress = () => G(() => window.__presses[window.__presses.length - 1] || null);
  T.bad = () => G(() => window.__bad);
  // UI flows
  T.materials = async () => { await T.ui(...UI.test); await T.ui(...UI.testItem(0)); await T.ui(...UI.testItem(4)); };
  T.openCraft = async () => { const open = await G(() => window.__game.scene.getScene('ui').craftWin && window.__game.scene.getScene('ui').craftWin.visible); if (!open) await T.ui(...UI.craft, 400); };
  T.card = async (i) => { await T.ui(...UI.card(i), 400); };
  T.closeCraft = async () => { const open = await G(() => { const u = window.__game.scene.getScene('ui'); return u.craftWin ? u.craftWin.visible : null; }); if (open !== false) await T.ui(...UI.craft, 400); };
  return T;
};
