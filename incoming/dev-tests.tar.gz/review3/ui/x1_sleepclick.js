// does Phaser process a real click while the game loop sleeps? (mouse and touch)
const { setup } = require('./common.js');
(async () => {
  for (const touch of [false, true]) {
    const T = await setup(touch ? { w: 1024, h: 768, touch: true } : { w: 1920, h: 1200 });
    const { G } = T;
    await T.settle();
    await G(() => { window.__presses.length = 0; window.__game.loop.sleep(); });
    const f0 = await G(() => window.__frames);
    const p = await T.w2p((35 - 39) * 40, (35 + 39) * 20);
    await T.tapPage(p.x, p.y);
    await T.page.waitForTimeout(300);
    const r = await G(() => ({ presses: window.__presses.map((x) => ({ tile: x.tile, path: x.after.path })), frames: window.__frames, sleeping: !window.__game.loop.running }));
    console.log(touch ? 'touch' : 'mouse', 'while asleep: frames', f0, '->', r.frames, '| presses', JSON.stringify(r.presses), '| loop asleep', r.sleeping);
    await G(() => window.__game.loop.wake());
    await T.page.waitForTimeout(500);
    console.log('   after wake: presses', await G(() => window.__presses.length), 'errors', JSON.stringify(T.errors));
    await T.browser.close();
  }
})();
