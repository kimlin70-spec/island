// (f) real clicks in fence mode right next to the walking player (loop frozen while aiming, like a user clicking what is on screen):
//  - tiles the body is on (tile just left, tile being entered, side tiles of the current diagonal step): refused, overlay red
//  - the next tile, or a side tile of the next diagonal step: built (overlay green), the player stops on the tile being entered
// usage: node f2_build_next.js <rounds> [speed3]
const { setup, UI } = require('./common.js');
const J = JSON.stringify;
const ROUNDS = +(process.argv[2] || 12);
const FAST = process.argv[3] === 'speed3';
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  try {
    await page.evaluate(async () => { const mod = await import('/src/systems/Pathfinder.js'); window.__findPath = mod.findPath; });
    await T.settle();
    await T.materials(); await T.materials();
    if (FAST) { await T.ui(...UI.test); await T.ui(...UI.testItem(3)); await T.ui(...UI.testItem(4)); }
    const stats = { refusedOk: 0, refusedBad: 0, builtOk: 0, builtBad: 0, stopOk: 0, stopBad: 0, redOk: 0, redBad: 0 };
    const kinds = ['left', 'entering', 'curSide', 'next', 'nextSide'];
    for (let round = 0; round < ROUNDS; round++) {
      await T.closeCraft();
      await T.settle();
      const dest = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, p = s.player, cam = s.cameras.main; let best = null;
        for (let r = p.tile.row - 9; r <= p.tile.row + 9; r++) for (let c = p.tile.col - 9; c <= p.tile.col + 9; c++) {
          if (!m.isWalkable(c, r) || m.pickObject((c - r) * 40, (c + r) * 20)) continue;
          const sx = (c - r) * 40 - cam.worldView.x, sy = (c + r) * 20 - cam.worldView.y; if (sx < 100 || sy < 150 || sx > 1700 || sy > 700) continue;
          const path = window.__findPath(m.cols, m.rows, p.tile, { col: c, row: r }, p.costAt); if (!path || path.length < 8) continue;
          let diag = 0; for (let i = 1; i < path.length; i++) if (path[i].col !== path[i - 1].col && path[i].row !== path[i - 1].row) diag++;
          const score = diag * 2 + path.length + Math.random() * 6; if (!best || score > best.score) best = { c, r, score }; }
        return best; });
      if (!dest) { console.log('no destination'); break; }
      await T.tapTile(dest.c, dest.r, 0);
      await T.ui(...UI.craft, 60); await T.ui(...UI.card(2), 60);
      { const q = await T.g2p(500, 400); await page.mouse.move(q.x, q.y); await page.mouse.move(q.x + 3, q.y + 3); }   // leave the card (the engine eats the first move out of a UI element)
      const kind = kinds[round % kinds.length];
      // wait until the player is mid-step in a useful spot for this kind, then aim and click with the loop frozen
      let done = false;
      for (let tries = 0; tries < 80 && !done; tries++) {
        await T.freeze();
        const plan = await G((kind) => { const s = window.__game.scene.getScene('game'), p = s.player, b = s.build, m = s.map;
          if (!p.moving) return { stop: true };
          const A = p.tile, B = p.path[0], C = p.path[1];
          const frac = Math.hypot(p.col - A.col, p.row - A.row);
          if (frac < 0.15 || frac > 0.85) return null;             // mid-step
          const diag = (a, b) => a && b && a.col !== b.col && a.row !== b.row;
          let t = null, expect = null;
          if (kind === 'left') { t = A; expect = 'refused'; }
          else if (kind === 'entering') { t = B; expect = 'refused'; }
          else if (kind === 'curSide') { if (!diag(A, B)) return null; t = Math.random() < 0.5 ? { col: B.col, row: A.row } : { col: A.col, row: B.row }; expect = 'refused'; }
          else if (kind === 'next') { if (!C) return null; t = C; expect = 'built'; }
          else if (kind === 'nextSide') { if (!diag(B, C)) return null; t = Math.random() < 0.5 ? { col: C.col, row: B.row } : { col: B.col, row: C.row }; expect = 'built'; }
          if (!m.isOpen(t.col, t.row) || m.structureAt(t.col, t.row) || Math.hypot(t.col - p.col, t.row - p.row) > 7) return null;
          return { t, expect, A: A.col + ',' + A.row, B: B.col + ',' + B.row, C: C ? C.col + ',' + C.row : null, pos: [+p.col.toFixed(3), +p.row.toFixed(3)], can: b.canBuildAt(t.col, t.row) }; }, kind);
        if (plan && plan.stop) { await T.thaw(); break; }
        if (!plan) { await T.thaw(); await page.waitForTimeout(30); continue; }
        // hover first (overlay), then click
        const p = await T.w2p((plan.t.col - plan.t.row) * 40, (plan.t.col + plan.t.row) * 20);
        await page.mouse.move(p.x + 1, p.y); await page.mouse.move(p.x, p.y);
        const mark = await G(() => { const b = window.__game.scene.getScene('game').build; return b.marks[0].visible ? b.marks[0].texture.key : null; });
        await page.mouse.down(); await page.mouse.up();
        const built = await G((t) => { const x = window.__game.scene.getScene('game').map.structureAt(t.col, t.row); return !!x && x.type === 'fence'; }, plan.t);
        await T.thaw();
        done = true;
        const red = mark === 'overlay_no';
        if (plan.expect === 'refused') { if (!built) stats.refusedOk++; else { stats.refusedBad++; console.log('   BUILT ON BODY', J(plan)); }
          if (red) stats.redOk++; else { stats.redBad++; console.log('   overlay not red on body tile', mark, J(plan)); } }
        else { if (built) stats.builtOk++; else { stats.builtBad++; console.log('   not built on a free tile', mark, J(plan)); }
          if (!red) stats.redOk++; else { stats.redBad++; console.log('   overlay red on a free tile', J(plan)); } }
        await T.stopped();
        const st = await T.snap();
        if (plan.expect === 'built' && built) { if (st.tile === plan.B) stats.stopOk++; else { stats.stopBad++; console.log('   stopped at', st.tile, 'expected', plan.B, J(plan)); } }
        console.log(`round ${round} ${kind}: ${J(plan)} mark ${mark} built ${built} -> stopped at ${st.tile}`);
      }
      await T.stopped();
    }
    console.log('stats', J(stats));
    ok('never built on the body tiles', stats.refusedBad === 0 && stats.refusedOk > 0);
    ok('built on free tiles next to the body', stats.builtBad === 0 && stats.builtOk > 0);
    ok('overlay red/green as expected', stats.redBad === 0);
    ok('stops on the tile being entered when the next step is blocked', stats.stopBad === 0);
    const bad = await T.bad();
    ok('per-frame invariants', bad.length === 0, J(bad.slice(0, 4)));
    ok('no console errors', T.errors.length === 0, J(T.errors));
  } catch (e) { console.error('CRASH', e); fails++; }
  finally { await T.browser.close(); }
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
})();
