#!/bin/bash
# 새 묶음에서 모든 시험(Phase 2~6, 새 묶음 확인)을 하나씩
S=/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad
$S/fix3/run_regress.sh p6b/b1.js p6/t1.js p6/t2.js p6/t3.js p6/t4.js p6/t5.js p6/t6.js p5/t1.js p5/t2.js p5/t3.js p5/t4.js p5/t5.js p5/t6.js p2/t1.js p2/t2.js p2/t3.js p3/t1.js p3/t2.js p3/t3.js p4/t1.js p4/t2.js p4/t3.js p4/t4.js p4/t5.js p4/t6.js p4/t7.js p4/t8.js
cd $S/review6/logic
echo "== pfuzz"
for a in "1 4 30000 random {} n1x" "11 3 30000 16.7 {} n2" "21 3 25000 100 {} n3"; do set -- $a; timeout 2400 node pfuzz.js $1 $2 $3 $4 "$5" $6 2>&1 | grep -E "^seed|page errors|CRASH"; done
echo ALLDONE
