const { open } = require('../p4/lib.js');
(async () => {
  const T = await open({ w: 960, h: 600 });
  const r = await T.G(() => { const s = window.__game.scene.getScene('game'), m = s.map;
    const wx = (43 - 33) * 40, wy = (43 + 33) * 20; const o = m.pickObject(wx, wy);
    return { picked: o ? { kind: o.kind, col: o.col, row: o.row, node: !!o.node } : null }; });
  console.log(JSON.stringify(r)); await T.browser.close();
})();
