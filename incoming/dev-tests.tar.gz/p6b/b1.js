// 새 묶음 확인: 새 맵(철광석 10개, 철광 지대)과 새 주인공 시트가 잘 뜨는가. 철광석은 막고, 누르면 "아직 캘 수 없습니다". (실제 클릭)
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G, W } = T;
  const info = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, tex = s.textures.get('char_player');
    const iron = m.objects.filter((o) => o.kind === 'iron');
    return { objects: m.objects.length, iron: iron.map((o) => [o.col, o.row, o.key, o.blocks, o.tall, m.isWalkable(o.col, o.row)]),
      soil: (() => { let n = 0, walk = 0; for (let r = 0; r < 64; r++) for (let c = 0; c < 64; c++) if (s.mapData.terrain[r][c] === 5) { n++; if (m.isWalkable(c, r) || m.objectAt(c, r)) walk++; } return [n, walk]; })(),
      frames: tex.frameTotal - 1, fw: tex.get(0).width, pframe: s.player.sprite.frame.name, pw: s.player.sprite.width,
      want: (() => { const a = s.cache.json.get('manifest').assets.char_player; return { n: a.frames.length, fw: a.frameWidth }; })() }; });
  ok('the new map: 270 objects, 10 iron ores that block and are not tall', info.objects === 270 && info.iron.length === 10 && info.iron.every((x) => x[3] && !x[4] && !x[5]) && info.iron.every((x) => /^obj_iron_[12]$/.test(x[2])), J(info.iron));
  ok('the iron soil (35 tiles) is land', info.soil[0] === 35 && info.soil[1] === 35, J(info.soil));
  ok('the player sheet matches the manifest (all named frames, frame width)', info.frames >= info.want.n && info.fw === info.want.fw && info.pw === info.want.fw, J({ frames: info.frames, fw: info.fw, want: info.want }));
  // 철광석 쪽으로 걸어가서(땅 클릭) 철광석을 누른다
  await T.tapWorld((43 - 36) * 40, (43 + 36) * 20);
  await W(() => !window.__game.scene.getScene('game').player.moving, null, 60000);
  await page.waitForTimeout(1500);
  await G(() => { const s = window.__game.scene.getScene('game'); window.__n = []; s.events.on('notice', (t) => window.__n.push(t)); });
  const pt = await G(() => { const s = window.__game.scene.getScene('game'), o = s.map.objectAt(45, 30), sp = o.sprite;
    return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.4 }; });
  const before = await G(() => { const p = window.__game.scene.getScene('game').player; return [p.tile.col, p.tile.row]; });
  await T.tapWorld(pt.wx, pt.wy);
  await page.waitForTimeout(600);
  const after = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; return { tile: [p.tile.col, p.tile.row], moving: p.moving, action: !!p.action, n: window.__n }; });
  ok('tapping an iron ore shows "아직 캘 수 없습니다" and the player does not walk', J(after.n) === J(['아직 캘 수 없습니다']) && !after.moving && !after.action && J(after.tile) === J(before), J({ before, after }));
  await page.screenshot({ path: __dirname + '/b1_iron.png' });
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
