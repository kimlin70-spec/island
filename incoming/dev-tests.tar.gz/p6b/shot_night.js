// 사용자에게 보여 줄 그림: 바닷가 쪽(35,43)에서 본 첫 밤의 해적선, 보트, 상륙한 해적
const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch();
  const page = await (await browser.newContext({ viewport: { width: 960, height: 600 }, deviceScaleFactor: 2 })).newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('http://127.0.0.1:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  await page.waitForTimeout(500);
  await page.evaluate(() => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player;
    g.loop.sleep(); let t = performance.now();
    const step = (n) => { for (let i = 0; i < n; i++) { t += 1000 / 60; g.headlessStep(t, 1000 / 60); } window.__t = t; };
    s.enemies.spawn = () => null;                              // 그림을 깔끔하게: 좀비는 끈다
    p.col = 35; p.row = 43; p.tile = { col: 35, row: 43 }; p.path.length = 0; p.syncSprite();
    s.cameras.main.centerOn(p.sprite.x, p.sprite.y);
    s.debugNight();
    step(60 * 69);                                             // 상륙 직후(밤 69초)
  });
  await page.evaluate(() => { const g = window.__game; window.__t += 1000 / 60; g.step(window.__t, 1000 / 60); });
  await page.waitForTimeout(300);
  await page.screenshot({ path: __dirname + '/night_pirates.png' });
  console.log('errors', JSON.stringify(errors));
  await browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
