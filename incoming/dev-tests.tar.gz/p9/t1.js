// Phase 9 확인 1: 짓기 반경 원(사용자 요청), 총 카드, 주인공의 총
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
const near = (a, b, t) => Math.abs(a - b) <= t;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.sleep(); await T.run(2);
  // 0) 짓기 반경 원 (1단계)
  const r0 = await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.debugGive();
    const ring = () => { const r = s.build.reachRing; return { v: r.visible, x: r.x, y: r.y, w: Math.round(r.displayWidth), h: Math.round(r.displayHeight), d: r.depth }; };
    window.__ring = ring; const before = ring(); s.build.setMode('fence'); return { before }; });
  await T.run(1);
  const r1 = await G(() => { const s = window.__S, p = s.player, w = { x: (p.col - p.row) * 40, y: (p.col + p.row) * 20 }; return { ring: window.__ring(), w }; });
  ok('reach circle: hidden normally; in fence mode a 7-tile circle (792x396) on the player at floor depth', !r0.before.v && r1.ring.v && r1.ring.x === r1.w.x && r1.ring.y === r1.w.y && near(r1.ring.w, 792, 1) && near(r1.ring.h, 396, 1) && r1.ring.d === 3, J({ r0, r1 }));
  // 원 밖의 칸은 overlay_no, 안의 빈 칸은 overlay_ok (원과 규칙이 맞는다)
  const edge = await G(() => { const s = window.__S, p = s.player.tile; const out = [];
    for (let dc = -9; dc <= 9; dc++) for (let dr = -9; dr <= 9; dr++) { const c = p.col + dc, r = p.row + dr;
      if (!s.map.isOpen(c, r) || s.map.anyStructureAt(c, r) || s.characterTiles().some((t) => t.col === c && t.row === r)) continue;
      const inside = Math.hypot(dc, dr) <= 7; if (s.build.canBuildAt(c, r) !== inside) out.push([dc, dr]); } return out; });
  ok('free tiles inside the circle are buildable and outside are not', edge.length === 0, J(edge));
  // 걸으면 원이 따라간다
  await G(() => { const s = window.__S, p = s.player.tile; for (const [dc, dr] of [[2, 0], [0, 2], [-2, 0], [0, -2]]) if (s.player.goTo(p.col + dc, p.row + dr)) return; });
  await T.run(10);
  const r2 = await G(() => { const s = window.__S, p = s.player; return { ring: window.__ring(), w: { x: (p.col - p.row) * 40, y: (p.col + p.row) * 20 }, moving: p.moving }; });
  ok('while walking in build mode the circle follows the player', r2.moving && r2.ring.v && near(r2.ring.x, r2.w.x, 0.01) && near(r2.ring.y, r2.w.y, 0.01), J(r2));
  await G(() => window.__S.build.setMode('remove')); await T.run(1);
  const r3 = await G(() => window.__ring().v);
  await G(() => window.__S.build.setMode(null)); await T.run(1);
  const r4 = await G(() => window.__ring().v);
  ok('remove mode (no reach limit) and no mode: circle hidden', !r3 && !r4, J({ r3, r4 }));
  await T.run(60);

  // 1) 2단계: 총 카드
  const c = await G(() => { const s = window.__S; s.startStage2(); s.debugGive();
    const u = window.__game.scene.getScene('ui'); const card = s.cardsFor ? null : null;
    const iron0 = s.inventory.count('iron'), wood0 = s.inventory.count('wood');
    const { cardsFor } = window.__mods || {}; return { iron0, wood0 }; });
  const card = await G(() => { const s = window.__S; return import('/src/systems/Crafting.js').then((m) => { const cards = m.cardsFor(2); const gun = cards[2];
    const st = s.cardState(gun); s.pressCard(gun); return { id: gun.id, icon: gun.icon, st, st2: s.cardState(gun), tools: s.tools.slice(), equip: s.equipment(), todo: s.todo.isDone('gun'),
      iron: s.inventory.count('iron'), wood: s.inventory.count('wood') }; }); });
  ok('gun card (3rd on the top row) costs iron 3 + wood 2, then shows as owned; gun in the equipment; to-do 2 checked',
    card.id === 'gun' && card.icon === 'icon_gun' && card.st === 'ok' && card.st2 === 'owned' && card.tools.includes('gun') && card.equip.includes('gun') && card.todo && card.iron === c.iron0 - 3 && card.wood === c.wood0 - 2, J({ c, card }));
  await T.run(2);
  const ui = await G(() => { const u = window.__game.scene.getScene('ui'); return { icons: u.equipIcons.map((i) => i.texture.key) }; });
  ok('the equipment bar shows icon_gun', ui.icons.includes('icon_gun'), J(ui));

  // 2) 사거리 안의 적: 그 자리에서 쏜다(겨누기 0.25초 -> 쏘기 0.15초, 불꽃, 총알, 피해 2). 1.4초마다.
  const set = await G(() => { const s = window.__S, p = s.player; p.path = []; p.stopAction();
    const P = p.tile; let at = null;
    for (const [dc, dr] of [[4, 0], [0, 4], [-4, 0], [0, -4], [3, 2], [-3, -2]]) if (s.map.isWalkable(P.col + dc, P.row + dr)) { at = { col: P.col + dc, row: P.row + dr }; break; }
    const z = window.__z = s.enemies.add('zombie', at); z.hp = 99; z.repathLeft = 1e9; z.wantPath = false; z.goalKey = 'x'; z.mayRepath = false;
    z.update = function (dt) { this.body.tick(dt); this.syncSprite(true); };   // 서 있기만
    window.__log = []; window.__hits = []; const oh = z.hurt.bind(z); z.hurt = (n, f) => { window.__hits.push([+s.elapsed.toFixed(3), n, f === s.player]); return oh(n, f); };
    s.events.on('postupdate', () => { const fr = s.map.assets.char_player.frames[+p.sprite.frame.name];
      const mz = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_muzzle'); const b = s.shots.list.filter((x) => x.kind === 'bullet');
      window.__log.push({ t: +s.elapsed.toFixed(3), fr, mz: mz.length, mzFlip: mz.length ? mz[0].flipX : null, mzx: mz.length ? mz[0].x : null, mzy: mz.length ? mz[0].y : null,
        b: b.length, fl: s.shots.flashes.length, pc: [p.col, p.row], flip: p.sprite.flipX, spx: p.sprite.x, spy: p.sprite.y }); });
    const t0 = s.elapsed; s.pressEnemy(z); return { at, P, t0 }; });
  await T.run(60 * 4);
  const sh = await G(() => ({ log: window.__log, hits: window.__hits, hp: window.__z.hp }));
  const p0 = sh.log[0].pc, moved = sh.log.some((l) => l.pc[0] !== p0[0] || l.pc[1] !== p0[1]);
  const firstGun2 = sh.log.find((l) => l.fr === 'gun2' || l.fr === 'bgun2'), firstGun1 = sh.log.find((l) => l.fr === 'gun1' || l.fr === 'bgun1');
  const muzzle = sh.log.filter((l) => l.mz > 0);
  const shotsAt = []; sh.log.forEach((l, i) => { if (l.mz > 0 && (i === 0 || sh.log[i - 1].mz === 0)) shotsAt.push(l.t); });
  const gaps = shotsAt.slice(1).map((x, i) => +(x - shotsAt[i]).toFixed(3));
  ok('in range: the player does not walk, aims (gun1) then fires (gun2) 0.25 s later', !moved && firstGun1 && firstGun2 && near(firstGun2.t - firstGun1.t, 0.25, 0.02), J({ moved, g1: firstGun1 && firstGun1.t, g2: firstGun2 && firstGun2.t }));
  ok('every shot: muzzle flash at the gun2 muzzle, flash light, a bullet; one shot every 1.4 s', shotsAt.length >= 3 && gaps.every((g) => near(g, 1.4, 0.02)) && sh.log.some((l) => l.fl > 0) && sh.log.some((l) => l.b > 0), J({ shotsAt, gaps }));
  const m1 = muzzle[0], mz = await G(() => window.__S.map.assets.char_player.muzzle);
  const want = m1 && { x: m1.spx + (m1.flip ? -mz.gun2[0] : mz.gun2[0]), y: m1.spy + mz.gun2[1] };
  ok('muzzle flash sits on the muzzle (gun2 or bgun2, flipped when facing left)', m1 && ((near(m1.mzx, want.x, 0.5) && near(m1.mzy, want.y, 0.5)) || (near(m1.mzx, m1.spx + (m1.flip ? -mz.bgun2[0] : mz.bgun2[0]), 0.5) && near(m1.mzy, m1.spy + mz.bgun2[1], 0.5))) && m1.mzFlip === m1.flip, J({ m1, want }));
  ok('each bullet hits for 2 (from the player)', sh.hits.length >= 3 && sh.hits.every((h) => h[1] === 2 && h[2]), J(sh.hits));
  const flightOk = sh.hits.length && shotsAt.length && sh.hits[0][0] > shotsAt[0];
  ok('damage lands when the bullet arrives (after the shot)', flightOk, J({ hit0: sh.hits[0], shot0: shotsAt[0] }));

  // 3) 사거리 밖: 사거리 안까지 걸어가서 쏜다
  const far = await G(() => { const s = window.__S, p = s.player, z = window.__z; p.stopAction(); p.path = [];
    const P = p.tile; let at = null;
    for (const [dc, dr] of [[9, 0], [0, 9], [-9, 0], [0, -9], [7, 6], [-7, -6]]) if (s.map.isWalkable(P.col + dc, P.row + dr)) { at = { col: P.col + dc, row: P.row + dr }; break; }
    z.col = at.col; z.row = at.row; z.tile = { ...at }; z.syncSprite(true); window.__hits.length = 0; s.pressEnemy(z); return { at, P }; });
  await T.until('const p = s.player; return !p.moving && p.swing;', 600);
  const fr = await G(() => { const s = window.__S, p = s.player, z = window.__z; return { pc: [p.col, p.row], d: Math.hypot(z.col - p.col, z.row - p.row) }; });
  await T.run(30);
  const fh = await G(() => window.__hits.length);
  ok('out of range (9 tiles): walks until inside 5 tiles, stops there and shoots', fr.d <= 5 && fr.d > 4 && fh >= 1, J({ far, fr, fh }));

  // 4) 가만히 서 있는데 사거리 안에 적이 오면 자동으로 쏜다(가장 가까운 적)
  const auto = await G(() => { const s = window.__S, p = s.player; p.stopAction(); p.path = []; p.cooldown = 0; s.enemies.remove(window.__z);
    const P = p.tile; const mk = (dc, dr) => { const c = P.col + dc, r = P.row + dr; if (!s.map.isWalkable(c, r)) return null; const z = s.enemies.add('zombie', { col: c, row: r }); z.hp = 99; z.update = function (dt) { this.body.tick(dt); this.syncSprite(true); }; return z; };
    let a = null, b = null; for (const [d1, d2] of [[[3, 0], [0, 4]], [[0, 3], [4, 0]], [[-3, 0], [0, -4]], [[2, 2], [-3, -3]]]) { if (s.map.isWalkable(P.col + d1[0], P.row + d1[1]) && s.map.isWalkable(P.col + d2[0], P.row + d2[1])) { a = mk(...d1); b = mk(...d2); break; } }
    window.__a = a; window.__b = b; const far = mk(6, 0) || mk(0, 6); window.__far = far; return { a: !!a, b: !!b }; });
  await T.run(60);
  const au = await G(() => ({ a: window.__a.hp, b: window.__b.hp, far: window.__far ? window.__far.hp : null, act: window.__S.player.action && window.__S.player.action.target === window.__a }));
  ok('standing still: shoots the nearest enemy in range automatically (not one out of range)', au.a === 97 && au.b === 99 && (au.far === null || au.far === 99) && au.act, J(au));

  // 4b) 저절로 쏘던 적이 사거리를 벗어나도 따라가지 않는다(검토 3). 눌러서 고른 적은 따라간다.
  const lv = await G(() => { const s = window.__S, p = s.player, a = window.__a; for (const e of [...s.enemies.list]) if (e !== a) s.enemies.remove(e);
    window.__p0 = { col: p.tile.col, row: p.tile.row }; const P = p.tile; let at = null;
    for (const [dc, dr] of [[8, 0], [0, 8], [-8, 0], [0, -8]]) if (s.map.isWalkable(P.col + dc, P.row + dr)) { at = { col: P.col + dc, row: P.row + dr }; break; }
    a.col = at.col; a.row = at.row; a.tile = { ...at }; return { chase: p.action && p.action.chase }; });
  await T.run(90);
  const lv2 = await G(() => { const p = window.__S.player; return { pc: [p.col, p.row], p0: window.__p0, act: !!p.action, moving: p.moving }; });
  ok('auto-fire: when its target leaves range the player stays put', lv.chase === false && lv2.pc[0] === lv2.p0.col && lv2.pc[1] === lv2.p0.row && !lv2.moving, J({ lv, lv2 }));
  await G(() => { const s = window.__S; s.pressEnemy(window.__a); });
  await T.run(30);
  const lv3 = await G(() => { const p = window.__S.player; return { moving: p.moving, chase: p.action && p.action.chase }; });
  ok('pressing that enemy makes the player go after it', lv3.chase === true && lv3.moving, J(lv3));
  // 4c) 왼쪽을 보고 쏘면 총구 불꽃이 총구에서 왼쪽으로 뻗는다(검토 1)
  const fl = await G(() => { const s = window.__S; s.shots.muzzle(500, 500, { flip: true }); s.shots.muzzle(700, 500, { flip: false });
    const ims = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_muzzle').slice(-2).map((o) => { const b = o.getBounds(); return { l: +b.left.toFixed(1), r: +b.right.toFixed(1), flip: o.flipX }; }); return ims; });
  const L = fl.find((f) => f.flip), R = fl.find((f) => !f.flip);
  ok('muzzle flash: facing right it starts at the muzzle and goes right; facing left it ends at the muzzle and goes left', L && R && near(L.r, 500, 4) && L.l < 470 && near(R.l, 700, 4) && R.r > 730, J(fl));
  const rc = await G(() => window.__S.build.reachRing.tintTopLeft.toString(16));
  ok('reach circle is green (0x7fd858)', rc === '7fd858', rc);

  // 5) 나무 베기는 그대로 도끼/단검으로
  const tr = await G(() => { const s = window.__S; for (const e of [...s.enemies.list]) s.enemies.remove(e); s.player.stopAction(); return s.nodes.toolFor({ node: { group: 'tree' } }); });
  ok('trees are still cut with a blade, not the gun', tr === 'dagger' || tr === 'axe', J(tr));
  await page.screenshot({ path: __dirname + '/p9_t1.png' });
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
