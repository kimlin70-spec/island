const { setup, J } = require('../p6/lib6.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 }); const { G } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.startStage2(); s.clock.startNight(); s.enemies.schedule = []; s.debugPirates();
    for (const e of [...s.enemies.list]) if (e.kind !== 'pirate_3') s.enemies.remove(e); const g = window.__g = s.enemies.list[0]; const P = s.player.tile; const at = { col: P.col + 9, row: P.row };
    g.col = at.col; g.row = at.row; g.tile = { ...at }; g.path = []; g.wantPath = true; g.repathLeft = 0; window.__walk = s.map.isWalkable(at.col, at.row); });
  console.log('walkable', await G(() => window.__walk));
  for (let i = 0; i < 6; i++) { await T.run(30); console.log(J(await G(() => { const g = window.__g, s = window.__S, p = s.player; return { pc: [+g.col.toFixed(2), +g.row.toFixed(2)], path: g.path.length, want: g.wantPath, rl: +g.repathLeft.toFixed(2), alive: g.alive, rising: g.rising, d: +Math.hypot(g.col - p.col, g.row - p.row).toFixed(2), gun: g.gun, fr: s.map.assets.char_pirate_3.frames[+g.sprite.frame.name], list: s.enemies.list.length }; }))); }
  console.log(J(T.errors)); await T.browser.close();
})();
