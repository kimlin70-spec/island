// 밤: 탑 둘, 총을 든 주인공, 총잡이 해적. 쏘는 순간을 찍는다
const { setup, J } = require('../p6/lib6.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 }); const { G, page } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); window.__G = s; s.enemies.schedule = []; s.startStage2(); s.debugGive(); s.debugGive(); s.tools.push('gun'); s.events.emit('tools-changed');
    const p = s.player.tile; const put = (type, dc, dr) => { const t = { col: p.col + dc, row: p.row + dr }; if (s.build.canBuildAt(t.col, t.row)) { const st = s.build.place(type, [t]); s.onBuilt(st); } };
    put('watchtower', 2, -3); put('guntower', -3, 1); for (let i = -2; i <= 2; i++) put('wire', 4, i);
    s.hurtPlayer = () => true; s.clock.startNight(); s.enemies.schedule = []; s.debugPirates();
    for (const e of s.enemies.list) e.hp = 99;
    for (const [dc, dr] of [[6, -2], [5, 4], [-5, -4]]) { const z = s.enemies.add('zombie', { col: p.col + dc, row: p.row + dr }); z.hp = 99; } });
  for (let i = 0; i < 1200; i++) { await T.run(1); const ok = await G(() => { const s = window.__G; const g = s.enemies.list.find((e) => e.kind === 'pirate_3');
    const m = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_muzzle').length; return g && g.gun && g.gun.t > 0.6 && g.gun.t < 0.66 && m >= 1 && s.shots.list.length >= 2; }); if (ok) break; }
  await T.run(1);
  await page.screenshot({ path: __dirname + '/p9_night.png' });
  console.log(J(T.errors)); await T.browser.close();
})();
