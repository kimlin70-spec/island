// Phase 9 확인 2: 총잡이 해적, 해적 부르기
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
const near = (a, b, t) => Math.abs(a - b) <= t;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.sleep(); await T.run(2);
  // 0) 1단계의 해적 상륙에는 총잡이가 없다
  const s1 = await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.clock.startNight(); s.enemies.schedule = [];
    s.pirates.land(); const kinds = s.enemies.list.map((e) => e.kind); window.__hp1 = s.enemies.list.map((e) => e.hp); const z = s.enemies.add('zombie', { col: 1, row: 1 }); window.__hp1.push(z.hp); for (const e of [...s.enemies.list]) s.enemies.remove(e); return kinds; });
  ok('stage 1: pirates land without a gunner', s1.length === 2 && !s1.includes('pirate_3'), J(s1));
  const hp1 = await G(() => window.__hp1);
  ok('stage 1 keeps the spec health (pirates 4, zombie 3)', hp1.join() === '4,4,3', J(hp1));
  // 1) 시험용 창: 2단계에 "해적 부르기"
  await G(() => { const s = window.__S; s.clock.startMorning(); s.resultPending = false; s.startStage2(); });
  await T.run(200);
  const labels = await G(() => window.__game.scene.getScene('ui').debugLabels.map((d) => d.label.text));
  ok('stage 2 test window has "해적 부르기"', labels.includes('해적 부르기') && labels.length === 7, J(labels));
  const day = await G(() => { const s = window.__S; s.debugPirates(); return s.enemies.list.length; });
  ok('"해적 부르기" in the day does nothing', day === 0, J(day));
  // 2) 밤에 부르면 배, 보트, 해적 둘과 총잡이 하나가 바로
  const call = await G(() => { const s = window.__S; s.hurtPlayer = s.hurtPlayer.bind(s); s.clock.startNight(); s.enemies.schedule = [];
    s.debugPirates(); const P = s.pirates; return { kinds: s.enemies.list.map((e) => e.kind), ship: P.ship.visible && P.ship.alpha === 1, boat: P.boat.visible, landDue: P.landDue }; });
  ok('at night it brings the ship and boat at once and lands 2 pirates + 1 gunner', call.ship && call.boat && !call.landDue && call.kinds.filter((k) => k === 'pirate_3').length === 1 && call.kinds.length === 3, J(call));
  // 총잡이만 남기고 주인공 근처로
  const g0 = await G(() => { const s = window.__S, p = s.player; for (const e of [...s.enemies.list]) if (e.kind !== 'pirate_3') s.enemies.remove(e);
    const g = window.__g = s.enemies.list[0]; const P = p.tile; let at = null;
    for (const [dc, dr] of [[9, 0], [0, 9], [-9, 0], [0, -9]]) if (s.map.isWalkable(P.col + dc, P.row + dr)) { at = { col: P.col + dc, row: P.row + dr }; break; }
    g.col = at.col; g.row = at.row; g.tile = { ...at }; g.path = []; g.wantPath = true; g.repathLeft = 0;
    window.__ev = []; window.__hearts = []; const hp0 = s.hearts.value;
    s.events.on('postupdate', () => { const fr = s.map.assets.char_pirate_3.frames[+g.sprite.frame.name];
      window.__ev.push({ t: +s.elapsed.toFixed(3), fr, pc: [g.col, g.row], mv: g.moving, b: s.shots.list.filter((x) => !x.homing).length, mz: s.children.list.filter((o) => o.texture && o.texture.key === 'fx_muzzle').length,
        d: Math.hypot(g.col - p.col, g.row - p.row), hearts: s.hearts.value, flip: g.sprite.flipX }); });
    return { at, P, hp0, speed: g.cfg.speed, hp: g.hp }; });
  ok('gunner: hp 3 x 2 (stage-2 difficulty) = 6, speed 1.6', g0.speed === 1.6 && g0.hp === 6, J(g0));
  const hpx = await G(() => { const s = window.__S; const z = s.enemies.add('zombie', { col: 1, row: 1 }); const pr = s.enemies.add('pirate_1', { col: 1, row: 2 });
    const out = { z: [z.hp, z.maxHp], p: [pr.hp, pr.maxHp], gt: (window.__cfg || {}).x }; s.enemies.remove(z); s.enemies.remove(pr); return out; });
  ok('stage 2: zombies 6 hp and pirates 8 hp (2x)', hpx.z[0] === 6 && hpx.z[1] === 6 && hpx.p[0] === 8 && hpx.p[1] === 8, J(hpx));
  console.log('until', J(await T.until('const q = window.__g; return !q.moving && q.gun;', 60 * 10)));
  console.log(J(await G(() => { const g = window.__g, s = window.__S, p = s.player; return { pc: [g.col, g.row], path: g.path.length, alive: g.alive, inList: s.enemies.list.includes(g), d: Math.hypot(g.col - p.col, g.row - p.row), pl: [p.col, p.row], night: s.clock.isNight, ev: window.__ev.length, active: window.__game.scene.isActive('game') }; })));
  await T.run(60 * 6);
  const ev = await G(() => window.__ev);
  const stopAt = ev.find((e) => !e.mv);
  const shots = []; ev.forEach((e, i) => { if (e.mz > 0 && (i === 0 || ev[i - 1].mz === 0)) shots.push(e.t); });
  const gaps = shots.slice(1).map((x, i) => +(x - shots[i]).toFixed(3));
  const aimStart = ev.find((e) => e.fr === 'aim');
  ok('walks toward the player and stops once within 4.5 tiles', stopAt && stopAt.d <= 4.5 && stopAt.d > 3.4, J(stopAt));
  ok('aims (aim) for 0.6 s, then shoots (shoot + muzzle flash); one shot every 2.6 s', aimStart && shots.length >= 2 && near(shots[0] - aimStart.t, 0.6, 0.04) && gaps.every((g) => near(g, 2.6, 0.02)), J({ aim: aimStart && aimStart.t, shots, gaps }));
  const seq = [...new Set(ev.filter((e) => e.t >= shots[0] - 0.7 && e.t < shots[0] + 2.0).map((e) => e.fr))];
  ok('picture order: aim -> shoot -> reload', seq.join(',').includes('aim,shoot,reload'), J(seq));
  const lost = ev.filter((e, i) => i && e.hearts < ev[i - 1].hearts);
  ok('a player who stands still is hit: 1 heart per shot, after the bullet flies (900 px/s)', lost.length >= 2 && lost[0].t > shots[0] && lost[0].t - shots[0] < 0.4, J({ lost: lost.map((l) => l.t), shots }));
  // 3) 겨누는 동안 움직이면 피한다
  const dodge = await G(() => { const s = window.__S; s.hearts.value = 5; window.__ev.length = 0; window.__dust = 0;
    const of = s.shots.dust.bind(s.shots); s.shots.dust = (w) => { window.__dust++; of(w); }; return true; });
  await T.until('const q = window.__g; return q.gun && !q.gun.shot && q.gun.t > 0.1;', 60 * 5);
  await G(() => { const s = window.__S, p = s.player, P = p.tile; for (const [dc, dr] of [[0, 4], [4, 0], [0, -4], [-4, 0], [0, 3], [3, 0]]) if (p.goTo(P.col + dc, P.row + dr)) return; });
  await T.until('const q = window.__g; return q.gun && q.gun.shot;', 120);
  await T.run(40);
  const dg = await G(() => ({ hearts: window.__S.hearts.value, dust: window.__dust, moved: window.__S.player.tile }));
  ok('moving during the aim (and still moving when it lands) dodges the bullet (no heart lost, dust where it lands)', dg.hearts === 5 && dg.dust >= 1, J(dg));
  // 4) 텐트 안이면 텐트를 쏜다(피해 2, 반드시 맞음)
  const tent = await G(() => { const s = window.__S, p = s.player, g = window.__g; p.stopAction(); p.path = [];
    const P = p.tile; let at = null;
    for (const [dc, dr] of [[1, 1], [-2, 1], [1, -2], [-2, -2], [2, 2]]) { const t = [{ col: P.col + dc, row: P.row + dr }, { col: P.col + dc + 1, row: P.row + dr }, { col: P.col + dc, row: P.row + dr + 1 }, { col: P.col + dc + 1, row: P.row + dr + 1 }];
      if (t.every((x) => s.build.canBuildAt(x.col, x.row))) { at = t; break; } }
    if (!at) return null; const tn = window.__tent = s.build.place('tent', at); s.rest.enter(tn); window.__th = []; const od = s.build.damage.bind(s.build);
    s.build.damage = (st, n, f) => { window.__th.push([st.type, n, f === g]); return od(st, n, f); }; window.__ev.length = 0; return { hp: tn.hp }; });
  await T.run(60 * 6);
  const th = await G(() => ({ th: window.__th, hp: window.__tent.hp, resting: window.__S.rest.resting, d: (() => { const g = window.__g, t = window.__tent.tiles; const c = (t[0].col + t[3].col) / 2, r = (t[0].row + t[3].row) / 2; return Math.hypot(g.col - c, g.row - r); })() }));
  ok('player in the tent: the gunner shoots the tent, 2 damage each, always hits', tent && th.th.length >= 1 && th.th.every((x) => x[0] === 'tent' && x[1] === 2 && x[2]) && (!th.resting || th.hp === tent.hp - 2 * th.th.length), J({ tent, th }));
  // 5) 탑과 주인공은 총잡이도 공격한다 / 아침에 날던 총알은 사라진다
  const tw = await G(() => { const s = window.__S; s.rest.exit && s.rest.resting && s.rest.exit(); return s.towers.pickTarget ? true : false; });
  const mo = await G(() => { const s = window.__S; s.shots.straight({ x: 0, y: 0 }, { x: 500, y: 500 }, 100, () => { window.__late = true; }); s.debugMorning(); return s.shots.list.filter((x) => x.hostile).length; });
  await T.run(60 * 8);
  const late = await G(() => !!window.__late);
  ok('morning: gunner bullets still flying are removed', mo === 0 && !late, J({ mo, late }));
  await page.screenshot({ path: __dirname + '/p9_t2.png' });
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
