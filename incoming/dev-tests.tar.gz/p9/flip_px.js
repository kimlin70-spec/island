// 총구 불꽃이 실제로 그려지는 가로 범위(픽셀): 오른쪽 / 왼쪽(Shots.muzzle 그대로, 4배)
const { setup, J } = require('../p6/lib6.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 }); const { G } = T;
  await T.sleep(); await T.run(2);
  const grab = () => G(() => new Promise((res) => { const g = window.__game; g.renderer.snapshotArea(760, 400, 400, 100, (img) => {
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d'); x.drawImage(img, 0, 0);
    res(Array.from(x.getImageData(0, 0, c.width, c.height).data)); }); window.__S.t += 0.0001; g.step(window.__S.t, 0.0001); }));
  await G(() => { const cam = window.__game.scene.getScene('game').cameras.main; cam.stopFollow(); window.__c = { x: cam.scrollX, y: cam.scrollY }; });
  await T.run(1); const base = await grab();
  const out = {};
  for (const flip of [false, true]) {
    await G((flip) => { const s = window.__game.scene.getScene('game'), cam = s.cameras.main; if (window.__m) window.__m.destroy();
      s.shots.muzzle(cam.scrollX + 960 / cam.zoom, cam.scrollY + 450 / cam.zoom, { flip }); const m = window.__m = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_muzzle').pop(); m.setScale(4); }, flip);
    await T.run(1); const px = await grab(); let lo = 1e9, hi = -1;
    for (let i = 0; i < px.length; i += 4) { const d = Math.abs(px[i] - base[i]) + Math.abs(px[i + 1] - base[i + 1]) + Math.abs(px[i + 2] - base[i + 2]); if (d > 40) { const x = (i / 4) % 400 + 760; lo = Math.min(lo, x); hi = Math.max(hi, x); } }
    out[flip ? 'left' : 'right'] = [lo, hi];
  }
  console.log('muzzle point x = 960', J(out)); await T.browser.close();
})();
