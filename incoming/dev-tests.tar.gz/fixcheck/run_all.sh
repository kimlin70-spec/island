#!/bin/bash
# 회귀 시험 묶음: 세 개씩 나란히 돌린다
cd "$(dirname "$0")/.."
run() { local name=$1; shift; timeout 900 node "$@" > fixcheck/$name.out 2>&1; echo "$name exit $?" >> fixcheck/summary.txt; }
: > fixcheck/summary.txt
run p4_t2 p4/t2.js & run p4_t3 p4/t3.js & run p4_t4 p4/t4.js & wait
run p4_t5 p4/t5.js & run p2_t2 p2/t2.js & run p2_t3 p2/t3.js & wait
run p3_t2 p3/t2.js & run p3_t3 p3/t3.js & run lg_v1 review/verify-logic/v1_ui.js & wait
run lg_v2 review/verify-logic/v2_wall.js & run lg_v3 review/verify-logic/v3_inprogress.js & run sp_v3 review/verify-spec/v3.js & wait
echo DONE >> fixcheck/summary.txt
