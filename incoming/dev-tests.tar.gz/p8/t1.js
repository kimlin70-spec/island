// Phase 8 확인 1: 망루와 총 타워
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
const near = (a, b, t) => Math.abs(a - b) <= t;
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.sleep(); await T.run(2);
  // 자리: 주인공에서 3칸 오른쪽 아래
  const spot = await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.startStage2(); s.debugGive(); s.debugGive();
    s.pressEnemy = () => {}; s.hurtPlayer = () => false; const p = s.player.tile;
    for (const [dc, dr] of [[3, 0], [0, 3], [-3, 0], [0, -3], [2, 2]]) if (s.build.canBuildAt(p.col + dc, p.row + dr)) return { col: p.col + dc, row: p.row + dr };
    return null; });
  // 1) 짓기: 사거리 원, 받침+포탑
  const b = await G((t) => { const s = window.__S; s.build.setMode('watchtower'); const wx = (t.col - t.row) * 40, wy = (t.col + t.row) * 20;
    s.build.point(wx, wy); const r = s.build.range; const ring = { vis: r.visible, w: Math.round(r.displayWidth), h: Math.round(r.displayHeight), x: r.x, y: r.y, depth: r.depth };
    s.pressing = true; s.build.commit(wx, wy); s.build.setMode(null);
    const tw = window.__tw = s.map.structureAt(t.col, t.row); const A = s.map.assets.build_watchtower;
    return { ring, hint: null, type: tw && tw.type, tur: tw && { x: tw.turret.x, y: tw.turret.y, depth: tw.turret.depth, frame: s.map.assets.turret_bow.frames[+tw.turret.frame.name] },
      base: { x: tw.sprite.x, y: tw.sprite.y, depth: tw.sprite.depth }, mount: A.mount, todo: s.todo.isDone('watchtower'), wood: s.inventory.count('wood'), walk: s.map.isWalkable(t.col, t.row), ringAfter: s.build.range.visible }; }, spot);
  ok('while building a watchtower the range circle (113.1x5 by 56.6x5) is on the tile', b.ring.vis && near(b.ring.w, 565.5, 1) && near(b.ring.h, 283, 1) && b.ring.depth === 3, J(b.ring));
  ok('built: base + turret at base + mount, turret depth base + 0.5, facing down (load4); blocks the way; to-do 3 checked; costs wood 8',
    b.type === 'watchtower' && b.tur.x === b.base.x + b.mount[0] && b.tur.y === b.base.y + b.mount[1] && b.tur.depth === b.base.depth + 0.5 && b.tur.frame === 'load4' && !b.walk && b.todo && b.wood === 40 - 8 && !b.ringAfter, J(b));
  // 2) 탑을 누르면 사거리 원 2초
  await G((t) => { const s = window.__S; const sp = window.__tw.sprite; s.onPress({ wasTouch: true, worldX: sp.x, worldY: sp.y - 60 }); }, spot);
  const r1 = await G(() => window.__S.build.range.visible);
  await T.run(60 * 2 + 5);
  const r2 = await G(() => window.__S.build.range.visible);
  ok('tapping a built tower shows its range for 2 s', r1 && !r2, J({ r1, r2 }));
  // 3) 사거리 밖의 좀비는 쏘지 않는다. 안으로 오면 돌아가서 쏜다. 1.1초마다, 화살은 맞으면 피해 1
  const z = await G((t) => { const s = window.__S; const z = window.__z = s.enemies.add('zombie', { col: t.col + 6, row: t.row }); z.hp = 99; z.repathLeft = 999; z.wantPath = false; z.goalKey = 'x';
    window.__shots = []; window.__hits = []; const T = s.towers; const of = T.fire.bind(T); T.fire = (tw) => { window.__shots.push(+s.elapsed.toFixed(3)); of(tw); };
    const oh = z.hurt.bind(z); z.hurt = (n, f) => { window.__hits.push([+s.elapsed.toFixed(3), n]); return oh(n, f); }; return true; }, spot);
  await T.run(60);
  const out = await G(() => ({ shots: window.__shots.length }));
  ok('a zombie 6 tiles away (range 5) is not shot', out.shots === 0, J(out));
  await G((t) => { const z = window.__z; z.col = t.col + 3; z.row = t.row - 1; z.tile = { col: z.col, row: z.row }; z.path = []; }, spot);
  await T.run(60 * 4);
  const sh = await G(() => { const s = window.__S, tw = window.__tw; return { shots: window.__shots.slice(), hits: window.__hits.slice(), dir: tw.dir, want: s.towers.dirTo(s.towers.foot(tw), window.__z.foot()), hp: window.__z.hp }; });
  const gaps = sh.shots.slice(1).map((x, i) => +(x - sh.shots[i]).toFixed(3));
  ok('inside range: the crossbow turns toward the zombie and shoots every 1.1 s; each arrow hits for 1', sh.dir === sh.want && sh.shots.length >= 3 && gaps.every((g) => near(g, 1.1, 0.02)) && sh.hits.length >= 3 && sh.hits.every((h) => h[1] === 1), J({ sh, gaps }));
  // 화살 비행: 곡선, 화살 끝이 날아가는 쪽
  const fl = await G(() => { const s = window.__S; const p = s.shots.list[0]; if (!p) return null; return { kind: p.kind, h: p.h, rot: p.sprite.rotation, t: p.t }; });
  ok('the arrow flies in an arc (height = min(60, dist x 0.25))', !fl || (fl.kind === 'arrow' && fl.h > 0 && fl.h <= 60), J(fl));
  // 4) 총 타워: 불꽃, 연기, 빛, 반동, 피해 3
  const g = await G((t) => { const s = window.__S; const p = s.player.tile; let at = null;
    for (const [dc, dr] of [[-3, 0], [0, -3], [-2, -2], [3, 3]]) if (s.build.canBuildAt(p.col + dc, p.row + dr)) { at = { col: p.col + dc, row: p.row + dr }; break; }
    const gt = window.__gt = s.build.place('guntower', [at]); s.onBuilt(gt); window.__gfx = []; window.__gl = 0;
    s.events.on('postupdate', () => { const n = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_muzzle').length; const p2 = s.children.list.filter((o) => o.texture && o.texture.key === 'fx_smoke_puff').length;
      if (!gt.turret) return; const off = Math.hypot(gt.turret.x - gt.mountAt.x, gt.turret.y - gt.mountAt.y); window.__gfx.push([n, p2, +off.toFixed(2), s.shots.flashes.length]); });
    const z = window.__z; z.hp = 99; z.col = at.col + 2; z.row = at.row + 2; z.tile = { col: z.col, row: z.row };
    window.__hits.length = 0; return { at, todo: s.todo.isDone('guntower'), frame: s.map.assets.turret_gun.frames[+gt.turret.frame.name] }; }, spot);
  await T.run(60 * 2);
  const gr = await G(() => ({ gfx: window.__gfx, hits: window.__hits.slice() }));
  const nShots = gr.hits.filter((h) => h[1] === 2).length;
  const muzzleFrames = gr.gfx.filter((x) => x[0] > 0).length, puff = gr.gfx.some((x) => x[1] > 0), recoil = Math.max(...gr.gfx.map((x) => x[2])), light = gr.gfx.some((x) => x[3] > 0);
  ok('gun tower: to-do 4 checked; turret uses dirN frames', g.todo && /^dir\d+$/.test(g.frame), J(g));
  ok('gun tower shot: muzzle flash ~0.07 s then smoke puff, flash light, turret recoil up to 3 px, damage 2 (user-lowered from 3)', muzzleFrames >= 4 * nShots && muzzleFrames <= 6 * nShots && puff && light && recoil > 2 && recoil <= 3.01 && gr.hits.some((h) => h[1] === 2), J({ muzzleFrames, puff, light, recoil, hits: gr.hits }));
  // 5) 목표를 잃은 화살: 땅에 꽂힘 2초 + 0.5초
  const lost = await G(() => { const s = window.__S; s.map.removeStructure(window.__gt); window.__gt.sprite.destroy(); s.towers.detach(window.__gt);
    window.__lostT = null; s.events.on('postupdate', () => { const n = s.children.list.filter((o) => o.texture && o.texture.key === 'proj_arrow_stuck').length; if (n && window.__lostT === null) window.__lostT = s.elapsed; if (!n && window.__lostT !== null && window.__goneT === undefined) window.__goneT = s.elapsed; });
    return true; });
  await T.until('return window.__S.shots.list.some((p) => p.kind === "arrow" && p.t > 0.2)', 300);
  await G(() => { const s = window.__S; s.enemies.kill(window.__z, 1, 0); });
  await T.run(60 * 4);
  const ls = await G(() => ({ a: window.__lostT, b: window.__goneT }));
  ok('an arrow whose target dies lands as proj_arrow_stuck, gone after 2.5 s', ls.a !== null && ls.b !== undefined && near(ls.b - ls.a, 2.5, 0.05), J(ls));
  // 6) 밤: 탑 등불, 올라오는 좀비는 쏘지 않는다
  const night = await G((t) => { const s = window.__S; const L = s.lightSources(); const lamp = s.map.assets.build_watchtower.lamp, tw = window.__tw;
    const has = L.some((l) => l.x === tw.sprite.x + lamp[0] && l.y === tw.sprite.y + lamp[1] && l.radius === 120 && l.alpha === 0.85);
    s.enemies.spawnPoint = () => ({ col: t.col + 2, row: t.row }); s.debugZombie(); window.__r = s.enemies.list[s.enemies.list.length - 1]; window.__shots.length = 0; return { has }; }, spot);
  await T.run(30);
  const rs = await G(() => ({ rising: window.__r.rising, shots: window.__shots.length }));
  ok('watchtower lamp light (120, 0.85) is in the night lights; a rising zombie is not shot', night.has && rs.rising && rs.shots === 0, J({ night, rs }));
  await T.run(60);
  const rs2 = await G(() => window.__shots.length);
  ok('after it has risen it is shot', rs2 >= 1, J(rs2));
  // 7) 탑 뒤로 가면 반투명(받침과 포탑 함께)
  const oc = await G((t) => { const s = window.__S, p = s.player; for (const e of [...s.enemies.list]) s.enemies.remove(e);
    p.col = t.col - 1; p.row = t.row - 1; p.tile = { col: p.col, row: p.row }; p.path = []; return true; }, spot);
  await T.run(30);
  const oc2 = await G(() => ({ base: +window.__tw.sprite.alpha.toFixed(2), tur: +window.__tw.turret.alpha.toFixed(2) }));
  ok('a character behind the tower makes base and turret see-through together', oc2.base === 0.5 && oc2.tur === 0.5, J(oc2));
  // 8) 좀비가 탑을 부순다
  const sm = await G((t) => { const s = window.__S, p = s.player; p.col = t.col - 3; p.row = t.row; p.tile = { col: p.col, row: p.row }; p.path = [];
    const tw = window.__tw; tw.hp = 2; s.towers.update = () => {}; 
    const z = s.enemies.add('zombie', { col: t.col + 1, row: t.row }); z.hp = 99; z.path = [{ col: t.col, row: t.row }]; z.wantPath = false; z.repathLeft = 99; z.goalKey = 'x';
    return true; }, spot);
  await T.run(60 * 4);
  const sm2 = await G((t) => { const s = window.__S; return { gone: !s.map.structureAt(t.col, t.row), turret: window.__tw.turret, tAct: null }; }, spot);
  ok('a zombie held by the tower smashes it; the turret goes with it', sm2.gone && sm2.turret === null, J(sm2));
  await page.screenshot({ path: __dirname + '/p8_t1.png' });
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
