const { setup, J } = require('../p6/lib6.js');
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G, page } = T;
  await T.sleep(); await T.run(2);
  await G(() => { const s = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.startStage2(); s.hurtPlayer = () => false; s.pressEnemy = () => {};
    const p = s.player.tile;
    s.build.place('watchtower', [{ col: p.col + 2, row: p.row - 2 }]); s.build.place('guntower', [{ col: p.col - 2, row: p.row + 2 }]);
    for (let k = 0; k < 4; k++) s.build.place('wire', [{ col: p.col + 3 + k, row: p.row + 3 }]);
    s.debugNight(); s.enemies.schedule = []; s.pirates.shipDue = false; s.pirates.landDue = false;
    for (const [dc, dr] of [[5, 1], [4, 4], [-4, 3], [1, 5]]) { const z = s.enemies.add('zombie', { col: p.col + dc, row: p.row + dr }); z.hp = 50; } });
  await T.run(150);
  for (let i = 0; i < 60; i++) { await T.run(1); if (await G(() => { const s = window.__game.scene.getScene('game'); return s.towers.shots.some((p) => p.kind === 'arrow' && p.t > 0.3 && p.t < 0.7) && s.children.list.some((o) => o.texture && o.texture.key === 'fx_muzzle'); })) break; }
  await page.screenshot({ path: __dirname + '/p8_night.png' });
  console.log('errors', J(T.errors));
  await T.browser.close();
})();
