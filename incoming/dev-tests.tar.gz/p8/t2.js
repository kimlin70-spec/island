// Phase 8 검토 뒤 확인: 사거리 원이 남지 않는다, 지을 때 포탑이 받침에 붙어 있다, 목표를 잃은 화살이 튀지 않는다,
// 긴 프레임·×3 에서도 총구 빛, 총 타워를 치우면 철광석 아이콘, 포탑을 눌러도 그 탑, 쏘는 간격이 긴 프레임에서도 그대로
const { setup, checker, J } = require('../p6/lib6.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { G } = T;
  await T.sleep(); await T.run(2);
  const at = await G(() => { const s = window.__S = window.__game.scene.getScene('game'); s.enemies.schedule = []; s.startStage2(); s.debugGive(); s.debugGive();
    s.pressEnemy = () => {}; s.hurtPlayer = () => false; const p = s.player.tile;
    const spots = []; for (const [dc, dr] of [[3, 0], [-3, 0], [0, 3], [0, -3], [3, 3], [-3, -3]]) if (s.build.canBuildAt(p.col + dc, p.row + dr)) spots.push({ col: p.col + dc, row: p.row + dr });
    return spots; });
  // 1) 사거리 원: 탑을 누르고 2초 안에 탑 카드를 골라도 남지 않는다
  const r = await G((at) => { const s = window.__S; const gt = window.__gt = s.build.place('guntower', [at[0]]);
    s.build.showRange(gt, 'guntower', 2); s.build.setMode('watchtower'); return { vis: s.build.range.visible }; }, at);
  await T.run(60 * 3);
  const r2 = await G(() => { const s = window.__S; const v = s.build.range.visible; s.build.setMode(null); return v; });
  ok('picking a tower card right after tapping a tower hides the old circle (no stale circle)', !r.vis && !r2, J({ r, r2 }));
  // 2) 지을 때 튀어나오는 동안 포탑이 받침의 mount 에 붙어 있다
  const pops = await G((at) => { const s = window.__S; s.build.setMode('watchtower'); s.pressing = true; const t = at[1]; s.build.commit((t.col - t.row) * 40, (t.col + t.row) * 20); s.build.setMode(null);
    const w = window.__wt = s.map.structureAt(t.col, t.row); window.__pop = [];
    s.events.on('postupdate', () => { if (window.__pop.length < 20) { const b = w.sprite, m = s.map.assets.build_watchtower.mount; window.__pop.push(+(w.turret.y - (b.y + m[1] * b.scaleY)).toFixed(2)); } }); return !!w; }, at);
  await T.run(20);
  const pl = await G(() => window.__pop.slice());
  ok('while the watchtower pops in, the turret stays on the base mount (scaled with it)', pops && pl.length > 5 && pl.every((d) => Math.abs(d) < 0.01), J(pl));
  // 3) 화살이 날던 중 목표가 쓰러져도 한 번에 튀지 않는다
  await G((at) => { const s = window.__S; const w = window.__wt; const z = window.__z = s.enemies.add('zombie', { col: w.col + 3, row: w.row }); z.hp = 99; z.repathLeft = 99; z.wantPath = false; z.goalKey = 'x';
    s.map.removeStructure(window.__gt); window.__gt.sprite.destroy(); s.towers.detach(window.__gt); }, at);
  await T.until('return window.__S.shots.list.some((p) => p.kind === "arrow" && p.t > 0.4)', 300);
  const j = await G(() => { const s = window.__S; const p = s.shots.list.find((q) => q.kind === 'arrow'); const y0 = p.sprite.y, x0 = p.sprite.x;
    s.enemies.kill(window.__z, 1, 0); window.__p = p; return { x0, y0 }; });
  await T.run(1);
  const j2 = await G(() => ({ x: window.__p.sprite.x, y: window.__p.sprite.y }));
  ok('when the target dies mid-flight the arrow does not jump (moves only a few px that frame)', Math.hypot(j2.x - j.x0, j2.y - j.y0) < 15, J({ j, j2 }));
  await T.run(200);
  // 4) 긴 프레임, ×3: 총구 빛이 그려진다. 쏘는 간격은 1.6초 그대로
  const g = await G((at) => { const s = window.__S; const gt = window.__gt2 = s.build.place('guntower', [at[2]]); s.debugSpeed = 3;
    const z = window.__z2 = s.enemies.add('zombie', { col: gt.col + 2, row: gt.row }); z.hp = 999; z.repathLeft = 999; z.wantPath = false; z.goalKey = 'x';
    for (const w of [window.__wt]) { s.map.removeStructure(w); w.sprite.destroy(); s.towers.detach(w); }
    window.__fl = 0; window.__fs = []; const of = s.towers.fire.bind(s.towers); s.towers.fire = (tw) => { window.__fs.push(s.elapsed); of(tw); };
    s.events.on('postupdate', () => { if (s.lightSources().some((l) => l.radius === 110)) window.__fl++; }); return true; }, at);
  await T.run(100, 100);
  const gr = await G(() => { const fs = window.__fs; return { flashFrames: window.__fl, shots: fs.length, gaps: fs.slice(1).map((x, i) => +(x - fs[i]).toFixed(3)) }; });
  const avg = gr.gaps.reduce((a, b) => a + b, 0) / gr.gaps.length;
  ok('at x3 with 100 ms frames the muzzle light is drawn for every shot', gr.flashFrames >= gr.shots && gr.shots >= 10, J(gr));
  ok('the gun tower still fires every 1.6 s on average with long frames (leftover time carried)', Math.abs(avg - 1.6) < 0.05, J({ avg, gaps: gr.gaps }));
  // 5) 총 타워를 치우면 돌 3, 철광석 2 와 아이콘
  const rm = await G(() => { const s = window.__S; s.debugSpeed = 1; const gt = window.__gt2; const pops = []; const op = s.effects.popup.bind(s.effects);
    s.effects.popup = (x, y, icon, label) => { pops.push([icon, label]); op(x, y, icon, label); }; s.build.remove(gt); return pops; });
  ok('removing a gun tower refunds stone 3 and iron 2 with their icons', J(rm) === J([['icon_stone', '+3'], ['icon_iron', '+2']]), J(rm));
  // 6) 포탑을 누르면 그 탑(사거리 원)
  const tp = await G((at) => { const s = window.__S; const gt = s.build.place('guntower', [at[3]]); s.build.rangeLeft = 0; s.build.range.setVisible(false);
    const tur = gt.turret; const p0 = [s.player.col, s.player.row];
    const picked = s.map.pickObject(tur.x, tur.y - 4); s.onPress({ wasTouch: true, worldX: tur.x, worldY: tur.y - 4 });
    return { picked: picked === gt, range: s.build.range.visible, moving: s.player.moving }; }, at);
  ok('tapping the gun on top of the tower picks that tower and shows its range (the player does not walk)', tp.picked && tp.range && !tp.moving, J(tp));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
