// Phase 3 첫 확인: 오류 없이 뜨는가, 울타리·모닥불·텐트를 코드로 놓아 보고 화면을 본다
const { open } = require('./lib.js');
const out = __dirname + '/';
(async () => {
  const T = await open();
  const { page, G, errors } = T;
  const r = await G(() => {
    const s = window.__game.scene.getScene('game'), b = s.build, st = s.mapData.playerStart;
    s.inventory.add('wood', 60); s.inventory.add('stone', 20);
    // preview_build.png 와 비슷하게: 7x7 둘레 일부에 울타리, 텐트, 모닥불
    const c0 = st.col - 3, r0 = st.row - 3; const ring = [];
    for (let c = c0; c < c0 + 7; c++) ring.push([c, r0]);
    for (let r = r0 + 1; r < r0 + 7; r++) ring.push([c0 + 6, r]);
    for (let c = c0 + 5; c >= c0; c--) ring.push([c, r0 + 6]);
    for (let r = r0 + 5; r > r0; r--) ring.push([c0, r]);
    const placed = [];
    for (const [c, r] of ring.slice(0, 13)) if (b.canBuildAt(c, r)) { b.place('fence', [{ col: c, row: r }]); placed.push([c, r]); }
    b.place('tent', [{ col: c0 + 2, row: r0 + 2 }, { col: c0 + 3, row: r0 + 2 }, { col: c0 + 2, row: r0 + 3 }, { col: c0 + 3, row: r0 + 3 }]);
    b.place('campfire', [{ col: c0 + 4, row: r0 + 4 }]);
    s.player.col = c0 + 5; s.player.row = r0 + 2; s.player.tile = { col: c0 + 5, row: r0 + 2 }; s.player.path = [];
    return { placed: placed.length, structures: s.map.structures.map(x => [x.type, x.col, x.row, x.sprite.texture.key, x.sprite.depth]).slice(0, 16) };
  });
  console.log(JSON.stringify(r));
  await page.waitForTimeout(1500);
  await page.screenshot({ path: out + 'camp.png' });
  console.log('errors', JSON.stringify(errors, null, 1));
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
