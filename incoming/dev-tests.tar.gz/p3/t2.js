// Phase 3: 짓기 상태, 바닥 표시, 울타리 연결, 모닥불, 텐트, 치우기, 할 일 (실제 마우스로)
const { open } = require('./lib.js');
const out = __dirname + '/';
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 250) : '')); };
(async () => {
  const T = await open();
  const { page, G, W, tilePos, arrive, errors } = T;
  const S = () => G(() => {
    const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'), b = s.build;
    return { wood: s.inventory.count('wood'), stone: s.inventory.count('stone'), mode: b.mode, tile: [s.player.tile.col, s.player.tile.row], moving: s.player.moving,
             marks: b.marks.filter(m => m.visible).map(m => [m.texture.key.replace('overlay_', ''), Math.round((m.x / 40 + m.y / 20) / 2), Math.round((m.y / 20 - m.x / 40) / 2)]),
             notice: u.noticeBox.visible ? u.noticeText.text : null, hint: u.hint, todo: [...s.todo.done], craft: u.craftWin.visible,
             structs: s.map.structures.map(x => x.type + '@' + x.col + ',' + x.row), selected: u.cards.filter(c => s.build.mode === c.card.id).map(c => c.card.id),
             cards: Object.fromEntries(u.cards.map(c => [c.card.id, [+c.box.alpha.toFixed(2), c.status.text]])) };
  });
  // 실제 마우스처럼 여러 번에 나눠 움직인다(패널을 벗어난 뒤의 첫 움직임은 UI가 받아 간다)
  const moveTo = async (x, y) => { await page.mouse.move(x - 6, y - 4, { steps: 6 }); await page.mouse.move(x - 2, y - 1); await page.mouse.move(x, y); };
  const hover = async (c, r) => { const p = await tilePos(c, r); await moveTo(p.x, p.y); await page.waitForTimeout(140); };
  const click = async (c, r) => { const p = await tilePos(c, r); await moveTo(p.x, p.y); await page.mouse.down(); await page.waitForTimeout(40); await page.mouse.up(); await page.waitForTimeout(160); };
  const CRAFT = [1824, 1104], cardX = (i) => 776 + 20 + i * 182 + 85, cardY = 898;
  const ui = async (x, y) => { await page.mouse.click(x, y); await page.waitForTimeout(160); };
  const key = (c, r) => G(([c, r]) => { const x = window.__game.scene.getScene('game').map.structureAt(c, r); return x ? x.sprite.texture.key : null; }, [c, r]);
  const st = await G(() => window.__game.scene.getScene('game').mapData.playerStart);
  const P = [st.col, st.row];
  await G(() => { const s = window.__game.scene.getScene('game'); s.inventory.add('wood', 30); s.inventory.add('stone', 10); });

  // A) 만들기 -> 울타리: 짓기 상태, 안내, 고른 카드
  await ui(...CRAFT);
  await ui(cardX(2), cardY);
  let s = await S();
  ok('A fence card: build mode, hint stays up, card selected', s.mode === 'fence' && s.notice === '울타리: 지을 칸을 누르세요' && s.selected.join() === 'fence', JSON.stringify([s.mode, s.notice, s.selected]));
  await page.waitForTimeout(3000);
  ok('A2 hint is still there after 3 seconds', (await S()).notice === '울타리: 지을 칸을 누르세요');

  // B) 바닥 표시: 지을 수 있는 칸은 초록, 나무 칸·주인공 칸·먼 곳은 빨강
  await hover(P[0] + 2, P[1]);
  s = await S();
  ok('B1 hover on free ground: green mark on that tile', s.marks.length === 1 && s.marks[0].join() === ['ok', P[0] + 2, P[1]].join(), JSON.stringify(s.marks));
  await hover(P[0], P[1]);
  ok('B2 player tile: red', (await S()).marks[0][0] === 'no');
  const tree = await G(([c, r]) => window.__game.scene.getScene('game').map.objects.filter(o => o.blocks).map(o => [o.col, o.row, Math.hypot(o.col - c, o.row - r)]).sort((a, b) => a[2] - b[2])[0], P);
  await hover(tree[0], tree[1]);
  s = await S();
  ok('B3 tree tile (within reach): red', s.marks[0][0] === 'no' && tree[2] <= 7, JSON.stringify([s.marks, tree]));
  // 빈 땅이면서 화면의 UI에 가리지 않는 칸을 거리 조건으로 고른다
  const freeAt = (lo, hi) => G(([c0, r0, lo, hi]) => {
    const s = window.__game.scene.getScene('game'), m = s.map, cam = s.cameras.main;
    for (let r = r0 - 9; r <= r0 + 9; r++) for (let c = c0 - 9; c <= c0 + 9; c++) {
      const d = Math.hypot(c - c0, r - r0);
      if (d < lo || d > hi || !m.isOpen(c, r) || m.objectAt(c, r) || m.structureAt(c, r)) continue;
      const sx = (c - r) * 40 - cam.scrollX, sy = (c + r) * 20 - cam.scrollY;
      if (sx > 380 && sx < 1500 && sy > 330 && sy < 700) return [c, r, +d.toFixed(2)];
    }
  }, [P[0], P[1], lo, hi]);
  const far = await freeAt(7.05, 8.6);
  await hover(far[0], far[1]);
  s = await S();
  ok('B4 free ground too far from the player: red', s.marks.length === 1 && s.marks[0][0] === 'no', JSON.stringify([far, s.marks]));
  const edge = await freeAt(6.9, 7.0);
  await hover(edge[0], edge[1]);
  s = await S();
  ok('B5 free ground within 7 tiles: green', s.marks.length === 1 && s.marks[0][0] === 'ok', JSON.stringify([edge, s.marks]));
  await page.screenshot({ path: out + 'mark_ok.png' });

  // M) 짓기 상태에서는 빨간 칸을 눌러도 아무 일도 없다(걷지도 않는다)
  await click(far[0], far[1]);
  s = await S();
  ok('M red tile click: nothing built, player does not walk', s.structs.length === 0 && !s.moving && s.wood === 30);

  // C, D) 누르면 바로 지어지고, 이웃한 울타리끼리 이어진다
  await click(P[0] + 2, P[1]);
  s = await S();
  ok('C1 click builds a fence at once, wood -1, mode stays', s.structs.join() === `fence@${P[0] + 2},${P[1]}` && s.wood === 29 && s.mode === 'fence' && !s.moving, JSON.stringify(s.structs));
  ok('C2 the built tile now shows red', s.marks.length === 1 && s.marks[0][0] === 'no');
  ok('C3 lone fence picture', await key(P[0] + 2, P[1]) === 'build_fence_0');
  await click(P[0] + 3, P[1]);
  ok('D1 neighbours along col connect (1 and 2)', await key(P[0] + 2, P[1]) === 'build_fence_1' && await key(P[0] + 3, P[1]) === 'build_fence_2', [await key(P[0] + 2, P[1]), await key(P[0] + 3, P[1])].join());
  await click(P[0] + 2, P[1] + 1);
  await click(P[0] + 2, P[1] - 1);
  ok('D2 corner piece connects three ways (1+4+8=13)', await key(P[0] + 2, P[1]) === 'build_fence_13' && await key(P[0] + 2, P[1] + 1) === 'build_fence_8' && await key(P[0] + 2, P[1] - 1) === 'build_fence_4', [await key(P[0] + 2, P[1]), await key(P[0] + 2, P[1] + 1), await key(P[0] + 2, P[1] - 1)].join());

  // E) 울타리 8개 -> 할 일 체크
  for (const [dc, dr] of [[3, 1], [3, -1], [4, 0]]) await click(P[0] + dc, P[1] + dr);
  s = await S();
  ok('E1 seven fences: to-do not yet checked', s.structs.length === 7 && !s.todo.includes('fence'));
  await click(P[0] + 4, P[1] + 1);
  s = await S();
  ok('E2 eighth fence checks the to-do', s.structs.length === 8 && s.todo.includes('fence') && s.wood === 22, JSON.stringify(s.todo));
  await page.screenshot({ path: out + 'fences.png' });

  // O) 월드에서 누르고 UI 위에서 떼면 짓지 않는다
  let p = await tilePos(P[0] - 2, P[1]);
  await moveTo(p.x, p.y); await page.mouse.down(); await page.waitForTimeout(60);
  await page.mouse.move(1700, 150, { steps: 6 }); await page.waitForTimeout(100);
  s = await S();
  ok('O1 marks hide while the pointer is over a panel', s.marks.length === 0);
  await page.mouse.up(); await page.waitForTimeout(150);
  ok('O2 releasing over a panel builds nothing', (await S()).structs.length === 8);

  // G) 텐트: 네 칸에 표시, 지으면 네 칸이 막히고 카드는 "보유", 짓기 상태가 풀린다
  await ui(cardX(4), cardY);
  s = await S();
  ok('G1 tent card selected, hint', s.mode === 'tent' && s.notice === '텐트: 지을 칸을 누르세요');
  // 포인터를 칸 (c, r) 과 (c+1, r+1) 사이(네 칸의 한가운데)에 둔다
  const mid = async (c, r) => { const a = await tilePos(c, r), b = await tilePos(c + 1, r + 1); return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }; };
  const tc = [P[0] - 3, P[1] - 1];
  p = await mid(tc[0], tc[1]);
  await moveTo(p.x, p.y + 3); await page.waitForTimeout(150);
  s = await S();
  const want4 = [[tc[0], tc[1]], [tc[0] + 1, tc[1]], [tc[0], tc[1] + 1], [tc[0] + 1, tc[1] + 1]].map(t => t.join()).sort().join('|');
  ok('G2 four marks on the 2x2 block under the pointer', s.marks.length === 4 && s.marks.map(m => m[1] + ',' + m[2]).sort().join('|') === want4, JSON.stringify(s.marks));
  await page.screenshot({ path: out + 'tent_marks.png' });
  // 한 칸이라도 막혀 있으면 지어지지 않는다(울타리와 겹치게)
  const bad = await mid(P[0] + 1, P[1]);
  await moveTo(bad.x, bad.y + 3); await page.waitForTimeout(150);
  s = await S();
  ok('G3 block overlapping a fence: some red, click builds nothing', s.marks.some(m => m[0] === 'no') && s.marks.some(m => m[0] === 'ok'), JSON.stringify(s.marks));
  await page.mouse.down(); await page.mouse.up(); await page.waitForTimeout(150);
  ok('G4 nothing built', (await S()).structs.length === 8);
  await moveTo(p.x, p.y + 3); await page.mouse.down(); await page.waitForTimeout(40); await page.mouse.up(); await page.waitForTimeout(200);
  s = await S();
  const tent = await G(() => { const s = window.__game.scene.getScene('game'), x = s.map.structures.find(x => x.type === 'tent'); return x && { tiles: x.tiles.map(t => t.col + ',' + t.row).sort().join('|'), x: x.sprite.x, y: x.sprite.y, key: x.sprite.texture.key, walk: x.tiles.map(t => s.map.isWalkable(t.col, t.row)), depth: x.sprite.depth, tall: x.tall }; });
  ok('G5 tent built on those four tiles, drawn at their centre', tent && tent.tiles === want4 && tent.x === ((tc[0] + 0.5) - (tc[1] + 0.5)) * 40 && tent.y === (tc[0] + tc[1] + 1) * 20 && tent.key === 'build_tent', JSON.stringify(tent));
  ok('G6 tent tiles blocked; wood -8 stone -2; card shows 보유; mode ends; to-do', tent.walk.every(v => !v) && s.wood === 14 && s.stone === 8 && s.cards.tent.join() === '0.45,보유' && s.mode === null && s.notice !== '텐트: 지을 칸을 누르세요' && s.todo.includes('tent'), JSON.stringify([s.wood, s.stone, s.cards.tent, s.mode, s.notice]));
  await ui(cardX(4), cardY);
  ok('G7 tent card cannot be chosen again', (await S()).mode === null);

  // H) 모닥불: 불꽃 애니메이션, 빛무리, 막힌 칸, 할 일
  await ui(cardX(3), cardY);
  await click(P[0], P[1] + 2);
  s = await S();
  const fire = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), x = s.map.structureAt(c, r); return x && { type: x.type, anim: x.sprite.anims.isPlaying && x.sprite.anims.currentAnim.key, glow: !!x.glow && [x.glow.blendMode, x.glow.displayWidth, x.glow.alpha, x.glow.depth - x.sprite.depth, x.glow.x - x.sprite.x, x.glow.y - x.sprite.y], walk: s.map.isWalkable(c, r) }; }, [P[0], P[1] + 2]);
  ok('H1 campfire built, flame animation, glow, blocked tile', fire && fire.type === 'campfire' && fire.anim === 'build_campfire_burn' && fire.glow && fire.glow.join() === [1, 220, 0.2, 1, 0, -17.5].join() && !fire.walk, JSON.stringify(fire));
  ok('H2 wood -3 stone -3, to-do, mode stays while affordable', s.wood === 11 && s.stone === 5 && s.todo.includes('campfire') && s.mode === 'campfire', JSON.stringify([s.wood, s.stone, s.mode]));
  const frames = new Set();
  for (let i = 0; i < 8; i++) { frames.add(await G(([c, r]) => window.__game.scene.getScene('game').map.structureAt(c, r).sprite.frame.name, [P[0], P[1] + 2])); await page.waitForTimeout(120); }
  ok('H3 flame cycles through burn1..3', frames.size === 3, [...frames].join());
  await page.screenshot({ path: out + 'camp_built.png' });

  // I) 재료가 떨어지면 "재료가 부족합니다"와 함께 풀린다
  await click(P[0] - 1, P[1] + 2);                           // 두 번째 모닥불: 나무 8, 돌 2 -> 다음은 못 짓는다
  s = await S();
  ok('I second campfire uses the last stone: notice and mode ends', s.stone === 2 && s.mode === null && s.notice === '재료가 부족합니다' && s.cards.campfire[0] === 0.45, JSON.stringify([s.wood, s.stone, s.mode, s.notice]));

  // N) 만들기 버튼을 다시 누르면 창이 닫히고 짓기 상태도 끝난다
  await ui(cardX(2), cardY);
  ok('N1 fence mode again', (await S()).mode === 'fence');
  await hover(P[0] - 2, P[1]);
  await ui(...CRAFT);
  s = await S();
  ok('N2 craft button closes the window and ends build mode, marks and hint gone', !s.craft && s.mode === null && s.marks.length === 0 && s.hint === null, JSON.stringify([s.craft, s.mode, s.marks, s.hint]));

  // F, P) 주인공은 울타리를 넘어 다닐 수 있고, 텐트와 모닥불은 돌아간다
  await G(() => { const s = window.__game.scene.getScene('game'); window.__visited = []; s.events.on('update', () => window.__visited.push(s.player.tile.col + ',' + s.player.tile.row)); });
  await click(P[0] + 5, P[1]);                               // 울타리 줄 건너편
  await arrive();
  s = await S();
  const crossed = await G(() => { const s = window.__game.scene.getScene('game'); return [...new Set(window.__visited)].filter(k => { const [c, r] = k.split(',').map(Number); const x = s.map.structureAt(c, r); return x && x.type === 'fence'; }); });
  ok('F1 (changed by request) goes around the fences, never through them', s.tile.join() === [P[0] + 5, P[1]].join() && crossed.length === 0, 'crossed ' + crossed.join(' '));
  // 울타리 그림을 누르면 그 칸으로 간다
  const fp = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), x = s.map.structureAt(c, r), cam = s.cameras.main; return { x: x.sprite.x - cam.scrollX, y: x.sprite.y - 14 - cam.scrollY }; }, [P[0] + 3, P[1] - 1]);
  const tileBefore = (await S()).tile.join();
  await page.mouse.click(fp.x, fp.y); await page.waitForTimeout(200);
  ok('F2 (changed by request) tapping a fence picture does nothing', !(await S()).moving && (await S()).tile.join() === tileBefore, (await S()).tile.join());
  // 모닥불을 누르면 아무 일도 없다
  const cp = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), x = s.map.structureAt(c, r), cam = s.cameras.main; return { x: x.sprite.x - cam.scrollX, y: x.sprite.y - 12 - cam.scrollY }; }, [P[0], P[1] + 2]);
  await page.mouse.click(cp.x, cp.y); await page.waitForTimeout(200);
  ok('F3 tapping the campfire does nothing', !(await S()).moving);
  // 텐트 건너편으로: 텐트 칸을 지나지 않는다
  await G(() => { window.__visited = []; });
  // 텐트 바로 뒤의 걸을 수 있는 칸(화면에서는 텐트 그림에 가려 있으므로 코드로 보낸다)
  const behind = await G(([c, r]) => { const s = window.__game.scene.getScene('game'); const t = [[c, r - 1], [c + 1, r - 1], [c - 1, r], [c - 1, r - 1]].find(t => s.map.isWalkable(t[0], t[1])); s.player.goTo(t[0], t[1]); return t; }, tc);
  await arrive();
  const through = await G(() => { const s = window.__game.scene.getScene('game'); return [...new Set(window.__visited)].filter(k => { const [c, r] = k.split(',').map(Number); const x = s.map.structureAt(c, r); return x && x.type !== 'fence'; }); });
  ok('P walks around the tent and campfires', (await S()).tile.join() === behind.join() && through.length === 0, 'to ' + behind.join() + ' through ' + through.join(' ') + ' visited ' + (await G(() => [...new Set(window.__visited)].length)));
  await page.waitForTimeout(500);
  const occ = await G(() => { const s = window.__game.scene.getScene('game'), x = s.map.structures.find(x => x.type === 'tent'); return { alpha: +x.sprite.alpha.toFixed(2), behind: x.sprite.depth > s.player.sprite.depth }; });
  ok('P2 standing behind the tent makes it half transparent', occ.alpha === 0.5 && occ.behind, JSON.stringify(occ));
  await page.screenshot({ path: out + 'behind_tent.png' });

  // J) 치우기: 모닥불 -> 나무 1, 돌 1 / 울타리 -> 0 / 텐트 -> 나무 4, 돌 1
  await click(P[0] - 1, P[1]);                               // 주인공을 가운데 쪽으로
  await arrive();
  await ui(...CRAFT);
  await ui(cardX(5), cardY);
  s = await S();
  ok('J1 remove card selected with its hint', s.mode === 'remove' && s.notice === '치우기: 없앨 시설을 누르세요' && s.selected.join() === 'remove');
  let before = s;
  const cp2 = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), x = s.map.structureAt(c, r), cam = s.cameras.main; return { x: x.sprite.x - cam.scrollX, y: x.sprite.y - 12 - cam.scrollY }; }, [P[0], P[1] + 2]);
  await page.mouse.click(cp2.x, cp2.y); await page.waitForTimeout(200);
  s = await S();
  ok('J2 removing a campfire gives back half: wood +1, stone +1', s.wood === before.wood + 1 && s.stone === before.stone + 1 && !s.structs.includes(`campfire@${P[0]},${P[1] + 2}`) && s.mode === 'remove', JSON.stringify([before.wood, before.stone, s.wood, s.stone]));
  await page.screenshot({ path: out + 'removed.png' });
  before = s;
  const fp2 = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), x = s.map.structureAt(c, r), cam = s.cameras.main; return { x: x.sprite.x - cam.scrollX, y: x.sprite.y - 14 - cam.scrollY }; }, [P[0] + 3, P[1]]);
  await page.mouse.click(fp2.x, fp2.y); await page.waitForTimeout(200);
  s = await S();
  ok('J3 removing a fence gives nothing back; neighbours reconnect', s.wood === before.wood && s.structs.length === before.structs.length - 1 && await key(P[0] + 2, P[1]) === 'build_fence_12' && await key(P[0] + 4, P[1]) === 'build_fence_4', [await key(P[0] + 2, P[1]), await key(P[0] + 4, P[1])].join());
  before = s;
  const tp = await G(() => { const s = window.__game.scene.getScene('game'), x = s.map.structures.find(x => x.type === 'tent'), cam = s.cameras.main; return { x: x.sprite.x - cam.scrollX, y: x.sprite.y - 40 - cam.scrollY }; });
  await page.mouse.click(tp.x, tp.y); await page.waitForTimeout(200);
  s = await S();
  ok('J4 removing the tent: wood +4, stone +1, tiles free, card back', s.wood === before.wood + 4 && s.stone === before.stone + 1 && !s.structs.some(x => x.startsWith('tent')) && s.cards.tent[1] === '', JSON.stringify([s.wood, s.stone, s.cards.tent]));
  // 땅을 눌러도(시설이 아닌 곳) 아무 일 없다
  await click(P[0] - 3, P[1] + 3);
  s = await S();
  ok('J5 in remove mode a ground tap does nothing', !s.moving && s.mode === 'remove');
  await ui(...CRAFT);

  // K) 그루터기 위에는 지을 수 있고, 지으면 그루터기가 사라진다
  const stump = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), m = s.map; const o = m.objects.filter(o => o.kind === 'tree').map(o => [o, Math.hypot(o.col - c, o.row - r)]).sort((a, b) => a[1] - b[1])[0][0]; o.node = null; m.toDecor(o, 'obj_stump', 'stump'); s.nodes.attach(o); return [o.col, o.row, m.objects.length]; }, P);
  await ui(...CRAFT); await ui(cardX(2), cardY);
  await hover(stump[0], stump[1]);
  ok('K1 stump tile shows green', (await S()).marks[0][0] === 'ok');
  await click(stump[0], stump[1]);
  const after = await G(([c, r]) => { const m = window.__game.scene.getScene('game').map; return { obj: !!m.objectAt(c, r), n: m.objects.length, st: m.structureAt(c, r) && m.structureAt(c, r).type }; }, stump);
  ok('K2 fence built on the stump and the stump is gone', after.st === 'fence' && !after.obj && after.n === stump[2] - 1, JSON.stringify(after));

  // Q) 걷는 중: 주인공이 막 들어서는 칸에는 지을 수 없다
  await ui(...CRAFT);
  await click(P[0] - 4, P[1] + 4);
  await page.waitForTimeout(250);
  const q = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; const n = p.path[0]; return n ? { next: [n.col, n.row], can: s.build.canBuildAt(n.col, n.row), here: s.build.canBuildAt(p.tile.col, p.tile.row) } : null; });
  ok('Q cannot build on the tile the player is stepping into', q && !q.can && !q.here, JSON.stringify(q));
  await arrive();

  console.log('errors', JSON.stringify(errors, null, 1));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
