// Phase 3: 터치로 짓기 — 손을 대고 있는 동안 표시가 보이고, 손을 뗄 때 짓는다
const { open } = require('./lib.js');
const out = __dirname + '/';
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 250) : '')); };
(async () => {
  const T = await open({ w: 1024, h: 768, touch: true });
  const { page, G, tilePos, errors } = T;
  const cdp = await page.context().newCDPSession(page);
  const touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map(p => ({ x: Math.round(p.x), y: Math.round(p.y), id: 1 })) });
  const toPage = (x, y) => G(([x, y]) => { const r = window.__game.canvas.getBoundingClientRect(); return { x: r.left + x * r.width / 1920, y: r.top + y * r.height / 1200 }; }, [x, y]);
  const tapUi = async (x, y) => { const p = await toPage(x, y); await page.touchscreen.tap(p.x, p.y); await page.waitForTimeout(160); };
  const S = () => G(() => { const s = window.__game.scene.getScene('game'), b = s.build; return { mode: b.mode, wood: s.inventory.count('wood'), moving: s.player.moving, marks: b.marks.filter(m => m.visible).map(m => [m.texture.key.replace('overlay_', ''), Math.round((m.x / 40 + m.y / 20) / 2), Math.round((m.y / 20 - m.x / 40) / 2)]), structs: s.map.structures.map(x => x.type + '@' + x.col + ',' + x.row) }; });
  const st = await G(() => window.__game.scene.getScene('game').mapData.playerStart);
  const P = [st.col, st.row];
  await G(() => { const s = window.__game.scene.getScene('game'); s.inventory.add('wood', 20); s.inventory.add('stone', 10); });
  await tapUi(1824, 1104);
  await tapUi(776 + 20 + 2 * 182 + 85, 898);
  let s = await S();
  ok('T1 touch: fence card selected, no mark before touching', s.mode === 'fence' && s.marks.length === 0, JSON.stringify(s));

  // 손을 대면 표시가 뜨고, 끌면 따라오고, 떼면 짓는다
  const a = await tilePos(P[0] - 2, P[1]), b = await tilePos(P[0] - 2, P[1] - 2);
  await touch('touchStart', [a]); await page.waitForTimeout(150);
  s = await S();
  ok('T2 finger down: green mark under the finger, nothing built yet', s.marks.join() === ['ok', P[0] - 2, P[1]].join() && s.structs.length === 0, JSON.stringify(s.marks));
  await touch('touchMove', [{ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }]); await page.waitForTimeout(60);
  await touch('touchMove', [b]); await page.waitForTimeout(150);
  s = await S();
  ok('T3 dragging moves the mark', s.marks.join() === ['ok', P[0] - 2, P[1] - 2].join() && s.structs.length === 0, JSON.stringify(s.marks));
  await touch('touchEnd', []); await page.waitForTimeout(200);
  s = await S();
  ok('T4 lifting the finger builds there; mark disappears; player does not walk', s.structs.join() === `fence@${P[0] - 2},${P[1] - 2}` && s.marks.length === 0 && !s.moving && s.wood === 19, JSON.stringify(s));

  // 짧게 톡 누르기
  const c = await tilePos(P[0] - 2, P[1] - 1);
  await page.touchscreen.tap(c.x, c.y); await page.waitForTimeout(200);
  s = await S();
  ok('T5 a quick tap builds too', s.structs.length === 2 && s.marks.length === 0, JSON.stringify(s.structs));

  // 손을 댄 채 패널 위로 끌고 가서 떼면 짓지 않는다
  const d = await tilePos(P[0] - 2, P[1] + 1), panel = await toPage(1700, 150);
  await touch('touchStart', [d]); await page.waitForTimeout(120);
  await touch('touchMove', [{ x: (d.x + panel.x) / 2, y: (d.y + panel.y) / 2 }]); await page.waitForTimeout(60);
  await touch('touchMove', [panel]); await page.waitForTimeout(120);
  const mid = await S();
  await touch('touchEnd', []); await page.waitForTimeout(200);
  s = await S();
  ok('T6 drag onto a panel and lift: nothing built, mark gone', mid.marks.length === 0 && s.structs.length === 2 && s.marks.length === 0, JSON.stringify([mid.marks, s.structs]));

  // 빨간 칸에서 떼면 짓지 않는다(주인공 칸)
  const e = await tilePos(P[0], P[1]);
  await touch('touchStart', [e]); await page.waitForTimeout(150);
  const red = await S();
  await touch('touchEnd', []); await page.waitForTimeout(200);
  s = await S();
  ok('T7 red tile: nothing built', red.marks[0][0] === 'no' && s.structs.length === 2);

  // 치우기: 시설을 톡 누르면 없어진다
  await tapUi(776 + 20 + 5 * 182 + 85, 898);
  const f = await tilePos(P[0] - 2, P[1] - 1);
  await page.touchscreen.tap(f.x, f.y - 6); await page.waitForTimeout(200);
  s = await S();
  ok('T8 remove by touch', s.mode === 'remove' && s.structs.length === 1, JSON.stringify(s.structs));
  await page.screenshot({ path: out + 'touch.png' });
  console.log('errors', JSON.stringify(errors));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
