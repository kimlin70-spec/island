const { chromium } = require('playwright');
const fs = require('fs');
const out = __dirname + '/';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1024, height: 768 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message + '\n' + e.stack));
  await page.route('**/src/config.js', async (route) => {
    let body = fs.readFileSync('/home/user/island/src/config.js', 'utf8');
    body = body.replace('width: 2048, height: 1536, dayZoom: 1.6, nightZoom: 1.0', 'width: 1024, height: 768, dayZoom: 0.8, nightZoom: 0.5');
    route.fulfill({ body, contentType: 'application/javascript' });
  });
  await page.goto('http://localhost:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('ui') && window.__game.scene.getScene('ui').cards);
  const G = (fn, arg) => page.evaluate(fn, arg);
  const W = (fn, t = 120000) => page.waitForFunction(fn, null, { timeout: t });
  await page.waitForTimeout(800);
  await page.screenshot({ path: out + 'p7_day.png' });
  console.log('errors@start', errors);

  // --- 1) 밤으로: 카메라, 화면색, 좀비 ---
  await G(() => { const g = window.__game.scene.getScene('game'); g.debugRevealAll(); g.debugToggleSpeed(); g.debugNight(); });
  await page.waitForTimeout(2500);
  console.log('night', await G(() => { const g = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'); return { zoom: g.cameras.main.zoom, tint: u.tintRect.fillColor.toString(16), label: g.clock.label, toSpawn: g.zombies.toSpawn.length, n: g.zombies.list.length }; }));
  await W(() => window.__game.scene.getScene('game').zombies.list.length >= 2);
  await page.screenshot({ path: out + 'p7_night.png' });
  // 집까지 와서 때리는지
  await W(() => window.__game.scene.getScene('game').house.hp < 40);
  console.log('house hit', await G(() => { const g = window.__game.scene.getScene('game'); return [g.house.hp, g.zombies.list.map(z => [z.tile.col, z.tile.row, z.hp])]; }));
  await page.screenshot({ path: out + 'p7_house.png' });
  // 좀비 누르기 -> 주인공이 가서 때린다
  const before = await G(() => window.__game.scene.getScene('game').zombies.list.length);
  await G(() => { const g = window.__game.scene.getScene('game'); const z = g.zombies.list[0]; window.__z = z; g.onTap(z.sprite.x, z.sprite.y - 40); });
  await W(() => !window.__z.alive);
  console.log('zombie killed by player; inv', await G(() => window.__game.scene.getScene('game').inventory.items));
  // 아침
  await G(() => window.__game.scene.getScene('game').debugMorning());
  await page.waitForTimeout(2500);
  console.log('morning', await G(() => { const g = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'); return { zoom: g.cameras.main.zoom, tint: u.tintRect.fillColor.toString(16), label: g.clock.label, n: g.zombies.list.length, house: g.house.hp, hearts: g.vitals.hearts }; }));

  // --- 2) 울타리로 집을 둘러싸면 부수고 들어온다 / 탑이 쏜다 ---
  await G(() => {
    const g = window.__game.scene.getScene('game');
    g.inventory.add('wood', 200); g.inventory.add('stone', 100);
    const h = g.mapData.house;
    let n = 0;
    for (let c = h.col - 2; c <= h.col + 3; c++) for (let r = h.row - 2; r <= h.row + 3; r++) {
      const edge = c === h.col - 2 || c === h.col + 3 || r === h.row - 2 || r === h.row + 3;
      if (edge && g.build.canBuildAt(c, r)) { g.build.place('fence', c, r); n++; }
    }
    window.__fences = n;
    g.player.teleport(26, 27);
    g.debugNight();
  });
  console.log('fences', await G(() => window.__fences));
  await W(() => window.__game.scene.getScene('game').mapSystem.structures.some(s => s.hp < s.maxHp));
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + 'p7_fence_hit.png' });
  console.log('fence damaged', await G(() => window.__game.scene.getScene('game').mapSystem.structures.filter(s => s.hp < s.maxHp).map(s => [s.col, s.row, s.hp])));
  await W(() => window.__game.scene.getScene('game').mapSystem.structures.length < window.__fences);
  console.log('fence broken; zombies', await G(() => window.__game.scene.getScene('game').zombies.list.length));
  await G(() => window.__game.scene.getScene('game').debugMorning());
  await page.waitForTimeout(500);
  console.log('after morning repaired:', await G(() => window.__game.scene.getScene('game').mapSystem.structures.every(s => s.hp === s.maxHp)));

  // 틈이 있으면 돌아간다: 울타리 하나를 치우고 좀비가 그 틈으로 오는지(울타리를 안 부수는지)
  await G(() => {
    const g = window.__game.scene.getScene('game');
    const gap = g.mapSystem.structureAt(26, 28) || g.mapSystem.structures[0];
    window.__gap = [gap.col, gap.row];
    g.build.remove(gap);
    window.__count = g.mapSystem.structures.length;
    // 탑 2개
    for (const [c, r] of [[28, 27], [24, 27]]) if (g.build.canBuildAt(c, r)) g.build.place('stoneTower', c, r);
    window.__count = g.mapSystem.structures.length;
    g.player.teleport(26, 26 + 1);
    g.debugNight();
  });
  await W(() => window.__game.scene.getScene('game').build.shots.length > 0, 180000);
  await page.screenshot({ path: out + 'p7_tower.png' });
  console.log('tower shooting');
  await W(() => { const g = window.__game.scene.getScene('game'); return g.zombies.toSpawn.length === 0 && g.zombies.list.length === 0; }, 240000);
  console.log('all zombies gone before morning; structures unchanged:', await G(() => [window.__game.scene.getScene('game').mapSystem.structures.length, window.__count, window.__game.scene.getScene('game').house.hp, window.__game.scene.getScene('game').vitals.hearts]));
  await G(() => window.__game.scene.getScene('game').debugMorning());

  // --- 3) 집이 부서지면 아침 ---
  await G(() => {
    const g = window.__game.scene.getScene('game');
    for (const s of [...g.mapSystem.structures]) g.build.destroy(s);
    g.inventory.items.wood = 10; g.inventory.items.stone = 9;
    g.player.teleport(30, 22);
    g.debugNight(); g.house.hp = 1;
  });
  await W(() => !window.__game.scene.getScene('game').clock.isNight, 180000);
  console.log('house destroyed ->', await G(() => { const g = window.__game.scene.getScene('game'); return { label: g.clock.label, house: g.house.hp, inv: g.inventory.items.wood + '/' + g.inventory.items.stone, n: g.zombies.list.length }; }));
  await page.waitForTimeout(700);
  await page.screenshot({ path: out + 'p7_destroyed.png' });

  // --- 4) 좀비가 주인공을 때린다 ---
  await G(() => {
    const g = window.__game.scene.getScene('game');
    g.vitals.hearts = 5; g.vitals.changed();
    const z = g.zombies.spawn(); window.__z = z;
    g.player.teleport(z.tile.col + 1, z.tile.row);
    g.player.cooldown = 1e9;   // 자동 공격을 막아 두고 맞는지만 본다
  });
  await W(() => window.__game.scene.getScene('game').vitals.hearts < 5, 60000);
  console.log('player hurt, hearts', await G(() => window.__game.scene.getScene('game').vitals.hearts));
  // 자동 공격
  await G(() => { window.__game.scene.getScene('game').player.cooldown = 0; });
  await W(() => !window.__z.alive, 60000);
  console.log('auto attack killed zombie');

  // --- 5) 시간이 저절로 흐른다 + 재료 되살아남 ---
  await G(() => {
    const g = window.__game.scene.getScene('game');
    const o = g.nodes.nodes.find(n => n.node.kind === 'bush'); g.nodes.deplete(o); window.__bush = o;
    g.clock.t = 149;
  });
  await W(() => window.__game.scene.getScene('game').clock.evening, 60000);
  await page.waitForTimeout(800);
  await page.screenshot({ path: out + 'p7_evening.png' });
  await G(() => { window.__game.scene.getScene('game').clock.t = 179; });
  await W(() => window.__game.scene.getScene('game').clock.isNight, 60000);
  await G(() => { window.__game.scene.getScene('game').clock.t = 119; });
  await W(() => !window.__game.scene.getScene('game').clock.isNight, 60000);
  console.log('auto cycle ok; bush regrown:', await G(() => !window.__bush.node.depleted), await G(() => window.__game.scene.getScene('game').clock.label));
  console.log('errors', errors);
  await browser.close();
})();
