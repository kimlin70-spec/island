// Phase 4 첫 확인: 오류 없이 뜨는가, 낮/저녁/밤 화면, 캠프를 지어 밤 화면을 preview_night 처럼 보기
const { open } = require('./lib.js');
const out = __dirname + '/';
(async () => {
  const T = await open();
  await T.G(() => { window.__game.scene.getScene('game').enemies.spawn = () => null; });   // Phase 4 시험: 좀비는 끈다
  const { page, G, errors } = T;
  await page.waitForTimeout(500);
  await page.screenshot({ path: out + 'day.png' });
  // preview_night 와 같은 자리: 7x7 둘레의 울타리, 텐트, 모닥불, 주인공은 울타리 밖
  const camp = await G(() => {
    const s = window.__game.scene.getScene('game'), b = s.build, m = s.map, st = s.mapData.playerStart, objs = s.mapData.objects;
    const occ = new Set(objs.map(o => o.col + ',' + o.row));
    const free = (c0, r0) => { for (let c = c0; c < c0 + 7; c++) for (let r = r0; r < r0 + 7; r++) if (occ.has(c + ',' + r) || ![1, 2].includes(s.mapData.terrain[r][c])) return false; return true; };
    let best = null;
    for (let c = st.col - 12; c < st.col + 6; c++) for (let r = st.row - 12; r < st.row + 6; r++) if (free(c, r)) { const d = (c + 3 - st.col) ** 2 + (r + 3 - st.row) ** 2; if (!best || d < best[2]) best = [c, r, d]; }
    const [c0, r0] = best;
    const ring = [];
    for (let c = c0; c < c0 + 7; c++) ring.push([c, r0]);
    for (let r = r0 + 1; r < r0 + 7; r++) ring.push([c0 + 6, r]);
    for (let c = c0 + 5; c >= c0; c--) ring.push([c, r0 + 6]);
    for (let r = r0 + 5; r > r0; r--) ring.push([c0, r]);
    // 주인공을 울타리 밖(preview 자리)으로
    const p = s.player; p.col = c0 + 5; p.row = r0 + 7; p.tile = { col: c0 + 5, row: r0 + 7 }; p.path = [];
    for (const [c, r] of ring) b.place('fence', [{ col: c, row: r }]);
    b.place('tent', [{ col: c0 + 2, row: r0 + 2 }, { col: c0 + 3, row: r0 + 2 }, { col: c0 + 2, row: r0 + 3 }, { col: c0 + 3, row: r0 + 3 }]);
    b.place('campfire', [{ col: c0 + 4, row: r0 + 4 }]);
    s.cameras.main.stopFollow(); s.cameras.main.centerOn((c0 + 1.5 - (r0 + 7.5)) * 40, (c0 + 1.5 + r0 + 7.5) * 20);
    return [c0, r0];
  });
  console.log('camp at', camp);
  // 저녁 한가운데 쯤
  await G(() => { const c = window.__game.scene.getScene('game').clock; c.t = 240 - 40 + 14; });
  await page.waitForTimeout(500);
  await page.screenshot({ path: out + 'dusk1.png' });
  await G(() => { const c = window.__game.scene.getScene('game').clock; c.t = 240 - 40 + 33; });
  await page.waitForTimeout(500);
  await page.screenshot({ path: out + 'dusk2.png' });
  await G(() => window.__game.scene.getScene('game').debugNight());
  await page.waitForTimeout(1500);
  await page.screenshot({ path: out + 'night.png' });
  console.log(JSON.stringify(await G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'); return { label: s.clock.label, amb: s.clock.ambient(), lm: u.lightmap.visible, notice: u.noticeText.text, lights: s.lightSources().length, fps: Math.round(window.__game.loop.actualFps) }; })));
  console.log('errors', JSON.stringify(errors, null, 1));
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
