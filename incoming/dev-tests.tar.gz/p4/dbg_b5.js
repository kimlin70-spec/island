const { open } = require('./lib.js');
(async () => {
  const T = await open({ w: 1920, h: 1200 });
  const { page, G } = T;
  await G(() => { const s = window.__game.scene.getScene('game'), orig = s.onPress; window.__presses = [];
    s.onPress = function (p) { const o = this.map.pickObject(p.worldX, p.worldY); const p2 = this.player;
      window.__presses.push({ wx: +p.worldX.toFixed(1), wy: +p.worldY.toFixed(1), picked: o ? (o.type || o.kind) + '@' + o.col + ',' + o.row : null, mode: this.build.mode, player: [+p2.col.toFixed(2), +p2.row.toFixed(2)] }); return orig.call(this, p); };
    const ob = s.build.commit.bind(s.build); s.build.commit = (wx, wy) => { window.__presses.push({ commit: [+wx.toFixed(1), +wy.toFixed(1)], player: [+s.player.col.toFixed(2), +s.player.row.toFixed(2)], occ: s.characterTiles().map(t=>t.col+','+t.row).join(' ') }); return ob(wx, wy); }; });
  const info = await G(() => { const s = window.__game.scene.getScene('game'), m = s.map, out = [];
    for (let k = 1; k <= 9; k++) { const o = m.objectAt(37 + k, 39); out.push(k + ':' + (m.isWalkable(37 + k, 39) ? 'w' : 'X') + (o ? o.kind : '')); }
    const cam = s.cameras.main; return { row: out.join(' '), cam: [cam.midPoint.x, cam.midPoint.y, cam.scrollX, cam.scrollY] }; });
  console.log(JSON.stringify(info));
  const w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main;
    return { x: (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, y: (wy - cam.midPoint.y) * cam.zoom + cam.height / 2 }; }, [wx, wy]);
  const clickTile = async (c, r) => { const p = await w2p((c - r) * 40, (c + r) * 20); await page.mouse.move(p.x, p.y); await page.mouse.click(p.x, p.y); };
  await page.mouse.click(1852, 328); await page.waitForTimeout(300); await page.mouse.click(1746, 402); await page.waitForTimeout(300); await page.mouse.click(1746, 402 + 4 * 66); await page.waitForTimeout(300);
  await clickTile(45, 39);
  console.log('path', await G(() => window.__game.scene.getScene('game').player.path.map(t => t.col + ',' + t.row).join(' ')));
  await page.mouse.click(1824, 1104); await page.waitForTimeout(400); await page.mouse.click(776 + 20 + 2 * 182 + 85, 898); await page.waitForTimeout(400);
  await clickTile(43, 39);
  await T.arrive();
  console.log(JSON.stringify(await G(() => window.__presses), null, 0));
  console.log(JSON.stringify(await G(() => { const s = window.__game.scene.getScene('game'); return { tile: [s.player.tile.col, s.player.tile.row], structs: s.map.structures.map(x => x.type + '@' + x.col + ',' + x.row) }; })));
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})();
