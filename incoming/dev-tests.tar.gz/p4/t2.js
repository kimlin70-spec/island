// Phase 4: 시간 흐름, 시계, 저녁·밤·아침 알림, 화면색, 빛(모닥불, 주인공), 시험용 도구(밤/아침/속도)
const { open, lum, trackTime } = require('./lib.js');
const out = __dirname + '/';
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 260) : '')); };
const hex = (n) => '#' + n.toString(16).padStart(6, '0');
(async () => {
  const T = await open();
  await T.G(() => { window.__game.scene.getScene('game').enemies.spawn = () => null; });   // Phase 4 시험: 좀비는 끈다
  const { page, G, W, errors } = T;
  await trackTime(G);
  await G(() => { window.__game.scene.getScene('game').events.on('preupdate', (t, d) => { window.__lastDelta = d; }); });
  const S = () => G(() => {
    const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'), c = s.clock, a = c.ambient();
    return { label: c.label, night: c.isNight, t: +c.t.toFixed(2), day: c.day, amb: '#' + a.color.toString(16).padStart(6, '0'), str: +a.strength.toFixed(3),
             lm: u.lightmap.visible, icon: u.clockIcon.texture.key, text: u.clockText.text, barW: u.clockShown.w, notice: u.noticeBox.visible ? u.noticeText.text : null,
             hearts: s.hearts.value, heartIcons: u.heartIcons.map(h => h.texture.key === 'icon_heart' ? 1 : 0).join(''), todo: [...s.todo.done], speed: s.speed, gts: Math.abs(window.__game.anims.globalTimeScale * window.__lastDelta / 1000 - s.dt) < 1e-6 ? s.speed : -window.__game.anims.globalTimeScale, gt: +window.__gt.toFixed(2) };
  });

  // A) 처음: 1일째 낮, 해, 하트 5개, 빛 지도 숨김
  let s = await S();
  ok('A1 starts at day 1: label, sun icon, hearts 5, lightmap hidden', s.label === '1일째 낮' && s.text === '1일째 낮' && s.icon === 'icon_sun' && s.heartIcons === '11111' && !s.lm && s.amb === '#ffffff', JSON.stringify(s));
  // 시계는 게임 시간대로 흐른다
  const t0 = s.t, g0 = s.gt;
  await page.waitForTimeout(2500);
  s = await S();
  ok('A2 clock follows game time', Math.abs((s.t - t0) - (s.gt - g0)) < 0.05 && s.t - t0 > 0.5, `clock +${(s.t - t0).toFixed(2)} game +${(s.gt - g0).toFixed(2)}`);
  ok('A3 progress bar width follows progress', s.barW === Math.round(356 * s.t / 240), s.barW + ' vs ' + Math.round(356 * s.t / 240));

  // B) 저녁: 낮의 마지막 40초. "곧 밤이 됩니다", 화면색이 변하기 시작한다
  await G(() => { window.__game.scene.getScene('game').clock.t = 199.6; });
  await W(() => window.__game.scene.getScene('game').clock.isDusk);
  await page.waitForTimeout(200);
  s = await S();
  ok('B1 dusk starts: notice', s.notice === '곧 밤이 됩니다', s.notice);
  await G(() => { window.__game.scene.getScene('game').clock.t = 210; });
  await page.waitForTimeout(300);
  s = await S();
  ok('B2 first half of dusk: colour moves toward #ffd2a6, light strength 0, lightmap shown', s.lm && s.str === 0 && s.amb !== '#ffffff' && s.amb !== '#ffd2a6', JSON.stringify([s.amb, s.str]));
  await G(() => { window.__game.scene.getScene('game').clock.t = 230; });
  await page.waitForTimeout(300);
  s = await S();
  ok('B3 second half of dusk: colour between #ffd2a6 and #6670b8, strength about 0.5', s.str > 0.45 && s.str < 0.6 && s.amb !== '#ffd2a6' && s.amb !== '#6670b8', JSON.stringify([s.amb, s.str]));

  // C) 밤: "밤이 되었습니다", 1일째 밤, 달, 파란 막대, 화면색 #6670b8
  await G(() => { window.__game.scene.getScene('game').clock.t = 239.7; });
  await W(() => window.__game.scene.getScene('game').clock.isNight);
  await page.waitForTimeout(200);
  s = await S();
  ok('C1 night: notice, label, moon, colour, strength 1', s.notice === '밤이 되었습니다' && s.label === '1일째 밤' && s.text === '1일째 밤' && s.icon === 'icon_moon' && s.amb === '#6670b8' && s.str === 1 && s.lm, JSON.stringify(s));
  await G(() => { window.__game.scene.getScene('game').clock.t = 40; });
  await page.waitForTimeout(400);
  const nightFill = await G(() => { const u = window.__game.scene.getScene('ui'); return u.clockBar.commandBuffer.filter(v => typeof v === 'number' && v > 0xffff).map(v => v.toString(16)); });
  ok('C2 night bar uses the night blue', nightFill.includes('687ac4'), nightFill.join());

  // D) 빛: 모닥불 둘레가 밝고, 주인공 둘레의 옅은 빛이 따라온다(카메라를 세워 두고 같은 화면 자리를 잰다)
  const fire = await G(() => {
    const s = window.__game.scene.getScene('game'), p = s.player.tile;
    for (const [dc, dr] of [[3, 0], [0, 3], [-3, 0], [0, -3], [3, 3]]) { const c = p.col + dc, r = p.row + dr; if (s.build.canBuildAt(c, r)) { s.build.place('campfire', [{ col: c, row: r }]); return [c, r]; } }
  });
  await G(() => { const s = window.__game.scene.getScene('game'); s.cameras.main.stopFollow(); });
  await page.waitForTimeout(400);
  const scr = (wx, wy) => G(([wx, wy]) => { const c = window.__game.scene.getScene('game').cameras.main; return [(wx - c.midPoint.x) * c.zoom + c.width / 2, (wy - c.midPoint.y) * c.zoom + c.height / 2]; }, [wx, wy]);
  const fw = await G(([c, r]) => { const s = window.__game.scene.getScene('game').map.structureAt(c, r).sprite; return [s.x, s.y]; }, fire);
  const [fx, fy] = await scr(fw[0] + 90, fw[1] - 17.5 + 40);   // 모닥불에서 조금 떨어진 땅
  const withFire = await lum(page, fx, fy, 14);
  const glowNight = await G(([c, r]) => +window.__game.scene.getScene('game').map.structureAt(c, r).glow.alpha.toFixed(3), fire);
  await page.screenshot({ path: out + 'night_fire.png' });
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.build.destroy(s.map.structureAt(c, r)); }, fire);
  await page.waitForTimeout(500);
  const noFire = await lum(page, fx, fy, 14);
  ok('D1 the ground near a campfire is brighter at night', withFire > noFire * 1.3, `with ${withFire} without ${noFire}`);
  ok('D2 campfire glow alpha is the night value 0.45', glowNight === 0.45, glowNight);
  // 주인공 빛
  const pw = await G(() => { const sp = window.__game.scene.getScene('game').player.sprite; return [sp.x, sp.y]; });
  const [px, py] = await scr(pw[0] + 70, pw[1] - 24);
  const withP = await lum(page, px, py, 12);
  const far = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player; const t = [p.tile.col + 8, p.tile.row - 8]; for (let k = 0; k < 6 && !s.map.isWalkable(t[0], t[1]); k++) t[0]--; p.col = t[0]; p.row = t[1]; p.tile = { col: t[0], row: t[1] }; p.path = []; return t; });
  await page.waitForTimeout(500);
  const noP = await lum(page, px, py, 12);
  ok('D3 the soft light around the player follows the player', withP > noP * 1.08, `near ${withP} after moving away ${noP}`);
  const pw2 = await G(() => { const sp = window.__game.scene.getScene('game').player.sprite; return [sp.x, sp.y]; });
  const [px2, py2] = await scr(pw2[0] + 70, pw2[1] - 24);
  const newSpot = await lum(page, px2, py2, 12);
  console.log('   light at the new player spot:', newSpot);

  // E) 아침: "2일째 아침입니다", 2일째 낮, 3초에 걸쳐 밝아진다, 하트 +2, 할 일 체크
  await G(() => { const s = window.__game.scene.getScene('game'); s.cameras.main.startFollow(s.player.sprite, false, 0.12, 0.12); s.hearts.value = 2; s.events.emit('hearts-changed'); s.clock.t = 149.7; });
  await W(() => !window.__game.scene.getScene('game').clock.isNight);
  await page.waitForTimeout(100);
  s = await S();
  ok('E1 morning: label day 2, no notice on the first morning (result window instead), sun, hearts +2, to-do 6 checked', s.label === '2일째 낮' && s.notice !== '2일째 아침입니다' && s.icon === 'icon_sun' && s.hearts === 4 && s.heartIcons === '11110' && s.todo.includes('morning'), JSON.stringify(s));
  const mid = await G(() => { const c = window.__game.scene.getScene('game').clock; c.dawn = 1.5; const a = c.ambient(); return ['#' + a.color.toString(16).padStart(6, '0'), +a.strength.toFixed(2)]; });
  ok('E2 halfway through the 3-second dawn the colour is between night and day', mid[0] !== '#6670b8' && mid[0] !== '#ffffff' && mid[1] === 0.5, JSON.stringify(mid));
  await W(() => window.__game.scene.getScene('game').clock.dawn === 0, null, 30000);
  await page.waitForTimeout(300);
  s = await S();
  ok('E3 after the dawn the screen is back to day (lightmap hidden)', s.amb === '#ffffff' && !s.lm && s.str === 0, JSON.stringify([s.amb, s.lm]));
  // Phase 5: 첫 아침의 결과 창 -> 계속하기
  await W(() => !!window.__game.scene.getScene('ui').modal, null, 30000);
  const kb = await G(() => { const u = window.__game.scene.getScene('ui'); const t = u.modal.list.find((o) => o.type === 'Text' && o.text === '계속하기'); return [t.x, t.y]; });
  await page.mouse.click(kb[0], kb[1]);
  await page.waitForTimeout(300);
  ok('E5 the first-morning result window closes with 계속하기', !(await G(() => window.__game.scene.getScene('ui').modal)) && await G(() => window.__game.scene.isActive('game')));
  const glowDay = await G(() => { const s = window.__game.scene.getScene('game'); const p = s.player.tile; for (const [dc, dr] of [[2, 0], [0, 2], [-2, 0], [0, -2]]) if (s.build.canBuildAt(p.col + dc, p.row + dr)) { const f = s.build.place('campfire', [{ col: p.col + dc, row: p.row + dr }]); s.build.updateGlow(0); const a = +f.glow.alpha.toFixed(2); s.build.destroy(f); return a; } });
  ok('E4 campfire glow alpha is the day value 0.2', glowDay === 0.2, glowDay);

  // F) 시험용 도구: 밤으로 / 아침으로 / 속도 (실제 클릭)
  const ui = async (x, y) => { await page.mouse.click(x, y); await page.waitForTimeout(250); };
  await ui(1852, 328);                                         // "시험"
  await page.screenshot({ path: out + 'debug_window.png' });
  const labels = await G(() => window.__game.scene.getScene('ui').debugLabels.map(d => d.label.text));
  // Phase 7: 첫 아침의 결과 창에서 "계속하기"를 누른 뒤면 2단계라 첫 단추가 "나무, 돌, 철광석 +20"
  const stage2 = await G(() => window.__game.scene.getScene('game').stage >= 2);
  ok('F0 debug window items', labels.join('|') === (stage2 ? '나무, 돌, 철광석 +20' : '나무, 돌 +20') + '|밤으로 넘기기|아침으로 넘기기|좀비 1마리 부르기|' + (stage2 ? '해적 부르기|' : '') + '속도 ×1|닫기', labels.join('|'));
  await ui(1746, 454);                                         // 밤으로 넘기기
  s = await S();
  ok('F1 "밤으로 넘기기" starts the night at once', s.night && s.t < 1 && s.label === '2일째 밤' && s.notice === '밤이 되었습니다', JSON.stringify(s));
  await ui(1746, 454);
  ok('F2 pressing it again during the night does nothing', (await S()).night && (await S()).label === '2일째 밤');
  await ui(1746, 510);                                         // 아침으로 넘기기
  s = await S();
  ok('F3 "아침으로 넘기기" starts the next morning', !s.night && s.label === '3일째 낮' && s.notice === '3일째 아침입니다', JSON.stringify(s));
  await ui(1746, 510);
  ok('F4 pressing it during the day does nothing', (await S()).label === '3일째 낮');
  await ui(1746, stage2 ? 678 : 622);                                         // 속도
  s = await S();
  const lab = await G((i) => window.__game.scene.getScene('ui').debugLabels[i].label.text, stage2 ? 5 : 4);
  ok('F5 speed toggle: ×3, label updates, animations follow', s.speed === 3 && s.gts === 3 && lab === '속도 ×3', JSON.stringify([s.speed, s.gts, lab]));
  const a0 = await S();
  await page.waitForTimeout(2000);
  const a1 = await S();
  ok('F6 at ×3 the clock runs with the faster game time', Math.abs((a1.t - a0.t) - (a1.gt - a0.gt)) < 0.05 && (a1.t - a0.t) > 2, `clock +${(a1.t - a0.t).toFixed(2)} game +${(a1.gt - a0.gt).toFixed(2)}`);
  await ui(1746, stage2 ? 678 : 622);
  s = await S();
  ok('F7 speed back to ×1', s.speed === 1 && s.gts === 1 && await G((i) => window.__game.scene.getScene('ui').debugLabels[i].label.text, stage2 ? 5 : 4) === '속도 ×1');
  await ui(1746, stage2 ? 734 : 678);                                         // 닫기
  ok('F8 close', !(await G(() => window.__game.scene.getScene('ui').debugWin.visible)));

  // G) 하루가 저절로 넘어간다(저녁 알림 한 번, 밤, 아침)
  const evts = await G(() => { const s = window.__game.scene.getScene('game'); window.__ev = []; for (const e of ['dusk', 'night', 'morning']) s.events.on(e, () => window.__ev.push(e)); s.clock.t = 239.5; return true; });
  await W(() => window.__game.scene.getScene('game').clock.isNight);
  await G(() => { window.__game.scene.getScene('game').clock.t = 149.5; });
  await W(() => !window.__game.scene.getScene('game').clock.isNight);
  const ev = await G(() => window.__ev);
  ok('G a whole cycle by itself: dusk once, night, morning', ev.join() === 'dusk,night,morning', ev.join());

  console.log('errors', JSON.stringify(errors, null, 1));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
