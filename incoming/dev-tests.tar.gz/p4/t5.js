// 숨겨진 "쉬는 중" 버튼 자리를 누르면 월드가 받는가 / 보일 때는 월드가 받지 않는가
const { open } = require('./lib.js');
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 200) : '')); };
(async () => {
  const T = await open();
  const { page, G, W, errors } = T;
  await G(() => { const s = window.__game.scene.getScene('game'); window.__presses = 0; s.input.on('pointerdown', () => window.__presses++); });
  await page.mouse.click(960, 1132); await page.waitForTimeout(250);
  const hiddenPress = await G(() => window.__presses);
  ok('hidden rest button: the world receives the tap', hiddenPress === 1, hiddenPress);
  // 텐트에 들어가서 버튼이 보일 때는 월드가 받지 않는다
  await G(() => { const s = window.__game.scene.getScene('game'), b = s.build, p = s.player.tile;
    for (const [dc, dr] of [[2, -2], [2, 1], [-3, -1]]) { const c = p.col + dc, r = p.row + dr, tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }]; if (tiles.every(t => b.canBuildAt(t.col, t.row))) { const t = b.place('tent', tiles); s.pressTent(t); return; } } });
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await G(() => { window.__presses = 0; });
  // 버튼의 가장자리(글자 위) 누르기 -> 나온다, 월드는 받지 않는다
  await page.mouse.click(1100, 1132); await page.waitForTimeout(250);
  const r = await G(() => ({ presses: window.__presses, resting: window.__game.scene.getScene('game').rest.resting }));
  ok('visible rest button: exits, the world does not get the tap', r.presses === 0 && !r.resting, JSON.stringify(r));
  console.log('errors', JSON.stringify(errors));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
