// 태블릿 크기(1024×768) 터치: 텐트 들어가기, 쉬는 중 버튼으로 나오기, 텐트를 눌러 나오기
const { open } = require('./lib.js');
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };

(async () => {
  const T = await open({ w: 1024, h: 768, touch: true });
  const { page, G, W } = T;
  const g2p = (x, y) => G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect();
    return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
  const w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height }; }, [wx, wy]);
  const tapGame = async (x, y) => { const p = await g2p(x, y); await page.touchscreen.tap(p.x, p.y); };
  const st = () => G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'), p = s.player;
    return { resting: s.rest.resting, hidden: !p.sprite.visible, tex: s.rest.tent ? s.rest.tent.sprite.texture.key : null, button: u.restBox ? u.restBox.visible : null,
             tile: [p.tile.col, p.tile.row], moving: p.moving, speed: s.speed }; });

  // 텐트를 주인공 가까이에 놓는다(짓기는 Phase 3 시험에서 확인했다)
  const tent = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    for (let r = p.tile.row - 4; r <= p.tile.row + 3; r++) for (let c = p.tile.col - 4; c <= p.tile.col + 3; c++) {
      const tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }];
      if (Math.max(Math.abs(c - p.tile.col), Math.abs(r - p.tile.row)) < 2) continue;
      if (tiles.every((t) => s.build.canBuildAt(t.col, t.row))) { const t = s.build.place('tent', tiles); return { x: t.sprite.x, y: t.sprite.y, h: t.sprite.displayHeight * t.sprite.originY, tiles }; }
    }
    return null; });
  ok('tent placed near the player', !!tent, JSON.stringify(tent && tent.tiles));
  const tapTent = async () => { const p = await w2p(tent.x, tent.y - tent.h * 0.5); await page.touchscreen.tap(p.x, p.y); };

  // 1. 텐트를 터치 -> 걸어가서 들어간다
  await page.waitForTimeout(300);
  await tapTent();
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
  await page.waitForTimeout(300);
  let s = await st();
  ok('touch the tent: walks there and goes in', s.resting && s.hidden && s.tex === 'build_tent_lit' && s.button === true && s.speed === 4, JSON.stringify(s));
  const entry = s.tile;

  // 2. 쉬는 중 버튼을 터치 -> 들어갔던 칸으로 나온다
  await tapGame(960, 1132);
  await page.waitForTimeout(400);
  s = await st();
  ok('touch the rest button: comes out on the entry tile', !s.resting && !s.hidden && s.tex === null && s.button === false && s.tile.join() === entry.join() && !s.moving && s.speed === 1, JSON.stringify(s));
  const tex = await G(() => window.__game.scene.getScene('game').map.structures.find((x) => x.type === 'tent').sprite.texture.key);
  ok('tent picture back to build_tent', tex === 'build_tent', tex);

  // 3. 다시 들어가서 텐트를 터치 -> 나온다
  await tapTent();
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
  await page.waitForTimeout(300);
  await tapTent();
  await page.waitForTimeout(400);
  s = await st();
  ok('touch the tent while resting: comes out', !s.resting && !s.hidden && s.button === false && s.tile.join() === entry.join(), JSON.stringify(s));

  // 4. 쉬는 동안 땅을 터치해도 아무 일이 없다
  await tapTent();
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 60000);
  await page.waitForTimeout(300);
  const far = await w2p((entry[0] + 2 - entry[1] - 2) * 40 + 0, (entry[0] + 2 + entry[1] + 2) * 20);
  await page.touchscreen.tap(far.x, far.y);
  await page.waitForTimeout(400);
  s = await st();
  ok('touch the ground while resting: nothing happens', s.resting && s.hidden && !s.moving, JSON.stringify(s));
  await page.screenshot({ path: __dirname + '/tablet_resting.png' });

  ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.browser.close();
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
