// Phase 4: 텐트에 들어가기, 쉬는 동안 시간 4배와 하트 회복, 나오기(버튼, 텐트), 치우기, 빛
const { open, trackTime } = require('./lib.js');
const out = __dirname + '/';
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 260) : '')); };
(async () => {
  const T = await open();
  await T.G(() => { window.__game.scene.getScene('game').enemies.spawn = () => null; });   // Phase 4 시험: 좀비는 끈다
  const { page, G, W, tilePos, arrive, errors } = T;
  await trackTime(G);
  await G(() => { window.__game.scene.getScene('game').events.on('preupdate', (t, d) => { window.__lastDelta = d; }); });
  const S = () => G(() => {
    const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'), p = s.player, tent = s.map.structures.find(x => x.type === 'tent');
    return { resting: s.rest.resting, visible: p.sprite.visible, tile: [p.tile.col, p.tile.row], moving: p.moving, tentKey: tent ? tent.sprite.texture.key : null,
             restBtn: u.restBox.visible, speed: s.speed, gts: Math.abs(window.__game.anims.globalTimeScale * window.__lastDelta / 1000 - s.dt) < 1e-6 ? s.speed : -window.__game.anims.globalTimeScale, hearts: s.hearts.value, heartIcons: u.heartIcons.map(h => h.texture.key === 'icon_heart' ? 1 : 0).join(''),
             clockT: +s.clock.t.toFixed(2), gt: +window.__gt.toFixed(2), lights: s.lightSources().map(l => [Math.round(l.x), Math.round(l.y), Math.round(l.radius), l.alpha]), structs: s.map.structures.length };
  });
  // 주인공 오른쪽 위에 텐트를 짓는다(코드로)
  const tent = await G(() => {
    const s = window.__game.scene.getScene('game'), b = s.build, p = s.player.tile;
    for (const [dc, dr] of [[2, -2], [2, 1], [-3, -1], [1, 2], [-2, 2]]) {
      const c = p.col + dc, r = p.row + dr, tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }];
      if (tiles.every(t => b.canBuildAt(t.col, t.row))) { const x = b.place('tent', tiles); return { col: c, row: r, x: x.sprite.x, y: x.sprite.y }; }
    }
  });
  console.log('tent at', JSON.stringify(tent));
  const tentPoint = () => G(() => { const s = window.__game.scene.getScene('game'), x = s.map.structures.find(x => x.type === 'tent'), c = s.cameras.main; return { x: (x.sprite.x - 10 - c.midPoint.x) + c.width / 2, y: (x.sprite.y - 45 - c.midPoint.y) + c.height / 2 }; });

  // A) 텐트를 누르면 붙은 칸까지 걸어가서 들어간다
  let tp = await tentPoint();
  await page.mouse.click(tp.x, tp.y);
  await page.waitForTimeout(150);
  let s = await S();
  ok('A1 tapping the tent walks to it', s.moving && !s.resting, JSON.stringify(s));
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await page.waitForTimeout(300);
  s = await S();
  const entry = s.tile;
  const adj = await G(([c, r]) => { const t = window.__game.scene.getScene('game').map.structures.find(x => x.type === 'tent'); return t.tiles.some(k => Math.max(Math.abs(k.col - c), Math.abs(k.row - r)) === 1); }, entry);
  ok('A2 inside: player hidden, tent lit, rest button, time ×4', !s.visible && s.tentKey === 'build_tent_lit' && s.restBtn && s.speed === 4 && s.gts === 4 && adj, JSON.stringify(s));
  await page.screenshot({ path: out + 'resting.png' });

  // B) 시간이 4배로 흐른다
  const a0 = await S();
  await page.waitForTimeout(2000);
  const a1 = await S();
  ok('B clock runs with game time at ×4', Math.abs((a1.clockT - a0.clockT) - (a1.gt - a0.gt)) < 0.1 && (a1.clockT - a0.clockT) > 3, `clock +${(a1.clockT - a0.clockT).toFixed(2)} game +${(a1.gt - a0.gt).toFixed(2)}`);

  // C) 8초(게임 시간)마다 하트가 1 찬다
  await G(() => { const s = window.__game.scene.getScene('game'); s.hearts.value = 2; s.events.emit('hearts-changed'); s.rest.healLeft = 8; window.__h0 = window.__gt; });
  await W(() => window.__game.scene.getScene('game').hearts.value === 3, null, 60000);
  const took = await G(() => window.__gt - window.__h0);
  s = await S();
  ok('C1 one heart after about 8 seconds of game time', took > 7.5 && took < 8.8 && s.heartIcons === '11100', took.toFixed(2) + 's ' + s.heartIcons);
  await W(() => window.__game.scene.getScene('game').hearts.value === 5, null, 90000);
  await page.waitForTimeout(1500);
  ok('C2 hearts stop at the maximum', (await S()).hearts === 5);

  // D) 쉬는 동안 땅을 눌러도 아무 일이 없다
  const g = await tilePos(entry[0] - 3, entry[1] + 2);
  await page.mouse.click(g.x, g.y);
  await page.waitForTimeout(200);
  s = await S();
  ok('D tapping the ground while resting does nothing', s.resting && !s.moving && !s.visible);

  // E) 아래 버튼을 누르면 들어갔던 칸으로 나온다
  await page.mouse.click(960, 1132);
  await page.waitForTimeout(250);
  s = await S();
  ok('E1 the rest button brings the player out on the entry tile', !s.resting && s.visible && s.tile.join() === entry.join() && s.tentKey === 'build_tent' && !s.restBtn && s.speed === 1 && s.gts === 1, JSON.stringify(s));
  await page.screenshot({ path: out + 'after_exit.png' });

  // F) 다시 들어가서 텐트를 누르면 나온다
  tp = await tentPoint();
  await page.mouse.click(tp.x, tp.y);
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await page.waitForTimeout(300);
  tp = await tentPoint();
  await page.mouse.click(tp.x, tp.y);
  await page.waitForTimeout(250);
  s = await S();
  ok('F tapping the tent while resting brings the player out', !s.resting && s.visible && s.tile.join() === entry.join(), JSON.stringify(s));

  // G) 밤의 빛: 쉬는 동안에는 텐트 문 앞의 빛, 주인공 빛은 없다
  await page.mouse.click(tp.x, tp.y);
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await G(() => window.__game.scene.getScene('game').debugNight());
  await page.waitForTimeout(800);
  s = await S();
  const door = await G(() => { const s = window.__game.scene.getScene('game'), t = s.rest.tent; return [Math.round(t.sprite.x + 40), Math.round(t.sprite.y - 1)]; });
  ok('G1 at night inside: one light at the tent door (110, alpha 0.8), no player light', s.lights.length === 1 && s.lights[0][0] === door[0] && s.lights[0][1] === door[1] && s.lights[0][2] === 110 && s.lights[0][3] === 0.8, JSON.stringify([s.lights, door]));
  await page.screenshot({ path: out + 'night_resting.png' });
  await page.mouse.click(960, 1132);
  await page.waitForTimeout(250);
  s = await S();
  ok('G2 after coming out: the player light is back', s.lights.length === 1 && s.lights[0][2] === 150 && s.lights[0][3] === 0.6, JSON.stringify(s.lights));

  // H) 쉬는 동안 치우기로 텐트를 없애면 주인공이 나온다
  await page.mouse.click(tp.x, tp.y);
  await W(() => window.__game.scene.getScene('game').rest.resting, null, 30000);
  await page.waitForTimeout(200);
  await page.mouse.click(1824, 1104); await page.waitForTimeout(200);            // 만들기
  await page.mouse.click(776 + 20 + 5 * 182 + 85, 898); await page.waitForTimeout(200);   // 치우기
  tp = await tentPoint();
  await page.mouse.click(tp.x, tp.y); await page.waitForTimeout(300);
  s = await S();
  ok('H removing the tent while inside: tent gone, player out on the entry tile, speed back', !s.resting && s.visible && s.structs === 0 && s.tile.join() === entry.join() && s.speed === 1 && !s.restBtn, JSON.stringify(s));
  await page.mouse.click(1824, 1104); await page.waitForTimeout(200);            // 창 닫기

  // I) 숨겨진 버튼 자리를 누르면 월드로 간다(땅이면 걸어간다)
  const below = await G(() => { const s = window.__game.scene.getScene('game'), c = s.cameras.main; for (let r = 0; r < 64; r++) for (let col = 0; col < 64; col++) { if (!s.map.isWalkable(col, r)) continue; const sx = (col - r) * 40 - c.scrollX, sy = (col + r) * 20 - c.scrollY; if (Math.abs(sx - 960) < 60 && Math.abs(sy - 1132) < 25) return [col, r, sx, sy]; } return null; });
  if (below) {
    await page.mouse.click(below[2], below[3]);
    await page.waitForTimeout(200);
    s = await S();
    ok('I the hidden rest button does not block the world', s.moving || s.tile.join() === below.slice(0, 2).join(), JSON.stringify([below, s.tile, s.moving]));
  } else console.log('   (I skipped: no walkable tile under the hidden button)');

  // J) 울타리로 둘러싸인 텐트는 들어갈 수 없다(갈 수 없으면 아무 일도 없다)
  await arrive();
  const t2 = await G(() => {
    const s = window.__game.scene.getScene('game'), b = s.build, p = s.player.tile;
    for (const [dc, dr] of [[3, -3], [-4, -3], [3, 2], [-4, 2]]) {
      const c = p.col + dc, r = p.row + dr, tiles = [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }];
      const ring = []; for (let cc = c - 1; cc <= c + 2; cc++) for (let rr = r - 1; rr <= r + 2; rr++) if (cc === c - 1 || cc === c + 2 || rr === r - 1 || rr === r + 2) ring.push([cc, rr]);
      if (tiles.every(t => b.canBuildAt(t.col, t.row)) && ring.every(([cc, rr]) => b.canBuildAt(cc, rr) || !s.map.isWalkable(cc, rr))) {
        b.place('tent', tiles); for (const [cc, rr] of ring) if (b.canBuildAt(cc, rr)) b.place('fence', [{ col: cc, row: rr }]); return [c, r];
      }
    }
  });
  if (t2) {
    tp = await tentPoint();
    await page.mouse.click(tp.x, tp.y);
    await page.waitForTimeout(400);
    s = await S();
    ok('J a fenced-in tent cannot be reached: nothing happens', !s.moving && !s.resting, JSON.stringify(s));
  } else console.log('   (J skipped: no place for a fenced tent)');

  console.log('errors', JSON.stringify(errors, null, 1));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
