// 검토에서 확인된 두 문제를 고친 뒤의 시험
//  A. 울타리 그림(윗부분 포함)을 누르면 아무 일도 없다(울타리 칸은 막힌 칸)
//  B. 걷는 도중 시설을 지어 비스듬한 걸음의 양옆이 막히면 그 걸음 앞에서 멈춘다. 걷는 중인 걸음의 양옆 칸에는 지을 수 없다.
const { open } = require('./lib.js');
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };

async function setup() {
  const T = await open({ w: 1920, h: 1200 });
  const { page, G } = T;
  T.g2p = (x, y) => G(([x, y]) => { const g = window.__game, r = g.canvas.getBoundingClientRect();
    return { x: r.left + x * r.width / g.canvas.width, y: r.top + y * r.height / g.canvas.height }; }, [x, y]);
  T.ui = async (x, y, wait = 300) => { const p = await T.g2p(x, y); await page.mouse.click(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  T.w2p = (wx, wy) => G(([wx, wy]) => { const g = window.__game, s = g.scene.getScene('game'), cam = s.cameras.main, r = g.canvas.getBoundingClientRect();
    const sx = (wx - cam.midPoint.x) * cam.zoom + cam.width / 2, sy = (wy - cam.midPoint.y) * cam.zoom + cam.height / 2;
    return { x: r.left + sx * r.width / g.canvas.width, y: r.top + sy * r.height / g.canvas.height, on: sx >= 0 && sy >= 0 && sx < cam.width && sy < cam.height }; }, [wx, wy]);
  T.clickWorld = async (wx, wy, wait = 0) => { const p = await T.w2p(wx, wy); if (!p.on) throw new Error('off ' + wx + ',' + wy); await page.mouse.move(p.x, p.y); await page.mouse.click(p.x, p.y); if (wait) await page.waitForTimeout(wait); };
  T.clickTile = (c, r, wait) => T.clickWorld((c - r) * 40, (c + r) * 20, wait);
  T.stopped = () => T.W(() => !window.__game.scene.getScene('game').player.moving, null, 60000);
  // 누를 때 게임이 실제로 받은 좌표와 고른 것
  await G(() => { const s = window.__game.scene.getScene('game'), orig = s.onPress; window.__presses = [];
    s.onPress = function (p) { const o = this.map.pickObject(p.worldX, p.worldY);
      window.__presses.push({ wx: p.worldX, wy: p.worldY, picked: o ? (o.type || o.kind) + '@' + o.col + ',' + o.row : null }); return orig.call(this, p); }; });
  // 프레임마다: 걷는 중 비스듬한 걸음의 양옆 칸이 막혔는가, 서 있거나 들어서는 칸이 막혔는가
  await G(() => { const s = window.__game.scene.getScene('game'), m = s.map; window.__bad = []; window.__trail = [];
    s.events.on('postupdate', () => { const p = s.player, w = (c, r) => m.isWalkable(c, r);
      window.__trail.push([+p.col.toFixed(3), +p.row.toFixed(3)]);
      const c0 = Math.floor(p.col), c1 = Math.ceil(p.col), r0 = Math.floor(p.row), r1 = Math.ceil(p.row);
      for (let c = c0; c <= c1; c++) for (let r = r0; r <= r1; r++) if (!w(c, r)) window.__bad.push({ at: [p.col, p.row], blocked: [c, r] }); }); });
  return T;
}
const materials = async (T) => { await T.ui(1852, 328); await T.ui(1746, 398); await T.ui(1746, 398 + 5 * 56); };   // 시험 -> +20 -> 닫기
const fenceMode = async (T) => { await T.ui(1824, 1104, 400); await T.ui(776 + 20 + 2 * 182 + 85, 898, 400); };      // 만들기 -> 울타리
const closeCraft = async (T) => { await T.ui(1824, 1104, 400); };
const P = (T) => T.G(() => { const p = window.__game.scene.getScene('game').player; return { tile: [p.tile.col, p.tile.row], moving: p.moving, path: p.path.map((t) => t.col + ',' + t.row) }; });

// 울타리 그림의 안쪽(둘레 8픽셀도 같은 울타리로 골라지는) 점 중, 울타리 칸이 아닌 걸을 수 있는 칸 위에 있는 것들
const fencePoints = (T, c, r, n) => T.G(([c, r, n]) => {
  const s = window.__game.scene.getScene('game'), m = s.map, f = m.structureAt(c, r), sp = f.sprite;
  const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY, pts = [];
  for (let y = Math.ceil(top) + 1; y < top + sp.displayHeight - 1; y++) for (let x = Math.ceil(left) + 1; x < left + sp.displayWidth - 1; x++) {
    const wx = x + 0.5, wy = y + 0.5;
    let inner = true;
    for (let dy = -1; dy <= 1 && inner; dy++) for (let dx = -1; dx <= 1 && inner; dx++) if (m.pickObject(wx + dx, wy + dy) !== f) inner = false;
    if (!inner) continue;
    const fx = wx / 40, fy = wy / 20, tc = Math.round((fx + fy) / 2), tr = Math.round((fy - fx) / 2);
    if ((tc !== c || tr !== r) && m.isWalkable(tc, tr)) pts.push({ wx, wy, tile: [tc, tr] });
  }
  const out = [], step = Math.max(1, Math.floor(pts.length / n));
  for (let i = 0; i < pts.length && out.length < n; i += step) out.push(pts[i]);
  return { total: pts.length, pts: out };
}, [c, r, n]);

(async () => {
  // ---------------- A1. 울타리 줄의 윗부분을 누른다 ----------------
  {
    const T = await setup();
    const start = (await P(T)).tile;
    await materials(T); await fenceMode(T);
    for (let c = 35; c <= 39; c++) await T.clickTile(c, 37, 150);
    await closeCraft(T);
    const built = await T.G(() => window.__game.scene.getScene('game').map.structures.map((s) => s.type + '@' + s.col + ',' + s.row).join(' '));
    ok('A1 fence wall built with real clicks', built.split(' ').length === 5, built);
    const F = await fencePoints(T, 37, 37, 12);
    console.log('   inner fence pixels over other walkable tiles:', F.total, 'tapping', F.pts.length);
    let moved = 0, notFence = 0;
    for (const q of F.pts) {
      await T.G(() => { window.__presses = []; });
      await T.clickWorld(q.wx, q.wy, 250);
      const pr = await T.G(() => window.__presses[0]);
      const st = await P(T);
      if (!pr || pr.picked !== 'fence@37,37') notFence++;
      if (st.moving || st.tile.join() !== start.join()) { moved++; console.log('   moved after tap', JSON.stringify(q), JSON.stringify(pr), JSON.stringify(st)); await T.stopped(); }
    }
    ok('A1 every tap picked the fence in the game', notFence === 0 && F.pts.length >= 8, `notFence ${notFence} of ${F.pts.length}`);
    ok('A1 tapping the fence never moves the player', moved === 0, `moved ${moved}`);
    // 대조: 울타리가 없는 땅을 누르면 걷는다
    await T.clickTile(start[0] - 1, start[1] + 1, 200);
    ok('A1 control: tapping ground still walks', (await P(T)).moving || (await P(T)).tile.join() === [start[0] - 1, start[1] + 1].join());
    await T.stopped();
    ok('A1 no console errors', T.errors.length === 0, JSON.stringify(T.errors));
    await T.browser.close();
  }

  // ---------------- A2. 울타리 우리 밖에서 모서리 울타리를 누른다 ----------------
  {
    const T = await setup();
    await T.G(() => { const s = window.__game.scene.getScene('game');
      for (const [c, r] of [[39, 38], [40, 38], [41, 38], [41, 39], [39, 40], [40, 40], [41, 40]]) s.build.place('fence', [{ col: c, row: r }]); });
    await T.clickTile(42, 41); await T.stopped();
    const st0 = await P(T);
    ok('A2 player outside the pen at 42,41', st0.tile.join() === '42,41', st0.tile.join());
    const F = await fencePoints(T, 41, 40, 400);
    const overPen = F.pts.filter((q) => q.tile.join() === '40,39');
    console.log('   inner pixels of corner fence 41,40 over the pen centre 40,39:', overPen.length);
    let moved = 0;
    for (const q of overPen.filter((_, i) => i % Math.max(1, Math.floor(overPen.length / 6)) === 0).slice(0, 6)) {
      await T.clickWorld(q.wx, q.wy, 250);
      const st = await P(T);
      if (st.moving || st.tile.join() !== '42,41') { moved++; await T.stopped(); }
    }
    ok('A2 tapping the corner fence does not walk into the pen', overPen.length > 0 && moved === 0, `moved ${moved}`);
    ok('A2 no console errors', T.errors.length === 0, JSON.stringify(T.errors));
    await T.browser.close();
  }

  // ---------------- B1/B2. 걷는 도중 비스듬한 걸음의 양옆에 울타리를 짓는다 ----------------
  for (const variant of ['two', 'one']) {
    const T = await setup();
    await materials(T);
    // 새 맵(2단계 묶음): 예전 목적지 (44,32)에 철광석이 생겼다. (43,33)으로 걷고, 걷는 길의 마지막 비스듬한 걸음 A -> B 의 양옆에 울타리를 짓는다.
    await T.clickTile(43, 33);
    const full = await T.G(() => { const p = window.__game.scene.getScene('game').player; return [[p.tile.col, p.tile.row], ...p.path.map((t) => [t.col, t.row])]; });
    let k = -1;
    for (let i = 3; i + 1 < full.length; i++) if (full[i][0] !== full[i + 1][0] && full[i][1] !== full[i + 1][1]) k = i;
    const A = full[k], B = full[k + 1], dc = B[0] - A[0], dr = B[1] - A[1];
    const path0 = full.slice(1).map((t) => t.join(',')).join(' ');
    await fenceMode(T);
    const sides = variant === 'two' ? [[B[0], A[1]], [A[0], B[1]]] : [[B[0], A[1]]];
    for (const [c, r] of sides) await T.clickTile(c, r);
    const built = await T.G((sides) => sides.every(([c, r]) => { const x = window.__game.scene.getScene('game').map.structureAt(c, r); return x && x.type === 'fence'; }), sides);
    await T.stopped();
    const st = await P(T);
    const trail = await T.G(() => window.__trail);
    const between = trail.filter(([c, r]) => { const t = (c - A[0]) * dc; return t > 0.02 && t < 0.98 && Math.abs((r - A[1]) - t * dr) < 0.01; });   // A -> B 사이
    console.log('   path at start', path0, '| step', A.join(','), '->', B.join(','), '| side fences', JSON.stringify(sides), 'built', built);
    ok(`B-${variant} side fence(s) built while walking`, built && k >= 3);
    ok(`B-${variant} player stops before the closed diagonal step`, st.tile.join() === A.join(), 'ended ' + st.tile.join() + ', expected ' + A.join());
    ok(`B-${variant} never between ${A.join(',')} and ${B.join(',')}`, between.length === 0, JSON.stringify(between.slice(0, 3)));
    const bad = await T.G(() => window.__bad);
    ok(`B-${variant} never touching a blocked tile (incl. diagonal side tiles)`, bad.length === 0, JSON.stringify(bad.slice(0, 3)));
    ok(`B-${variant} no console errors`, T.errors.length === 0, JSON.stringify(T.errors));
    await T.browser.close();
  }

  // ---------------- B3. 화면에서 곧은(칸으로는 비스듬한) 울타리 줄을 걷는 길 앞에 짓는다 ----------------
  {
    const T = await setup();
    await materials(T);
    await T.clickTile(43, 33);   // 새 맵(2단계 묶음): (44,32)에는 철광석이 생겨서 한 칸 앞에서 멈춘다
    await fenceMode(T);
    const line = [[40, 33], [41, 34], [42, 35], [43, 36]];
    for (const [c, r] of line) await T.clickTile(c, r);
    const built = await T.G((line) => line.filter(([c, r]) => window.__game.scene.getScene('game').map.structureAt(c, r)).length, line);
    await T.stopped();
    const st = await P(T);
    const trail = await T.G(() => window.__trail);
    const maxD = Math.max(...trail.map(([c, r]) => c - r));
    ok('B3 fence line built while walking', built === 4, 'built ' + built);
    ok('B3 player does not cross the fence line', maxD < 7, `max col-row ${maxD.toFixed(2)}, ended ${st.tile.join()}`);
    const bad = await T.G(() => window.__bad);
    ok('B3 never touching a blocked tile', bad.length === 0, JSON.stringify(bad.slice(0, 3)));
    ok('B3 no console errors', T.errors.length === 0, JSON.stringify(T.errors));
    await T.browser.close();
  }

  // ---------------- B4. 걷는 중인 걸음이 차지하는 칸 ----------------
  {
    const T = await setup();
    const r = await T.G(() => {
      const s = window.__game.scene.getScene('game'), p = s.player, b = s.build;
      const key = (a) => a.map((t) => t.col + ',' + t.row).sort().join(' ');
      const out = {};
      out.still = key(p.occupiedTiles());
      // 37,39 -> 38,38 비스듬히 걷는 중
      p.path = [{ col: 38, row: 38 }, { col: 39, row: 37 }]; p.col = 37.4; p.row = 38.6;
      out.diag = key(p.occupiedTiles());
      out.sideBuild = [b.canBuildAt(38, 39), b.canBuildAt(37, 38)];
      out.farBuild = b.canBuildAt(40, 39);
      // 되돌아가는 중(가던 칸 38,38 은 길에서 빠졌지만 몸은 아직 그 사이에 있다)
      p.path = [{ col: 37, row: 39 }];
      out.back = key(p.occupiedTiles());
      // 걸음을 막 시작한 순간(아직 칸 중심)
      p.col = 37; p.row = 39; p.path = [{ col: 38, row: 38 }];
      out.begin = key(p.occupiedTiles());
      // 곧게 걷는 중
      p.col = 37.5; p.row = 39; p.path = [{ col: 38, row: 39 }];
      out.straight = key(p.occupiedTiles());
      p.col = 37; p.row = 39; p.path = []; p.syncSprite();
      return out;
    });
    console.log('   ', JSON.stringify(r));
    ok('B4 standing: one tile', r.still === '37,39');
    ok('B4 mid diagonal step: both ends and both side tiles', r.diag === '37,38 37,39 38,38 38,39');
    ok('B4 cannot build on the side tiles of the step in progress', r.sideBuild.every((x) => x === false) && r.farBuild === true, JSON.stringify(r.sideBuild) + ' far ' + r.farBuild);
    ok('B4 backing out of a diagonal step still covers the four tiles', r.back === '37,38 37,39 38,38 38,39');
    ok('B4 start of a diagonal step covers the four tiles', r.begin === '37,38 37,39 38,38 38,39');
    ok('B4 straight step: two tiles', r.straight === '37,39 38,39');
    ok('B4 no console errors', T.errors.length === 0, JSON.stringify(T.errors));
    await T.browser.close();
  }

  // ---------------- B5. 곧은 길 위의 칸에 울타리(이전과 같이 그 앞에서 멈춘다) ----------------
  {
    const T = await setup();
    // 37,39 에서 곧게 8칸 걸을 수 있고, 도착 칸 위에 사물 그림이 없는 방향
    const dir = await T.G(() => { const m = window.__game.scene.getScene('game').map;
      for (const [dc, dr] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { let good = true;
        for (let k = 1; k <= 8; k++) if (!m.isWalkable(37 + dc * k, 39 + dr * k)) good = false;
        const c = 37 + dc * 8, r = 39 + dr * 8;
        if (good && !m.pickObject((c - r) * 40, (c + r) * 20)) return [dc, dr]; }
      return null; });
    await materials(T);
    const dest = [37 + dir[0] * 8, 39 + dir[1] * 8];
    await T.clickTile(dest[0], dest[1]);
    const path0 = (await P(T)).path;
    await fenceMode(T);
    await T.clickTile(37 + dir[0] * 6, 39 + dir[1] * 6);          // 걷는 중이라 화면이 움직여 한 칸 옆에 지어질 수도 있다
    await T.stopped();
    const st = await P(T);
    const fence = await T.G(() => { const f = window.__game.scene.getScene('game').map.structures[0]; return f ? f.col + ',' + f.row : null; });
    const i = path0.indexOf(fence);
    console.log('   dir', dir, 'path', path0.join(' '), '| fence at', fence, '| ended', st.tile.join());
    ok('B5 straight walk: fence built on the path ahead', i > 0, 'index ' + i);
    ok('B5 straight walk stops in front of the fence', i > 0 && st.tile.join() === path0[i - 1], 'ended ' + st.tile.join());
    ok('B5 no console errors', T.errors.length === 0, JSON.stringify(T.errors));
    await T.browser.close();
  }

  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
