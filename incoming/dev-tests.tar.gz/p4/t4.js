// 사용자 요청 두 가지: (1) 주인공도 울타리를 지나가지 못한다 (2) 곡괭이로 그루터기·돌 부스러기를 파내 땅을 고르게 한다
const { open } = require('./lib.js');
const out = __dirname + '/';
let fails = 0;
const ok = (name, cond, extra = '') => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + String(extra).slice(0, 260) : '')); };
(async () => {
  const T = await open();
  const { page, G, W, tilePos, tapTile, arrive, errors } = T;
  const S = () => G(() => { const s = window.__game.scene.getScene('game'), u = window.__game.scene.getScene('ui'), p = s.player;
    return { tile: [p.tile.col, p.tile.row], moving: p.moving, acting: !!p.action, path: p.path.map(t => t.col + ',' + t.row), wood: s.inventory.count('wood'), stone: s.inventory.count('stone'),
             notice: u.noticeBox.visible ? u.noticeText.text : null, frame: p.sprite.frame.name }; });
  await G(() => { const s = window.__game.scene.getScene('game'); window.__visited = []; window.__frames = new Set(); s.events.on('update', () => { window.__visited.push(s.player.tile.col + ',' + s.player.tile.row); window.__frames.add(s.player.sprite.frame.name); }); });
  const P = await G(() => { const p = window.__game.scene.getScene('game').player.tile; return [p.col, p.row]; });
  const place = (list) => G((list) => { const s = window.__game.scene.getScene('game'); let n = 0; for (const [c, r] of list) if (s.build.canBuildAt(c, r)) { s.build.place('fence', [{ col: c, row: r }]); n++; } return n; }, list);
  const fenceTiles = () => G(() => window.__game.scene.getScene('game').map.structures.filter(x => x.type === 'fence').map(x => x.col + ',' + x.row));

  // ── (1) 울타리 ──
  // A) 울타리 줄을 사이에 두고 건너편을 누르면, 울타리를 밟지 않고 돌아서 간다
  const line = [];
  for (let r = P[1] - 2; r <= P[1] + 2; r++) line.push([P[0] + 2, r]);
  const n = await place(line);
  const fences = new Set(await fenceTiles());
  await G(() => { window.__visited = []; });
  await tapTile(P[0] + 4, P[1]);
  await page.waitForTimeout(150);
  let s = await S();
  ok('A1 a path to the other side goes around the fence line', s.moving && !s.path.some(k => fences.has(k)), JSON.stringify({ n, path: s.path }));
  await arrive();
  s = await S();
  const stepped = (await G(() => [...new Set(window.__visited)])).filter(k => fences.has(k));
  ok('A2 arrived without stepping on a fence', s.tile.join() === [P[0] + 4, P[1]].join() && stepped.length === 0, JSON.stringify([s.tile, stepped]));

  // B) 울타리 그림(칸)을 누르면 아무 일도 없다
  const fp = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), x = s.map.structureAt(c, r), cam = s.cameras.main; return { x: x.sprite.x - cam.scrollX, y: x.sprite.y - 8 - cam.scrollY }; }, [P[0] + 2, P[1]]);
  await page.mouse.click(fp.x, fp.y);
  await page.waitForTimeout(200);
  s = await S();
  ok('B tapping a fence does nothing (the fence tile cannot be entered)', !s.moving && s.tile.join() === [P[0] + 4, P[1]].join(), JSON.stringify(s));

  // C) 사방을 울타리로 막으면 나갈 수 없고, 하나를 치우면 그 틈으로 나간다
  const Q = [P[0] + 4, P[1]];
  const ring = [];
  for (let dc = -1; dc <= 1; dc++) for (let dr = -1; dr <= 1; dr++) if (dc || dr) ring.push([Q[0] + dc, Q[1] + dr]);
  await place(ring);
  const closed = await G(([c, r]) => { const m = window.__game.scene.getScene('game').map; let open = 0; for (let dc = -1; dc <= 1; dc++) for (let dr = -1; dr <= 1; dr++) if ((dc || dr) && m.isWalkable(c + dc, r + dr)) open++; return open; }, Q);
  await tapTile(Q[0] - 4, Q[1] + 3);
  await page.waitForTimeout(200);
  s = await S();
  ok('C1 fenced in on all sides: tapping outside does nothing', closed === 0 && !s.moving && s.tile.join() === Q.join(), JSON.stringify({ closed, s }));
  await page.screenshot({ path: out + 'fenced_in.png' });
  // 치우기로 아래쪽 울타리 하나를 없앤다(실제 클릭)
  await page.mouse.click(1824, 1104); await page.waitForTimeout(200);
  await page.mouse.click(776 + 20 + 5 * 182 + 85, 898); await page.waitForTimeout(200);
  // 모서리(비스듬한 칸)는 치워도 지나갈 수 없다(모서리를 끊고 지나가지 않는 규칙). 옆면을 치운다.
  const corner = [Q[0] - 1, Q[1] + 1];
  const gap = [Q[0], Q[1] + 1];
  const gp = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), x = s.map.structureAt(c, r), cam = s.cameras.main; return { x: x.sprite.x - cam.scrollX, y: x.sprite.y - 8 - cam.scrollY }; }, gap);
  await page.mouse.click(gp.x, gp.y); await page.waitForTimeout(200);
  await page.mouse.click(1824, 1104); await page.waitForTimeout(200);
  const removed = await G(([c, r]) => !window.__game.scene.getScene('game').map.structureAt(c, r), gap);
  await G(() => { window.__visited = []; });
  await tapTile(Q[0] - 4, Q[1] + 3);
  await page.waitForTimeout(150);
  s = await S();
  ok('C2 after removing one fence the player walks out through the gap', removed && s.moving, JSON.stringify({ removed, path: s.path }));
  const cornerStill = await G(([c, r]) => !!window.__game.scene.getScene('game').map.structureAt(c, r), corner);
  await arrive();
  const via = await G(([c, r]) => window.__visited.includes(c + ',' + r), gap);
  ok('C3 went through the opened tile', via && (await S()).tile.join() === [Q[0] - 4, Q[1] + 3].join());

  // D) 걸어가는 길 앞에 울타리를 지으면 그 앞에서 멈춘다
  const D0 = (await S()).tile;
  const target = await G(([c, r]) => { const s = window.__game.scene.getScene('game'); for (const [dc, dr] of [[-6, 0], [0, 6], [6, 0], [0, -6], [-5, 3], [3, 5]]) { const t = [c + dc, r + dr]; if (s.map.isWalkable(t[0], t[1])) return t; } }, D0);
  const walk = await G(([c, r]) => window.__game.scene.getScene('game').player.goTo(c, r), target);
  await page.waitForTimeout(100);
  const ahead = await G(() => { const p = window.__game.scene.getScene('game').player; const t = p.path[2] || p.path[p.path.length - 1]; return [t.col, t.row]; });
  await place([ahead]);
  await page.waitForTimeout(100);
  await arrive();
  s = await S();
  ok('D building a fence on the path ahead stops the player before it', walk && s.tile.join() !== ahead.join() && s.tile.join() !== target.join() && Math.max(Math.abs(s.tile[0] - ahead[0]), Math.abs(s.tile[1] - ahead[1])) <= 1, JSON.stringify({ ahead, s: s.tile }));

  // ── (2) 땅 고르기 ──
  // E) 나무를 베면 그루터기. 곡괭이가 없으면 그루터기를 눌렀을 때 "곡괭이가 필요합니다"
  const tree = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; return s.map.objects.filter(o => o.kind === 'tree' && s.player.neighborsOf(o.tiles).length).map(o => [o.col, o.row, Math.hypot(o.col - p.col, o.row - p.row)]).sort((a, b) => a[2] - b[2])[0]; });
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.pressNode(s.map.objectAt(c, r)); }, tree);
  await W(([c, r]) => window.__game.scene.getScene('game').map.objectAt(c, r).kind === 'stump', tree, 60000);
  await page.waitForTimeout(700);
  const stump = await G(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return { kind: o.kind, key: o.sprite.texture.key, group: o.node && o.node.group, hp: o.node && o.node.hp, pickable: o.pickable, blocks: o.blocks }; }, tree);
  s = await S();
  ok('E1 a chopped tree leaves a stump that can be dug (walkable, pickable)', stump.kind === 'stump' && stump.key === 'obj_stump' && stump.group === 'ground' && stump.hp === 3 && stump.pickable && !stump.blocks && !s.acting, JSON.stringify(stump));
  const sp = await G(([c, r]) => { const s = window.__game.scene.getScene('game'), o = s.map.objectAt(c, r), cam = s.cameras.main; return { x: o.sprite.x - cam.scrollX, y: o.sprite.y - 8 - cam.scrollY }; }, tree);
  const w0 = s.wood;
  await page.mouse.click(sp.x, sp.y);
  await page.waitForTimeout(200);
  s = await S();
  ok('E2 without a pickaxe: "곡괭이가 필요합니다" and no walking', s.notice === '곡괭이가 필요합니다' && !s.moving && !s.acting, JSON.stringify(s));

  // F) 곡괭이를 만들고 그루터기를 누르면 다가가서 파내고, 그루터기가 사라진다(재료는 그대로)
  await G(() => { const s = window.__game.scene.getScene('game'); s.inventory.add('wood', 3); s.pressCard({ id: 'pickaxe', type: 'tool', icon: 'icon_pickaxe' }); });
  const w1 = (await S()).wood;
  await G(() => window.__frames.clear());
  await page.mouse.click(sp.x, sp.y);
  await page.waitForTimeout(150);
  s = await S();
  ok('F1 with a pickaxe the stump is a target', s.acting, JSON.stringify(s));
  await W(([c, r]) => !window.__game.scene.getScene('game').map.objectAt(c, r), tree, 30000);
  s = await S();
  const fr = await G(() => [...window.__frames].map((i) => window.__game.scene.getScene('game').player.asset.frames[i]));
  ok('F2 the stump is dug out: tile clear, nothing gained, pickaxe pictures', s.wood === w1 && fr.some((n) => /pick1$/.test(n)) && fr.some((n) => /pick2$/.test(n)), JSON.stringify({ wood: [w0, w1, s.wood], fr }));
  await page.screenshot({ path: out + 'dug.png' });
  const free = await G(([c, r]) => { const m = window.__game.scene.getScene('game').map; return { obj: m.objectAt(c, r), walk: m.isWalkable(c, r), n: m.objects.filter(o => o.col === c && o.row === r).length }; }, tree);
  ok('F3 the tile is plain ground now', free.obj === null && free.walk && free.n === 0, JSON.stringify(free));

  // G) 그루터기 위에 서 있으면 옆 칸으로 비켜서서 판다
  const tree2 = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; return s.map.objects.filter(o => o.kind === 'tree' && s.player.neighborsOf(o.tiles).length).map(o => [o.col, o.row, Math.hypot(o.col - p.col, o.row - p.row)]).sort((a, b) => a[2] - b[2])[0]; });
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.pressNode(s.map.objectAt(c, r)); }, tree2);
  await W(([c, r]) => window.__game.scene.getScene('game').map.objectAt(c, r).kind === 'stump', tree2, 60000);
  await page.waitForTimeout(700);
  await G(([c, r]) => { const p = window.__game.scene.getScene('game').player; p.col = c; p.row = r; p.tile = { col: c, row: r }; p.path = []; }, tree2);
  await page.waitForTimeout(300);
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.pressNode(s.map.objectAt(c, r)); }, tree2);
  await page.waitForTimeout(100);
  s = await S();
  ok('G1 standing on the stump: the player steps to a neighbouring tile first', s.moving && s.path.length >= 1, JSON.stringify(s));
  await W(([c, r]) => !window.__game.scene.getScene('game').map.objectAt(c, r), tree2, 30000);
  s = await S();
  ok('G2 then digs it out from the side', s.tile.join() !== [tree2[0], tree2[1]].join() && Math.max(Math.abs(s.tile[0] - tree2[0]), Math.abs(s.tile[1] - tree2[1])) === 1, JSON.stringify(s.tile));

  // H) 돌을 캐면 돌 부스러기. 곡괭이로 파내면 사라진다
  const rock = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; return s.map.objects.filter(o => o.kind === 'rock' && s.player.neighborsOf(o.tiles).length).map(o => [o.col, o.row, Math.hypot(o.col - p.col, o.row - p.row)]).sort((a, b) => a[2] - b[2])[0]; });
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.pressNode(s.map.objectAt(c, r)); }, rock);
  await W(([c, r]) => window.__game.scene.getScene('game').map.objectAt(c, r).kind === 'rubble', rock, 90000);
  const st0 = (await S()).stone;
  await page.waitForTimeout(700);
  ok('H1 the player stops after the rock (does not start digging the rubble by itself)', !(await S()).acting);
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.pressNode(s.map.objectAt(c, r)); }, rock);
  await W(([c, r]) => !window.__game.scene.getScene('game').map.objectAt(c, r), rock, 30000);
  ok('H2 rubble dug out, no stone gained', (await S()).stone === st0);

  // I) 파내던 그루터기 칸에 시설을 지으면 파내기가 멈춘다(오류 없이)
  const tree3 = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player.tile; return s.map.objects.filter(o => o.kind === 'tree' && s.player.neighborsOf(o.tiles).length).map(o => [o.col, o.row, Math.hypot(o.col - p.col, o.row - p.row)]).sort((a, b) => a[2] - b[2])[0]; });
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.pressNode(s.map.objectAt(c, r)); }, tree3);
  await W(([c, r]) => window.__game.scene.getScene('game').map.objectAt(c, r).kind === 'stump', tree3, 60000);
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'), o = s.map.objectAt(c, r); o.node.hp = 99; s.pressNode(o); }, tree3);
  await W(() => window.__game.scene.getScene('game').player.swing !== null, null, 30000);
  await G(([c, r]) => { const s = window.__game.scene.getScene('game'); s.inventory.add('wood', 1); s.build.place('fence', [{ col: c, row: r }]); }, tree3);
  await page.waitForTimeout(800);
  s = await S();
  ok('I building on the stump being dug stops the digging cleanly', !s.acting && await G(([c, r]) => window.__game.scene.getScene('game').map.structureAt(c, r).type === 'fence' && !window.__game.scene.getScene('game').map.objectAt(c, r), tree3));

  console.log('errors', JSON.stringify(errors, null, 1));
  console.log(fails ? `FAILED ${fails}` : 'ALL PASS');
  await T.browser.close();
})().catch((e) => { console.error('TEST CRASHED', e); process.exit(1); });
