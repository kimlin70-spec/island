// 나무가 막 그루터기가 된 바로 다음 순간에 그 그루터기를 누르면, 곡괭이로 파는 새 행동이 시작된다(눌림이 사라지지 않는다).
// 게임 루프를 재우고 프레임을 하나씩 돌려서, 나무가 그루터기로 바뀐 프레임 바로 뒤에 누른다.
const { open } = require('./lib.js');
let fails = 0;
const ok = (name, cond, info = '') => { console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? '  ' + info : '')); if (!cond) fails++; };
(async () => {
  const T = await open({ w: 960, h: 600 });
  const { G } = T;
  const r = await G(() => {
    const g = window.__game, s = g.scene.getScene('game'), p = s.player, m = s.map;
    s.tools = ['dagger', 'axe', 'pickaxe'];
    g.loop.sleep();
    let time = g.loop.time || 0;
    const step = () => { time += 50; s.sys.step(time, 50); };
    const tree = m.objects.filter((o) => o.node && o.node.group === 'tree')
      .sort((a, b) => Math.hypot(a.col - p.tile.col, a.row - p.tile.row) - Math.hypot(b.col - p.tile.col, b.row - p.tile.row))[0];
    s.pressNode(tree);
    let n = 0;
    while (tree.kind !== 'stump' && n < 2000) { step(); n++; }
    const stale = { kind: tree.kind, action: !!p.action, valid: p.action ? p.action.isValid() : null };
    s.pressNode(tree);                      // 그루터기가 된 바로 다음, 다음 프레임 전에 누른다
    const after = { action: !!p.action, valid: p.action ? p.action.isValid() : null, same: p.action ? p.action.target === tree : null, tool: p.action ? p.action.tool() : null };
    let k = 0;
    while (m.objects.includes(tree) && tree.kind === 'stump' && k < 2000) { step(); k++; }
    const dug = !m.objects.includes(tree) || tree.kind !== 'stump';
    g.loop.wake();
    return { tree: [tree.col, tree.row], framesToStump: n, stale, after, framesToDig: k, dug };
  });
  console.log(JSON.stringify(r));
  ok('tree became a stump', r.stale.kind === 'stump' && r.framesToStump < 2000);
  // Phase 10: 내려치기를 프레임 앞쪽에서 하므로, 그 프레임 안에 끝난 행동이 지워질 수도 있다(어느 쪽이든 새로 누른 것이 받아져야 한다)
  ok('right after: the old action is gone or no longer valid', !r.stale.action || r.stale.valid === false);
  ok('pressing the stump then starts digging with the pickaxe', r.after.action && r.after.valid && r.after.same && r.after.tool === 'pickaxe', JSON.stringify(r.after));
  ok('the stump is dug out', r.dug && r.framesToDig < 2000, 'frames ' + r.framesToDig);
  ok('no console errors', T.errors.length === 0, JSON.stringify(T.errors));
  await T.browser.close();
  console.log(fails ? `\n${fails} FAILED` : '\nALL PASS');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
