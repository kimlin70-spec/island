// Player sheet in the engine: frame cut rectangles, and crops of the player in each stage-1 frame (both facings) during real play.
const { setup, checker, J, UI } = require('./blib.js');
const { ok, done } = checker();
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  await T.sleep(); await T.run(2);
  const cuts = await G(() => { const t = window.__game.textures.get('char_player'); const out = [];
    for (let i = 0; i < t.frameTotal - 1; i++) { const f = t.get(i); out.push([f.cutX, f.cutY, f.cutWidth, f.cutHeight]); } return out; });
  ok('11 frames, each 114x99 cut at i*114', cuts.length === 11 && cuts.every((c, i) => c[0] === i * 114 && c[1] === 0 && c[2] === 114 && c[3] === 99), J(cuts));
  // real play: craft axe + pickaxe, chop the tree west of start and east of start, dig, to see both facings
  await T.testItemS(0);
  await T.uiS(...UI.craft); await T.uiS(...UI.card(0)); await T.uiS(...UI.card(1)); await T.uiS(...UI.craft);
  const shots = [];
  const grab = async (tag) => {
    const sp = await G(() => { const p = window.__game.scene.getScene('game').player.sprite; return { x: p.x, y: p.y, f: String(p.frame.name), flip: p.flipX }; });
    const g = await T.w2g(sp.x, sp.y);
    const file = __dirname + `/c_${tag}_f${sp.f}_${sp.flip ? 'L' : 'R'}.png`;
    await page.screenshot({ path: file, clip: { x: Math.round(g.x - 70), y: Math.round(g.y - 90), width: 140, height: 110 } });
    shots.push([tag, sp.f, sp.flip]);
  };
  // find trees near start: one with smaller x (left) and one with larger x (right)
  const trees = await G(() => { const s = window.__game.scene.getScene('game'), p = s.player;
    return s.map.objects.filter((o) => o.node && o.node.group === 'tree' && Math.hypot(o.col - p.col, o.row - p.row) < 6).map((o) => ({ c: o.col, r: o.row, x: o.sprite.x - p.sprite.x })); });
  const left = trees.filter((t) => t.x < -20).sort((a, b) => Math.abs(a.x) - Math.abs(b.x))[0];
  const right = trees.filter((t) => t.x > 20).sort((a, b) => Math.abs(a.x) - Math.abs(b.x))[0];
  for (const [tag, t] of [['left', left], ['right', right]]) {
    if (!t) continue;
    const pt = await T.objPoint(t.c, t.r, 0.35);
    await T.tapWorld(pt.wx, pt.wy); await T.run(1);
    await T.until('return s.player.swing && !s.player.swing.struck;', 900);
    await grab(tag + '_axe1');
    await T.until('return s.player.swing && s.player.swing.struck;', 60);
    await grab(tag + '_axe2');
    await T.until('return !s.player.action;', 600);
    await T.run(5);
    await grab(tag + '_idle');
    // dig the stump
    const sp = await G(([c, r]) => { const o = window.__game.scene.getScene('game').map.objectAt(c, r); return o ? { wx: o.sprite.x, wy: o.sprite.y - o.sprite.displayHeight * o.sprite.originY * 0.5 } : null; }, [t.c, t.r]);
    if (sp) {
      await T.tapWorld(sp.wx, sp.wy); await T.run(1);
      await T.until('return s.player.swing && !s.player.swing.struck;', 600);
      await grab(tag + '_pick1');
      await T.until('return s.player.swing && s.player.swing.struck;', 60);
      await grab(tag + '_pick2');
      await T.until('return !s.player.action;', 600);
    }
  }
  // walk frames
  await T.tapTileW(40, 36); await T.run(8); await grab('walk_a'); await T.run(6); await grab('walk_b');
  await T.until('return !s.player.moving;', 600);
  await T.tapTileW(36, 40); await T.run(8); await grab('walk_c'); await T.run(6); await grab('walk_d');
  console.log('INFO shots', J(shots));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
