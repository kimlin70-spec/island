// review6b/bundle helpers on top of p6/lib6.js (pirates ON)
const path = require('path');
const lib6 = require('../../p6/lib6.js');
exports.J = JSON.stringify;
exports.checker = lib6.checker;
exports.UI = lib6.UI;
exports.setup = async (opts = {}) => {
  const T = await lib6.setup(opts);
  const { page, G } = T;
  T.shotB = async (name) => { const p = path.join(__dirname, name + '.png'); await page.screenshot({ path: p }); return p; };
  // record every player frame that was on screen (after update), and flips
  await G(() => {
    const s = window.__game.scene.getScene('game');
    window.__frames = {}; window.__flips = {};
    s.events.on('postupdate', () => {
      const sp = s.player.sprite; if (!sp.visible) return;
      const f = String(sp.frame.name); window.__frames[f] = (window.__frames[f] || 0) + 1;
      window.__flips[sp.flipX ? 'L' : 'R'] = (window.__flips[sp.flipX ? 'L' : 'R'] || 0) + 1;
    });
  });
  T.frames = () => G(() => ({ frames: window.__frames, flips: window.__flips }));
  // a point (world) on an object sprite with opaque pixels around it, which pickObject returns for that object
  T.objPoint = (col, row, fracY = 0.45) => G(([col, row, fracY]) => {
    const s = window.__game.scene.getScene('game'), m = s.map, o = m.objectAt(col, row);
    if (!o) return null;
    const sp = o.sprite, key = sp.texture.key, W = sp.width, H = sp.height;
    const left = sp.x - sp.displayWidth * sp.originX, top = sp.y - sp.displayHeight * sp.originY;
    const A = (x, y) => s.textures.getPixelAlpha(x, y, key, sp.frame.name) || 0;
    let best = null;
    const cy0 = Math.round(H * fracY);
    for (let d = 0; d < H && !best; d++) for (const ly of [cy0 - d, cy0 + d]) {
      if (ly < 4 || ly >= H - 4) continue;
      for (let lx = 4; lx < W - 4; lx++) {
        let okk = true;
        for (let a = -4; a <= 4 && okk; a++) for (let b = -4; b <= 4; b++) if (A(lx + a, ly + b) < 200) { okk = false; break; }
        if (!okk) continue;
        const wx = left + lx + 0.5, wy = top + ly + 0.5;
        if (m.pickObject(wx, wy) === o) { best = { wx, wy, lx, ly }; break; }
      }
      if (best) break;
    }
    return best;
  }, [col, row, fracY]);
  T.pstate = () => G(() => {
    const s = window.__game.scene.getScene('game'), p = s.player;
    return { at: [+p.col.toFixed(3), +p.row.toFixed(3)], tile: [p.tile.col, p.tile.row], path: p.path.map((t) => [t.col, t.row]),
      action: p.action ? (p.action.target.kind || p.action.target.type || 'enemy') : null, swing: !!p.swing,
      cursor: s.cursor.visible, frame: String(p.sprite.frame.name), flip: p.sprite.flipX, depth: +p.sprite.depth.toFixed(2),
      terrain: s.mapData.terrain[p.tile.row][p.tile.col], marks: s.build.marks.filter((k) => k.visible).length, mode: s.build.mode };
  });
  return T;
};
