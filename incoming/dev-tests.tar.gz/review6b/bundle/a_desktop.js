// Desktop 1920x1200, real mouse clicks. Iron field walk, ore taps, animations, building on iron soil, night, zombies, pirates.
const { setup, checker, J, UI } = require('./blib.js');
const { ok, done } = checker();
const ORES = [[43, 31], [44, 32], [46, 33], [47, 28], [47, 34], [49, 31], [49, 33], [45, 30], [47, 32], [48, 29]];
(async () => {
  const T = await setup({ w: 1920, h: 1200 });
  const { page, G } = T;
  const log = (...a) => console.log('INFO', ...a);
  await page.waitForTimeout(3000);
  await T.shotB('a00_start');
  await T.sleep(); await T.run(2);
  let st = await T.pstate();
  ok('start: player idle at (37,39), frame idle(0)', J(st.tile) === '[37,39]' && st.frame === '0', J(st));

  // 1. walk into the iron field by clicking ground
  const walkTo = async (c, r, max = 60 * 20) => {
    await T.tapTileW(c, r); await T.run(1);
    const res = await T.until('return !s.player.moving;', max);
    const s2 = await T.pstate();
    return { ok: res.ok && J(s2.tile) === J([c, r]), st: s2 };
  };
  let w = await walkTo(43, 32);
  ok('click iron soil (43,32): walks there, terrain 5', w.ok && w.st.terrain === 5, J(w.st));
  await T.shotB('a01_field_edge');
  for (const [c, r] of [[46, 29], [48, 31], [45, 33], [48, 34], [44, 30], [47, 29], [43, 33], [49, 32], [46, 31]]) {
    w = await walkTo(c, r);
    ok(`walk on iron soil to (${c},${r})`, w.ok && w.st.terrain === 5, J(w.st));
  }
  ok('no body on a blocked tile so far', (await T.bad()).length === 0, J(await T.bad()));
  await T.shotB('a02_field_mid');

  // 2. tap each ore (real click on an opaque part): exactly "아직 캘 수 없습니다", nothing else
  const notesSince = async (n0) => (await T.notices()).slice(n0).map((n) => n[2]);
  for (const [c, r] of ORES) {
    const pt = await T.objPoint(c, r);
    if (!pt) { ok(`ore (${c},${r}) has a pick point`, false); continue; }
    const before = await T.pstate();
    const n0 = (await T.notices()).length;
    await T.tapWorld(pt.wx, pt.wy); await T.run(3);
    const after = await T.pstate();
    const ns = await notesSince(n0);
    ok(`tap ore (${c},${r}): only the notice, no walk/action/cursor`, J(ns) === J(['아직 캘 수 없습니다']) && J(after.tile) === J(before.tile)
      && after.path.length === 0 && !after.action && !after.cursor, J({ ns, before: before.tile, after }));
  }
  // walking, then tap an ore: keeps walking to the same tile
  await T.tapTileW(43, 33); await T.run(4);
  const mid = await T.pstate();
  const pt44 = await T.objPoint(44, 32);
  let n0 = (await T.notices()).length;
  await T.tapWorld(pt44.wx, pt44.wy); await T.run(1);
  const mid2 = await T.pstate();
  ok('tap ore while walking: the walk goes on unchanged', J(mid2.path) === J(mid.path.slice(-mid2.path.length)) && mid2.path.length > 0 && J(mid2.path[mid2.path.length - 1]) === '[43,33]', J({ mid, mid2 }));
  await T.until('return !s.player.moving;', 600);
  st = await T.pstate();
  ok('...and arrives at (43,33); notice once', J(st.tile) === '[43,33]' && J(await notesSince(n0)) === J(['아직 캘 수 없습니다']), J({ st, ns: await notesSince(n0) }));

  // 3. depth / see-through: behind the tree (47,30) and the pine (48,32) on iron soil; behind and in front of ores
  w = await walkTo(46, 29); await T.run(30);
  let occ = await G(() => { const m = window.__game.scene.getScene('game').map; return [m.objectAt(47, 30).sprite.alpha, m.objectAt(48, 32).sprite.alpha, m.objectAt(45, 30).sprite.alpha]; });
  ok('behind the tree (47,30) on iron soil: tree see-through 0.5', w.ok && occ[0] === 0.5, J({ w: w.st.tile, occ }));
  await T.shotB('a03_behind_tree');
  w = await walkTo(47, 31); await T.run(30);
  occ = await G(() => { const m = window.__game.scene.getScene('game').map, p = window.__game.scene.getScene('game').player;
    const o = (c, r) => m.objectAt(c, r).sprite; return { tree: o(47, 30).alpha, pine: o(48, 32).alpha, oreFront: [o(47, 32).depth, p.sprite.depth], oreBack: [o(47, 28).depth] }; });
  ok('in front of the tree: opaque; behind the pine (48,32): see-through', w.ok && occ.tree === 1 && occ.pine === 0.5, J(occ));
  ok('ore (47,32) south of the player is drawn in front of the player (depth)', occ.oreFront[0] > occ.oreFront[1], J(occ));
  await T.shotB('a04_behind_pine_ore');
  w = await walkTo(46, 32); await T.run(30);   // west of ore (47,32)? (46,32) is free; ore (46,33) is south-east-ish
  await T.shotB('a05_near_ores');

  // 4. animations with the 114 px sheet: dagger on the tree, then axe, pickaxe on stump/rock
  // tap the tree (47,30) leaves
  const tp = await T.objPoint(47, 30, 0.3);
  await T.tapWorld(tp.wx, tp.wy); await T.run(1);
  let r1 = await T.until('return s.player.swing;', 600);
  await T.run(20);
  st = await T.pstate();
  ok('dagger swing on the tree (frames dagger1/dagger2 = 3/4 seen)', r1.ok, J({ st, f: await T.frames() }));
  // give materials and craft the axe while chopping (real clicks on UI)
  await T.testItemS(0);
  await T.uiS(...UI.craft);
  await T.uiS(...UI.card(0));
  await T.uiS(...UI.card(1));
  await T.uiS(...UI.craft);
  r1 = await T.until('return s.map.objectAt(47,30).kind === "stump";', 60 * 15);
  let fr = await T.frames();
  ok('tree cut to a stump with the axe; axe frames seen', r1.ok && fr.frames['5'] > 0 && fr.frames['6'] > 0 && fr.frames['3'] > 0 && fr.frames['4'] > 0, J({ r1, fr }));
  // ore tap with the pickaxe: still only the notice
  await T.until('return !s.player.moving && !s.player.swing && !s.player.action;', 120);
  const pt45 = await T.objPoint(45, 30);
  n0 = (await T.notices()).length;
  const b4 = await T.pstate();
  await T.tapWorld(pt45.wx, pt45.wy); await T.run(30);
  const af = await T.pstate();
  ok('with a pickaxe, tapping an ore still only says "아직 캘 수 없습니다"', J(await notesSince(n0)) === J(['아직 캘 수 없습니다']) && J(af.tile) === J(b4.tile) && !af.action && af.path.length === 0, J({ b4, af, ns: await notesSince(n0) }));
  // dig the stump with the pickaxe
  const sp = await G(() => { const sp = window.__game.scene.getScene('game').map.objectAt(47, 30).sprite; return { wx: sp.x, wy: sp.y - sp.displayHeight * sp.originY * 0.5 }; });
  await T.tapWorld(sp.wx, sp.wy); await T.run(1);
  r1 = await T.until('return !s.map.objectAt(47,30);', 60 * 10);
  fr = await T.frames();
  ok('stump dug with the pickaxe; pick frames 7/8 seen', r1.ok && fr.frames['7'] > 0 && fr.frames['8'] > 0, J({ r1, fr }));
  await T.until('return !s.player.moving && !s.player.swing && !s.player.action;', 120);

  // 5. building on iron soil (fence x3, campfire); marks on ore tile are red
  await T.uiS(...UI.craft);
  await T.uiS(...UI.card(2));
  const marksAt = async (c, r) => { const w2 = T.tileW(c, r); const p = await T.w2p(w2.wx, w2.wy); await page.mouse.move(p.x, p.y); await T.run(2);
    return G(() => { const b = window.__game.scene.getScene('game').build; return b.marks.filter((k) => k.visible).map((k) => [k.texture.key, Math.round(k.x), Math.round(k.y)]); }); };
  let mk = await marksAt(45, 31);
  ok('fence mode: hover free iron soil (45,31) -> overlay_ok', mk.length === 1 && mk[0][0] === 'overlay_ok', J(mk));
  mk = await marksAt(45, 30);
  ok('fence mode: hover ore tile (45,30) -> overlay_no', mk.length === 1 && mk[0][0] === 'overlay_no', J(mk));
  const built = [];
  for (const [c, r] of [[45, 31], [44, 31], [44, 30]]) {
    const w2 = T.tileW(c, r); await T.tapWorld(w2.wx, w2.wy); await T.run(2);
    built.push(await G(([c, r]) => { const s2 = window.__game.scene.getScene('game').map.structureAt(c, r); return s2 ? s2.type + ':' + s2.sprite.texture.key : null; }, [c, r]));
  }
  ok('three fences built on iron soil, joined', built.every((b) => b && b.startsWith('fence')), J(built));
  // click on the ore tile itself (its own tile centre) in fence mode -> no build
  const w45 = T.tileW(45, 30); await T.tapWorld(w45.wx, w45.wy); await T.run(2);
  ok('fence mode: clicking the ore tile does not build', !(await G(() => window.__game.scene.getScene('game').map.structureAt(45, 30))));
  await T.uiS(...UI.card(3));
  const cf = await G(() => { const s2 = window.__game.scene.getScene('game'); for (const [c, r] of [[46, 30], [47, 29], [48, 30], [46, 28], [47, 31]]) if (s2.build.canBuildAt(c, r)) return [c, r]; return null; });
  const w46 = T.tileW(cf[0], cf[1]); await T.tapWorld(w46.wx, w46.wy); await T.run(2);
  ok('campfire built on iron soil ' + J(cf), (await G((cf) => { const s2 = window.__game.scene.getScene('game').map.structureAt(cf[0], cf[1]); return s2 && s2.type + ':' + s2.cfg.name + ':' + window.__game.scene.getScene('game').mapData.terrain[cf[1]][cf[0]]; }, cf)) === 'campfire:모닥불:5');
  await T.shotB('a06_built_on_iron');
  await T.uiS(...UI.craft);
  st = await T.pstate();
  ok('build mode closed', st.mode === null, J(st));

  // 6. night near the iron field, zombies and pirates
  await T.testItemS(1);
  await T.run(60 * 2);
  await T.shotB('a07_night_field');
  for (let i = 0; i < 2; i++) await T.testItemS(3);
  const rz = await T.until('return s.enemies.list.some((e) => Math.max(Math.abs(e.tile.col - s.player.tile.col), Math.abs(e.tile.row - s.player.tile.row)) <= 1);', 60 * 60);
  log('zombie near', J(rz));
  await T.shotB('a08_zombie_near');
  // fight: click the nearest enemy repeatedly until gone
  for (let k = 0; k < 40; k++) {
    const n = await G(() => window.__game.scene.getScene('game').enemies.list.length);
    if (!n) break;
    const ep = await T.enemyPoint(0);
    try { await T.tapWorld(ep.wx, ep.wy); } catch (e) { await T.run(30); continue; }
    await T.run(45);
  }
  const zl = await G(() => window.__game.scene.getScene('game').enemies.list.length);
  log('enemies left after fight', zl, J(await T.snap()));
  ok('no body on a blocked tile (player, zombies)', (await T.bad()).length === 0, J(await T.bad()));
  // pirates (heal first so the fight does not end in "쓰러졌습니다")
  await G(() => window.__game.scene.getScene('game').hearts.heal(5));
  const rp = await T.until('return s.enemies.list.some((e) => e.kind.startsWith("pirate"));', 60 * 150);
  ok('pirates land', rp.ok, J(rp));
  const rpn = await T.until('return s.enemies.list.some((e) => e.kind.startsWith("pirate") && Math.max(Math.abs(e.tile.col - s.player.tile.col), Math.abs(e.tile.row - s.player.tile.row)) <= 2);', 60 * 60);
  log('pirate near', J(rpn), J(await T.pir()));
  await T.shotB('a09_pirate_near');
  for (let k = 0; k < 60; k++) {
    const n = await G(() => window.__game.scene.getScene('game').enemies.list.length);
    if (!n) break;
    const ep = await T.enemyPoint(0);
    try { await T.tapWorld(ep.wx, ep.wy); } catch (e) { await T.run(30); continue; }
    await T.run(40);
    if (await G(() => !window.__game.scene.getScene('game').scene.isActive())) break;
  }
  log('after pirates', J(await T.snap()));
  ok('no body on a blocked tile (pirates)', (await T.bad()).length === 0, J(await T.bad()));
  fr = await T.frames();
  ok('gun frames (9, 10) never shown; both flips used', !fr.frames['9'] && !fr.frames['10'] && fr.flips.L > 0 && fr.flips.R > 0, J(fr));
  log('frames', J(fr));
  log('notices', J((await T.notices()).map((n) => n[2])));
  ok('no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
