// Tablet 1024x768, real touch taps: start screen, walk into the iron field, tap ores, build on iron soil, night, zombie and pirate fight.
const { setup, checker, J, UI } = require('./blib.js');
const { ok, done } = checker();
const ORES = [[43, 31], [44, 32], [46, 33], [47, 28], [47, 34], [49, 31], [49, 33], [45, 30], [47, 32], [48, 29]];
(async () => {
  const T = await setup({ w: 1024, h: 768, touch: true });
  const { page, G } = T;
  const log = (...a) => console.log('INFO', ...a);
  await page.waitForTimeout(2500);
  await T.shotB('b00_start');
  // tap an ore during the intro notices (real time, game loop running)
  const n00 = (await T.notices()).length;
  const ptA = await T.objPoint(43, 31);
  const onScreen = await T.w2p(ptA.wx, ptA.wy);
  log('ore (43,31) on screen at start', J(onScreen));
  if (onScreen.on) {
    await T.tapWorld(ptA.wx, ptA.wy); await page.waitForTimeout(400);
    const s0 = await T.pstate();
    ok('tablet: tap ore (43,31) from the start tile: notice only', J((await T.notices()).slice(n00).map((n) => n[2])) === J(['아직 캘 수 없습니다']) && J(s0.tile) === '[37,39]' && s0.path.length === 0 && !s0.cursor, J(s0));
    await T.shotB('b01_ore_notice');
  }
  await T.sleep(); await T.run(2);
  const walkTo = async (c, r, max = 60 * 20) => {
    await T.tapTileW(c, r); await T.run(1);
    const res = await T.until('return !s.player.moving;', max);
    const s2 = await T.pstate();
    return { ok: res.ok && J(s2.tile) === J([c, r]), st: s2 };
  };
  for (const [c, r] of [[43, 32], [45, 31], [47, 33], [48, 30], [46, 31]]) {
    const w = await walkTo(c, r);
    ok(`tablet: walk on iron soil to (${c},${r})`, w.ok && w.st.terrain === 5, J(w.st));
  }
  await T.shotB('b02_field');
  for (const [c, r] of ORES) {
    const pt = await T.objPoint(c, r);
    const before = await T.pstate();
    const n0 = (await T.notices()).length;
    await T.tapWorld(pt.wx, pt.wy); await T.run(3);
    const after = await T.pstate();
    const ns = (await T.notices()).slice(n0).map((n) => n[2]);
    ok(`tablet: tap ore (${c},${r}): only the notice`, J(ns) === J(['아직 캘 수 없습니다']) && J(after.tile) === J(before.tile) && after.path.length === 0 && !after.action && !after.cursor, J({ ns, after }));
  }
  // build by touch on iron soil
  await T.testItemS(0);
  await T.uiS(...UI.craft);
  await T.uiS(...UI.card(2));
  const built = [];
  for (const [c, r] of [[45, 31], [44, 31], [44, 30], [45, 30]]) {
    const w2 = T.tileW(c, r); await T.tapWorld(w2.wx, w2.wy); await T.run(2);
    built.push(await G(([c, r]) => { const s2 = window.__game.scene.getScene('game').map.structureAt(c, r); return s2 ? s2.type : null; }, [c, r]));
  }
  ok('tablet: fences on free iron soil, none on the ore tile (45,30)', J(built) === J(['fence', 'fence', 'fence', null]), J(built));
  await T.uiS(...UI.craft);
  // night, zombies, fight by touch
  await T.testItemS(1);
  await T.testItemS(3);
  await T.run(60);
  await T.shotB('b03_night');
  const rz = await T.until('return s.enemies.list.some((e) => Math.max(Math.abs(e.tile.col - s.player.tile.col), Math.abs(e.tile.row - s.player.tile.row)) <= 3);', 60 * 60);
  log('zombie near', J(rz));
  for (let k = 0; k < 30; k++) {
    const n = await G(() => window.__game.scene.getScene('game').enemies.list.length);
    if (!n) break;
    const ep = await T.enemyPoint(0);
    try { await T.tapWorld(ep.wx, ep.wy); } catch (e) { await T.run(30); continue; }
    await T.run(45);
  }
  const snap = await T.snap();
  log('after zombie fight', J(snap));
  ok('tablet: zombie defeated by touch', snap.defeated >= 1, J(snap));
  await G(() => window.__game.scene.getScene('game').hearts.heal(5));
  const rp = await T.until('return s.enemies.list.some((e) => e.kind.startsWith("pirate") && Math.max(Math.abs(e.tile.col - s.player.tile.col), Math.abs(e.tile.row - s.player.tile.row)) <= 3);', 60 * 160);
  log('pirate near', J(rp));
  await T.shotB('b04_pirates');
  const fr = await T.frames();
  ok('tablet: no gun frames', !fr.frames['9'] && !fr.frames['10'], J(fr));
  ok('tablet: no body on blocked tiles', (await T.bad()).length === 0, J(await T.bad()));
  ok('tablet: no console errors', T.errors.length === 0, J(T.errors));
  await T.browser.close();
  process.exit(done() ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
