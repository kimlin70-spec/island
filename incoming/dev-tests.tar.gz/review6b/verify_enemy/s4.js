// enemy-1 in real-play conditions: the player stands in the camp gate and auto-fights (as the game does when standing still)
// stackedNow(): number of enemies standing at a tile centre shared with another enemy, next to the player
const run = (o, enemies, secs) => { const V = window.__V; V.reset(Object.assign({ player: { col: 34, row: 39 } }, o));
  const s = window.__game.scene.getScene('game'), E = s.enemies;
  V.ring([34, 39]);
  for (const [k, c, r] of enemies) V.add(k, c, r);
  const timeline = []; let stackedFrames = 0, maxStacked = 0, firstStackF = null, lastStackF = null; let f = 0;
  for (; f < 60 * secs; f++) {
    V.step(1);
    const cnt = new Map();
    for (const e of E.list) if (e.col === e.tile.col && e.row === e.tile.row) { const k = e.tile.col + ',' + e.tile.row; cnt.set(k, (cnt.get(k) || 0) + 1); }
    let st = 0; for (const v of cnt.values()) if (v > 1) st += v;
    if (st) { stackedFrames++; if (firstStackF === null) firstStackF = V.frame; lastStackF = V.frame; }
    maxStacked = Math.max(maxStacked, st);
    if (V.frame % 60 === 0) timeline.push(`${V.frame / 60}s alive=${E.list.length} stackedEnemies=${st} hearts=${s.hearts.value}`);
    if (s.hearts.value <= 0) break;
  }
  return { sm: V.summary(), defeated: E.defeated, hearts: s.hearts.value, stackedSeconds: +(stackedFrames / 60).toFixed(1), maxStacked,
    stackWindow: firstStackF === null ? null : `${(firstStackF / 60).toFixed(1)}s..${(lastStackF / 60).toFixed(1)}s`, endedAt: +(V.frame / 60).toFixed(1),
    timeline: timeline.filter((x, i) => i % 2 === 0).join(' | ') };
};
const SIX = [['zombie', 27, 39], ['zombie', 27, 37], ['zombie', 27, 41], ['zombie', 26, 38], ['zombie', 26, 40], ['pirate_1', 25, 39]];
const FOUR = [['zombie', 27, 39], ['zombie', 27, 37], ['pirate_1', 26, 41], ['pirate_2', 25, 39]];
exports.gateFight6 = new Function('return (' + run.toString() + ')({ fight: true, damage: false }, ' + JSON.stringify(SIX) + ', 30)');
exports.gateFight6Damage = new Function('return (' + run.toString() + ')({ fight: true, damage: true }, ' + JSON.stringify(SIX) + ', 30)');
exports.gateFight4 = new Function('return (' + run.toString() + ')({ fight: true, damage: false }, ' + JSON.stringify(FOUR) + ', 30)');
exports.gateFight4Damage = new Function('return (' + run.toString() + ')({ fight: true, damage: true }, ' + JSON.stringify(FOUR) + ', 30)');
