// node vrun.js <scenario-file> <names|all> <modes: new,old> [cpuThrottle]
// Every request to the game server is answered from a snapshot of commit cd6db05 (immune to concurrent edits of the
// working tree). Mode 'old' swaps only src/systems/Enemy.js for the be6fcd0 version. The repo is never touched.
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const DIR = __dirname;
const SNAP = DIR + '/snap';
const HSRC = fs.readFileSync(DIR + '/vh_page.js', 'utf8');
const OLD = fs.readFileSync(DIR + '/Enemy_old.js', 'utf8');
const file = process.argv[2];
const names = process.argv[3] && process.argv[3] !== 'all' ? process.argv[3].split(',') : null;
const modes = (process.argv[4] || 'new,old').split(',');
const throttle = +(process.argv[5] || 1);
const SC = require(DIR + '/' + file);
const MIME = { '.js': 'application/javascript', '.json': 'application/json', '.png': 'image/png', '.html': 'text/html', '.css': 'text/css',
  '.webp': 'image/webp', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.txt': 'text/plain', '.md': 'text/plain', '.woff2': 'font/woff2', '.ttf': 'font/ttf' };

async function openPage(browser, mode) {
  const ctx = await browser.newContext({ viewport: { width: 960, height: 600 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  const served = { snap: 0, miss: [] };
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  await page.route('http://127.0.0.1:8000/**', (route) => {
    let u = new URL(route.request().url()).pathname;
    if (u.endsWith('/')) u += 'index.html';
    const rel = decodeURIComponent(u).replace(/^\/+/, '');
    if (mode === 'old' && rel === 'src/systems/Enemy.js') return route.fulfill({ status: 200, contentType: MIME['.js'], body: OLD });
    const f = path.join(SNAP, rel);
    if (!f.startsWith(SNAP) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { served.miss.push(rel); return route.fulfill({ status: 404, body: 'not in snapshot' }); }
    served.snap++;
    return route.fulfill({ status: 200, contentType: MIME[path.extname(f)] || 'application/octet-stream', body: fs.readFileSync(f) });
  });
  await page.goto('http://127.0.0.1:8000/');
  await page.waitForFunction(() => window.__game && window.__game.scene.isActive('game') && window.__game.scene.isActive('ui'), null, { timeout: 120000 });
  await page.waitForTimeout(300);
  await page.evaluate(async () => { const m = await import('/src/config.js'); m.CONFIG.pirate.enabled = true; });
  await page.addScriptTag({ content: HSRC });
  await page.evaluate(() => window.__V.ready);
  const v = await page.evaluate(() => window.__V.version);
  if (v !== mode) throw new Error('version mismatch: wanted ' + mode + ' got ' + v);
  const fp = await page.evaluate(async () => { const t = await (await fetch('/src/systems/Enemy.js')).text(); return { len: t.length, avoid: t.includes('this.avoid'), stepOk: t.includes('stepOk') }; });
  console.log(`[${mode}] served from snapshot: ${served.snap} files, missing: ${JSON.stringify(served.miss.slice(0, 5))}, Enemy.js ${JSON.stringify(fp)}`);
  if (throttle > 1) {
    const cdp = await ctx.newCDPSession(page);
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: throttle });
    console.log(`[${mode}] CPU throttling x${throttle}`);
  }
  return { ctx, page, errors };
}

(async () => {
  const browser = await chromium.launch();
  for (const mode of modes) {
    const T = await openPage(browser, mode);
    for (const [name, fn] of Object.entries(SC)) {
      if (names && !names.includes(name)) continue;
      const t0 = Date.now();
      let r;
      try { r = await T.page.evaluate(fn); } catch (e) { console.log(`=== ${name} [${mode}] ERROR ${e.message}`); continue; }
      console.log(`=== ${name} [${mode}] (${((Date.now() - t0) / 1000).toFixed(1)}s wall)`);
      const { sm, ...rest } = r || {};
      if (sm) {
        console.log(`  version=${sm.version} frame=${sm.frame} player=${sm.player} hearts=${sm.hearts} fences=${sm.fences} damaged=[${sm.damaged}]`);
        console.log(`  routeSearch ${JSON.stringify(sm.fr)}`);
        for (const e of sm.enemies) console.log('  ' + e);
      }
      for (const [k, v] of Object.entries(rest)) console.log(`  ${k}: ${typeof v === 'string' ? v : JSON.stringify(v)}`);
    }
    console.log(`page errors [${mode}]:`, JSON.stringify(T.errors.slice(0, 5)));
    await T.ctx.close();
  }
  await browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
