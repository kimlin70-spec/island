// Independent in-page harness for verifying the enemy findings. window.__V.
// Game loop is put to sleep; frames are stepped by hand with headlessStep (same update code as the game).
(() => {
  const g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player, b = s.build, E = s.enemies, P = s.pirates;
  const K = (t) => t.col + ',' + t.row;
  const V = { t: performance.now(), D: 1000 / 60, frame: 0, nextId: 0 };
  window.__V = V;
  if (!g.loop.sleeping) g.loop.sleep();
  const origPress = s.pressEnemy.bind(s);
  const origHitPlayer = E.hitPlayer.bind(E);
  const origHitStructure = E.hitStructure.bind(E);

  V.ready = (async () => {
    const EM = await import('/src/systems/Enemy.js');
    const WM = await import('/src/systems/Walker.js');
    V.version = EM.Enemy.prototype.onTarget ? 'new' : 'old';
    const EP = EM.Enemy.prototype, WP = WM.Walker.prototype;
    const oRepath = EP.repath;
    EP.repath = function (target, key) {
      const before = this.path.map(K).join(' ');
      const r = oRepath.call(this, target, key);
      const after = this.path.map(K).join(' ');
      const st = V.st(this); st.repaths++; if (before !== after) st.changed++;
      V.ev.push({ f: V.frame, k: 'repath', id: this.__id, at: K(this.tile), mid: this.col !== this.tile.col || this.row !== this.tile.row, before, after });
      return r;
    };
    const oFR = WP.findRoute;
    WP.findRoute = function (goals, from) {
      const t0 = performance.now();
      const r = oFR.call(this, goals, from);
      const dt = performance.now() - t0;
      if (this !== p) {
        V.fr.n++; V.fr.ms += dt; V.fr.frameMs += dt; V.fr.max = Math.max(V.fr.max, dt);
        if (!r) { V.fr.fail++; V.fr.failMs += dt; }
      }
      return r;
    };
  })();

  V.st = (e) => {
    if (e.__id === undefined) e.__id = ++V.nextId;
    if (!V.stats[e.__id]) V.stats[e.__id] = { id: e.__id, kind: e.kind, repaths: 0, changed: 0, hits: 0, smashes: 0, firstHitF: null,
      stacked: 0, stackedAdj: 0, stackedAdjHeldMax: 0, stackedAdjHeldCur: 0, tiles: [] };
    return V.stats[e.__id];
  };

  V.reset = (o = {}) => {
    g.scene.processQueue();
    if (s.sys.settings.status !== 5) { s.scene.resume(); g.scene.processQueue(); }
    if (s.rest.resting) s.rest.exit();
    for (const e of [...E.list]) E.remove(e);
    for (const x of [...m.structures]) b.destroy(x);
    E.schedule = [];
    s.clock.isNight = false; s.clock.t = 10; s.clock.day = 1;
    P.shipDue = false; P.landDue = false;
    if (s.debugSpeed !== 1) s.debugToggleSpeed();
    p.stopAction(); p.path = []; p.cooldown = 0; p.chaseLeft = 0;
    const st = o.player;
    p.col = st.col; p.row = st.row; p.tile = { col: st.col, row: st.row }; p.syncSprite();
    s.hearts.value = s.hearts.max;
    V.damage = !!o.damage;
    s.pressEnemy = o.fight ? origPress : () => {};
    E.hitPlayer = (e) => { const st = V.st(e); st.hits++; if (st.firstHitF === null) st.firstHitF = V.frame; V.ev.push({ f: V.frame, k: 'hit', id: e.__id, at: K(e.tile) }); if (V.damage) origHitPlayer(e); };
    E.hitStructure = (e, x) => { V.st(e).smashes++; V.ev.push({ f: V.frame, k: 'smash', id: e.__id, at: K(e.tile), x: K(x), hp: x.hp - e.cfg.structureDamage }); origHitStructure(e, x); };
    V.stats = {}; V.ev = []; V.frame = 0;
    V.fr = { n: 0, ms: 0, fail: 0, failMs: 0, max: 0, frameMs: 0, maxFrameMs: 0, framesOver4: 0 };
    V.snap = [];
    return true;
  };
  V.ring = (gap) => {
    for (let r = 36; r <= 42; r++) for (let c = 34; c <= 40; c++)
      if ((r === 36 || r === 42 || c === 34 || c === 40) && !(c === gap[0] && r === gap[1])) V.fence(c, r);
  };
  V.smashLog = () => V.ev.filter((x) => x.k === 'smash').map((x) => `${x.f}#${x.id}@${x.at}->${x.x}:${x.hp}`).join(' ');
  V.plans = (ids, n = 6) => V.ev.filter((x) => x.k === 'repath' && (!ids || ids.includes(x.id))).slice(-n).map((x) => `${x.f}#${x.id}@${x.at}${x.mid ? '~' : ''}[${x.after}]`).join(' ');
  V.fence = (c, r) => b.place('fence', [{ col: c, row: r }]);
  V.add = (kind, c, r) => { const e = E.add(kind, { col: c, row: r }); V.st(e); return e.__id; };
  V.byId = (id) => E.list.find((e) => e.__id === id);
  V.tent = (c, r) => b.place('tent', [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }]);

  // step n frames; per frame: stacked detection (two enemies at the centre of the same tile)
  V.step = (n, D = V.D) => {
    for (let i = 0; i < n; i++) {
      V.fr.frameMs = 0;
      const ft0 = performance.now();
      V.t += D; g.headlessStep(V.t, D); V.frame++;
      const ft = performance.now() - ft0;
      V.fr.stepMax = Math.max(V.fr.stepMax || 0, ft);
      V.fr.stepOver16 = (V.fr.stepOver16 || 0) + (ft > 16.7 ? 1 : 0);
      V.fr.stepOver8 = (V.fr.stepOver8 || 0) + (ft > 8 ? 1 : 0);
      V.fr.stepSum = (V.fr.stepSum || 0) + ft;
      if (V.fr.frameMs > 0) V.fr.searchFrames = (V.fr.searchFrames || 0) + 1;
      V.fr.maxFrameMs = Math.max(V.fr.maxFrameMs, V.fr.frameMs);
      if (V.fr.frameMs > 4) V.fr.framesOver4++;
      const dt = D / 1000;
      const tgt = E.target();
      const cnt = new Map();
      for (const e of E.list) if (e.col === e.tile.col && e.row === e.tile.row) cnt.set(K(e.tile), (cnt.get(K(e.tile)) || 0) + 1);
      for (const e of E.list) {
        const st = V.st(e);
        const atC = e.col === e.tile.col && e.row === e.tile.row;
        const stacked = atC && cnt.get(K(e.tile)) > 1;
        if (stacked) st.stacked += dt;
        const adj = e.nextTo(tgt) && !tgt.tiles.some((t) => t.col === e.tile.col && t.row === e.tile.row);
        const nx = e.path[0];
        const held = atC && nx && (nx.col !== e.tile.col || nx.row !== e.tile.row) && !!m.structureAt(nx.col, nx.row);
        if (stacked && adj) st.stackedAdj += dt;
        if (stacked && adj && held) { st.stackedAdjHeldCur += dt; st.stackedAdjHeldMax = Math.max(st.stackedAdjHeldMax, st.stackedAdjHeldCur); } else st.stackedAdjHeldCur = 0;
        const last = st.tiles[st.tiles.length - 1];
        if (atC && (!last || last[1] !== K(e.tile))) st.tiles.push([V.frame, K(e.tile)]);
      }
    }
    return V.frame;
  };

  V.summary = () => {
    const tgt = E.target();
    return {
      version: V.version, frame: V.frame, player: K(p.here()), hearts: s.hearts.value,
      fences: m.structures.filter((x) => x.type === 'fence').length,
      damaged: m.structures.filter((x) => x.hp < x.maxHp || x.hp < 6).map((x) => x.type[0] + K(x) + ':' + x.hp).join(' '),
      fr: { n: V.fr.n, fail: V.fr.fail, ms: +V.fr.ms.toFixed(1), failMs: +V.fr.failMs.toFixed(1), max: +V.fr.max.toFixed(2), maxFrameMs: +V.fr.maxFrameMs.toFixed(2), framesOver4: V.fr.framesOver4,
        wholeStep: { max: +(V.fr.stepMax || 0).toFixed(2), avg: +((V.fr.stepSum || 0) / Math.max(1, V.frame)).toFixed(2), over8: V.fr.stepOver8 || 0, over16_7: V.fr.stepOver16 || 0 } },
      enemies: E.list.map((e) => { const st = V.st(e); return `#${e.__id} ${e.kind} @${K(e.tile)}${e.col === e.tile.col && e.row === e.tile.row ? '' : '~'} path[${e.path.map(K).join(' ')}] inPlace=${e.inPlace(tgt) ? 1 : 0} hits=${st.hits} smashes=${st.smashes} firstHitF=${st.firstHitF} stacked=${st.stacked.toFixed(1)}s stackedAdj=${st.stackedAdj.toFixed(1)}s stackedAdjHeldMax=${st.stackedAdjHeldMax.toFixed(1)}s repaths=${st.repaths}(${st.changed} changed) tiles=${st.tiles.slice(-4).map((x) => x[0] + ':' + x[1]).join(' ')}`; }),
    };
  };
})();
