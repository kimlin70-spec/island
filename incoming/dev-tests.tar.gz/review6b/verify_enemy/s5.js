// enemy-3 secondary claim: cost of one route search with the avoid Set (string key per neighbour check) vs without it
exports.bench = () => { const V = window.__V; V.reset({ player: { col: 33, row: 15 } });
  const id = V.add('zombie', 34, 15), e = V.byId(id);
  const batch = (fn, reps, rounds) => { const ts = []; for (let r = 0; r < rounds; r++) { const t0 = performance.now(); for (let i = 0; i < reps; i++) fn(); ts.push((performance.now() - t0) / reps); } ts.sort((a, b) => a - b); return +ts[rounds >> 1].toFixed(4); };
  const far = [{ col: 37, row: 45 }], pocket = [{ col: 33, row: 14 }];
  for (let i = 0; i < 200; i++) e.findRoute(far);                      // warm-up
  const out = {};
  e.avoid = new Set(['33,15']);
  out.farWithAvoidMs = batch(() => e.findRoute(far), 30, 21);
  out.pocketFloodWithAvoidMs = batch(() => { if (e.findRoute(pocket)) throw new Error('pocket reachable?'); }, 10, 21);
  e.avoid = null;
  out.farWithoutAvoidMs = batch(() => e.findRoute(far), 30, 21);
  out.pocketWithoutAvoid = (e.findRoute(pocket) || []).map((t) => t.col + ',' + t.row).join(' ');
  return out; };
