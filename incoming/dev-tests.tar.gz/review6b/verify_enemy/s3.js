// enemy-3: how common are pocket spots, and frame cost under CPU throttling
// pocketCount: for every open tile P, is there an open neighbour N that the enemy rules can reach only through P?
// (BFS from a far reference tile with P impassable; diagonal steps need both side tiles walkable, as Enemy.sideOk)
exports.pocketCount = () => {
  const s = window.__game.scene.getScene('game'), m = s.map, V = window.__V;
  V.reset({ player: s.mapData.playerStart });
  const C = m.cols, R = m.rows;
  const open = (c, r) => c >= 0 && r >= 0 && c < C && r < R && m.isOpen(c, r);
  const walk = (c, r) => c >= 0 && r >= 0 && c < C && r < R && m.isWalkable(c, r);
  const ref = s.mapData.zombieSpawns[0];
  const bfs = (bc, br) => {
    const seen = new Uint8Array(C * R), q = [ref.row * C + ref.col];
    seen[q[0]] = 1;
    while (q.length) {
      const i = q.pop(), c = i % C, r = (i - c) / C;
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        if (!dc && !dr) continue;
        const nc = c + dc, nr = r + dr;
        if (!open(nc, nr) || (nc === bc && nr === br)) continue;
        if (dc && dr && (!walk(c + dc, r) || !walk(c, r + dr))) continue;
        const ni = nr * C + nc;
        if (!seen[ni]) { seen[ni] = 1; q.push(ni); }
      }
    }
    return seen;
  };
  const base = bfs(-1, -1);
  let openTiles = 0, pocketSpots = 0; const examples = [];
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
    if (!open(c, r) || !base[r * C + c]) continue;
    openTiles++;
    const seen = bfs(c, r);
    let pocket = null;
    for (let dr = -1; dr <= 1 && !pocket; dr++) for (let dc = -1; dc <= 1 && !pocket; dc++) {
      if (!dc && !dr) continue;
      const nc = c + dc, nr = r + dr;
      if (open(nc, nr) && base[nr * C + nc] && !seen[nr * C + nc]) pocket = nc + ',' + nr;
    }
    if (pocket) { pocketSpots++; if (examples.length < 8) examples.push(c + ',' + r + '->' + pocket); }
  }
  return { cols: C, rows: R, openTilesReachable: openTiles, pocketSpots, pct: +(100 * pocketSpots / openTiles).toFixed(1), examples, playerStart: s.mapData.playerStart };
};

// realistic: 6 zombies at the pocket spot (33,15), the player fights back and takes damage
exports.deadEndReal = () => { const V = window.__V; V.reset({ player: { col: 33, row: 15 }, fight: true, damage: true });
  const s = window.__game.scene.getScene('game');
  for (const [c, r] of [[36, 17], [37, 18], [38, 17], [36, 19], [37, 20], [38, 19]]) V.add('zombie', c, r);
  V.step(60 * 30);
  const fails = V.ev.filter((x) => x.k === 'repath').length;
  return { sm: V.summary(), hearts: s.hearts.value, defeated: s.enemies.defeated, repaths: fails }; };

// crowd at the pocket spot, hearts frozen, the player does not fight (worst case)
exports.deadEndPerf = () => { const V = window.__V; V.reset({ player: { col: 33, row: 15 } });
  for (const [c, r] of [[36, 17], [37, 18], [38, 17], [36, 19], [37, 20], [38, 19], [35, 21], [39, 18], [40, 17], [39, 20]]) V.add('zombie', c, r);
  V.step(60 * 30);
  return { sm: V.summary() }; };

// same as deadEndReal, run after the others so the route code is warmed up
exports.deadEndRealWarm = exports.deadEndReal;
