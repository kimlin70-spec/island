// enemy-3 scenarios (route-search cost) + map dump around the pocket spots
exports.mapAround = () => {
  const s = window.__game.scene.getScene('game'), m = s.map;
  const dump = (c0, r0, c1, r1, mark) => {
    const L = [];
    for (let r = r0; r <= r1; r++) {
      let line = String(r).padStart(3) + ' ';
      for (let c = c0; c <= c1; c++) {
        const k = c + ',' + r;
        line += mark[k] || (!m.isOpen(c, r) ? '#' : '.');
      }
      L.push(line);
    }
    return '    ' + Array.from({ length: c1 - c0 + 1 }, (_, i) => String((c0 + i) % 10)).join('') + '\n' + L.join('\n');
  };
  return { a: '\n' + dump(26, 8, 44, 24, { '33,15': 'P', '33,14': 'o' }), b: '\n' + dump(18, 12, 34, 26, { '26,19': 'P', '27,19': 'o' }) };
};

exports.deadEndPerf = () => { const V = window.__V; V.reset({ player: { col: 33, row: 15 } });
  for (const [c, r] of [[36, 17], [37, 18], [38, 17], [36, 19], [37, 20], [38, 19], [35, 21], [39, 18], [40, 17], [39, 20]]) V.add('zombie', c, r);
  V.step(60 * 30);
  return { sm: V.summary() }; };

exports.forestGap6 = () => { const V = window.__V; V.reset({ player: { col: 26, row: 19 } });
  for (const [c, r] of [[30, 15], [31, 16], [32, 15], [33, 16], [30, 13], [34, 14]]) V.add('zombie', c, r);
  V.step(60 * 25);
  return { sm: V.summary() }; };

// realistic: same pocket spot, the player fights back (auto-fight) and loses hearts; stop at game over or 30 s
exports.deadEndReal = () => { const V = window.__V; V.reset({ player: { col: 33, row: 15 }, fight: true, damage: true });
  const s = window.__game.scene.getScene('game');
  for (const [c, r] of [[36, 17], [37, 18], [38, 17], [36, 19], [37, 20], [38, 19]]) V.add('zombie', c, r);
  let f = 0;
  for (; f < 60 * 30; f++) { V.step(1); if (s.hearts.value <= 0) break; }
  const sm = V.summary();
  return { sm, frames: f, hearts: s.hearts.value, defeated: s.enemies.defeated, paused: s.sys.settings.status }; };
