// enemy-1 / enemy-2 scenarios, reproduced independently (fixed 60 Hz, player does not fight, no heart loss)
exports.campGate = () => { const V = window.__V; V.reset({ player: { col: 34, row: 39 } });
  V.ring([34, 39]);
  for (const [c, r] of [[27, 39], [27, 37], [27, 41], [26, 38], [26, 40]]) V.add('zombie', c, r);
  V.add('pirate_1', 25, 39);
  V.step(60 * 30);
  return { sm: V.summary(), smashes: V.smashLog(), lastPlans: V.plans() }; };

exports.doorway = () => { const V = window.__V; V.reset({ player: { col: 39, row: 39 } });
  for (let r = 33; r <= 45; r++) if (r !== 39) V.fence(39, r);
  V.add('zombie', 33, 39); V.add('zombie', 33, 38); V.add('zombie', 33, 40); V.add('pirate_1', 32, 39); V.add('zombie', 32, 41);
  V.step(60 * 25);
  return { sm: V.summary(), smashes: V.smashLog(), lastPlans: V.plans() }; };

exports.repro = () => { const V = window.__V; V.reset({ player: { col: 37, row: 39 } });
  V.fence(38, 39);
  for (const [c, r] of [[36, 38], [37, 38], [38, 38], [36, 39], [36, 40], [37, 40], [38, 40]]) V.add('zombie', c, r);
  V.add('pirate_1', 33, 39);
  V.step(60 * 20);
  return { sm: V.summary(), smashes: V.smashLog(), lastPlans: V.plans() }; };

exports.campGateInside = () => { const V = window.__V; V.reset({ player: { col: 35, row: 39 } });
  V.ring([34, 39]);
  for (const [c, r] of [[27, 39], [27, 37], [27, 41], [26, 38], [26, 40]]) V.add('zombie', c, r);
  V.add('pirate_1', 25, 39);
  V.step(60 * 30);
  return { sm: V.summary(), smashes: V.smashLog() }; };
