// natural gap on the real map: player at (34,19) chopping trees; its north neighbour (34,18) is reachable only through
// the player's tile or by a ~38-tile walk round the forest. 6 zombies come from the south-east.
exports.naturalGap = () => { const H = window.__H; H.reset({ player: { col: 34, row: 19 }, traceRepath: true });
  for (const [c, r] of [[38, 24], [39, 25], [37, 26], [40, 23], [38, 27], [41, 25]]) H.add('zombie', c, r);
  H.step(60 * 40);
  const rp = H.events('repath').filter((x) => x.before !== x.after && x.after.split(' ').length > 8).map((x) => `${x.f} #${x.id} at ${x.at} -> ${x.after.split(' ').length} tiles to ${x.after.split(' ').pop()}`);
  return { sm: H.summary(), longPlans: rp.slice(0, 12) }; };
