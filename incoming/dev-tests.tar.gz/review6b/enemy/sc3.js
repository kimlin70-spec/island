exports.insidePen1twoTrace = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 }, traceRepath: true, trace: { from: 340, to: 900 } });
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) H.fence(37 + dc, 39 + dr);
  const a = H.add('zombie', 37, 39), b = H.add('pirate_1', 37, 39), c = H.add('zombie', 33, 39);
  H.step(60 * 15);
  const tr = H.tr.filter((x, i, arr) => i === 0 || x.e !== arr[i - 1].e).map((x) => x.f + ' P' + x.P + ' :: ' + x.e);
  const rp = H.events('repath').filter((x) => x.f >= 340 && x.id === a).map((x) => `${x.f} #${x.id} at ${x.at}${x.mid ? '~' : ''} [${x.before}] -> [${x.after}]`);
  return { sm: H.summary(), tr: tr.slice(0, 60), rp }; };
