// Scenario set 2: pens, tent in a corner, player walking onto enemies
exports.pen1 = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) H.fence(37 + dc, 39 + dr);
  H.add('zombie', 31, 39); H.add('zombie', 43, 39); H.add('pirate_1', 37, 33); H.add('pirate_2', 37, 45); H.add('zombie', 32, 35);
  H.step(60 * 30); return { sm: H.summary() }; };
exports.pen3 = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) if (Math.abs(dc) === 2 || Math.abs(dr) === 2) H.fence(37 + dc, 39 + dr);
  H.add('zombie', 31, 39); H.add('zombie', 43, 39); H.add('pirate_1', 37, 33); H.add('pirate_2', 37, 45); H.add('zombie', 32, 35);
  H.step(60 * 30); return { sm: H.summary() }; };
exports.insidePen1 = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });   // zombie on the player's tile inside a 1x1 pen
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) H.fence(37 + dc, 39 + dr);
  H.add('zombie', 37, 39);
  H.step(60 * 15); return { sm: H.summary(), smash: H.events('smash').map((x) => x.f + ':' + x.x + ':' + x.hp + (x.onT ? ':onT' : '')).join(' ') }; };
exports.insidePen1two = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });   // zombie + pirate on the player's tile inside a 1x1 pen, 1 zombie outside
  for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dc || dr) H.fence(37 + dc, 39 + dr);
  H.add('zombie', 37, 39); H.add('pirate_1', 37, 39); H.add('zombie', 33, 39);
  H.step(60 * 15); return { sm: H.summary(), smash: H.events('smash').map((x) => x.f + ':' + x.id + ':' + x.x + ':' + x.hp + (x.onT ? ':onT' : '')).join(' ') }; };
// tent in a corner: only the west side is open (fake rocks elsewhere). Player rests. 6 zombies + 2 pirates.
exports.tentCorner = () => { const H = window.__H; H.reset({ player: { col: 39, row: 40 } });
  for (let r = 38; r <= 43; r++) for (let c = 40; c <= 43; c++) if (!(c >= 40 && c <= 41 && r >= 40 && r <= 41)) H.block(c, r);
  H.tent(40, 40); H.rest();
  const ids = [H.add('zombie', 32, 40), H.add('zombie', 33, 38), H.add('zombie', 33, 42), H.add('zombie', 31, 41), H.add('zombie', 30, 39), H.add('zombie', 30, 43), H.add('pirate_1', 34, 46), H.add('pirate_2', 34, 34)];
  H.step(60 * 12); const a = H.summary();
  H.step(60 * 30); const b = H.summary();
  return { sm: b, mid: a.enemies.map((e) => e.id + '@' + e.tile + (e.smashing ? 'S' : '') + (e.atC ? '' : '~')).join(' '), resting: b.resting }; };
// tent with a pocket behind it (a tile next to the tent reachable only through the tent)
exports.tentPocket = () => { const H = window.__H; H.reset({ player: { col: 39, row: 40 } });
  for (let r = 38; r <= 43; r++) for (let c = 40; c <= 44; c++) if (!(c >= 40 && c <= 41 && r >= 40 && r <= 41) && !(c === 42 && r === 40)) H.block(c, r);
  H.tent(40, 40); H.rest();
  [[32, 40], [33, 38], [33, 42], [31, 41], [30, 39], [30, 43]].forEach(([c, r]) => H.add('zombie', c, r)); H.add('pirate_1', 34, 46);
  H.step(60 * 20); return { sm: H.summary() }; };
// player walks onto a standing zombie's tile, then back, several times
exports.walkOnto = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  const z = H.add('zombie', 33, 39), pz = H.add('pirate_1', 41, 39);
  H.step(60 * 8);
  const log = [];
  for (let k = 0; k < 6; k++) {
    const e = H.byId(k % 2 ? pz : z);
    const t = { ...e.tile };
    H.walk(t.col, t.row);
    H.step(60 * 3);
    log.push(H.summary().enemies.map((x) => x.id + '@' + x.tile + ' onPTmax ' + x.onPTmax + ' fromPT ' + x.hitsFromPT).join(' | '));
  }
  return { sm: H.summary(), log }; };
