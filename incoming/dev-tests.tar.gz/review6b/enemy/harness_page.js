// Page-side scenario harness for the enemy-logic review. window.__H.
// The game loop is put to sleep; frames are stepped by hand with g.headlessStep (same update code as the game).
(() => {
  const g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player, b = s.build, E = s.enemies, P = s.pirates;
  const K = (t) => t.col + ',' + t.row;
  const cheb = (a, z) => Math.max(Math.abs(a.col - z.col), Math.abs(a.row - z.row));
  const H = { frame: 0, t: performance.now(), D: 1000 / 60 };
  window.__H = H;
  if (!g.loop.sleeping) g.loop.sleep();

  // ── instrumentation (installed once) ──
  const Enemy = Object.getPrototypeOf(E.list[0] || {}).constructor;
  H.ready = (async () => {
    const mod = await import('/src/systems/Enemy.js');
    const W = await import('/src/systems/Walker.js');
    H.Enemy = mod.Enemy; H.Walker = W.Walker;
    const EP = mod.Enemy.prototype;
    const origRepath = EP.repath;
    EP.repath = function (target, key) {
      const before = this.path.map(K).join(' ');
      const t0 = performance.now();
      H.cur.inRepath = this;
      const r = (H.repathImpl || origRepath).call(this, target, key);
      H.cur.inRepath = null;
      const dt = performance.now() - t0;
      const after = this.path.map(K).join(' ');
      H.cur.repaths++;
      H.cur.repathMs += dt;
      const st = H.st(this);
      st.repaths++;
      if (before !== after) st.repathChanged++;
      if (H.traceRepath) H.ev.push({ f: H.frame, k: 'repath', id: this.__id, at: K(this.tile), mid: this.col !== this.tile.col || this.row !== this.tile.row, before, after, tgt: target.tiles.map(K).join(' '), want: this.wantPath, ms: +dt.toFixed(3) });
      return r;
    };
    const origFR = W.Walker.prototype.findRoute;
    W.Walker.prototype.findRoute = function (goals, from) {
      const t0 = performance.now();
      const r = origFR.call(this, goals, from);
      const dt = performance.now() - t0;
      if (this !== p) { H.cur.astar++; H.cur.astarMs += dt; if (!r) H.cur.astarFail++; if (dt > H.cur.astarMaxMs) H.cur.astarMaxMs = dt; }
      return r;
    };
    const origHitPlayer = E.hitPlayer.bind(E);
    E.hitPlayer = function (e) {
      const here = p.here();
      const st = H.st(e);
      st.hits++;
      const onT = e.tile.col === here.col && e.tile.row === here.row;
      if (onT) st.hitsFromPlayerTile++;
      if (st.firstHitF === null) st.firstHitF = H.frame;
      st.lastHitF = H.frame;
      H.ev.push({ f: H.frame, k: 'hit', id: e.__id, at: K(e.tile), p: K(here), onT });
      H.hurt++;
      return; // hearts unchanged (no game over during scenarios)
    };
    const origHS = E.hitStructure.bind(E);
    E.hitStructure = function (e, x) {
      const st = H.st(e); st.smashes++;
      H.ev.push({ f: H.frame, k: 'smash', id: e.__id, at: K(e.tile), x: x.type + '@' + K(x), hp: x.hp - e.cfg.structureDamage, onT: e.onTarget(E.target()) });
      return origHS(e, x);
    };
  })();

  H.st = (e) => {
    if (e.__id === undefined) e.__id = ++H.nextId;
    if (!H.stats[e.__id]) H.stats[e.__id] = { id: e.__id, kind: e.kind, repaths: 0, repathChanged: 0, hits: 0, hitsFromPlayerTile: 0, smashes: 0, firstHitF: null, lastHitF: null,
      onPT: 0, onPTmax: 0, onPTcur: 0, stacked: 0, arrivals: [], adjF: null, adjNoAttack: 0, adjNoAttackMax: 0, adjNoAttackCur: 0, lastTile: K(e.tile) };
    return H.stats[e.__id];
  };

  // ── world set-up ──
  H.fakes = [];
  H.reset = (o = {}) => {
    g.scene.processQueue();
    if (s.sys.settings.status !== 5) { s.scene.resume(); g.scene.processQueue(); }
    if (s.rest.resting) s.rest.exit();
    for (const e of [...E.list]) E.remove(e);
    for (const x of [...m.structures]) b.destroy(x);
    for (const f of H.fakes) { if (f.kind === 'obj') m.objectGrid[f.i] = f.prev; else m.map.terrain[f.r][f.c] = f.prev; }
    H.fakes = [];
    E.schedule = [];
    E.spawn = () => null;
    s.clock.isNight = false; s.clock.t = 10; s.clock.day = 1; s.clock.dawn = 0;
    P.shipDue = false; P.landDue = false;
    if (s.debugSpeed !== 1) s.debugToggleSpeed();
    s.resultPending = false;
    p.stopAction(); p.path = []; p.cooldown = 0; p.chaseLeft = 0;
    const st = o.player || s.mapData.playerStart;
    p.col = st.col; p.row = st.row; p.tile = { col: st.col, row: st.row }; p.syncSprite();
    s.pressEnemy = o.fight ? H.origPressEnemy : () => {};
    H.stats = {}; H.nextId = H.nextId || 0; H.ev = []; H.frames = []; H.hurt = 0; H.frame = 0;
    H.cur = { repaths: 0, repathMs: 0, astar: 0, astarMs: 0, astarFail: 0, astarMaxMs: 0 };
    H.perFrame = { maxRepaths: 0, maxAstar: 0, maxAstarMs: 0, maxRepathMs: 0, totRepaths: 0, totAstar: 0, totAstarMs: 0, totAstarFail: 0, maxSingleAstarMs: 0 };
    H.traceRepath = !!o.traceRepath;
    H.trace = o.trace || null; H.tr = [];
    return true;
  };
  H.origPressEnemy = s.pressEnemy.bind(s);
  H.fence = (c, r) => b.place('fence', [{ col: c, row: r }]);
  H.fire = (c, r) => b.place('campfire', [{ col: c, row: r }]);
  H.tent = (c, r) => b.place('tent', [{ col: c, row: r }, { col: c + 1, row: r }, { col: c, row: r + 1 }, { col: c + 1, row: r + 1 }]);
  H.block = (c, r) => { const i = r * m.cols + c; H.fakes.push({ kind: 'obj', i, prev: m.objectGrid[i] }); m.objectGrid[i] = { kind: 'rock', blocks: true, fake: true }; s.onMapChanged(); };
  H.water = (c, r) => { H.fakes.push({ kind: 'ter', c, r, prev: m.map.terrain[r][c] }); m.map.terrain[r][c] = 0; s.onMapChanged(); };
  H.add = (kind, c, r) => { const e = E.add(kind, { col: c, row: r }); H.st(e); return e.__id; };
  H.byId = (id) => E.list.find((e) => e.__id === id);
  H.walk = (c, r) => p.goTo(c, r);
  H.rest = () => { const t = m.structures.find((x) => x.type === 'tent'); if (t) s.rest.enter(t); return s.rest.resting; };
  H.unrest = () => s.rest.exit();
  H.kill = (id) => { const e = H.byId(id); if (e) E.kill(e); };
  H.destroyAt = (c, r) => { const x = m.structureAt(c, r); if (x) b.destroy(x); };

  // ── stepping with per-frame checks ──
  H.step = (n, D = H.D) => {
    for (let i = 0; i < n; i++) {
      H.cur = { repaths: 0, repathMs: 0, astar: 0, astarMs: 0, astarFail: 0, astarMaxMs: 0 };
      H.t += D;
      g.headlessStep(H.t, D);
      H.frame++;
      const dt = Math.min(D / 1000, 0.1) * s.speed;
      const pf = H.perFrame, c = H.cur;
      pf.maxRepaths = Math.max(pf.maxRepaths, c.repaths); pf.maxAstar = Math.max(pf.maxAstar, c.astar);
      pf.maxAstarMs = Math.max(pf.maxAstarMs, c.astarMs); pf.maxRepathMs = Math.max(pf.maxRepathMs, c.repathMs);
      pf.maxSingleAstarMs = Math.max(pf.maxSingleAstarMs, c.astarMaxMs);
      pf.totRepaths += c.repaths; pf.totAstar += c.astar; pf.totAstarMs += c.astarMs; pf.totAstarFail += c.astarFail;
      const tgt = E.target(), here = p.here();
      const centreTiles = new Map();
      for (const e of E.list) if (e.col === e.tile.col && e.row === e.tile.row) { const k = K(e.tile); centreTiles.set(k, (centreTiles.get(k) || 0) + 1); }
      for (const e of E.list) {
        const st = H.st(e);
        const atC = e.col === e.tile.col && e.row === e.tile.row;
        const k = K(e.tile);
        if (atC && k !== st.lastTile) { st.arrivals.push([H.frame, k]); st.lastTile = k; }
        const onPT = !s.rest.resting && atC && e.tile.col === here.col && e.tile.row === here.row;
        if (onPT) { st.onPT += dt; st.onPTcur += dt; st.onPTmax = Math.max(st.onPTmax, st.onPTcur); } else st.onPTcur = 0;
        if (atC && centreTiles.get(k) > 1) st.stacked += dt;
        // standing next to the target (not on it), not attacking/smashing the target for a long time
        const adj = atC && e.nextTo(tgt) && !e.onTarget(tgt);
        if (adj && st.adjF === null) st.adjF = H.frame;
        const busy = tgt.structure ? e.smashing === tgt.structure : e.hitLeft !== null;
        if (adj && !busy && !e.attackLeft) { st.adjNoAttackCur += dt; st.adjNoAttackMax = Math.max(st.adjNoAttackMax, st.adjNoAttackCur); } else st.adjNoAttackCur = 0;
      }
      if (H.trace && H.frame >= (H.trace.from || 0) && H.frame <= (H.trace.to || 1e9)) {
        H.tr.push({ f: H.frame, P: K(here) + (p.moving ? '*' : ''), e: E.list.filter((e) => !H.trace.ids || H.trace.ids.includes(e.__id)).map((e) => `${e.__id}${e.kind[0]}@${+e.col.toFixed(2)},${+e.row.toFixed(2)} t${K(e.tile)} p[${e.path.slice(0, 4).map(K).join(' ')}${e.path.length > 4 ? '…' + e.path.length : ''}]${e.smashing ? ' S:' + e.smashing.type + K(e.smashing) : ''}${e.hitLeft !== null ? ' h' + e.hitLeft.toFixed(2) : ''} w${e.wantPath ? 1 : 0} r${e.repathLeft.toFixed(2)}`).join(' | ') });
      }
    }
    return H.frame;
  };
  H.summary = () => {
    const out = { frame: H.frame, player: K(p.here()), resting: s.rest.resting, perFrame: H.perFrame, enemies: [] };
    for (const e of E.list) {
      const st = H.st(e);
      out.enemies.push({ id: e.__id, kind: e.kind, tile: K(e.tile), atC: e.col === e.tile.col && e.row === e.tile.row, path: e.path.map(K).join(' '), smashing: e.smashing ? e.smashing.type + '@' + K(e.smashing) : null,
        hitLeft: e.hitLeft === null ? null : +e.hitLeft.toFixed(2), inPlace: e.inPlace(E.target()), nextTo: e.nextTo(E.target()), onT: e.onTarget(E.target()),
        repaths: st.repaths, repathChanged: st.repathChanged, hits: st.hits, hitsFromPT: st.hitsFromPlayerTile, smashes: st.smashes,
        onPT: +st.onPT.toFixed(2), onPTmax: +st.onPTmax.toFixed(2), stacked: +st.stacked.toFixed(2), arrivals: st.arrivals.length, lastArr: st.arrivals.slice(-6).map((a) => a[0] + ':' + a[1]).join(' '),
        firstHitF: st.firstHitF, lastHitF: st.lastHitF, adjF: st.adjF, adjNoAttackMax: +st.adjNoAttackMax.toFixed(2) });
    }
    for (const id of Object.keys(H.stats)) if (!E.list.some((e) => String(e.__id) === id)) out.enemies.push({ id: +id, gone: true, hits: H.stats[id].hits, hitsFromPT: H.stats[id].hitsFromPlayerTile });
    out.structures = m.structures.map((x) => x.type[0] + K(x) + ':' + x.hp).join(' ');
    return out;
  };
  H.events = (k) => H.ev.filter((x) => !k || x.k === k);
})();
