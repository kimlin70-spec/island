// Scenario set 4: natural forest gap on the real map, fence-ring doorway, crowd latency, performance
// forest gap at (26,19): its only open neighbours are (27,19) (north-east side) and (26,20) (south side)
exports.forestGap = () => { const H = window.__H; H.reset({ player: { col: 26, row: 19 } });
  H.add('zombie', 30, 15); H.add('zombie', 31, 16); H.add('zombie', 32, 15);
  H.step(60 * 25); return { sm: H.summary() }; };
exports.forestGap6 = () => { const H = window.__H; H.reset({ player: { col: 26, row: 19 } });
  for (const [c, r] of [[30, 15], [31, 16], [32, 15], [33, 16], [30, 13], [34, 14]]) H.add('zombie', c, r);
  H.step(60 * 25); return { sm: H.summary() }; };
// camp: a 7x7 fence ring around (37,39) with a one-tile gap at (34,39) on the west side; the player stands in the gap
exports.campGate = () => { const H = window.__H; H.reset({ player: { col: 34, row: 39 } });
  for (let r = 36; r <= 42; r++) for (let c = 34; c <= 40; c++) if ((r === 36 || r === 42 || c === 34 || c === 40) && !(c === 34 && r === 39)) H.fence(c, r);
  for (const [c, r] of [[27, 39], [27, 37], [27, 41], [26, 38], [26, 40]]) H.add('zombie', c, r);
  H.add('pirate_1', 25, 39);
  H.step(60 * 30); return { sm: H.summary() }; };
