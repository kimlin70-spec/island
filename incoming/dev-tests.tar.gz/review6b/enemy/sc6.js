// Micro-benchmark: cost of one route search (flood that fails, and a normal long search), with and without the avoid set.
exports.bench = () => { const H = window.__H; H.reset({ player: { col: 33, row: 15 } });
  const id = H.add('zombie', 34, 15); const e = H.byId(id);
  const s = window.__game.scene.getScene('game');
  const target = s.enemies.target();
  const pocket = [{ col: 33, row: 14 }];                  // reachable only through the player's tile
  const far = [{ col: 37, row: 45 }];                     // far away, reachable
  const time = (fn, n) => { const ts = []; for (let i = 0; i < n; i++) { const t0 = performance.now(); fn(); ts.push(performance.now() - t0); } ts.sort((a, b) => a - b); return { med: +ts[n >> 1].toFixed(3), p90: +ts[Math.floor(n * 0.9)].toFixed(3), max: +ts[n - 1].toFixed(3) }; };
  const out = {};
  // batch timing for better resolution
  const batch = (fn, reps, rounds) => { const ts = []; for (let r = 0; r < rounds; r++) { const t0 = performance.now(); for (let i = 0; i < reps; i++) fn(); ts.push((performance.now() - t0) / reps); } ts.sort((a, b) => a - b); return { med: +ts[rounds >> 1].toFixed(3), min: +ts[0].toFixed(3), max: +ts[rounds - 1].toFixed(3) }; };
  e.avoid = new Set(['33,15']);
  out.floodNew = batch(() => { if (e.findRoute(pocket)) throw new Error('found'); }, 20, 15);
  out.farNew = batch(() => e.findRoute(far), 20, 15);
  e.avoid = null;
  // old: the pocket is reachable through the player's tile, so make an equally unreachable goal: a water tile is filtered out... use a fake unreachable pocket instead
  out.farOld = batch(() => e.findRoute(far), 20, 15);
  // old code flood for comparison: block the player's tile with a fake rock so the pocket is unreachable without the avoid set
  H.block(33, 15);
  out.floodOldCostAt = batch(() => { if (e.findRoute(pocket)) throw new Error('found'); }, 20, 15);
  return out; };
