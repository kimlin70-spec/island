// Crowd latency: fence doorway, 12 zombies + 2 pirates. After 20 s the player walks 3 tiles west.
// Measure for each enemy: frames from the player's tile change until its next repath, and until its next hit.
exports.crowdDoorway = () => { const H = window.__H; H.reset({ player: { col: 39, row: 39 }, traceRepath: true });
  for (let r = 33; r <= 45; r++) if (r !== 39) H.fence(39, r);
  const spots = [[33, 39], [33, 38], [33, 40], [32, 39], [32, 41], [32, 37], [31, 39], [31, 38], [31, 40], [30, 39], [30, 41], [30, 37]];
  for (const [c, r] of spots) H.add('zombie', c, r);
  H.add('pirate_1', 29, 39); H.add('pirate_2', 29, 40);
  H.step(60 * 20);
  const s0 = H.summary();
  const f0 = H.frame;
  H.walk(36, 39);
  // wait until the player's tile changes, then measure
  let fChange = null;
  for (let i = 0; i < 120 && fChange === null; i++) { H.step(1); const g = window.__game.scene.getScene('game'); if (g.player.here().col !== 39) fChange = H.frame; }
  H.step(60 * 15);
  const rp = H.events('repath'), hits = H.events('hit');
  const per = {};
  for (const e of s0.enemies) {
    const r1 = rp.find((x) => x.id === e.id && x.f >= fChange);
    const h1 = hits.find((x) => x.id === e.id && x.f >= fChange);
    per[e.id] = { kind: e.kind, at: e.tile, repathAfter: r1 ? r1.f - fChange : null, firstHitAfter: h1 ? h1.f - fChange : null };
  }
  return { sm: H.summary(), before: s0.enemies.map((e) => e.id + '@' + e.tile + (e.inPlace ? '' : '*')).join(' '), fChange, per, perFrame: H.perFrame }; };
// Performance: natural dead-end in the forest. Player at (33,15) whose neighbour (33,14) is reachable only through the player's tile.
exports.deadEndPerf = () => { const H = window.__H; H.reset({ player: { col: 33, row: 15 } });
  for (const [c, r] of [[36, 17], [37, 18], [38, 17], [36, 19], [37, 20], [38, 19], [35, 21], [39, 18], [40, 17], [39, 20]]) H.add('zombie', c, r);
  H.step(60 * 30); return { sm: H.summary() }; };
