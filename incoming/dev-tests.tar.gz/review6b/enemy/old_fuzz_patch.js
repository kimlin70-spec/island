// Switch Enemy to the old (be6fcd0) behaviour at runtime, for statistical comparison in the fuzz (repo untouched).
window.__oldReady = import('/src/systems/Enemy.js').then((mod) => {
  const EP = mod.Enemy.prototype;
  EP.costAt = function (col, row) {
    if (!this.map.isOpen(col, row)) return 0;
    return this.map.structureAt(col, row) ? this.cfg.breakCost : 1;
  };
  EP.goalsAround = function (tiles) {
    const all = [], seen = new Set(tiles.map((t) => t.col + ',' + t.row));
    for (const t of tiles) {
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        const c = t.col + dc, r = t.row + dr, k = c + ',' + r;
        if (seen.has(k) || !this.costAt(c, r)) continue;
        seen.add(k);
        all.push({ col: c, row: r });
      }
    }
    const taken = this.system.takenTiles(this);
    return { all, free: all.filter((t) => !taken.has(t.col + ',' + t.row)) };
  };
  EP.repath = function (target, key) {
    this.wantPath = false;
    this.repathLeft = this.cfg.repathInterval;
    this.goalKey = key;
    this.goalKind = target.structure ? 'tent' : 'player';
    if (!this.moving && this.inPlace(target)) return;
    const g = this.goalsAround(target.tiles);
    if (this.routeOn(g.free)) return;
    if (g.free.length < g.all.length && this.routeOn(g.all)) return;
    this.wantPath = true;
  };
  EP.update = function (dt) {
    this.repathLeft -= dt;
    this.attackLeft = Math.max(0, this.attackLeft - dt);
    this.shakeLeft = Math.max(0, this.shakeLeft - dt);
    const target = this.system.target();
    const key = target.tiles.map((t) => t.col + ',' + t.row).join(' ');
    const kind = target.structure ? 'tent' : 'player';
    if (key !== this.goalKey && !(this.smashing && kind === this.goalKind)) this.wantPath = true;
    if (!this.moving && !this.inPlace(target)) this.wantPath = true;
    if (this.wantPath && this.repathLeft <= 0 && this.system.mayRepath()) this.repath(target, key);
    const swinging = this.attackLeft > 0;
    if (!swinging) this.walk(dt, this.speedNow());
    const atCentre = this.col === this.tile.col && this.row === this.tile.row;
    const next = this.path[0];
    const blocker = atCentre && next && (next.col !== this.tile.col || next.row !== this.tile.row)
      ? this.map.structureAt(next.col, next.row) : null;
    const standing = atCentre && (!this.moving || blocker || swinging);
    if (standing && this.nextTo(target)) {
      if (target.structure) this.smash(target.structure, dt);
      else this.attackPlayer(dt);
    } else if (blocker) {
      this.smash(blocker, dt);
    } else {
      this.hitLeft = null;
      this.smashing = null;
    }
    this.syncSprite(standing);
  };
  return 'old';
});
