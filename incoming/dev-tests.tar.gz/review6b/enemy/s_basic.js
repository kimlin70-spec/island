// Scenario batch 1: open field sanity, previous repro (fence + 7 zombies + pirate), corridor, doorway.
const { start, J } = require('./lib.js');
const only = process.argv[2] ? process.argv[2].split(',') : null;
const SC = {};

// S1: one zombie from far, open ground. Must arrive next to the player, never stand on its tile, attack every 2 s.
SC.s1 = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  const a = H.add('zombie', 30, 39), b = H.add('pirate_1', 44, 39);
  H.step(60 * 20); return H.summary(); };

// S2: previous review repro. Fence east of the player, 7 zombies on the other neighbours, pirate from the west.
SC.s2 = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 }, traceRepath: true });
  H.fence(38, 39);
  for (const [c, r] of [[36, 38], [37, 38], [38, 38], [36, 39], [36, 40], [37, 40], [38, 40]]) H.add('zombie', c, r);
  const pir = H.add('pirate_1', 33, 39);
  H.step(60 * 6); const mid = H.summary();
  H.step(60 * 14); const end = H.summary();
  return { mid: mid.enemies.filter((e) => e.kind !== 'zombie'), end, rp: H.events('repath').filter((x) => x.id === pir).slice(0, 12), smash: H.events('smash').slice(0, 10) }; };

// S2b: same, but zombie at 38,38 is killed after 4 s: the pirate (held next to the player, stacked) should move there.
SC.s2b = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 }, traceRepath: true });
  H.fence(38, 39);
  const zs = [[36, 38], [37, 38], [38, 38], [36, 39], [36, 40], [37, 40], [38, 40]].map(([c, r]) => H.add('zombie', c, r));
  const pir = H.add('pirate_1', 33, 39);
  H.step(60 * 4); const before = H.summary().enemies.find((e) => e.id === pir);
  H.kill(zs[2]);
  H.step(60 * 4); const after = H.summary().enemies.find((e) => e.id === pir);
  return { before, after }; };

SC.s3 = () => { // natural corridor (fake rocks) along row 39, cols 30..44; player at 37,39 in the middle; 3 zombies + 1 pirate from the west
  const H = window.__H; H.reset({ player: { col: 37, row: 39 }, traceRepath: true });
  for (let c = 30; c <= 44; c++) { H.block(c, 38); H.block(c, 40); }
  H.block(45, 39);   // dead end east of the player (the east side is reachable only through the player's tile)
  const ids = [H.add('zombie', 31, 39), H.add('zombie', 32, 39), H.add('zombie', 33, 39), H.add('pirate_2', 30, 39)];
  H.step(60 * 15); const sm = H.summary();
  return { sm, rp: H.events('repath').slice(-12), perFrame: H.perFrame }; };

SC.s3b = () => { // corridor, open at both ends (long way round exists), player in the middle, 4 enemies from the west
  const H = window.__H; H.reset({ player: { col: 37, row: 39 }, traceRepath: true });
  for (let c = 31; c <= 43; c++) { H.block(c, 38); H.block(c, 40); }
  const ids = [H.add('zombie', 28, 39), H.add('zombie', 27, 39), H.add('pirate_1', 26, 39), H.add('zombie', 26, 40)];
  H.step(60 * 40); const sm = H.summary();
  return { sm, rp: H.events('repath').slice(-10) }; };

SC.s4 = () => { // doorway: fence line along col 39 from row 33 to 45 with the gap at row 39; player in the gap; 4 zombies from the west
  const H = window.__H; H.reset({ player: { col: 39, row: 39 }, traceRepath: true });
  for (let r = 33; r <= 45; r++) if (r !== 39) H.fence(39, r);
  const ids = [H.add('zombie', 33, 39), H.add('zombie', 33, 38), H.add('zombie', 33, 40), H.add('pirate_1', 32, 39), H.add('zombie', 32, 41)];
  H.step(60 * 25); const sm = H.summary();
  return { sm, rp: H.events('repath').slice(-10), smash: H.events('smash').length }; };

(async () => {
  const T = await start();
  for (const [name, fn] of Object.entries(SC)) {
    if (only && !only.includes(name)) continue;
    const t0 = Date.now();
    const r = await T.G(fn);
    console.log('=== ' + name + ' (' + ((Date.now() - t0) / 1000).toFixed(1) + 's)');
    console.log(JSON.stringify(r, null, 1));
  }
  console.log('page errors:', J(T.errors.slice(0, 5)));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
