const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const fs = require('fs');
(async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  const out = await T.G(() => {
    const s = window.__game.scene.getScene('game'), m = s.map;
    const lines = [];
    let hdr = '    '; for (let c = 0; c < m.cols; c++) hdr += (c % 10); lines.push(hdr);
    for (let r = 0; r < m.rows; r++) {
      let L = String(r).padStart(3) + ' ';
      for (let c = 0; c < m.cols; c++) {
        if (!m.isLand(c, r)) { L += '~'; continue; }
        const o = m.objectAt(c, r);
        if (o && o.blocks) { L += o.kind === 'rock' ? 'R' : o.kind === 'iron' ? 'I' : o.kind === 'bush' ? 'B' : 'T'; continue; }
        if (o) { L += o.kind === 'stump' ? 's' : o.kind === 'rubble' ? 'r' : 'd'; continue; }
        L += '.';
      }
      lines.push(L);
    }
    return { lines, start: s.mapData.playerStart, spawns: s.mapData.zombieSpawns, landing: s.mapData.pirates.landing };
  });
  fs.writeFileSync(__dirname + '/map.txt', out.lines.join('\n') + '\n' + JSON.stringify({ start: out.start, spawns: out.spawns, landing: out.landing }) + '\n');
  console.log('errors', JSON.stringify(T.errors));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
