// Node side: open one page (pirates ON), inject the harness, run scenario functions in the page.
const fs = require('fs');
const { open } = require('/tmp/claude-0/-home-user-island/9b8c3acf-fed1-566e-aa66-4621d1b42a39/scratchpad/p4/lib.js');
const HSRC = fs.readFileSync(__dirname + '/harness_page.js', 'utf8');
const OSRC = fs.readFileSync(__dirname + '/old_patch.js', 'utf8');
exports.start = async () => {
  const T = await open({ w: 960, h: 600, pirates: true });
  await T.page.addScriptTag({ content: HSRC });
  await T.G(() => window.__H.ready);
  await T.page.addScriptTag({ content: OSRC });
  await T.G(() => window.__H.ready.then(() => new Promise((r) => setTimeout(r, 50))));
  await T.G(() => { if (!window.__H.useOld) throw new Error('old patch missing'); });
  return T;
};
exports.J = (x) => JSON.stringify(x);
