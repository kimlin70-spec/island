// node run.js <scenario-file> <names|all> <modes: new,old>
const { start, J } = require('./lib.js');
const file = process.argv[2], names = process.argv[3] && process.argv[3] !== 'all' ? process.argv[3].split(',') : null;
const modes = (process.argv[4] || 'new,old').split(',');
const SC = require('./' + file);
const fmt = (sm) => {
  const L = [];
  L.push(`  player ${sm.player}${sm.resting ? ' (resting)' : ''}  frame ${sm.frame}  structures: ${sm.structures}`);
  const pf = sm.perFrame;
  L.push(`  perFrame: maxRepaths ${pf.maxRepaths} maxAstar ${pf.maxAstar} maxAstarMs ${pf.maxAstarMs.toFixed(1)} maxSingleAstarMs ${pf.maxSingleAstarMs.toFixed(1)} totRepaths ${pf.totRepaths} totAstar ${pf.totAstar} totAstarFail ${pf.totAstarFail} totAstarMs ${pf.totAstarMs.toFixed(1)}`);
  for (const e of sm.enemies) {
    if (e.gone) { L.push(`  #${e.id} gone hits ${e.hits} fromPT ${e.hitsFromPT}`); continue; }
    L.push(`  #${e.id} ${e.kind.padEnd(8)} t${e.tile.padEnd(6)} ${e.atC ? 'C' : '~'} path[${e.path}] ${e.smashing ? 'S:' + e.smashing : ''} inPlace ${e.inPlace ? 1 : 0} hits ${e.hits} fromPT ${e.hitsFromPT} smashes ${e.smashes} onPT ${e.onPT}/${e.onPTmax} stacked ${e.stacked} repaths ${e.repaths}(${e.repathChanged}) arr ${e.arrivals} [${e.lastArr}] adjNoAtk ${e.adjNoAttackMax} firstHit ${e.firstHitF}`);
  }
  return L.join('\n');
};
(async () => {
  const T = await start();
  for (const [name, fn] of Object.entries(SC)) {
    if (names && !names.includes(name)) continue;
    for (const mode of modes) {
      await T.G((m) => (m === 'old' ? window.__H.useOld() : window.__H.useNew()), mode);
      const t0 = Date.now();
      let r;
      try { r = await T.G(fn); } catch (e) { console.log('=== ' + name + ' [' + mode + '] ERROR ' + e.message); continue; }
      console.log('=== ' + name + ' [' + mode + '] (' + ((Date.now() - t0) / 1000).toFixed(1) + 's)');
      if (r && r.sm) { console.log(fmt(r.sm)); const { sm, ...rest } = r; if (Object.keys(rest).length) console.log('  extra ' + J(rest)); }
      else if (r && r.enemies) console.log(fmt(r));
      else console.log('  ' + J(r));
    }
  }
  console.log('page errors:', J(T.errors.slice(0, 5)));
  await T.browser.close();
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
