// Scenario set 1 (each runs entirely in the page; returns { sm, ... })
exports.open = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  H.add('zombie', 30, 39); H.add('pirate_1', 44, 39); H.add('zombie', 37, 33); H.add('zombie', 37, 45);
  H.step(60 * 20); return { sm: H.summary() }; };
exports.repro = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  H.fence(38, 39);
  for (const [c, r] of [[36, 38], [37, 38], [38, 38], [36, 39], [36, 40], [37, 40], [38, 40]]) H.add('zombie', c, r);
  H.add('pirate_1', 33, 39);
  H.step(60 * 20); return { sm: H.summary() }; };
exports.corridorDeadEnd = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  for (let c = 30; c <= 44; c++) { H.block(c, 38); H.block(c, 40); }
  H.block(45, 39);
  H.add('zombie', 31, 39); H.add('zombie', 32, 39); H.add('zombie', 33, 39); H.add('pirate_2', 30, 39);
  H.step(60 * 15); return { sm: H.summary() }; };
exports.corridorLoop = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  for (let c = 31; c <= 43; c++) { H.block(c, 38); H.block(c, 40); }
  H.add('zombie', 28, 39); H.add('zombie', 27, 39); H.add('pirate_1', 26, 39); H.add('zombie', 26, 40);
  H.step(60 * 40); return { sm: H.summary() }; };
exports.doorway = () => { const H = window.__H; H.reset({ player: { col: 39, row: 39 } });
  for (let r = 33; r <= 45; r++) if (r !== 39) H.fence(39, r);
  H.add('zombie', 33, 39); H.add('zombie', 33, 38); H.add('zombie', 33, 40); H.add('pirate_1', 32, 39); H.add('zombie', 32, 41);
  H.step(60 * 25); return { sm: H.summary() }; };
exports.doorway3 = () => { const H = window.__H; H.reset({ player: { col: 39, row: 39 } });
  for (let r = 33; r <= 45; r++) if (r !== 39) H.fence(39, r);
  H.add('zombie', 33, 39); H.add('zombie', 33, 38); H.add('zombie', 33, 40); H.add('zombie', 32, 40);
  H.step(60 * 25); return { sm: H.summary() }; };
