// Extra checks for the enemy-logic review, installed on top of pfuzz_page.js (window.__pf).
(() => {
  const pf = window.__pf, g = window.__game, s = g.scene.getScene('game'), m = s.map, p = s.player, E = s.enemies;
  const K = (t) => t.col + ',' + t.row;
  const cheb = (a, z) => Math.max(Math.abs(a.col - z.col), Math.abs(a.row - z.row));
  const X = new Map();   // enemy -> extra state
  pf.astar = { n: 0, fail: 0, ms: 0, maxFrameMs: 0, maxOneMs: 0, frameMs: 0, frameN: 0, maxFrameN: 0, slowFrames: 0 };
  // A* timing (Walker.findRoute), enemies only
  import('/src/systems/Walker.js').then((W) => {
    const orig = W.Walker.prototype.findRoute;
    W.Walker.prototype.findRoute = function (goals, from) {
      const t0 = performance.now();
      const r = orig.call(this, goals, from);
      const dt = performance.now() - t0;
      if (this !== p) { const A = pf.astar; A.n++; A.ms += dt; A.frameMs += dt; A.frameN++; if (!r) A.fail++; if (dt > A.maxOneMs) A.maxOneMs = dt; }
      return r;
    };
  });
  // a hit from the player's own tile (centre of the enemy on the player's tile) is never allowed
  const prevHit = E.hitPlayer.bind(E);
  E.hitPlayer = function (e) {
    const h = p.here();
    if (e.tile.col === h.col && e.tile.row === h.row) pf.fail('hit-from-player-tile', { z: pf.zs(e), p: pf.ps() });
    pf.stat('hit-checked');
    return prevHit(e);
  };
  const prevHS = E.hitStructure.bind(E);
  E.hitStructure = function (e, x) {
    const t = E.target();
    if (!t.structure && e.onTarget(t)) pf.stat('smash-from-player-tile');
    return prevHS(e, x);
  };
  let lastHere = null, hereSince = 0, structVersion = 0, lastStructN = -1, lastStructKey = '';
  pf.extraCheck = (dt) => {
    const A = pf.astar;
    if (A.frameMs > A.maxFrameMs) A.maxFrameMs = A.frameMs;
    if (A.frameN > A.maxFrameN) A.maxFrameN = A.frameN;
    if (A.frameMs > 8) A.slowFrames++;
    A.frameMs = 0; A.frameN = 0;
    const here = p.here(), hk = K(here);
    if (hk !== lastHere) { lastHere = hk; hereSince = 0; } else hereSince += dt;
    const sk = m.structures.length + ':' + m.structures.map((x) => K(x)).join(' ');
    if (sk !== lastStructKey) { lastStructKey = sk; structVersion++; }
    const tgt = E.target();
    for (const e of E.list) {
      let x = X.get(e);
      if (!x) { x = { stand: null, changes: [], near: 0, lastHitRun: 0, stackHeld: 0, reported: {} }; X.set(e, x); }
      const atC = e.col === e.tile.col && e.row === e.tile.row;
      // oscillation: standing-tile changes while the player's tile and the structures do not change
      if (atC && !e.moving) {
        const k = K(e.tile);
        if (x.stand !== null && x.stand !== k) x.changes.push({ t: pf.gt, k, here: hk, sv: structVersion });
        x.stand = k;
      }
      x.changes = x.changes.filter((c) => pf.gt - c.t < 6);
      const same = x.changes.filter((c) => c.here === hk && c.sv === structVersion);
      if (same.length >= 4 && !x.reported.osc) { x.reported.osc = true; pf.fail('osc-standing-tile', { z: pf.zs(e), changes: same.map((c) => c.k + '@' + c.t.toFixed(2)).join(' ') }); }
      // near the player (tile within 1, player not resting) for a long time without any hit
      if (x.nearHere !== hk || p.moving) { x.near = 0; x.lastHitRun = 0; x.reported.near = false; x.nearHere = hk; }
      if (!tgt.structure && cheb(e.tile, here) <= 1 && !s.rest.resting && !p.moving) {
        x.near += dt;
        if (e.__ap === pf.frame) x.lastHitRun = x.near;   // attackPlayer ran this frame
        const lim = e.cfg.firstHitDelay + e.cfg.hitInterval + 1.0;
        if (x.near - x.lastHitRun > lim && !x.reported.near) { x.reported.near = true; pf.fail('near-player-no-attack', { z: pf.zs(e), near: +x.near.toFixed(2), since: +(x.near - x.lastHitRun).toFixed(2), p: pf.ps(), hereSince: +hereSince.toFixed(2) }); }
      } else { x.near = 0; x.lastHitRun = 0; x.reported.near = false; }
      // stacked next to the player, held by a structure, for a long time (the player standing still)
      const others = E.list.filter((o) => o !== e && o.col === o.tile.col && o.row === o.tile.row && K(o.tile) === K(e.tile));
      const nx = e.path[0];
      const held = atC && nx && K(nx) !== K(e.tile) && !!m.structureAt(nx.col, nx.row);
      if (!tgt.structure && atC && others.length && held && e.nextTo(tgt) && !e.onTarget(tgt) && hereSince > 0) {
        x.stackHeld += dt;
        if (x.stackHeld > 4 && !x.reported.sh) { x.reported.sh = true; pf.stat('stacked-held-4s'); pf.fail('stacked-held-next-to-player', { z: pf.zs(e), path: e.path.map(K).join(' '), structAhead: m.structureAt(nx.col, nx.row).type, p: pf.ps() }); }
      } else { x.stackHeld = 0; x.reported.sh = false; }
    }
    for (const e of [...X.keys()]) if (!E.list.includes(e)) X.delete(e);
  };
})();
