exports.campGateInsideTrace = () => { const H = window.__H; H.reset({ player: { col: 35, row: 39 }, traceRepath: true });
  for (let r = 36; r <= 42; r++) for (let c = 34; c <= 40; c++) if ((r === 36 || r === 42 || c === 34 || c === 40) && !(c === 34 && r === 39)) H.fence(c, r);
  for (const [c, r] of [[27, 39], [27, 37], [27, 41], [26, 38], [26, 40]]) H.add('zombie', c, r);
  H.add('pirate_1', 25, 39);
  H.step(60 * 30);
  const rp = H.events('repath').filter((x) => x.before !== x.after).map((x) => `${x.f} #${x.id} at ${x.at}${x.mid ? '~' : ''} -> [${x.after}]`);
  const sm = H.events('smash').map((x) => `${x.f} #${x.id} at ${x.at} hits ${x.x} hp->${x.hp}`);
  const fencesLeft = window.__game.scene.getScene('game').build.count('fence');
  return { sm: H.summary(), rp, smash: sm, fencesLeft }; };
