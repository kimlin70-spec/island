// commit-to-smash while the player moves inside a 3x3 pen; step-off when the player walks into the tile a zombie is entering;
// camp gate with the player one tile inside the gate.
exports.commitSmash = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 } });
  for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) if (Math.abs(dc) === 2 || Math.abs(dr) === 2) H.fence(37 + dc, 39 + dr);
  const z = H.add('zombie', 31, 39);
  const moves = [[36, 39], [38, 40], [36, 38], [38, 38], [37, 40], [36, 40]];
  for (let k = 0; k < 9; k++) { H.step(120); const m = moves[k % moves.length]; H.walk(m[0], m[1]); }
  H.step(300);
  return { sm: H.summary(), smash: H.events('smash').map((x) => x.f + ':' + x.x + ':' + x.hp).join(' ') }; };
exports.stepIntoEnteringTile = () => { const H = window.__H; H.reset({ player: { col: 37, row: 39 }, trace: { from: 0, to: 0 } });
  const g = window.__game.scene.getScene('game');
  const id = H.add('zombie', 31, 39); const z = H.byId(id);
  // wait until the zombie is mid-step into (34,39), then walk the player to (34,39)
  let ok = false;
  for (let i = 0; i < 600 && !ok; i++) { H.step(1); if (z.tile.col === 33 && z.col > 33.3 && z.path[0] && z.path[0].col === 34) ok = true; }
  H.walk(34, 39);
  const log = [];
  for (let i = 0; i < 240; i++) { H.step(1); if (i % 10 === 0) log.push(`${H.frame} P${g.player.here().col},${g.player.here().row} z@${z.col.toFixed(2)},${z.row.toFixed(2)} t${z.tile.col},${z.tile.row} p[${z.path.map((t) => t.col + ',' + t.row).join(' ')}] h${z.hitLeft === null ? '-' : z.hitLeft.toFixed(2)}`); }
  return { sm: H.summary(), ok, log }; };
exports.campGateInside = () => { const H = window.__H; H.reset({ player: { col: 35, row: 39 } });
  for (let r = 36; r <= 42; r++) for (let c = 34; c <= 40; c++) if ((r === 36 || r === 42 || c === 34 || c === 40) && !(c === 34 && r === 39)) H.fence(c, r);
  for (const [c, r] of [[27, 39], [27, 37], [27, 41], [26, 38], [26, 40]]) H.add('zombie', c, r);
  H.add('pirate_1', 25, 39);
  H.step(60 * 30); return { sm: H.summary() }; };
